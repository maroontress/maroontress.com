/*
        TextArea2.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

int GetLengthAtLine(SylTextBlockSet *tbs, int y);
int IsEndOfLineAtLine(SylTextBlockSet *tbs, int y);
int IsBottomAtLine(SylTextBlockSet *tbs, int y);

int GetWidthAtLine(SylTextBlockSet *tbs, XFontSet fs, int x, int y);
int GetRowsAtLine(SylTextBlockSet *tbs, XFontSet fs, int w, int y);

void InsertCharIntoSylTextBlockSet(SylTextBlockSet *, XFontSet, int,
				   int, int, wchar_t, int *, int *);
void InsertLineFeedIntoSylTextBlockSet(SylTextBlockSet *, XFontSet, int,
				       int, int, int *, int *);
void DeleteLeftCharInSylTextBlockSet(SylTextBlockSet *, XFontSet, int,
				     int, int, int *, int *);
void DeletePrevCharInSylTextBlockSet(SylTextBlockSet *, XFontSet, int,
				     int, int, int *, int *);
void DeleteToLineEndSylTextBlockSet(SylTextBlockSet *, XFontSet, int,
				    int, int, int *, int *);
void DeleteNextCharInSylTextBlockSet(SylTextBlockSet *, XFontSet, int,
				     int, int, int *, int *);
