/*
        property.h 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

void SetProperties(Display *, Window, char *, char *, char *, int, char **,
		   int, int, int, int, int, int);
int IsWMCloseMessage(XEvent *ev);
