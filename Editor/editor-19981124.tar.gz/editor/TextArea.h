/*
        TextArea.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#define AREA_LINES_PER_BLOCK 4
#define AREA_EDIT_MODE 0

typedef struct SylTextBlock {
    struct SylTextBlock *next;
    struct SylTextBlock *prev;
    SylText *body[AREA_LINES_PER_BLOCK];
    int n_bodies;
} SylTextBlock;

typedef struct SylTextBlockSet {
    struct SylTextBlock *top;
    struct SylTextBlock *cur;
    struct SylTextBlock *last;
    int current_block;         /* nth block */
    int current_line;          /* nth block begin at this line */
    int n_lines;               /* total lines */
} SylTextBlockSet;

typedef struct SylLocation {
    int x;
    int y;
} SylLocation;

typedef struct SylTextArea {
    Display *disp;
    XIC ic;
    int mode;
    Window parent;
    Window window;
    int ascent;
    int descent;
    int font_width;
    int font_height;
    Pixmap pixmap;
    Pixmap mark_lf;
    Pixmap mark_eof;
    GC gc;
    SylFontSet fontset;
    XFontSet fs;
    int parent_width;
    int parent_height;
    int width;
    int height;
    int depth;
    unsigned long pixel[6];
    SylKeymap *keymap[256];

    SylTextBlockSet *tbs;
    wchar_t *buf;           /* $B%d%s%/$5$l$?%F%-%9%H(B */
    SylLocation current;
    SylLocation started;
    SylLocation pasting;
    int saved_width;
    
    SylVScrollbar *vsb;
    int baseline_skip;
    int visible_begin;
    int visible_cols;

    int pointed;
    int focus;
    int grabbed;
    int selected;
    int redraw;
    int format;
    int converting;
    Atom property;
    Atom text_atom;
    Atom compound_text_atom;
    Atom targets_atom;
} SylTextArea;

SylTextArea * CreateSylTextArea(Display *, XIC, Window, char *, int);
void FreeSylTextArea(SylTextArea *);
void SendSylTextArea(SylTextArea *, XEvent *);
int NiceSylTextArea(SylTextArea *);

int ReadSylTextArea(SylTextArea *, char *);
int WriteSylTextArea(SylTextArea *, char *);
void ResetSylTextArea(SylTextArea *);
