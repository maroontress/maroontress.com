static SylSetting
  ColorSet0 = {"foreground", "Foreground", "black", NULL},
  ColorSet1 = {"background", "Background", "white", NULL},
  ColorSet2 = {"mediumGray", "MediumGray", "gray70", NULL},
  ColorSet3 = {"dimGray", "DimGray", "gray50", NULL},
  ColorSet4 = {"illuminated", "Illuminated", "#ffe0e0", NULL},
  ColorSet5 = {"preedited", "Foreground", "green4", NULL},
  *ColorSet[] = {
    &ColorSet0,
    &ColorSet1,
    &ColorSet2,
    &ColorSet3,
    &ColorSet4,
    &ColorSet5,
    NULL};
enum { Foreground, Background, MediumGray, DimGray, Illuminated, Preedited,};
