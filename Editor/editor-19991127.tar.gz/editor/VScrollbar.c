/*
       VScrollbar.c 1.3 for X11R6 & GNU C Compiler

       Copyright (C) 1996, 1997, 1998, 1999 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <stdio.h>

#include "Resource.h"
#include "VScrollbar.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define THIS_CLASS "Scrollbar"

#if 0
static SylSetting
    Brightest  = {"brightest",  "Brightest",  "gray100", NULL},
    LightGray  = {"lightGray",  "LightGray",  "gray85",  NULL},
    MediumGray = {"mediumGray", "MediumGray", "gray70",  NULL},
    DimGray    = {"dimGray",    "DimGray",    "gray50",  NULL},
    DarkGray   = {"darkGray",   "DarkGray",   "gray30",  NULL},
    Darkest    = {"darkest",    "Darkest",    "gray10",  NULL},
    *ColorSet[] = {&Brightest, &LightGray, &MediumGray,
		   &DimGray, &DarkGray, &Darkest, NULL};
#endif

#include "VScrollbarColorSet.h"

static Window
ParentWindow(Display *disp, Window window)
{
    Window root, parent, *childp;
    unsigned int children;

    if (XQueryTree(disp, window, &root, &parent, &childp, &children))
	XFree(childp);
    return (parent);
}

static Cursor
CreateNullCursor(Display *disp)
{
    static unsigned char bit[] = {
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    XColor color = {0, 0, 0, 0, DoRed | DoGreen | DoBlue};
    Pixmap p;
    Cursor c;

    p = XCreateBitmapFromData(disp, DefaultRootWindow(disp), bit, 16, 16);
    c = XCreatePixmapCursor(disp, p, p, &color, &color, 0, 0);
    XFreePixmap(disp, p);
    return (c);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
		  SylVScrollbar *vsb)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
	return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
	FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
	FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
	return (1);
    
    LoadSylColorset(disp, fq_name, fq_class, ColorSet, vsb->pixel);
    return (0);
}
 
static int
HeightOfCatch(SylVScrollbar *vsb)
{
    return ((vsb->maxline > vsb->lines) ?
	max(vsb->height * vsb->lines / vsb->maxline, SYL_VSB_HMIN)
	: vsb->height);
}

static int
WidthOfCatch(SylVScrollbar *vsb)
{
    return ((vsb->grabbed == True && vsb->button == 1)
	? SYL_VSB_WIDTH - 1 : SYL_VSB_WIDTH);
}

SylVScrollbar *
ReserveSylVScrollbar(Display *disp, Window window, char *component,
		     int cur, int end, int parline,
		     void (*scroll)(void *, int, int),
		     void (*adjust)(void *, int), void *data)
{
    XWindowAttributes atr;
    SylVScrollbar *vsb;

    if ((vsb = (SylVScrollbar *)malloc(sizeof(SylVScrollbar))) == NULL)
	goto no_vscrollbar;
    if ((vsb->pixel = CreateSylColorset(ColorSet)) == NULL)
        goto no_colorset;
    if (GetAllPreferences(disp, window, component, THIS_CLASS, vsb))
	goto no_preferences;
    XGetWindowAttributes(disp, window, &atr);
    vsb->disp = disp;
    vsb->window = window;
    vsb->parent = ParentWindow(disp, window);
    vsb->current = cur;
    vsb->maxline = end;
    vsb->height = atr.height;
    vsb->lines = atr.height / parline;
    vsb->parline = parline;
    vsb->callback_scroll = scroll;
    vsb->callback_adjust = adjust;
    vsb->callback_data = data;
    vsb->grabbed = False;
    vsb->bar = XCreateSimpleWindow(disp, vsb->parent,
        atr.x + atr.width + SYL_VSB_SEP, atr.y, SYL_VSB_WIDTH, atr.height,
	0, vsb->pixel[Darkest], vsb->pixel[DimGray]);
    vsb->catch = XCreateSimpleWindow(disp, vsb->bar, 0, 0,
	SYL_VSB_WIDTH, HeightOfCatch(vsb),
        0, vsb->pixel[Darkest], vsb->pixel[MediumGray]);
    vsb->cursor = CreateNullCursor(disp);
    vsb->gc = XCreateGC(disp, vsb->bar, 0, 0);
    XSetFunction(disp, vsb->gc, GXcopy);
    XSetLineAttributes(disp, vsb->gc, 0, LineSolid, CapButt, JoinMiter);
    XSelectInput(disp, vsb->bar, ExposureMask);
    XMapRaised(disp, vsb->bar);
    XSelectInput(disp, vsb->catch, ExposureMask
		 | ButtonPressMask | ButtonReleaseMask);
    XMapRaised(disp, vsb->catch);
    return (vsb);

no_preferences:
    FreeSylColorset(vsb->pixel);
no_colorset:
    free(vsb);
no_vscrollbar:
    return (NULL);
}

void 
PutbackSylVScrollbar(SylVScrollbar *vsb)
{
    if (vsb == NULL)
	return;
    XFreeCursor(vsb->disp, vsb->cursor);
    XDestroyWindow(vsb->disp, vsb->catch);
    XDestroyWindow(vsb->disp, vsb->bar);
    XFreeGC(vsb->disp, vsb->gc);
    FreeSylColorset(vsb->pixel);
    free(vsb);
}

static void
ExposeCatch(SylVScrollbar *vsb)
{
    int last = HeightOfCatch(vsb) - 1;

    XSetForeground(vsb->disp, vsb->gc, vsb->pixel[Brightest]);
    XDrawPoint(vsb->disp, vsb->catch, vsb->gc, 0, 0);

    XSetForeground(vsb->disp, vsb->gc, vsb->pixel[LightGray]);
    XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, 0, SYL_VSB_WIDTH - 3, 0);
    XDrawLine(vsb->disp, vsb->catch, vsb->gc, 0, 1, 0, last - 2);
    
    if (vsb->grabbed == True && vsb->button == 1) {
	XSetForeground(vsb->disp, vsb->gc, vsb->pixel[DarkGray]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, last - 1,
		  SYL_VSB_WIDTH - 3, last - 1);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, SYL_VSB_WIDTH - 2, 1,
		  SYL_VSB_WIDTH - 2, last - 2);

	XSetForeground(vsb->disp, vsb->gc, vsb->pixel[Darkest]);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc,
	    SYL_VSB_WIDTH - 2, last - 1);
	XSetForeground(vsb->disp, vsb->gc, vsb->pixel[DimGray]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 0, last,
	    SYL_VSB_WIDTH - 2, last);
    }
    else {
	XSetForeground(vsb->disp, vsb->gc, vsb->pixel[DarkGray]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, last - 1,
		  SYL_VSB_WIDTH - 3, last - 1);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, SYL_VSB_WIDTH - 2, 1,
		  SYL_VSB_WIDTH - 2, last - 2);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 0, last,
		  SYL_VSB_WIDTH - 1, last);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, SYL_VSB_WIDTH - 1, 0,
		  SYL_VSB_WIDTH - 1, last - 1);
	
	XSetForeground(vsb->disp, vsb->gc, vsb->pixel[Darkest]);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc,
	    SYL_VSB_WIDTH - 2, last - 1);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc,
	    SYL_VSB_WIDTH - 1, last);
    }
}

static void
ExposeBar(SylVScrollbar *vsb)
{
    XSetForeground(vsb->disp, vsb->gc, vsb->pixel[DarkGray]);
    XDrawLine(vsb->disp, vsb->bar, vsb->gc, 1, 0, SYL_VSB_WIDTH - 1, 0);
    XDrawLine(vsb->disp, vsb->bar, vsb->gc, 0, 1, 0, vsb->height - 1);
    
    XSetForeground(vsb->disp, vsb->gc, vsb->pixel[Darkest]);
    XDrawPoint(vsb->disp, vsb->bar, vsb->gc, 0, 0);
}

static void
AdjustPointer(Display *disp, int newx, int newy)
{
    XWarpPointer(disp, None, DefaultRootWindow(disp), 0, 0, 0, 0, newx, newy);
}

static int
AdjustCatch(SylVScrollbar *vsb)
{
    int base, newx, newy;
    XWindowAttributes atr;

    XGetWindowAttributes(vsb->disp, vsb->catch, &atr);
    base = vsb->maxline - vsb->lines;
    newx = 0;
    newy = ((base <= 0) ? 0 :
        (vsb->height - atr.height) * vsb->current / base);
    if (vsb->grabbed == True && vsb->button == 1) {
	++newx;
	++newy;
    }
    if (newy != atr.y)
	XMoveWindow(vsb->disp, vsb->catch, newx, newy);
    return (newy - atr.y);
}

static int
ScrollWindow(SylVScrollbar *vsb, int dif)
{
    int new;

    new = max(min(vsb->current + dif, vsb->maxline - vsb->lines), 0);
    dif = new - vsb->current;
    if (dif) {
	if (abs(dif) < vsb->lines)
	    vsb->callback_scroll(vsb->callback_data, vsb->current, dif);
	else
	    vsb->callback_adjust(vsb->callback_data, new);
	vsb->current = new;
    }
    return (dif);
}

void
ScrollSylVScrollbar(SylVScrollbar *vsb, int dif)
{
    if (vsb == NULL)
	return;
    if (ScrollWindow(vsb, dif)) {
	(void) AdjustCatch(vsb);
    }
}

void
JumpSylVScrollbar(SylVScrollbar *vsb, int new)
{
    if (vsb == NULL)
	return;
    vsb->current = max(min(new, vsb->maxline - vsb->lines), 0);
    vsb->callback_adjust(vsb->callback_data, vsb->current);
    (void) AdjustCatch(vsb);
}

static void
PushCatch(SylVScrollbar *vsb)
{
    XResizeWindow(vsb->disp, vsb->catch,
	SYL_VSB_WIDTH - 1, HeightOfCatch(vsb));
    (void) AdjustCatch(vsb);
}

static void
PopCatch(SylVScrollbar *vsb)
{
    XResizeWindow(vsb->disp, vsb->catch, SYL_VSB_WIDTH, HeightOfCatch(vsb));
    (void) AdjustCatch(vsb);
}

void
RangeSylVScrollbar(SylVScrollbar *vsb, int newmax)
{
    if (vsb == NULL || vsb->maxline == newmax)
	return;
    vsb->maxline = newmax;
    XResizeWindow(vsb->disp, vsb->catch,
		  WidthOfCatch(vsb), HeightOfCatch(vsb));
    (void) AdjustCatch(vsb);
}

static int
RootYpointer(Display *disp)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, DefaultRootWindow(disp),
	&root, &child, &rx, &ry, &wx, &wy, &kb);
    return (ry);
}

static void
SmoothMotion(SylVScrollbar *vsb)
{
    int cury;

    if ((cury = RootYpointer(vsb->disp)) != vsb->orgy) {
        if (ScrollWindow(vsb, cury - vsb->orgy))
            vsb->orgy += AdjustCatch(vsb);
        AdjustPointer(vsb->disp, vsb->orgx, vsb->orgy);
    }
}

static int
WindowYpointer(Display *disp, Window d)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, d, &root, &child, &rx, &ry, &wx, &wy, &kb);
    return (wy);
}

static void
JumpMotion(SylVScrollbar *vsb)
{
    int diff, base, cury;

    cury = WindowYpointer(vsb->disp, vsb->bar) - vsb->orgp;
    base = vsb->height - HeightOfCatch(vsb);
    diff = (cury * (vsb->maxline - vsb->lines) + base / 2) / base;
    (void) ScrollWindow(vsb, diff - vsb->current);
    XMoveWindow(vsb->disp, vsb->catch, 0, max(min(cury, base), 0));
}

static void
StepMotion(SylVScrollbar *vsb)
{
    int diff, base, cury;

    cury = RootYpointer(vsb->disp);
    base = (vsb->height - HeightOfCatch(vsb));
    diff = (cury - vsb->orgy) * (vsb->maxline - vsb->lines) / base;
    if (ScrollWindow(vsb, (vsb->orgc + diff) - vsb->current))
	(void) AdjustCatch(vsb);
}

int
SendSylVScrollbar(SylVScrollbar *vsb, XEvent *ev)
{
    if (vsb == NULL)
	return (-1);
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window == vsb->catch) {
	    if (ev->xexpose.count == 0)
		ExposeCatch(vsb);
	}	
	else if (ev->xexpose.window == vsb->bar) {
	    if (ev->xexpose.count == 0)
		ExposeBar(vsb);
	}
	else {
	    return (1);
	}
	break;
    case ButtonPress:
	if (ev->xbutton.window != vsb->catch || vsb->maxline <= vsb->lines)
	    return (1);
	XGrabPointer(vsb->disp, vsb->catch, False, ButtonMotionMask
	     | ButtonReleaseMask | PointerMotionHintMask,
	     GrabModeAsync, GrabModeSync, DefaultRootWindow(vsb->disp),
	     None, ev->xbutton.time);
	vsb->grabbed = True;
	if ((vsb->button = ev->xbutton.button) == 1) {
	    XDefineCursor(vsb->disp, vsb->bar, vsb->cursor);
	    PushCatch(vsb);
	}
	vsb->orgc = vsb->current;
	vsb->orgx = ev->xbutton.x_root;
	vsb->orgy = ev->xbutton.y_root;
	vsb->orgp = ev->xbutton.y;
	break;
    case MotionNotify:
	if (vsb->grabbed != True)
	    return (1);
	while (XCheckMaskEvent(vsb->disp, ButtonMotionMask, ev))
	    ;
	if (vsb->button == 1)
	    SmoothMotion(vsb);
	else if (vsb->button == 2)
	    StepMotion(vsb);
	else
	    JumpMotion(vsb);
	break;
    case ButtonRelease:
	if (vsb->grabbed != True)
	    return (1);
	XUngrabPointer(vsb->disp, ev->xbutton.time);
	vsb->grabbed = False;
	if (vsb->button == 1) {
	    PopCatch(vsb);
	    XUndefineCursor(vsb->disp, vsb->bar);
	}
	else if (vsb->button == 3) {
	    AdjustCatch(vsb);
	}
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != vsb->window)
	    return (1);
	XMoveResizeWindow(vsb->disp, vsb->bar,
	    ev->xconfigure.x + ev->xconfigure.width + SYL_VSB_SEP,
	    ev->xconfigure.y, SYL_VSB_WIDTH, ev->xconfigure.height);
	vsb->height = ev->xconfigure.height;
	vsb->lines = vsb->height / vsb->parline;
	XResizeWindow(vsb->disp, vsb->catch,
		      WidthOfCatch(vsb), HeightOfCatch(vsb));
	if (vsb->maxline - vsb->current < vsb->lines)
	    vsb->current = max(0, vsb->maxline - vsb->lines);
	vsb->callback_adjust(vsb->callback_data, vsb->current);
	(void) AdjustCatch(vsb);
	break;
    default:
	return(1);
    }
    return (0);
}
