/*
       VScrollbar.h 1.3 for X11R6 & GNU C Compiler

       Copyright (C) 1996, 1997, 1998, 1999 Syllabub
       Maroontress Fast Software.
*/

#define SYL_VSB_SEP 2     /* window$B$H=D(Bscroll bar$B$N6-3&$N(Bpixel$B?t(B */
#define SYL_VSB_WIDTH 16  /* $B=D(Bscroll bar$B$N2#I}$N(Bpixel$B?t(B */
#define SYL_VSB_HMIN 12   /* $B=D(Bscroll bar$B$N9b$5$N:G>.(Bpixel$B?t(B (2$B0J>e(B) */

typedef struct {
    Display * disp;
    Window parent;
    Window window;
    Window catch;
    Window bar;
    GC gc;
    Cursor cursor;
    unsigned long *pixel;
    int current;        /* ($BI=<(HO0O$N@hF,9T(B) - 1 */
    int maxline;        /* $BAm9T?t(B */
    int height;         /* $BI=<(HO0O$N(Bpixel$B?t(B, $B2DJQ(B */
    int lines;          /* $BI=<(HO0O$N9T?t(B, $B2DJQ(B */         
    int parline;        /* 1$B9T$"$?$j$N(Bpixel$B?t(B, $B8GDj(B */
    int grabbed;        /* $B%9%/%m!<%k%P!<$,%I%i%C%0$5$l$F$$$l$P(BTrue */
    int orgx, orgy;     /* drag$B3+;O;~$N%k!<%H%&%#%s%I%&$KBP$9$k%]%$%s%H(B */
    int orgc;           /* (drag$B3+;O;~$NI=<(HO0O$N@hF,9T(B) - 1 */
    int orgp;           /* drag$B3+;O;~$N(Bcatch$B$N(Bbar$B$KBP$9$k(By$B:BI8(B */
    int button;         /* drag$B3+;O;~$K2!$5$l$F$$$?%\%?%s(B */
    void (*callback_scroll)(void *, int, int);
    void (*callback_adjust)(void *, int);
    void *callback_data;
} SylVScrollbar;

/*
    Function:
	ReserveSylVScrollbar - $B=DJ}8~$N%9%/%m!<%k%P!<$r3NJ]$9$k!#(B

    Synopsis:
        SylVScrollbar * ReserveSylVScrollbar(display, window, component,
	    beginning, total_lines, unit_height, scroll, adjust, data);
	Display *display;
        Window window;
	char *component;
	int beginning;
	int total_lines;
	int unit_height;
	void (*scroll)(void *, int, int);
	void (*adjust)(void *, int);
	void *data;

    Description:
        ReserveSylVScrollbar$B$O9TC10L$N%9%/%m!<%k=hM}$r=u$1$k!#M-8B$J@~2h(B
	$B:Q$_$N(BPixmap$B$rItJ,I=<($5$;$k$3$H$K$OIT8~$-$G$"$k!#$=$N>l9g$OB>$N(B
	$B5!9=$rMxMQ$7$?J}$,M-Mx$K$J$k!#(B

        display$B$O(BDisplay$B<1JL;R!#(Bwindow$B$O%9%/%m!<%k$NBP>]$H$J$k(BWindow$B<1JL(B
	$B;R!#(Bbeginning$B$OI=<(HO0O$N@hF,9T!#$?$@$7Bh(Bn$B9TL\$rI=<(HO0O$N@hF,9T$K(B
	$BI=<($9$k$?$a$K$O!"(Bbeginning$B$K(B(n - 1)$B$rBeF~$9$k!#(Btotal_lines$B$OAm(B
	$B9T?t!#(Bunit_height$B$O(B1$B9T$"$?$j$N%T%/%;%k?t!#(Bcomponent$B$O9=@.;RL>!#(B

	scroll$B$O%3!<%k%P%C%/4X?t$X$N%]%$%s%?!#(Bscroll(data, n - 1, m)$B$G(B
	n$B9TL\!JI=<(HO0O$N@hF,9T!K$,(Bm$B9T%9%/%m!<%k$9$k$h$&$K<BAu$9$kI,MW$,(B
	$B$"$k!#(Badjust$B$b%3!<%k%P%C%/4X?t$X$N%]%$%s%?!#(Badjust(data, n - 1)
	$B$G(Bn$B9TL\$,I=<(HO0O$N@hF,9T$KI=<($5$l$k$h$&$K<BAu$7$F$"$kI,MW$,$"$k!#(B
	data$B$O%3!<%k%P%C%/4X?t$KEO$9%G!<%?$N%]%$%s%?!#(Bscroll(data, a, b)
	$B$,(Badjust(data, a+b)$B$HEy2A$K$J$kI,MW$,$"$k!#%3!<%k%P%C%/4X?t$N<BAu(B
	$B$G$O!"(Bscroll$B$NFbIt$+$i(Badjust$B$r8F$V!"$^$?$O$=$N5U$r$9$k$3$H$O2DG=!#(B
	scroll$B$H(Badjust$B$O8F=PB&$+$iD>@\8F$s$G$O$J$i$J$$!#$=$NBe$o$j$K!"$=$l(B
	$B$>$l(BScrollVScrollbar, JumpVScrollbar$B$r8F$V$3$H!#%3!<%k%P%C%/$+$i(B
	SylVScrollbar$B$K4X$9$k4X?t$r8F$S=P$7$F$O$J$i$J$$!J:FF~IT2D!K!#(B

	ReserveSylVScrollbar$B$O<:GT$9$k$H(BNULL$B$rJV$9!#(B

    See also:
        SendSylVScrollbar, PutbackSylVScrollbar, ScrollSylVScrollbar,
	JumpSylVScrollbar, RewriteSylVScrollbar, RangeSylVScrollbar
*/

SylVScrollbar * ReserveSylVScrollbar(Display *, Window, char *, int, int, int,
				     void (*)(void *, int, int),
				     void (*)(void *, int), void *);
int SendSylVScrollbar(SylVScrollbar *, XEvent *);
void ScrollSylVScrollbar(SylVScrollbar *, int);
void JumpSylVScrollbar(SylVScrollbar *, int);
#define RewriteSylVScrollbar(x) JumpSylVScrollbar((x), (x)->current)
void RangeSylVScrollbar(SylVScrollbar *, int);
void PutbackSylVScrollbar(SylVScrollbar *);
