static SylSetting
  ColorSet0 = {"foreground", "Foreground", "black", NULL},
  ColorSet1 = {"background", "Background", "white", NULL},
  ColorSet2 = {"illuminated", "Illuminated", "#ffe0e0", NULL},
  ColorSet3 = {"brightest", "Brightest", "gray100", NULL},
  ColorSet4 = {"lightGray", "LightGray", "gray85", NULL},
  ColorSet5 = {"mediumGray", "MediumGray", "gray70", NULL},
  ColorSet6 = {"dimGray", "DimGray", "gray50", NULL},
  ColorSet7 = {"darkGray", "DarkGray", "gray30", NULL},
  ColorSet8 = {"darkest", "Darkest", "gray10", NULL},
  *ColorSet[] = {
    &ColorSet0,
    &ColorSet1,
    &ColorSet2,
    &ColorSet3,
    &ColorSet4,
    &ColorSet5,
    &ColorSet6,
    &ColorSet7,
    &ColorSet8,
    NULL};
enum { Foreground, Background, Illuminated, Brightest, LightGray, MediumGray, DimGray, DarkGray, Darkest,};
