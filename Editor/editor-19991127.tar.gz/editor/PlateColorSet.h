static SylSetting
  ColorSet0 = {"foreground", "Foreground", "black", NULL},
  ColorSet1 = {"mediumGray", "MediumGray", "gray70", NULL},
  *ColorSet[] = {
    &ColorSet0,
    &ColorSet1,
    NULL};
enum { Foreground, MediumGray,};
