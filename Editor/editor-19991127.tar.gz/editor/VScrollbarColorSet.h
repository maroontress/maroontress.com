static SylSetting
  ColorSet0 = {"brightest", "Brightest", "gray100", NULL},
  ColorSet1 = {"lightGray", "LightGray", "gray85", NULL},
  ColorSet2 = {"mediumGray", "MediumGray", "gray70", NULL},
  ColorSet3 = {"dimGray", "DimGray", "gray50", NULL},
  ColorSet4 = {"darkGray", "DarkGray", "gray30", NULL},
  ColorSet5 = {"darkest", "Darkest", "gray10", NULL},
  *ColorSet[] = {
    &ColorSet0,
    &ColorSet1,
    &ColorSet2,
    &ColorSet3,
    &ColorSet4,
    &ColorSet5,
    NULL};
enum { Brightest, LightGray, MediumGray, DimGray, DarkGray, Darkest,};
