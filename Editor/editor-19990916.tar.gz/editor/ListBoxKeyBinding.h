static SylSetting
  KeyBinding0 = {"pressButton", "PressButton", "Return, Control-m", NULL},
  KeyBinding1 = {"nextField", "NextField", "Control-Tab", NULL},
  KeyBinding2 = {"previousField", "PreviousField", "Control-Shift-Tab", NULL},
  KeyBinding3 = {"nextLine", "NextLine", "Down, Control-n", NULL},
  KeyBinding4 = {"previousLine", "PreviousLine", "Up, Control-p", NULL},
  *KeyBinding[] = {
    &KeyBinding0,
    &KeyBinding1,
    &KeyBinding2,
    &KeyBinding3,
    &KeyBinding4,
    NULL};
