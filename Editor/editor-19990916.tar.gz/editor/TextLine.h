/*
        TextLine.h 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

typedef struct SylTextLine {
    Display *disp;
    XIC ic;
    XIMStyle ic_style;
    Window parent;
    Window window;
    Window next_field;
    Window prev_field;
    Pixmap pixmap;
    GC gc;
    SylFontSet fontset;
    int width;
    int height;
    int sidemargin;
    int depth;
    unsigned long pixel[6];
    SylKeymap **keymap;

    SylText *text;
    int size;
    int left;
    int cursor;
    int right;
    int dragging;
    int left_dragged;
    int right_dragged;
    int pointed;
    int focus;
    int grabbed;
    int redraw;
    int converting;
    int n_preedit_chars;   /* on-the-spot only: $BA0JT=8Cf$NJ8;z?t(B */
    int preedit_caret;     /* on-the-spot only: $BA0JT=8Cf$N%-%c%l%C%H$N0LCV(B */
    int preedit_drawing;   /* on-the-spot only: $B%U%#!<%I%P%C%/$NIA2h>uBV(B */
    int preedit_begin;     /* on-the-spot only: $BA0JT=83+;O0LCV(B */
    XIMFeedback *feedback; /* on-the-spot only: $B%U%#!<%I%P%C%/$N%3%T!<(B */
    Time stamp;            /* $B%;%l%/%7%g%s3MF@$K;HMQ$7$?%?%$%`%9%?%s%W(B */
    Atom property;
    Atom text_atom;
    Atom compound_text_atom;
    Atom targets_atom;
    Atom timestamp_atom;
    void (*callback)(int);
} SylTextLine;

SylTextLine * CreateSylTextLine(Display *, Window, char *, void (*)(int));
void FreeSylTextLine(SylTextLine *);
void SendSylTextLine(SylTextLine *, XEvent *);
int NiceSylTextLine(SylTextLine *);
void SetFieldOrderSylTextLine(SylTextLine *, Window, Window);
void SetICSylTextLine(SylTextLine *, XIC, XIMStyle);
int GetMBStringSylTextLine(SylTextLine *, char *);
void SetMBStringSylTextLine(SylTextLine *, char *); /* added */
