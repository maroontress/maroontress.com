/*
        Resource.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

typedef struct {
    char *name;
    char *class;
    char *orig;
    char *spec;
} SylSetting;

typedef struct SylKeymap {
    unsigned int mod;
    unsigned int func;
    struct SylKeymap *next;
} SylKeymap;

typedef struct {
    XFontSet id;
    int width;
    int height;
    int ascent;
    int descent;
} SylFontSet;

int FQLength(char *, char *c);
void FQCompose(char *, char *, char *);
XrmDatabase MergedResourceDatabase(Display *);
void GetPreference(Display *, char *, char *, SylSetting *);
void LoadColorset(Display *, char *, char *, SylSetting **, unsigned long *);
void LoadFontset(Display *, char *, char *, SylSetting **, SylFontSet *);
void LoadIMStyleset(Display *, char *, char *, SylSetting **, XIMStyle *);
void LoadKeybinding(Display *, char *, char *, SylSetting **, SylKeymap **);
void SetFQClassHint(Display *, Window, char *, char *, Window);
