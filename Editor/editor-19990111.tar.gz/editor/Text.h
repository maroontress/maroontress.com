/*
        Text.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

typedef struct {
    wchar_t *wcs; /* $B%o%$%I%-%c%i%/%?J8;zNs(B */
    int len;      /* $BJ8;z?t(B */
    int eol;      /* End Of Line (True or False) */
} SylText;

#define LengthOfSylText(t) ((t)->len)
#define EndOfLineSylText(t) ((t)->eol)

SylText * CreateSylTextFromWCString(wchar_t *wcs, int eol);
void FreeSylText(SylText *txt);
wchar_t * CreateWCStringFromSylText(SylText *txt, int bgn, int end);
void InsertWCharIntoSylText(SylText *txt, int n, wchar_t c);
void InsertWCStringIntoSylText(SylText *txt, int n, wchar_t *p);
void DeleteWCharOfSylText(SylText *txt, int n);
void DeleteWCStringOfSylText(SylText *txt, int n, int m);
void ChangeEndOfLineSylText(SylText *txt, int eol);

SylText *ConcatAndCreateSylText(SylText *head, SylText *tail);
void SplitAndCreateSylTexts(SylText *txt, int n, int eol,
			    SylText **head, SylText **tail);
