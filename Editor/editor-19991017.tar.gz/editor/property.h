/*
        property.h 1.2 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

void SetProperties(Display *, Window, char *, char *, char *, int, char **,
		   XSizeHints *, Pixmap, Pixmap, Window);
int IsWMCloseMessage(XEvent *ev);
void SetDefaultFocusWindow(Window);
