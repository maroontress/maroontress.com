/*
        TextArea1.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

void GetSelectedRegion(SylTextArea *txt, SylLocation *left,
		       SylLocation *right);
unsigned int SizeOfSelectedRegion(SylTextArea *txt, SylLocation *left,
				  SylLocation *right);
void CopySelectedRegionToWCString(SylTextArea *txt, SylLocation *left,
				  SylLocation *right, wchar_t *wcs);
void SetSelectionOwner(SylTextArea *txt, Time tm);
void ResetSelectionOwner(SylTextArea *txt);

int IsEqualSylLocation(SylLocation *p, SylLocation *q);
SylLocation LocationPointed(SylTextArea *txt, int w, int h);

void BackSpace(SylTextArea *txt, Time tm);
void Delete(SylTextArea *txt, Time tm);
void YankLine(SylTextArea *txt, Time tm);
void YankLineWithShift(SylTextArea *txt, Time tm);
void KillLine(SylTextArea *txt, Time tm);

void CursorBeginingOfLine(SylTextArea *txt, Time tm);
void CursorBeginingOfLineWithShift(SylTextArea *txt, Time tm);
void CursorEndOfLine(SylTextArea *txt, Time tm);
void CursorEndOfLineWithShift(SylTextArea *txt, Time tm);

void CursorNextWord(SylTextArea *txt, Time tm);
void CursorNextWordWithShift(SylTextArea *txt, Time tm);
void CursorPrevWord(SylTextArea *txt, Time tm);
void CursorPrevWordWithShift(SylTextArea *txt, Time tm);

void CursorLeft(SylTextArea *txt, Time tm);
void CursorLeftWithShift(SylTextArea *txt, Time tm);
void CursorRight(SylTextArea *txt, Time tm);
void CursorRightWithShift(SylTextArea *txt, Time tm);

void InsertChar(SylTextArea *txt, wchar_t c);
void LineFeed(SylTextArea *txt, Time tm);

void CursorLeftEdge(SylTextArea *txt, Time tm);
void CursorLeftEdgeWithShift(SylTextArea *txt, Time tm);
void CursorRightEdge(SylTextArea *txt, Time tm);
void CursorRightEdgeWithShift(SylTextArea *txt, Time tm);

void CursorUp(SylTextArea *txt, Time tm);
void CursorUpWithShift(SylTextArea *txt, Time tm);
void CursorDown(SylTextArea *txt, Time tm);
void CursorDownWithShift(SylTextArea *txt, Time tm);

void GrabbedCursorUp(SylTextArea *txt);
void GrabbedCursorDown(SylTextArea *txt);
