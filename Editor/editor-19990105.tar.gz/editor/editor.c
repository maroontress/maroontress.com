/*
        editor.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "TextArea.h"
#include "property.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

char **GlobalAv;
int GlobalAc;

#define DEFAULT_WIDTH 320
#define DEFAULT_HEIGHT 500

#define THIS_CLASS "Editor"

static SylSetting
    Foreground  = {"foreground", "Foreground", "black",  NULL},
    MediumGray  = {"mediumGray", "MediumGray", "gray70", NULL},
    *ColorSet[] = {&Foreground, &MediumGray, NULL};

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset",  "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

static SylSetting
    IMStyle = {"ximStyle", "XIMStyle", "PreeditNothing,StatusNothing", NULL},
    *IMStyleSet[] = {&IMStyle, NULL};

static int MainPower = 1;
static Display *Disp;
static unsigned long Pixels[2];
static int BaseWindowWidth = DEFAULT_WIDTH;
static int BaseWindowHeight = DEFAULT_HEIGHT;
static Window BaseWindow;
static Window MainWindow;
static int MainWindowWidth = DEFAULT_WIDTH;
static int MainWindowHeight = DEFAULT_HEIGHT;

static XIMStyle
FindBestStyle(XIM im, XIMStyle request)
{
    int n;
    XIMStyle best_style, style;
    XIMStyles *supported;

    XGetIMValues(im, XNQueryInputStyle, &supported, NULL);
    best_style = 0;
#if 0
    printf("supported->count_styles: %d\n", supported->count_styles);
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        printf("supported->supported_styles[%d]: %lx;", n, style);
	if (style & XIMPreeditArea)
	    printf(" XIMPreeditArea");
	if (style & XIMPreeditCallbacks)
	    printf(" XIMPreeditCallbacks");
	if (style & XIMPreeditPosition)
	    printf(" XIMPreeditPosition");
	if (style & XIMPreeditNothing)
	    printf(" XIMPreeditNothing");
	if (style & XIMPreeditNone)
	    printf(" XIMPreeditNone");
	if (style & XIMStatusArea)
	    printf(" XIMStatusArea");
	if (style & XIMStatusCallbacks)
	    printf(" XIMStatusCallbacks");
	if (style & XIMStatusNothing)
	    printf(" XIMStatusNothing");
	if (style & XIMStatusNone)
	    printf(" XIMStatusNone");
	printf("\n");
    }
#endif
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        if (style == request) {
            best_style = style;
            break;
        }
    }
    XFree(supported);
    return (best_style);
}

static XIC
CreateIC(XIM im, XIMStyle request, Window win, XFontSet fs,
	 unsigned long fore, unsigned long back)
{
    XIC ic;
    XVaNestedList preedit, status;
    XPoint Origin = {0, 0};

    preedit = XVaCreateNestedList(0, XNFontSet, fs,
				  XNForeground, fore,
				  XNBackground, back,
				  XNSpotLocation, &Origin, NULL);
    status = XVaCreateNestedList(0, XNFontSet, fs,
				 XNForeground, fore,
				 XNBackground, back,
				 NULL);
    ic = XCreateIC(im, XNInputStyle, request, XNClientWindow, win,
                   XNPreeditAttributes, preedit, XNStatusAttributes, status,
                   NULL);
    XFree(preedit);
    XFree(status);
    return (ic);
}

static void
SetGeometry(XIC ic, char *name, XRectangle *area)
{
    XVaNestedList list;

    list = XVaCreateNestedList(0, XNArea, area, NULL);
    XSetICValues(ic, name, list, NULL);
    XFree(list);
}

static void
WindowMain(XEvent *ev, XIC ic, XIMStyle style, SylFontSet *font)
{
    XRectangle region;

    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
    case ConfigureNotify:
	if (ev->xconfigure.window != BaseWindow)
            break;
	BaseWindowWidth = ev->xconfigure.width;
	BaseWindowHeight = ev->xconfigure.height;
	if (style & XIMPreeditArea) {
	    region.width = max(ev->xconfigure.width - font->height * 6, 1);
	    region.height = font->height;
	    region.x = ev->xconfigure.width - region.width;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(ic, XNPreeditAttributes, &region);
	}
	if (style & XIMStatusArea) {
	    region.width = min(ev->xconfigure.width, font->height * 6);
	    region.height = font->height;
	    region.x = 0;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(ic, XNStatusAttributes, &region);
	}
	MainWindowWidth = BaseWindowWidth;
	MainWindowHeight = BaseWindowHeight - font->height;
	if (MainWindowHeight > 0)
	    XResizeWindow(Disp, MainWindow, MainWindowWidth, MainWindowHeight);
	break;
    }
}

static void
GetToplevelPreferences(Display *disp, char *name, char *class,
		       unsigned long *p, SylFontSet *f, XIMStyle *style)
{
    char *Resources;
    XrmDatabase Database;
    SylSetting **s;

    LoadColorset(disp, class, ColorSet, p);
    LoadFontset(disp, name, FontSet, f);
    LoadIMStyleset(name, IMStyleSet, style);
    if ((Resources = XResourceManagerString(disp)) == NULL)
	return;
    Database = XrmGetStringDatabase(Resources);
    for (s = ColorSet; *s != NULL; ++s)
	GetPreference(Database, name, class, *s);
    for (s = FontSet; *s != NULL; ++s)
	GetPreference(Database, name, class, *s);
    for (s = IMStyleSet; *s != NULL; ++s)
	GetPreference(Database, name, class, *s);
    LoadColorset(disp, name, ColorSet, p);
    LoadFontset(disp, name, FontSet, f);
    LoadIMStyleset(name, IMStyleSet, style);
    XrmDestroyDatabase(Database);  
}

int
main(int ac, char **av)
{
    XIM im;
    XIC ic;
    XIMStyle style;
    long BaseWindowMask, EventMask = 0;
    XEvent ev;
    SylFontSet fs;
    SylTextArea *region;

    GlobalAc = ac;
    GlobalAv = av;
    if (ac != 3) {
	printf("usage: %s read-file write-file\n", av[0]);
	exit(1);
    }
    if ((Disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    if (XSetLocaleModifiers("") == NULL)
        fprintf(stderr, "%s: Warning: cannot set locale modifiers.\n", av[0]);

    GetToplevelPreferences(Disp, "editor", THIS_CLASS, Pixels, &fs, &style);
    if (fs.id == None) {
        fprintf(stderr, "%s: cannot create fontset.\n", av[0]);
        exit(1);
    }
    if ((im = XOpenIM(Disp, NULL, NULL, NULL)) == NULL) {
        fprintf(stderr, "%s: cannot open input method.\n", av[0]);
        exit(1);
    }
    if ((style = FindBestStyle(im, style)) == 0) {
        fprintf(stderr, "%s: no available style of input method.\n", av[0]);
        exit(1);
    }

    BaseWindow = XCreateSimpleWindow(Disp, DefaultRootWindow(Disp), 0, 0,
        BaseWindowWidth, BaseWindowHeight, 1, Pixels[0], Pixels[1]);
    SetProperties(Disp, BaseWindow, "editor (exp)", "editor", THIS_CLASS,
	ac, av, 0, 0, 0, 0, 1, 1);
    if ((ic = CreateIC(im, style, BaseWindow, fs.id, Pixels[0], Pixels[1]))
	== NULL) {
        fprintf(stderr, "%s: cannot create input context.\n", av[0]);
        exit(1);
    }
    BaseWindowMask = StructureNotifyMask;
    if (XGetICValues(ic, XNFilterEvents, &EventMask, NULL) == NULL)
	BaseWindowMask |= EventMask;
    else
	fprintf(stderr, "%s: warning: current IM has no specification"
		" of the `XNFilterEvents' value.\n", av[0]);
    XSelectInput(Disp, BaseWindow, BaseWindowMask);
    XSetICFocus(ic);
    XMapRaised(Disp, BaseWindow);

    MainWindow = XCreateSimpleWindow(Disp, BaseWindow, 0, 0,
        MainWindowWidth, MainWindowHeight, 0, Pixels[0], Pixels[1]);
    XSetWindowBackgroundPixmap(Disp, MainWindow, ParentRelative);
    XSelectInput(Disp, MainWindow, StructureNotifyMask);
    SetFQClassHint(Disp, BaseWindow, "edit", "Paned", MainWindow);
    XMapRaised(Disp, MainWindow);

    if ((region = CreateSylTextArea(Disp, ic, MainWindow, "text",
        AREA_EDIT_MODE)) == NULL) {
        fprintf(stderr, "%s: cannot create SylTextArea.\n", av[0]);
	exit(1);
    }
    if (ReadSylTextArea(region, av[1])) {
        fprintf(stderr, "%s: cannot read file `%s'.\n", av[0], av[1]);
    }
    while (MainPower) {
        while (XEventsQueued(Disp, QueuedAfterReading) == 0
               && (NiceSylTextArea(region))) {
            ;
	}
	XNextEvent(Disp, &ev);
	if (XFilterEvent(&ev, None))
            continue;
	if (IsWMCloseMessage(&ev))
	    break;
	SendSylTextArea(region, &ev);
        WindowMain(&ev, ic, style, &fs);
    }
    if (WriteSylTextArea(region, av[2])) {
        fprintf(stderr, "%s: cannot write file `%s'.\n", av[0], av[2]);
    }
    FreeSylTextArea(region);
    XDestroyWindow(Disp, BaseWindow);
    XCloseDisplay(Disp);
    exit(0);
}
