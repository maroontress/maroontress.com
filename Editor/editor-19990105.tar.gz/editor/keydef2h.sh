#!/bin/sh
while read func name args
do
	c1=`echo $name | sed -e 's/^\(.\).*/\1/' | tr a-z A-Z`
	c2=`echo $name | sed -e 's/^.\(.*\)/\1/'`
	echo '{"'$name'"', '"'$c1$c2'"', '"'$args'"', 'NULL},'
done
