#!/bin/sh

while read line
do
	echo {'"'$line'"', AREA_`echo $line|tr a-z A-Z`},
done
