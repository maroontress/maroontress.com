/*
        WCString.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <stdlib.h>

#include "WCString.h"

int
wstrlen(wchar_t *str)
{
    int n;
    
    for (n = 0; *str; ++n)
	++str;
    return (n);
}

wchar_t *
wstrcpy(wchar_t *d, wchar_t *s)
{
    wchar_t *p = d;

    while ((*d = *s) != 0) {
	++d;
	++s;
    }
    return (p);
}

wchar_t *
wstrncpy(wchar_t *d, wchar_t *s, int n)
{
    wchar_t *p = d;

    while ((*d = *s) != 0 && n > 0) {
	++d;
	++s;
	--n;
    }
    return (p);
}
