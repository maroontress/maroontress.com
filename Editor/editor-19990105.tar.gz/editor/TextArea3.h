/*
        TextArea3.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

SylTextBlockSet * CreateSylTextBlockSet(void);
void FreeSylTextBlockSet(SylTextBlockSet *tbs);

SylText * NextLineSylTextBlock(SylTextBlock *tb, int n);
SylText * PrevLineSylTextBlock(SylTextBlock *tb, int n);

void FreeNextLine(SylTextBlockSet *tbs, SylTextBlock *tb, int n);
SylTextBlock * SplitSylTextBlock(SylTextBlockSet *tbs);
SylTextBlock * SeekSylTextBlockAtLine(SylTextBlockSet *tbs, int y);
void InsertLineFeedIntoSylTextBlock(SylText **body, int n, int x,
				    int n_bodies);
int AdjustAfterInserted(SylText **body, int n, int n_bodies,
			XFontSet fs, int width);
void Reformat(SylTextBlockSet *tbs, int y, XFontSet fs, int width);
