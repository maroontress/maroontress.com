/*
        FontStack.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997, 1998 Syllabub
        Maroontress Fast Software.
*/

typedef struct FontStack {
    short type;
    short body;
} FontStack;

#define FS_EOF -1
#define FS_CONST 0
#define FS_STACK 1
#define FS_WIDTH 2
#define FS_HEIGHT 3
#define FS_ASCENT 4
#define FS_DESCENT 5
#define FS_ADD 6
#define FS_SUB 7
#define FS_MUL 8
#define FS_DIV 9
#define FS_MIN 10
#define FS_MAX 11
#define FS_CLEAR_STACKS 12
#define FS_FILL_CIRCLE 13
#define FS_FILL_POLYGON 14
#define FS_DRAW_LINES 15
#define FS_DRAW_SEGMENT 16

#define FS_SUCCESS 0
#define FS_INVALID_STACK 1
#define FS_STACK_OVERFLOW 2
#define FS_INVALID_XFONTSET 3

int DrawFontStack(Display *, Drawable, GC, XFontSet, int, int, FontStack *);
