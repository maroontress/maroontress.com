/*
        FontStack.h 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1997, 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

typedef struct SylFontStack {
    short type;
    short body;
} SylFontStack;

#define SYL_FS_EOF -1
#define SYL_FS_CONST 0
#define SYL_FS_STACK 1
#define SYL_FS_WIDTH 2
#define SYL_FS_HEIGHT 3
#define SYL_FS_ASCENT 4
#define SYL_FS_DESCENT 5
#define SYL_FS_ADD 6
#define SYL_FS_SUB 7
#define SYL_FS_MUL 8
#define SYL_FS_DIV 9
#define SYL_FS_MIN 10
#define SYL_FS_MAX 11
#define SYL_FS_CLEAR_STACKS 12
#define SYL_FS_FILL_CIRCLE 13
#define SYL_FS_FILL_POLYGON 14
#define SYL_FS_DRAW_LINES 15
#define SYL_FS_DRAW_SEGMENT 16

#define SYL_FS_SUCCESS 0
#define SYL_FS_INVALID_STACK 1
#define SYL_FS_STACK_OVERFLOW 2
#define SYL_FS_INVALID_XFONTSET 3

int DrawSylFontStack(Display *, Drawable, GC, XFontSet, int, int,
		     SylFontStack *);
