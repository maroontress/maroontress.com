/*
        TextArea.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "Selection.h"
#include "Resource.h"
#include "FontStack.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "TextArea.h"
#include "TextArea1.h"
#include "TextArea2.h"
#include "TextArea3.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define THIS_CLASS "TextArea"
#define DRAGGING_SCROLL_DELAY (20 * 1000) /* microseconds */
#define FOCUS_FRAME_WIDTH 1

static SylSetting
    Foreground  = {"foreground",  "Foreground",  "black",   NULL},
    Background  = {"background",  "Background",  "white",   NULL},
    MediumGray  = {"mediumGray",  "MediumGray",  "gray70",  NULL},
    DimGray     = {"dimGray",     "DimGray",     "gray50",  NULL},
    Illuminated = {"illuminated", "Illuminated", "#ffe0e0", NULL},
    Highlighted = {"highlighted", "Highlighted", "#3f00ff", NULL},
    *ColorSet[] = {&Foreground, &Background, &MediumGray,
		   &DimGray, &Illuminated, &Highlighted, NULL};

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

#include "TextAreaKeyBinding.h"

static void (*BranchSylTextArea[])(SylTextArea *, Time) = {
#include "TextAreaBranch.h"
};

static SylFontStack DownArrowStack[] = {
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
    {SYL_FS_DESCENT},
    {SYL_FS_STACK, 0},
    {SYL_FS_HEIGHT}, {SYL_FS_SUB}, {SYL_FS_DESCENT},
        {SYL_FS_SUB}, {SYL_FS_CONST, 1},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_DRAW_SEGMENT}, {SYL_FS_CLEAR_STACKS},
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},
        {SYL_FS_DIV}, {SYL_FS_CONST, 4},
    {SYL_FS_MIN}, {SYL_FS_CONST, 1}, {SYL_FS_MUL}, {SYL_FS_CONST, 2},
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_HEIGHT}, {SYL_FS_SUB}, {SYL_FS_DESCENT},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_SUB}, {SYL_FS_CONST, 1}, {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_STACK, 0},
    {SYL_FS_STACK, 0},
    {SYL_FS_STACK, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_DRAW_LINES}, {SYL_FS_CONST, 3}, {SYL_FS_EOF}};

static SylFontStack LeftStopStack[] = {
    {SYL_FS_HEIGHT}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},
        {SYL_FS_DIV}, {SYL_FS_CONST, 8},
    {SYL_FS_ADD}, {SYL_FS_CONST, 1}, {SYL_FS_MIN}, {SYL_FS_CONST, 1},
    {SYL_FS_HEIGHT}, {SYL_FS_SUB}, {SYL_FS_DESCENT},
        {SYL_FS_SUB}, {SYL_FS_CONST, 1},
    {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 2},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 0}, {SYL_FS_ADD}, {SYL_FS_STACK, 2},
    {SYL_FS_DRAW_SEGMENT},
    {SYL_FS_STACK, 1}, {SYL_FS_ADD}, {SYL_FS_CONST, 1},
    {SYL_FS_STACK, 0},
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_STACK, 1},
        {SYL_FS_SUB}, {SYL_FS_STACK, 1},
    {SYL_FS_SUB}, {SYL_FS_CONST, 1},
    {SYL_FS_STACK, 2},
    {SYL_FS_CONST, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 2},
        {SYL_FS_MUL}, {SYL_FS_CONST, 2},
    {SYL_FS_FILL_POLYGON}, {SYL_FS_CONST, 3}, {SYL_FS_EOF}};

static SylFontStack CenterLDotStack[] = {
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},
        {SYL_FS_DIV}, {SYL_FS_CONST, 4},
    {SYL_FS_MIN}, {SYL_FS_CONST, 1}, {SYL_FS_MUL}, {SYL_FS_CONST, 2},
    {SYL_FS_STACK, 0}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0}, {SYL_FS_ADD}, {SYL_FS_STACK, 1},
    {SYL_FS_HEIGHT}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_CONST, 0},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_CONST, 0},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 4},
    {SYL_FS_CONST, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 4},
    {SYL_FS_STACK, 4},
    {SYL_FS_FILL_POLYGON}, {SYL_FS_CONST, 8}, {SYL_FS_EOF}};

static void
GetWindowPointer(Display *disp, Window w, int *x, int *y)
{
    Window root, child;
    int rx, ry, kb;

    XQueryPointer(disp, w, &root, &child, &rx, &ry, x, y, &kb);
}

static void
MoveCursorDragged(SylTextArea *txt)
{
    int x, y;

    GetWindowPointer(txt->disp, txt->window, &x, &y);
    if (y < 0) {
	y = 0;
	x = 0;
    }
    txt->current = LocationPointed(txt, x, y);
}

static SylTextArea *callback = NULL;

static void
adjustcallback(int n)
{
    callback->visible_begin = n;
    if (callback->vsb->grabbed == True) {
	if (callback->current.y < n) {
	    callback->current.y = n;
	    callback->current.x = GetRowsAtLine(callback->tbs,
						&callback->fontset,
						callback->saved_width,
						callback->current.y);
	    if (callback->selected)
		ResetSelectionOwner(callback);
	}
	else if (callback->current.y >= n + callback->visible_cols) {
	    callback->current.y = n + callback->visible_cols - 1;
	    callback->current.x = GetRowsAtLine(callback->tbs,
						&callback->fontset,
						callback->saved_width,
						callback->current.y);
	    if (callback->selected)
		ResetSelectionOwner(callback);
	}
    }
    callback->redraw = True;
}

static void
scrollcallback(int n, int m)
{
    adjustcallback(n + m);
}

static Pixmap
CreateMark(Display *disp, Window win, XFontSet fs, int w, int h,
	   SylFontStack *s)
{
    GC gc;
    Pixmap d;

    d = XCreatePixmap(disp, win, w, h, 1);
    gc = XCreateGC(disp, d, 0, 0);
    XSetForeground(disp, gc, 0);
    XFillRectangle(disp, d, gc, 0, 0, w, h);
    XSetForeground(disp, gc, 1);
    DrawSylFontStack(disp, d, gc, fs, 0, 0, s);
    XFreeGC(disp, gc);
    return (d);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
		  SylTextArea *txt)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
	return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
	FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
	FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
	return (1);

    LoadSylColorset(disp, fq_name, fq_class, ColorSet, txt->pixel);
    LoadSylFontset(disp, fq_name, fq_class, FontSet, &txt->fontset);
    LoadSylKeybinding(disp, fq_name, fq_class, KeyBinding, txt->keymap);
    return (0);
}

SylTextArea *
CreateSylTextArea(Display *disp, XIC ic, Window parent, char *component)
{
    XWindowAttributes attr;
    SylTextArea *txt;
    Pixmap background;
    static char tile_bits[] = {0x0f, 0x0f, 0x0f, 0x0f, 0xf0, 0xf0, 0xf0, 0xf0};

    if ((txt = (SylTextArea *)malloc(sizeof(SylTextArea))) == NULL)
        goto no_text_area;
    if ((txt->tbs = CreateSylTextBlockSet()) == NULL)
	goto no_text_block_set;
    if ((txt->keymap = CreateSylKeymap()) == NULL)
	goto no_keymap;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, txt))
	goto no_preferences;
    txt->buf = NULL;
    txt->sidemargin = (txt->fontset.width + 2) / 2 + FOCUS_FRAME_WIDTH;
    txt->baseline_skip = (2 * txt->fontset.descent) + txt->fontset.height;
    XGetWindowAttributes(disp, parent, &attr);
    txt->parent_width = attr.width;
    txt->parent_height = attr.height;
    txt->visible_begin = 0;
    txt->visible_cols = max(1, txt->parent_height / txt->baseline_skip);
    txt->width = attr.width;
    txt->height = txt->visible_cols * txt->baseline_skip;
    txt->depth = attr.depth;
    txt->window = XCreateSimpleWindow(disp, parent,
	0, (attr.height - txt->height) / 2, txt->width, txt->height,
	0, txt->pixel[0], txt->pixel[2]);
    background = XCreatePixmapFromBitmapData(disp, txt->window,
	tile_bits, 8, 8, txt->pixel[2], txt->pixel[3], attr.depth);
    XSetWindowBackgroundPixmap(disp, txt->window, background);
    XFreePixmap(disp, background);
    XSelectInput(disp, txt->window, ExposureMask | KeyPressMask
        | ButtonPressMask | OwnerGrabButtonMask | ButtonReleaseMask
        | FocusChangeMask | EnterWindowMask | LeaveWindowMask
	| StructureNotifyMask); 
    SetFQClassHint(disp, parent, component, THIS_CLASS, txt->window);
    XMapRaised(disp, txt->window);
    txt->next_field = None;
    txt->prev_field = None;
    if ((txt->vsb = ReserveSylVScrollbar(disp, txt->window,
        "verticalScrollbar", 0, attr.height, txt->baseline_skip,
	scrollcallback, adjustcallback)) == NULL)
	goto no_vscrollbar;
    txt->pixmap = XCreatePixmap(disp, parent,
	txt->width, txt->height, txt->depth);
    txt->wallpaper = None;
    txt->mark_lf = CreateMark(disp, txt->window, txt->fontset.id,
	txt->fontset.width, txt->fontset.height, DownArrowStack);
    txt->mark_eof = CreateMark(disp, txt->window, txt->fontset.id,
	txt->fontset.width, txt->fontset.height, LeftStopStack);
    txt->mark_tab = CreateMark(disp, txt->window, txt->fontset.id,
	txt->fontset.width, txt->fontset.height, CenterLDotStack);
    txt->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, txt->gc, False);
    txt->xgc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, txt->xgc, False);
    XSetBackground(disp, txt->xgc, 0);
    txt->disp = disp;
    txt->ic = ic;
    txt->parent = parent;
    txt->current.x = 0;
    txt->current.y = 0;
    txt->started = txt->current;
    txt->pasting = txt->current;
    txt->saved_width = 0;
    txt->pointed = False;
    txt->focus = False;
    txt->focus_delay = 0;
    txt->grabbed = False;
    txt->selected = False;
    txt->stamp = CurrentTime;
    txt->redraw = True;
    txt->format = False;
    txt->converting = 0;
    txt->property = XInternAtom(disp, "TextAreaProperty", False);
    txt->text_atom = XInternAtom(disp, "TEXT", False);
    txt->compound_text_atom = XInternAtom(disp, "COMPOUND_TEXT", False);
    txt->targets_atom = XInternAtom(disp, "TARGETS", False);
    txt->timestamp_atom = XInternAtom(disp, "TIMESTAMP", False);
    return (txt);

no_vscrollbar:    
    XDestroyWindow(txt->disp, txt->window);
no_preferences:
    FreeSylKeymap(txt->keymap);
no_keymap:
    FreeSylTextBlockSet(txt->tbs);
no_text_block_set:
    free(txt);
no_text_area:
    return (NULL);
}

void
FreeSylTextArea(SylTextArea *txt)
{
    XFreePixmap(txt->disp, txt->mark_lf);
    XFreePixmap(txt->disp, txt->mark_eof);
    XFreePixmap(txt->disp, txt->mark_tab);
    XFreePixmap(txt->disp, txt->pixmap);
    if (txt->wallpaper != None)
	XFreePixmap(txt->disp, txt->wallpaper);
    XFreeGC(txt->disp, txt->xgc);
    XFreeGC(txt->disp, txt->gc);
    PutbackSylVScrollbar(txt->vsb);
    XDestroyWindow(txt->disp, txt->window);
    FreeSylKeymap(txt->keymap);
    FreeSylTextBlockSet(txt->tbs);
    if (txt->buf != NULL)
	free(txt->buf);
    free(txt);
}

static void
SetSpotLocation(XIC ic, int x, int y)
{
    XVaNestedList list;
    XPoint spot;
    
    spot.x = x;
    spot.y = y;
    list = XVaCreateNestedList(0, XNSpotLocation, &spot, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}

static void
DrawCursor(SylTextArea *txt, int cx, int cy)
{
    int rx, lx, ty, by;

    if (txt->focus == True) {
        lx = cx - ((txt->fontset.width / 3) & ~1);
        rx = cx + ((txt->fontset.width / 3) & ~1);
        ty = cy + txt->fontset.descent;
        by = cy + txt->fontset.descent + txt->fontset.height - 1;
	XSetLineAttributes(txt->disp, txt->gc, 0,
			   LineSolid, CapButt, JoinRound);
        XDrawLine(txt->disp, txt->pixmap, txt->gc, cx, ty + 1, cx, by - 1);
        XDrawLine(txt->disp, txt->pixmap, txt->gc, lx, ty, cx - 1, ty);
        XDrawLine(txt->disp, txt->pixmap, txt->gc, lx, by, cx - 1, by);
        XDrawLine(txt->disp, txt->pixmap, txt->gc, cx + 1, ty, rx, ty);
        XDrawLine(txt->disp, txt->pixmap, txt->gc, cx + 1, by, rx, by);
        if (txt->ic != NULL) {
            SetSpotLocation(txt->ic, cx, ty + txt->fontset.ascent);
        }
    }
}

static void
DrawNormalText(SylTextArea *txt, int x, int w, int y, wchar_t *s, int n)
{
    /*
      XSetForeground(txt->disp, txt->gc, txt->pixel[0]);
      DrawText(txt->disp, txt->pixmap, &txt->fontset, txt->gc, x, w, y, s, n);
    */
    DrawText(txt, txt->pixel[0], x, w, y, s, n);
}

static void
DrawReverseText(SylTextArea *txt, int x, int w, int y, wchar_t *s, int n,
		unsigned long bg_pixel)
{
    /*
      XSetForeground(txt->disp, txt->gc, bg_pixel);
      XSetBackground(txt->disp, txt->gc, txt->pixel[0]);
      DrawImageText(txt->disp, txt->pixmap, &txt->fontset, txt->gc, x, w, y,
      s, n);
    */
    DrawImageText(txt, bg_pixel, txt->pixel[0], x, w, y, s, n);
}

static void
DrawReverseDumb(SylTextArea *txt, int x, int w, int y, wchar_t *s, int n)
{
    /*
      XSetBackground(txt->disp, txt->gc, txt->pixel[2]);
      DrawImageText(txt->disp, txt->pixmap, &txt->fontset, txt->gc, x, w, y,
      s, n);
    */
    DrawImageText(txt, txt->pixel[0], txt->pixel[2], x, w, y, s, n);
}

static void
DrawTextBody(SylTextArea *txt, SylTextBlock *tb, int m, int n, int cy, 
	     int leftmargin, int topmargin, unsigned long bg,
	     SylLocation *head, SylLocation *tail)
{
    static wchar_t cl_mark[] = {' '};
    wchar_t *str;
    int x, w, y, len, continued = False;

    x = leftmargin;
    y = cy + topmargin;
    len = LengthOfSylText(tb->body[m]);
    str = CreateWCStringFromSylText(tb->body[m], 0, len);

    if (!txt->selected || n < head->y || tail->y < n) {
	DrawNormalText(txt, x, 0, y, str, len);
	continued = False;
    }
    else if (head->y < n && n < tail->y) {
	DrawReverseText(txt, x, 0, y, str, len, bg);
	continued = True;
    }
    else if (head->y == n && n == tail->y) {
	DrawNormalText(txt, x, 0, y, str, head->x);
	w = TextEscapement(&txt->fontset, str, head->x);
	DrawReverseText(txt, x, w, y, str + head->x, tail->x - head->x, bg);
	w = TextEscapement(&txt->fontset, str, tail->x);
	DrawNormalText(txt, x, w, y, str + tail->x, len - tail->x);
	continued = False;
    }
    else if (head->y == n) {
	DrawNormalText(txt, x, 0, y, str, head->x);
	w = TextEscapement(&txt->fontset, str, head->x);
	DrawReverseText(txt, x, w, y, str + head->x, len - head->x, bg);
	continued = True;
    }
    else if (tail->y == n) {
	DrawReverseText(txt, x, 0, y, str, tail->x, bg);
	w = TextEscapement(&txt->fontset, str, tail->x);
	DrawNormalText(txt, x, w, y, str + tail->x, len - tail->x);
	continued = False;
    }

    w = TextEscapement(&txt->fontset, str, len);
    if (EndOfLineSylText(tb->body[m])) {
	if (continued)
	    DrawImageMark(txt, bg, x + w, y, txt->mark_lf);
	else
	    DrawXparentMark(txt, x + w, y, txt->mark_lf);
    }
    else if (tb->next == NULL && m + 1 == tb->n_bodies) {
	DrawXparentMark(txt, x + w, y, txt->mark_eof);
    }
    else
	DrawReverseDumb(txt, x, w, y, cl_mark, 1);
    if (n == txt->current.y) {
	w = TextEscapement(&txt->fontset, str, txt->current.x);
	XSetForeground(txt->disp, txt->gc, txt->pixel[0]);
	DrawCursor(txt, x + w, cy);
    }
    free(str);
}

#if 1
static void
DrawSpot(SylTextArea *txt, int r)
{
    int x, y;

    x = txt->sidemargin;
    y = txt->fontset.descent + txt->fontset.ascent;
    x += GetWidthAtLine(txt->tbs, &txt->fontset,
			txt->current.x, txt->current.y);
    y += (txt->current.y - txt->visible_begin) * txt->baseline_skip;
    XSetForeground(txt->disp, txt->gc, txt->pixel[2]);
    XSetLineAttributes(txt->disp, txt->gc, txt->fontset.descent,
		       LineSolid, CapButt, JoinRound);
    XDrawArc(txt->disp, txt->pixmap, txt->gc,
	     x - r, y - r - txt->fontset.descent, 2 * r,  2 * r,
	     0, 360 * 64);
}
#endif

static void
DrawTextArea(SylTextArea *txt)
{
    SylTextBlock *tb;
    SylLocation left, right;
    int n, y, m, n_lim, offset, leftmargin, topmargin;
    unsigned long bg_pixel;

    leftmargin = txt->sidemargin;
    topmargin = txt->fontset.descent + txt->fontset.ascent;
    bg_pixel = (txt->pointed == True) ? txt->pixel[4] : txt->pixel[1];
    if (txt->wallpaper == None) {
	XSetForeground(txt->disp, txt->gc, bg_pixel);
	XFillRectangle(txt->disp, txt->pixmap, txt->gc,
		       0, 0, txt->width, txt->height);
    }
    else {
	XSetTile(txt->disp, txt->gc, txt->wallpaper);
	XSetFillStyle(txt->disp, txt->gc, FillTiled);
	XFillRectangle(txt->disp, txt->pixmap, txt->gc,
		       0, 0, txt->width, txt->height);
	XSetFillStyle(txt->disp, txt->gc, FillSolid);
    }

    if (txt->visible_begin + txt->visible_cols > txt->tbs->n_lines)
	txt->visible_begin = max(0, txt->tbs->n_lines - txt->visible_cols);
    if (txt->current.y < txt->visible_begin)
	txt->visible_begin = txt->current.y;
    else if (txt->current.y >= txt->visible_begin + txt->visible_cols)
	txt->visible_begin = txt->current.y - txt->visible_cols + 1;
    n = txt->visible_begin;
    n_lim = txt->visible_begin + txt->visible_cols;
    y = 0;
    tb = SeekSylTextBlockAtLine(txt->tbs, n);
    offset = txt->tbs->current_line;
    GetSelectedRegion(txt, &left, &right);
    for (; tb != NULL && n < n_lim; tb = tb->next) {
	for (m = n - offset; n < n_lim && m < tb->n_bodies; ++m) {
	    DrawTextBody(txt, tb, m, n, y, leftmargin, topmargin, bg_pixel,
			 &left, &right);
	    ++n;
	    y += txt->baseline_skip;
	}
	offset += tb->n_bodies;
    }
    if (txt->focus == True) {
	XSetForeground(txt->disp, txt->gc, txt->pixel[0]);
	XSetLineAttributes(txt->disp, txt->gc, 0,
			   LineSolid, CapButt, JoinRound);
	for (n = 0; n < FOCUS_FRAME_WIDTH; ++n) {
	    XDrawRectangle(txt->disp, txt->pixmap, txt->gc, n, n,
			   txt->width - 1 - 2 * n, txt->height - 1 - 2 * n);
	}
    }
}

static void
FormatTextArea(SylTextArea *txt)
{
    SylText *cur, *next;
    SylTextBlock *tb;
    SylTextBlockSet *tbs;
    int y, width, n, len;

    width = TextAreaTextWidth(txt);
    tbs = txt->tbs;
    for (y = 0; (tb = SeekSylTextBlockAtLine(tbs, y)) != NULL; ++y) {
	if (tb->n_bodies >= SYL_TA_LINES_PER_BLOCK) {
	    (void) SplitSylTextBlock(txt->tbs);
	    tb = SeekSylTextBlockAtLine(txt->tbs, y);
	}
	n = y - tbs->current_line;
	while (tb != NULL && EndOfLineSylText(tb->body[n]) == False
	       && (next = NextLineSylTextBlock(tb, n)) != NULL) {
	    len = LengthOfSylText(tb->body[n]);
	    cur = ConcatAndCreateSylText(tb->body[n], next);
	    FreeSylText(tb->body[n]);
	    tb->body[n] = cur;
	    FreeNextLine(tbs, tb, n);
	    if (y < txt->current.y) {
		--(txt->current.y);
		if (y == txt->current.y)
		    txt->current.x += len;
	    }
	}
	if (AdjustAfterInserted(tb->body, n, tb->n_bodies,
				&txt->fontset, width)) {
	    ++(tb->n_bodies);
	    ++(tbs->n_lines);
	    if (y < txt->current.y)
		++(txt->current.y);
	    else if ((y == txt->current.y)
		     && ((len = LengthOfSylText(tb->body[n]))
			 <= txt->current.x)) {
		++(txt->current.y);
		txt->current.x -= len;
	    }
	}
    }
}

int
NiceSylTextArea(SylTextArea *txt)
{
    int x, y;
    
    XFlush(txt->disp);
    if (txt->format == True) {
	FormatTextArea(txt);
	if (txt->width < txt->parent_width
	    && txt->visible_cols >= txt->tbs->n_lines
	    && txt->parent_width > 0) {
	    txt->width = txt->parent_width;
	}
	else if (txt->width >= txt->parent_width
		 && txt->visible_cols < txt->tbs->n_lines
		 && txt->parent_width > SYL_VSB_SEP + SYL_VSB_WIDTH) {
	    txt->width = txt->parent_width - (SYL_VSB_SEP + SYL_VSB_WIDTH);
	}
	else {
	    txt->format = False;
	    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
					      txt->current.x, txt->current.y);
	    XResizeWindow(txt->disp, txt->window, txt->width, txt->height);
	    XFreePixmap(txt->disp, txt->pixmap);
	    txt->pixmap = XCreatePixmap(txt->disp, txt->parent,
					txt->width, txt->height, txt->depth);
	    txt->redraw = True;
	}
	return (1);
    }
    if (txt->redraw == True) {
	if (txt->width < txt->parent_width
	    && txt->visible_cols >= txt->tbs->n_lines
	    && txt->parent_width > 0) {
	    txt->width = txt->parent_width;
	    txt->format = True;
	    return (1);
	}
	else if (txt->width >= txt->parent_width
		 && txt->visible_cols < txt->tbs->n_lines
		 && txt->parent_width > SYL_VSB_SEP + SYL_VSB_WIDTH) {
	    txt->width = txt->parent_width - (SYL_VSB_SEP + SYL_VSB_WIDTH);
	    txt->format = True;
	    return (1);
	}
	else if (txt->focus_delay > 0) {
	    DrawTextArea(txt);
	    DrawSpot(txt, txt->focus_delay);
	    XCopyArea(txt->disp, txt->pixmap, txt->window, txt->gc,
		      0, 0, txt->width, txt->height, 0, 0);
	    XSync(txt->disp, False);
	    txt->focus_delay /= 2;
	    return (1);
	}
	else {
	    DrawTextArea(txt);
	    XCopyArea(txt->disp, txt->pixmap, txt->window, txt->gc,
		      0, 0, txt->width, txt->height, 0, 0);
	    if (txt->vsb->grabbed == False) {
		RangeSylVScrollbar(txt->vsb, txt->tbs->n_lines);
		JumpSylVScrollbar(txt->vsb, txt->visible_begin);
	    }
	    txt->redraw = False;
	}
    }
    if (txt->grabbed == True) {
	GetWindowPointer(txt->disp, txt->window, &x, &y);
	if (y < 0) {
	    GrabbedCursorUp(txt);
	    XFlush(txt->disp);
	    usleep(DRAGGING_SCROLL_DELAY);
	    return (1);
	}
	else if (y >= txt->height) {
	    GrabbedCursorDown(txt); 
	    XFlush(txt->disp);
	    usleep(DRAGGING_SCROLL_DELAY);
	    return (1);
	}
    }
    return (0);
}

static void
LookupKey(SylTextArea *txt, XKeyEvent *key, wchar_t c)
{
    SylKeymap *ptr;

    if (key->state & Mod3Mask) {
	/* NEC PC-98xx: GRPH$B%-!<(B (Mod3Mask) $B$r(BAlt$B%-!<$H$7$F2r<a$5$;$k!#(B*/
	key->state &= ~Mod3Mask;
	key->state |= Mod1Mask;
    }
    if (key->keycode == 0 && c == '\n') {
	/*
	  kinput2: $B%P!<%8%g%s(B2.0.1$B$G$O!"(BReturn/Tab$B$N%-!<%7%`!"%-!<%3!<%I!"(B
	  $B=$>~%-!<$N>uBV$,<N$F$i$l$F$7$^$&!#(Bvje$B$J$i$A$c$s$HF0$/$N$K!#(B
	  Control-m$B$J$iDL$k$N$G!"$"$k0UL#LdBj$O$J$$$s$@$1$I(B...$B!#(B
	*/
	fprintf(stderr, "warning: the current IM does not pass the keycode"
		" of `Return' key.\n");
	LineFeed(txt, key->time);
	return;
    }
    key->state &= (ShiftMask | ControlMask | Mod1Mask);
    for (ptr = txt->keymap[key->keycode]; ptr != NULL; ptr = ptr->next) {
	if (key->state == ptr->mod) {
	    (BranchSylTextArea[ptr->func])(txt, key->time);
	    return;
	}
    }
    if (c >= ' ' || c == '\t')
	InsertChar(txt, c);
}

static void
LookupPressedKeyWithIC(SylTextArea *txt, XKeyEvent *key)
{
    int n, n_lookups;
    KeySym ks;
    Status lookup_status;
#if 0
    /*
      $B;EMM$@$H$3$C$A$G$$$$$O$:$J$N$K(B... $B%9%F!<%?%9$,(BXBufferOverflow$B$N(B
      $B$H$-(BXwcLookupString()$B$NJV$9CM$O!VI,MW$J%P%C%U%!$NBg$-$5!W$N$O$:(B
      $B$@$,!"F~NO%a%=%C%I$K$h$C$F$O>!<j$KF~NO%3%s%F%/%9%H$r@Z$j5M$a$k!#(B
    */
    wchar_t *drain, buf[1], *str = buf;

    n_lookups = XwcLookupString(txt->ic, key, str, 1, &ks, &lookup_status);
    if (lookup_status == XBufferOverflow) {
        if ((str = (wchar_t *)alloca(sizeof(wchar_t) * n_lookups)) == NULL) {
            if ((drain = XwcResetIC(txt->ic)) != NULL)
                XFree(drain);
            return;
        }
        n_lookups = XwcLookupString(txt->ic, key, str, n_lookups, &ks,
                                    &lookup_status);
    }
#else
    wchar_t *drain, str[1024];

    n_lookups = XwcLookupString(txt->ic, key, str, 1024, &ks, &lookup_status);
#endif
    switch (lookup_status) {
    case XBufferOverflow:
        if ((drain = XwcResetIC(txt->ic)) != NULL)
            XFree(drain);
        break;
    case XLookupKeySym:
	/*
	  X11R6.4$B$G$O!"(BXwcLookupString()$B$,H>3Q%+%?%+%J$rJV$5$J$$$h$&$K(B
	  $BJQ99$5$l$?$h$&$G$9!J%-!<%7%`$OJV$k!K!#(B
	*/
        LookupKey(txt, key, 0);
        break;
    case XLookupChars:
        for (n = 0; n < n_lookups; ++n)
            LookupKey(txt, key, str[n]);
        break;
    case XLookupBoth:
        LookupKey(txt, key, str[0]);
        for (n = 1; n < n_lookups; ++n)
            LookupKey(txt, key, str[n]);
        break;
    }
}

static void
SendSelectionReply(SylTextArea *txt, XEvent *ev)
{
    XSelectionRequestEvent *req = &(ev->xselectionrequest);
    SylLocation left, right;
    wchar_t *wcs;
    unsigned int len;

    GetSelectedRegion(txt, &left, &right);
    len = SizeOfSelectedRegion(txt, &left, &right);
    /*
      CopySelectedRegionToWCString()$B$O:G8e$K%L%kJ8;z$rIU2C$9$k$N$G!"(B
      1$BJ8;zJ,B?$/3NJ]$7$F$*$/!#(B
    */
    if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * (len + 1))) != NULL)
	CopySelectedRegionToWCString(txt, &left, &right, wcs);
    SylRespondSelectionRequestWithWCString(req, wcs, txt->stamp,
        txt->targets_atom, txt->timestamp_atom, XA_STRING, txt->text_atom,
	txt->compound_text_atom);
}

static void
GetPixmapProperty(SylTextArea *txt, XEvent *ev)
{
    Pixmap *contents;
    Atom property_type;
    int format, x, y, w, h, border_width, depth;
    long n_items, remain;
    XSelectionEvent *sel = &(ev->xselection);
    Window root;

    if (XGetWindowProperty(sel->display, sel->requestor, sel->property,
			   0, 8192, False, AnyPropertyType,
			   &property_type, &format, &n_items,
			   &remain, (void *)&contents) != Success) {
	return;
    }
    if (property_type == XA_PIXMAP && format == 32 && n_items > 0
	&& (XGetGeometry(txt->disp, contents[0], &root, &x, &y, &w, &h,
			 &border_width, &depth), txt->depth) == depth) {
	if (txt->wallpaper != None)
	    XFreePixmap(txt->disp, txt->wallpaper);
	txt->wallpaper = XCreatePixmap(txt->disp, txt->window, w, h, depth);
	XCopyArea(txt->disp, contents[0], txt->wallpaper, txt->gc,
		  0, 0, w, h, 0, 0);
	txt->redraw = True;
    }
    XFree(contents);
    XDeleteProperty(sel->display, sel->requestor, sel->property);
}

static void
GetWindowProperty(SylTextArea *txt, XEvent *ev)
{
    XTextProperty text;
    wchar_t **list;
    int n_lists, n;
    XSelectionEvent *sel = &(ev->xselection);

    if (sel->property == XA_PIXMAP) {
	GetPixmapProperty(txt, ev);
	return;
    }
    if (sel->property != txt->property) {
	printf("property is different from the requested\n");
	XDeleteProperty(sel->display, sel->requestor, sel->property);
	return;
    }
    if (XGetTextProperty(sel->display, sel->requestor, &text, sel->property)
	== 0) {
	printf("target is %s(%ld), XGetTextProperty failed\n",
	       XGetAtomName(txt->disp, sel->target), sel->target);
	return;
    }
    XDeleteProperty(sel->display, sel->requestor, sel->property);
    if ((n = XwcTextPropertyToTextList(txt->disp, &text, &list, &n_lists))
	< 0) {
	printf("text.value is %s(%ld), XwcTextPropertyToTextList failed\n",
	       text.value, text.nitems);
	XFree(text.value);
	return;
    }
    XFree(text.value);
    /*
      Bug?: text.value$B$K(BJIS$B%3!<%I$GF|K\8l$,3JG<$5$l$F$$$F!"(Btext.value$B$N(B
      $B:G8e$N(B3$B%P%$%H$,(BKanjiOut(0x1b 0x28 0x42)$B$N$H$-!"4X?t(BXwcTextProperty
      ToTextList()$B$O$J$<$+(B3$B$rJV$9!#$3$3$G$O$H$j$"$($:La$jCM(Bn$B$,(B (0$B$N$H$-$O(B
      $B$b$A$m$s(B) $B@5$N$H$-$b=hM}$rB39T$9$k!#(B
    */
    if (txt->selected)
	ResetSelectionOwner(txt);
    txt->current = txt->pasting;
    if (n_lists > 0) {
	for (n = 0; (*list)[n]; ++n) {
	    /*
	      $B$3$N%k!<%WFb$N<BAu$OCY$/!";CDjE*$G$"$k!#(BReadSylTextArea()
	      $B$N$h$&$J<BAu$NJ}$,B?>/$^$7$@$,!":,K\E*$K0lJ8;z$:$D=hM}$9$k(B
	      $BJ}K!$O8zN(E*$G$O$J$$!#(B
	    */
	    if ((*list)[n] >= ' ' || (*list)[n] == '\t')
		InsertChar(txt, (*list)[n]);
	    else if ((*list)[n] == '\n')
		LineFeed(txt, CurrentTime);
	    else
		InsertChar(txt, ' ');
	}
    }
    XwcFreeStringList(list);
    txt->redraw = True;
}

void
SendSylTextArea(SylTextArea *txt, XEvent *ev)
{
    callback = txt;
    if (SendSylVScrollbar(txt->vsb, ev) == 0)
        return;

    switch (ev->type) {
    case Expose:
        if (ev->xexpose.window != txt->window || txt->format == True)
            return;
        XCopyArea(txt->disp, txt->pixmap, txt->window, txt->gc,
            ev->xexpose.x, ev->xexpose.y,
            ev->xexpose.width, ev->xexpose.height,
            ev->xexpose.x, ev->xexpose.y);
        break;
    case EnterNotify:
        if (ev->xcrossing.window != txt->window)
            return;
        txt->pointed = True;
        txt->redraw = True;
        break;
    case LeaveNotify:
        if (ev->xcrossing.window != txt->window)
            return;
        txt->pointed = False;
        txt->redraw = True;
        break;
    case ButtonPress:
        if (ev->xbutton.window != txt->window)
            return;
	if (txt->focus == False) {
	    XSetInputFocus(txt->disp, txt->window, RevertToParent,
			   ev->xbutton.time);
	}
	if (ev->xbutton.button == 1) {
	    XGrabPointer(txt->disp, txt->window, False, ButtonMotionMask
		| ButtonReleaseMask | PointerMotionHintMask,
		GrabModeAsync, GrabModeSync, DefaultRootWindow(txt->disp),
		None, ev->xbutton.time);
	    txt->grabbed = True;
	    txt->current = LocationPointed(txt, ev->xbutton.x, ev->xbutton.y);
	    txt->started = txt->current;
	    txt->redraw = True;
	}
        else if (ev->xbutton.button == 2) {
	    txt->pasting = LocationPointed(txt, ev->xbutton.x, ev->xbutton.y);
	    XConvertSelection(txt->disp, XA_PRIMARY, txt->text_atom,
			      txt->property, txt->window, ev->xbutton.time);
	    XConvertSelection(txt->disp, XA_PRIMARY, XA_PIXMAP,
			      XA_PIXMAP, txt->window, ev->xbutton.time);
	    txt->converting += 2;
	    txt->redraw = True;
        }
	break;
    case MotionNotify:
        if (txt->grabbed != True)
            return;
        /*
	  Bug?: $B%;%l%/%7%g%s$r=jM-$9$k%&%#%s%I%&$,%H%C%W%l%Y%k%&%#%s%I%&(B
	  $B$G$J$$$?$a$+!"F10l%"%W%j%1!<%7%g%s4V$G4X?t(BXSetSelectionOwner()
	  $B$r8F$S=P$7$F$b(BSelectionClear$B%$%Y%s%H$,$3$J$$$3$H$,$"$k!#BP:v$H(B
	  $B$7$F!"(BMotionNotify$B$r<u$1<h$C$F$$$k$H$-$K?7$?$JJ8;zNs$,%I%i%C%0(B
	  $B$5$l$?$i!"(Bowner$B$r(BNone$B$H$7$F4X?t(BXSetSelectionOwner()$B$r8F$S=P$7!"(B
	  $B0lEY6/@)E*$K%;%l%/%7%g%s$N%*!<%J$G$J$/$J$k$h$&$K$7$?!#(B
        */
	if (txt->selected)
	    XSetSelectionOwner(txt->disp, XA_PRIMARY, None, ev->xmotion.time);
	MoveCursorDragged(txt);
	txt->selected = !IsEqualSylLocation(&txt->current, &txt->started);
        txt->redraw = True;
	break;
    case ButtonRelease:
        if (txt->grabbed != True)
            return;
        XUngrabPointer(txt->disp, ev->xbutton.time);
        txt->grabbed = False;
	txt->selected = !IsEqualSylLocation(&txt->current, &txt->started);
	if (txt->selected)
	    SetSelectionOwner(txt, ev->xbutton.time);
	else if (XGetSelectionOwner(txt->disp, XA_PRIMARY) == txt->window)
	    ResetSelectionOwner(txt);
	txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
					  txt->current.x, txt->current.y);
        txt->redraw = True;
        break;
    case FocusIn:
        if (ev->xfocus.window != txt->window
            || ev->xfocus.detail == NotifyPointer)
            return;
        if (txt->ic != NULL)
            XSetICValues(txt->ic, XNFocusWindow, txt->window, NULL);
        txt->focus = True;
        txt->focus_delay = max(txt->width, txt->height);
        txt->redraw = True;
        break;
    case FocusOut:
        if (ev->xfocus.window != txt->window
            || ev->xfocus.detail == NotifyPointer)
            return;
        txt->focus = False;
        txt->focus_delay = 0;
        txt->redraw = True;
        break;
    case KeyPress:
        if (ev->xkey.window != txt->window || txt->focus == False)
            return;
        if (txt->ic != NULL)
            LookupPressedKeyWithIC(txt, &(ev->xkey));
        break;
    case SelectionNotify:
        if (txt->converting == 0 || ev->xselection.selection != XA_PRIMARY)
	    break;
	if (ev->xselection.property != None)
	    GetWindowProperty(txt, ev);
	--(txt->converting);
	break;
    case SelectionClear:
        if (ev->xselectionclear.window != txt->window)
	    break;
	txt->selected = False;
	txt->redraw = True;
        break;
    case SelectionRequest:
        if (ev->xselectionrequest.owner == txt->window && txt->selected)
            SendSelectionReply(txt, ev);
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != txt->parent)
            return;
	txt->parent_width = ev->xconfigure.width;
	txt->parent_height = ev->xconfigure.height;
	txt->visible_cols = max(1, txt->parent_height / txt->baseline_skip);
	/*
	  txt->width$B$K$D$$$F$O%9%/%m!<%k%P!<$,8=$l$k$H7h$a$&$A$7$F@07A(B
	  $B$9$k!#%U%)!<%^%C%H8e!"2hLLFb$K<}$^$j$=$&$J$i$b$&0lEY@07A$7$F(B
	  $B<}B+$5$;$k!#(B
	*/
	txt->width = max(1, txt->parent_width - (SYL_VSB_SEP + SYL_VSB_WIDTH));
	txt->height = txt->visible_cols * txt->baseline_skip;
	XMoveResizeWindow(txt->disp, txt->window,
			  0, (txt->parent_height - txt->height) / 2,
			  txt->width, txt->height);
	if (txt->selected)
	    ResetSelectionOwner(txt);
	XClearWindow(txt->disp, txt->window); /* $B$*9%$_$G$I$&$>!#(B*/
	txt->format = True;
        break;
    }
}

int
ReadSylTextArea(SylTextArea *txt, char *name)
{
    int n, m, len, new_x, new_y, width;
    wchar_t c, *str, *ptr;
    unsigned char *buffer;
    FILE *fp;
    long size;

    XClearWindow(txt->disp, txt->window);
    XFlush(txt->disp);
    if ((fp = fopen(name, "r")) == NULL)
	return (1);
    fseek(fp, 0, SEEK_END);
    size = ftell(fp);
    rewind(fp);
    if ((buffer = (unsigned char *)malloc(size + 1)) == NULL) {
	fclose(fp);
	return (1);
    }
    fread(buffer, size, 1, fp);
    fclose(fp);
    width = TextAreaTextWidth(txt);
    for (m = 0; m < size; m = n + 1) {
	for (n = m; n < size && buffer[n] != '\n'; ++n)
	    ;
	buffer[n] = 0;
	len = n - m + 1;
	if ((str = (wchar_t *)malloc(len * sizeof(wchar_t))) == NULL) {
	    free(buffer);
	    return (1);
	}
	mbstowcs(str, buffer + m, len);
	for (ptr = str; *ptr != 0; ++ptr) {
	    c = ((*ptr >= ' ' || *ptr == '\t') ? *ptr : ' ');
	    InsertCharIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					  txt->current.x, txt->current.y, c,
					  &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
	if (n < size) {
	    InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					      txt->current.x, txt->current.y,
					      &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
	free(str);
    }
    free(buffer);
    txt->current.x = 0;
    txt->current.y = 0;
    txt->saved_width = 0;
    txt->redraw = True;
    return (0);
}

int
WriteSylTextArea(SylTextArea *txt, char *name)
{
    SylTextBlock *tb;
    int y, n, m, s, t, len;
    wchar_t *str;
    unsigned char buffer[sizeof(wchar_t)];
    FILE *fp;

    XFlush(txt->disp);
    if ((fp = fopen(name, "w")) == NULL)
	return (1);
    y = 0;
    for (tb = txt->tbs->top; tb != NULL; tb = tb->next) {
	for (m = 0; m < tb->n_bodies; ++m) {
	    len = LengthOfSylText(tb->body[m]);
	    str = CreateWCStringFromSylText(tb->body[m], 0, len);
	    for (n = 0; n < len; ++n) {
		if ((t = wctomb(buffer, str[n])) > 0) {
		    for (s = 0; s < t; ++s)
			putc((int)buffer[s], fp);
		}
	    }
	    if (EndOfLineSylText(tb->body[m]))
		putc('\n', fp);
	    free(str);
	    ++y;
	}
    }
    fclose(fp);
    return (0);
}

void
ResetSylTextArea(SylTextArea *txt)
{
    if (txt->buf != NULL) {
	free(txt->buf);
	txt->buf = NULL;
    }
    FreeSylTextBlockSet(txt->tbs);
    txt->tbs = CreateSylTextBlockSet();
    txt->visible_begin = 0;
    txt->current.x = 0;
    txt->current.y = 0;
    txt->saved_width = 0;
    txt->redraw = True;
    txt->format = False;
}

void
SetFieldOrderSylTextArea(SylTextArea *txt, Window prev, Window next)
{
    txt->prev_field = prev;
    txt->next_field = next;
}
