/*
        Selection.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

void SylRespondSelectionRequestWithWCString(XSelectionRequestEvent *,
					    wchar_t *, Time,
					    Atom targets_atom,
					    Atom timestamp_atom,
					    Atom string_atom,
					    Atom text_atom,
					    Atom compound_text_atom);
