/*
        Tape.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "Tape.h"

#define THIS_CLASS "Tape"

static SylSetting
    Foreground  = {"foreground",  "Foreground",  "black",   NULL},
    MediumGray  = {"mediumGray",  "MediumGray",  "gray70",  NULL},
    *ColorSet[] = {&Foreground, &MediumGray, NULL};

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

static SylSetting
    LabelStr = {"label", "Label", "", NULL},
    GravityStr = {"gravity", "Gravity", "Center", NULL};

static int
StringToGravity(char *str)
{
    if (strcmp(str, "NorthWest") == 0)
	return (NorthWestGravity);
    else if (strcmp(str, "North") == 0)
	return (NorthGravity);
    else if (strcmp(str, "NorthEast") == 0)
	return (NorthEastGravity);
    else if (strcmp(str, "West") == 0)
	return (WestGravity);
    else if (strcmp(str, "Center") == 0)
	return (CenterGravity);
    else if (strcmp(str, "East") == 0)
	return (EastGravity);
    else if (strcmp(str, "SouthWest") == 0)
	return (SouthWestGravity);
    else if (strcmp(str, "South") == 0)
	return (SouthGravity);
    else if (strcmp(str, "SouthEast") == 0)
	return (SouthEastGravity);
    else 
	return (CenterGravity);
}

static int
PositionX(int parent_width, int width, int gravity)
{
    switch (gravity) {
    case NorthWestGravity:
    case WestGravity:
    case SouthWestGravity:
	return (0);
    case NorthEastGravity:
    case EastGravity:
    case SouthEastGravity:
	return (parent_width - width);
    }
    return ((parent_width - width) / 2);
}

static int
PositionY(int parent_height, int height, int gravity)
{
    switch (gravity) {
    case NorthWestGravity:
    case NorthGravity:
    case NorthEastGravity:
	return (0);
    case SouthWestGravity:
    case SouthGravity:
    case SouthEastGravity:
	return (parent_height - height);
    }
    return ((parent_height - height) / 2);
}

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return (abs(XwcTextEscapement(fs->id, str, len)));
}

static int
TextEscapementOfSylText(SylFontSet *fs, SylText *txt)
{
    int len, width;
    wchar_t *wcs;
    
    len = LengthOfSylText(txt);
    wcs = CreateWCStringFromSylText(txt, 0, len);
    width = TextEscapement(fs, wcs, len);
    free(wcs);
    return (width);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  SylTape *tap)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    LoadSylColorset(disp, fq_name, fq_class, ColorSet, tap->pixel);
    LoadSylFontset(disp, fq_name, fq_class, FontSet, &tap->fontset);
    GetSylSetting(disp, fq_name, fq_class, &LabelStr);
    if ((tap->text = CreateSylTextFromMBString(LabelStr.spec, True)) == NULL)
        return(1);
    GetSylSetting(disp, fq_name, fq_class, &GravityStr);
    tap->gravity = StringToGravity(GravityStr.spec);
    return (0);
}

SylTape *
CreateSylTape(Display *disp, Window parent, char *component)
{
    XWindowAttributes attr;
    SylTape *tap;

    if ((tap = (SylTape *)malloc(sizeof(SylTape))) == NULL)
        goto no_tape;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, tap))
        goto no_preferences;
    tap->sidemargin = 1;
    XGetWindowAttributes(disp, parent, &attr);
    tap->width = TextEscapementOfSylText(&tap->fontset, tap->text)
	+ tap->sidemargin * 2;
    tap->height = tap->fontset.height + tap->sidemargin * 2;
    tap->window = XCreateSimpleWindow(disp, parent,
	PositionX(attr.width, tap->width, tap->gravity),
	PositionY(attr.height, tap->height, tap->gravity),
        tap->width, tap->height, 0, tap->pixel[0], tap->pixel[1]);
    XSelectInput(disp, tap->window, ExposureMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, tap->window);
    XMapRaised(disp, tap->window);
    tap->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, tap->gc, False);
    tap->disp = disp;
    tap->parent = parent;
    tap->redraw = False;
    return (tap);

no_preferences:
    free(tap);
no_tape:
    return (NULL);
}

void
FreeSylTape(SylTape *tap)
{
    XDestroyWindow(tap->disp, tap->window);
    XFreeGC(tap->disp, tap->gc);
    FreeSylText(tap->text);
    free(tap);
}

void
SendSylTape(SylTape *tap, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
        if (ev->xexpose.window != tap->window || ev->xexpose.count > 0)
            break;
	tap->redraw = True;
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != tap->parent)
            return;
        XMoveWindow(tap->disp, tap->window,
	    PositionX(ev->xconfigure.width, tap->width, tap->gravity),
	    PositionY(ev->xconfigure.height, tap->height, tap->gravity));
        tap->redraw = True;
        break;
    }
}

static void
DrawWindow(SylTape *tap)
{
    int len;
    wchar_t *wcs;

    len = LengthOfSylText(tap->text);
    wcs = CreateWCStringFromSylText(tap->text, 0, len);
    XSetForeground(tap->disp, tap->gc, tap->pixel[0]);
    XwcDrawString(tap->disp, tap->window, tap->fontset.id, tap->gc,
                  tap->sidemargin, tap->fontset.ascent + tap->sidemargin,
		  wcs, len);
    free(wcs);
}

int
NiceSylTape(SylTape *tap)
{
    XFlush(tap->disp);
    if (tap->redraw == True) {
        DrawWindow(tap);
        tap->redraw = False;
    }
    return (0);
}
