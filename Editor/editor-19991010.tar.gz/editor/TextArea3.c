/*
        TextArea3.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "TextArea.h"
#include "TextArea3.h"

void
DrawImageMark(SylTextArea *txt, unsigned int bg, int x, int y, Pixmap m)
{
    XSetForeground(txt->disp, txt->gc, bg);
    XSetBackground(txt->disp, txt->gc, txt->pixel[5]);
    XCopyPlane(txt->disp, m, txt->pixmap, txt->gc,
	       0, 0, txt->fontset.width, txt->fontset.height,
	       x, y - txt->fontset.ascent, 1);
}

void
DrawXparentMark(SylTextArea *txt, int x, int y, Pixmap m)
{
    XSetFunction(txt->disp, txt->xgc, GXandInverted);
    XSetForeground(txt->disp, txt->xgc, ~0);
    XCopyPlane(txt->disp, m, txt->pixmap, txt->xgc,
	       0, 0, txt->fontset.width, txt->fontset.height,
	       x, y - txt->fontset.ascent, 1);
    XSetFunction(txt->disp, txt->xgc, GXor);
    XSetForeground(txt->disp, txt->xgc, txt->pixel[5]);
    XCopyPlane(txt->disp, m, txt->pixmap, txt->xgc,
	       0, 0, txt->fontset.width, txt->fontset.height,
	       x, y - txt->fontset.ascent, 1);
}

/**/

static int
SpanEscapement(SylFontSet *fs, wchar_t *str, int len, int *w)
{
    int n;

    for (n = 0; n < len && str[n] != '\t'; ++n)
	;
    if (n > 0)
	*w += abs(XwcTextEscapement(fs->id, str, n));
    if (n < len) {
	*w += fs->width - 1 + fs->tabsep;
	*w /= fs->tabsep;
	*w *= fs->tabsep;
	++n;
    }
    return (n);
}

int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
#if 0
    return (abs(XwcTextEscapement(fs->id, str, len)));
#else
    int n, w;

    w = 0;
    while ((n = SpanEscapement(fs, str, len, &w)) < len) {
	str += n;
	len -= n;
    }	
    return (w);
#endif
}

/**/

static int
DrawSpan(SylTextArea *t, unsigned int fg,
	 int x, int y, wchar_t *str, int len, int *w)
{
    int n, m = 0;

    for (n = 0; n < len && str[n] != '\t'; ++n)
	;
    if (n > 0) {
	XSetForeground(t->disp, t->gc, fg);
	XwcDrawString(t->disp, t->pixmap, t->fontset.id, t->gc,
		      x, y, str, n);
	m = abs(XwcTextEscapement(t->fontset.id, str, n));
	*w += m;
    }
    if (n < len) {
	*w += t->fontset.width - 1 + t->fontset.tabsep;
	*w /= t->fontset.tabsep;
	*w *= t->fontset.tabsep;
	DrawXparentMark(t, x + m, y, t->mark_tab);
	++n;
    }
    return (n);
}

void
DrawText(SylTextArea *t, unsigned int fg,
	 int x, int w, int y, wchar_t *str, int len)
{
    int n;

    while ((n = DrawSpan(t, fg, x + w, y, str, len, &w)) < len) {
	str += n;
	len -= n;
    }	
}

void
DrawTextWithUnderline(SylTextArea *t, unsigned int fg,
		      int x, int w, int y, wchar_t *str, int len)
{
    int m, n;

    m = w;
    while ((n = DrawSpan(t, fg, x + w, y, str, len, &w)) < len) {
	str += n;
	len -= n;
    }	
    y += t->fontset.descent / 2;
    XSetLineAttributes(t->disp, t->gc, t->fontset.descent / 2,
		       LineSolid, CapButt, JoinRound);
    XDrawLine(t->disp, t->pixmap, t->gc, x + m, y, x + w, y);
}

static int
DrawImageSpan(SylTextArea *t, unsigned int fg, unsigned int bg,
	      int x, int y, wchar_t *str, int len, int *w)
{
    int n, d, m = 0;

    for (n = 0; n < len && str[n] != '\t'; ++n)
	;
    if (n > 0) {
	XSetForeground(t->disp, t->gc, fg);
	XSetBackground(t->disp, t->gc, bg);
	XwcDrawImageString(t->disp, t->pixmap, t->fontset.id, t->gc,
			   x, y, str, n);
	m = abs(XwcTextEscapement(t->fontset.id, str, n));
	*w += m;
    }
    if (n < len) {
	d = *w;
	*w += t->fontset.width - 1 + t->fontset.tabsep;
	*w /= t->fontset.tabsep;
	*w *= t->fontset.tabsep;
	d = *w - d;
	XSetForeground(t->disp, t->gc, t->pixel[5]);
	XFillRectangle(t->disp, t->pixmap, t->gc, x + m, y - t->fontset.ascent,
		       d, t->fontset.height);
	DrawImageMark(t, fg, x + m, y, t->mark_tab);
	++n;
    }
    return (n);
}

void
DrawImageText(SylTextArea *t, unsigned int fg, unsigned int bg,
	      int x, int w, int y, wchar_t *str, int len)
{
    int n;

    while ((n = DrawImageSpan(t, fg, bg, x + w, y, str, len, &w))
	   < len) {
	str += n;
	len -= n;
    }	
}

/**/

static SylTextBlock *
CreateSylTextBlock(void)
{
    SylTextBlock *tb;

    if ((tb = (SylTextBlock *)malloc(sizeof(SylTextBlock))) == NULL)
	return (NULL);
    tb->next = NULL;
    tb->prev = NULL;
    tb->n_bodies = 0;
    return (tb);
}

static void
FreeSylTextBlock(SylTextBlock *tb)
{
    int n;

    for (n = 0; n < tb->n_bodies; ++n)
	FreeSylText(tb->body[n]);
    free(tb);    
}

/*
  tbs->cur$B$N(B `$B<!$K(B' $B?7$7$$(BSylTextBlock$B$rA^F~$7!"A^F~$7$?(BSylTextBlock
  $B$X$N%]%$%s%?$rJV$9(B. 
*/
static SylTextBlock *
InsertSylTextBlock(SylTextBlockSet *tbs)
{
    SylTextBlock *tb;

    if ((tb = CreateSylTextBlock()) == NULL)
	return (NULL);
    if (tbs->top == NULL) {
	tb->prev = NULL;
	tb->next = NULL;
	tbs->top = tb;
	tbs->last = tb;
	tbs->current_block = 0;
	tbs->current_line = 0;
    }
    else {
	if (tbs->cur == tbs->last) {
	    tb->next = NULL;
	    tbs->last = tb;
	}
	else {
	    tb->next = tbs->cur->next;
	    tb->next->prev = tb;
	}
	tb->prev = tbs->cur;
	tb->prev->next = tb;
	tbs->current_line += tbs->cur->n_bodies;
	++(tbs->current_block);
    }
    tbs->cur = tb;
    return (tb);
}


SylTextBlockSet *
CreateSylTextBlockSet(void)
{
    wchar_t null = 0;
    SylTextBlock *tb;
    SylTextBlockSet *tbs;

    if ((tbs = (SylTextBlockSet *)malloc(sizeof(SylTextBlockSet))) == NULL)
	return (NULL);
    tbs->top = NULL;
    tbs->cur = NULL;
    tbs->last = NULL;
    tbs->current_block = 0;
    tbs->n_lines = 0;
    tb = InsertSylTextBlock(tbs);
    tb->body[0] = CreateSylTextFromWCString(&null, False);
    ++(tb->n_bodies);
    tbs->n_lines = 1;
    return (tbs);
}

void
FreeSylTextBlockSet(SylTextBlockSet *tbs)
{
    SylTextBlock *ptr, *next;

    for (ptr = tbs->top; ptr != NULL;) {
	next = ptr->next;
	FreeSylTextBlock(ptr);
	ptr = next;
    }
    free(tbs);
}

/*
  tb->body[n]$B$N<!$N9T$G$"$k(BSylText$B$X$N%]%$%s%?$rJV$9(B.
*/
SylText *
NextLineSylTextBlock(SylTextBlock *tb, int n)
{
    if (n + 1 >= tb->n_bodies) {
	if ((tb = tb->next) == NULL)
	    return (NULL);
	return (tb->body[0]);
    }
    return (tb->body[n + 1]);
}

/*
  tb->body[n]$B$NA0$N9T$G$"$k(BSylText$B$X$N%]%$%s%?$rJV$9(B.
*/
SylText *
PrevLineSylTextBlock(SylTextBlock *tb, int n)
{
    if (n - 1 < 0) {
	if ((tb = tb->prev) == NULL)
	    return (NULL);
	return (tb->body[tb->n_bodies - 1]);
    }
    return (tb->body[n - 1]);
}

/*
  tbs$B$K=jB0$7$F$$$k(Btb$B$N(Btb->body[n]$B$N(B `$B<!$N(B' $B9T$r:o=|$9$k(B.
*/
void
FreeNextLine(SylTextBlockSet *tbs, SylTextBlock *tb, int n)
{
    int k;
    SylTextBlock *nb, *next;

    if (n + 1 >= tb->n_bodies) {
	nb = tb->next;
	FreeSylText(nb->body[0]);
	for (k = 1; k < nb->n_bodies; ++k)
	    nb->body[k - 1] = nb->body[k];
	if (--(nb->n_bodies) == 0) {
	    next = nb->next;
	    free(nb);
	    nb = next;
	    tb->next = nb;
	    if (nb != NULL)
		nb->prev = tb;
	    else
		tbs->last = tb;
	}
    }
    else {
	FreeSylText(tb->body[n + 1]);
	for (k = n + 2; k < tb->n_bodies; ++k)
	    tb->body[k - 1] = tb->body[k];
	--(tb->n_bodies);
    }
    --(tbs->n_lines);
}

/*
  tbs->cur$B$rA0H>$H8eH>$N(B2$B$D$N(BSylTextBlock$B$KJ,3d$9$k(B. $BLa$jCM$O8eH>$N(B
  SylTextBlock$B$X$N%]%$%s%?(B. tbs->cur$B$b8eH>$N(BSylTextBlock$B$r;X$9$h$&$K(B
  $BJQ99$5$l$k(B. $B8F$S=P$9A0$K(Btbs->cur->n_bodies$B$,(B(SYL_TA_LINES_PER_BLOCK / 2)
  $B$h$j$bBg$-$/$J$1$l$P$J$i$J$$(B.
*/
SylTextBlock *
SplitSylTextBlock(SylTextBlockSet *tbs)
{
    int n, m;
    SylTextBlock *dst, *src;

#ifdef TRACE
    printf("SplitSylTextBlock: entered\n");
#endif
    dst = InsertSylTextBlock(tbs);
    src = dst->prev;
    for (n = 0, m = (SYL_TA_LINES_PER_BLOCK / 2); n < m; ++n)
	dst->body[n] = src->body[m + n];
    src->n_bodies = m;
    dst->n_bodies = m;
    tbs->current_line -= m;
    tbs->cur = dst;
#ifdef TRACE
    printf("SplitSylTextBlock: leaved\n");
#endif
    return (dst);
}

/*
  y$B9TL\$r4^$`(BSylTextBlock$B$r;X$9$h$&$K(Btbs->cur$B$rJQ99$9$k(B. $BLa$jCM$O(B
  tbs->cur$B$HEy$7$/$J$k(B.
*/
SylTextBlock *
SeekSylTextBlockAtLine(SylTextBlockSet *tbs, int y)
{
    if (tbs->top == NULL) {
#if 1
	printf("SeekSylTextBlockAtLine: warning: tbs->top is null.");
#endif
	InsertSylTextBlock(tbs);
    }
    while (y < tbs->current_line) {
	tbs->cur = tbs->cur->prev;
	--(tbs->current_block);
	tbs->current_line -= tbs->cur->n_bodies;
    }
    while (y >= tbs->current_line + tbs->cur->n_bodies
	   && tbs->cur->next != NULL) {
	tbs->current_line += tbs->cur->n_bodies;
	++(tbs->current_block);
	tbs->cur = tbs->cur->next;
    }
    if (y >= tbs->current_line + tbs->cur->n_bodies)
	return (NULL);
    return (tbs->cur);
}

/*
  body[n]$B$N(Bx$BJ8;zL\$K(BLF$B$rA^F~$9$k(B. $B8F$S=P$9A0$K!"(Bn_bodies$B$,(BSYL_TA_LINES_
  PER_BLOCK$B$h$j$b>.$5$$I,MW$,$"$k(B. $BLa$C$?8e!"8F$S=P$7B&$O(BSylTextBlock$B$N(B
  $B%a%s%P(Bn_bodies$B$r=$@5$9$kI,MW$,$"$k!#(B
*/
void
InsertLineFeedIntoSylTextBlock(SylText **body, int n, int x, int n_bodies)
{
    int k;
    SylText *txt;

    for (k = n_bodies; k > n; --k)
	body[k] = body[k - 1];
    txt = body[n];
    SplitAndCreateSylTexts(txt, x, True, &body[n], &body[n + 1]);
    FreeSylText(txt);
}

/*
  $BJ8;zA^F~8e$N(Bbody[n]$B$,0l9T$NI}(Bwidth$B!J%T%/%;%k?t!K$K<}$^$i$J$1$l$P(B
  $BJ,3d$9$k!#8F$S=P$9A0$K!"(Bn_bodies$B$,(BSYL_TA_LINES_PER_BLOCK$B$h$j$b>.$5$$(B
  $BI,MW$,$"$k(B. $BLa$jCM$H$7$F!"J,3d$7$?>l9g$O(B1$B$r!"$7$J$+$C$?>l9g$O(B0$B$r(B
  $BJV$9!#La$jCM$,(B1$B$N$H$-$O!"8F$S=P$7B&$O(BSylTextBlock$B$N%a%s%P(Bn_bodies$B$r(B
  $B=$@5$9$kI,MW$,$"$k!#(B
*/
int
AdjustAfterInserted(SylText **body, int n, int n_bodies,
		    SylFontSet *fs, int width)
{
    int k, len;
    wchar_t *str;
    SylText *txt;

    len = LengthOfSylText(body[n]);
    str = CreateWCStringFromSylText(body[n], 0, len);
#if 0
    while (TextEscapement(fs, str, len) > width && len > 1)
	--len;
#else
    if (TextEscapement(fs, str, len) > width && len > 1) {
	int len_min, len_max;

	len_min = 1;
	len_max = len;
	while (len_max - len_min > 1) {
	    len = (len_max + len_min) / 2;
	    if (TextEscapement(fs, str, len) > width)
		len_max = len;
	    else
		len_min = len;
	}    
	len = len_min;
    }
#endif
    free(str);
    if (len == LengthOfSylText(body[n]))
	return (0);
    for (k = n_bodies; k > n; --k)
	body[k] = body[k - 1];
    txt = body[n];
    SplitAndCreateSylTexts(txt, len, False, &body[n], &body[n + 1]);
    FreeSylText(txt);
    return (1);
}

void
Reformat(SylTextBlockSet *tbs, int y, SylFontSet *fs, int width)
{
    int n;
    SylText *cur, *next;
    SylTextBlock *tb;

#ifdef TRACE
    printf("Reformat: entered\n");
#endif
    tb = SeekSylTextBlockAtLine(tbs, y);
    n = y - tbs->current_line;
#ifdef TRACE
    printf("Reformat: n=%d, y=%d, current_line=%d\n", n, y, tbs->current_line);
#endif
    while (tb != NULL && EndOfLineSylText(tb->body[n]) == False
	   && (next = NextLineSylTextBlock(tb, n)) != NULL) {
	cur = ConcatAndCreateSylText(tb->body[n], next);
	FreeSylText(tb->body[n]);
	tb->body[n] = cur;
	FreeNextLine(tbs, tb, n);
	if (tb->n_bodies >= SYL_TA_LINES_PER_BLOCK) {
	    y = tbs->current_line + n;
	    (void) SplitSylTextBlock(tbs);
	    tb = SeekSylTextBlockAtLine(tbs, y);
	    n = y - tbs->current_line;
	}
	if (AdjustAfterInserted(tb->body, n, tb->n_bodies, fs, width)) {
	    ++(tb->n_bodies);
	    ++(tbs->n_lines);
	}
	if (++n >= tb->n_bodies) {
	    tb = SeekSylTextBlockAtLine(tbs, tbs->current_line + n);
	    n = 0;
	}
    }
#ifdef TRACE
    printf("Reformat: leaved\n");
#endif
}
