/*
        Text.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "WCString.h"
#include "Text.h"

SylText *
CreateSylTextFromMBString(char *mbs, int eol)
{
    SylText *txt;
    wchar_t *wcs;
    int bytes, len;

    bytes = strlen(mbs) + 1;
    if ((wcs = (wchar_t *)alloca(sizeof(MB_LEN_MAX) * bytes)) == NULL
        /*
	  $BCm0U(B: $B4X?t(Bmbstowcs(wc_dst, mb_src, n_bytes)$B$N(B3$BHVL\$N0z?t$K$O!"(B
	  $B%L%kJ8;z$r4^$a$?%5%$%:$rM?$($J$$$H!":G8e$K!V%o%$%I%-%c%i%/%?J8;z(B
	  $BNs$N%L%kJ8;z!W$rIU2C$7$J$$!#$D$^$j!"(B1$BHVL\$N0z?t$N%P%C%U%!%5%$%:$r(B
	  $BM?$($J$1$l$P$J$i$J$$!#(B
        */
        || (len = mbstowcs(wcs, mbs, bytes)) < 0
        || (txt = (SylText *)malloc(sizeof(SylText))) == NULL) {
        return (NULL);
    }
    if ((txt->wcs = (wchar_t *)malloc(sizeof(wchar_t) * (len + 1))) == NULL) {
        free(txt);
        return (NULL);
    }
    wstrcpy(txt->wcs, wcs);
    txt->len = len;
    txt->eol = eol;
    return (txt);
}

SylText *
CreateSylTextFromWCString(wchar_t *wcs, int eol)
{
    SylText *txt;
    
    if ((txt = (SylText *)malloc(sizeof(SylText))) == NULL)
	return (NULL);
    txt->len = wstrlen(wcs);
    txt->eol = eol;
    if ((txt->wcs = (wchar_t *)malloc((txt->len + 1) * sizeof(wchar_t)))
	== NULL) {
	free(txt);
	return (NULL);
    }
    wstrcpy(txt->wcs, wcs);
    return (txt);
}

void
FreeSylText(SylText *txt)
{
    free(txt->wcs);
    free(txt);
}

wchar_t *
CreateWCStringFromSylText(SylText *txt, int bgn, int end)
{
    wchar_t *wcs;

    if ((wcs = (wchar_t *)malloc((end - bgn + 1) * sizeof(wchar_t))) == NULL)
	return (NULL);
    wstrncpy(wcs, txt->wcs + bgn, end - bgn);
    wcs[end - bgn] = 0;
    return (wcs);
}

char *
CreateMBStringFromSylText(SylText *txt, int bgn, int end)
{
    int bytes;
    char *mbs;

    bytes = sizeof(MB_LEN_MAX) * (end - bgn + 1);
    if ((mbs = (char *)alloca(bytes)) == NULL
	/*
	  wcstombs()$B$NLa$jCM$O(Bsize_t$B$@$,!"(Bman$B%Z!<%8$K$h$k$H(B-1$B$rJV$9(B
	  $B$3$H$b$"$k!#(B
	*/
	|| (int)wcstombs(mbs, txt->wcs, bytes) < 0) {
        return (NULL);
    }
    return (strdup(mbs));
}

void
InsertWCharIntoSylText(SylText *txt, int n, wchar_t c)
{
    wchar_t *sum;
    int len;

    len = txt->len + 1;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return;
    wstrncpy(sum, txt->wcs, n);
    sum[n] = c;
    wstrcpy(sum + n + 1, txt->wcs + n);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
}

void
InsertWCStringIntoSylText(SylText *txt, int n, wchar_t *p)
{
#if 0
    while (*p) {
	InsertWCharIntoSylText(txt, n, *p);
	++n;
	++p;
    }
#else
    wchar_t *sum;
    int len, add;

    add = wstrlen(p);
    len = txt->len + add;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return;
    wstrncpy(sum, txt->wcs, n);
    wstrcpy(sum + n, p);
    wstrcpy(sum + n + add, txt->wcs + n);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
#endif
}

void
DeleteWCharOfSylText(SylText *txt, int n)
{
    wchar_t *sum;
    int len;

    if (txt->len <= 0 || txt->len <= n)
	return;
    len = txt->len - 1;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return;
    wstrncpy(sum, txt->wcs, n);
    wstrcpy(sum + n, txt->wcs + n + 1);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
}

void
DeleteWCStringOfSylText(SylText *txt, int n, int m)
{
#if 0
    for (m -= n; m > 0; --m) {
	DeleteWCharOfSylText(txt, n);
    }
#else
    wchar_t *sum;
    int len;

    if (txt->len <= 0 || txt->len <= n || txt->len < m || n >= m)
	return;
    len = txt->len - (m - n);
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	 return;
    wstrncpy(sum, txt->wcs, n); 
    wstrcpy(sum + n, txt->wcs + m);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
#endif
}

void
ChangeEndOfLineSylText(SylText *txt, int eol)
{
    txt->eol = eol;
}

/*
  head$B$N8e$K(Btail$B$rO"7k$7$?FbMF$HEy$7$$(BSylText$B$r:n@.$7JV$9(B.
*/
SylText *
ConcatAndCreateSylText(SylText *head, SylText *tail)
{
    wchar_t *s, *d;
    SylText *txt;
    
    if ((txt = (SylText *)malloc(sizeof(SylText))) == NULL)
	return (NULL);
    txt->len = LengthOfSylText(head) + LengthOfSylText(tail);
    txt->eol = EndOfLineSylText(tail);
    if ((txt->wcs = (wchar_t *)malloc((txt->len + 1) * sizeof(wchar_t)))
	== NULL) {
	free(txt);
	return (NULL);
    }
    d = txt->wcs;
    for (s = head->wcs; *s != 0; ++s)
	*d++ = *s;
    for (s = tail->wcs; *s != 0; ++s)
	*d++ = *s;
    *d = 0;
    return (txt);
}

/*
  txt$B$N(Bn$BJ8;zL\$^$G$NFbMF$r(Bhead$B$K!"(Bn$BJ8;zL\0J9_$NFbMF$r(Btail$B$K:n@.$9$k(B.
*/
void
SplitAndCreateSylTexts(SylText *txt, int n, int eol,
		       SylText **head, SylText **tail)
{
    if ((*head = (SylText *)malloc(sizeof(SylText))) != NULL) {
	(*head)->wcs = CreateWCStringFromSylText(txt, 0, n);
	(*head)->len = n;
	(*head)->eol = eol;
    }
    if ((*tail = (SylText *)malloc(sizeof(SylText))) != NULL) {
	(*tail)->wcs = CreateWCStringFromSylText(txt, n, LengthOfSylText(txt));
	(*tail)->len = LengthOfSylText(txt) - n;
	(*tail)->eol = EndOfLineSylText(txt);
    }
}

int
CompareSylText(SylText *t1, SylText *t2)
{
    return (wstrcmp(t1->wcs, t2->wcs));
}
