typedef struct SylNull {
    Display *disp;
    Window parent;
} SylNull;

SylNull * CreateSylNull(Display *, Window);
void FreeSylNull(SylNull *);
