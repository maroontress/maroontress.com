/*
        TextArea1.h 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

void GetSelectedRegion(SylTextArea *txt, SylLocation *left,
		       SylLocation *right);
unsigned int SizeOfRegion(SylTextArea *txt, SylLocation *left,
			  SylLocation *right);
void CopyRegionToWCString(SylTextArea *txt, SylLocation *left,
			  SylLocation *right, wchar_t *wcs);
void DeleteRegion(SylTextArea *txt, SylLocation *left,
		  SylLocation *right); /* 1999-10-09: added */
void SetSelectionOwner(SylTextArea *txt, Time tm);
void ResetSelectionOwner(SylTextArea *txt);

int IsEqualSylLocation(SylLocation *p, SylLocation *q);
SylLocation LocationOfDestination(SylTextArea *, SylLocation *, int);
SylLocation LocationPointed(SylTextArea *txt, int w, int h);

void InsertWCharIntoSylTextArea(SylTextArea *txt, wchar_t c);

int RowsAfterMovingVertically(SylTextArea *txt); /* 1999-10-09: added */

void GrabbedCursorUp(SylTextArea *txt);
void GrabbedCursorDown(SylTextArea *txt);

extern void (*BranchSylTextArea[])(SylTextArea *, Time);
