/*
        TextLine.h 1.3 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999, 2000, 2001 Syllabub
        Maroontress Fast Software.
*/

typedef struct SylTextLine {
    Display *disp;
    Window parent;
    Window window;
    Window next_field;
    Window prev_field;
    Pixmap pixmap;
    GC gc;
    SylFontSet fontset;
    int width;
    int height;
    int sidemargin;
    int textwidth;
    int depth;
    int gravity;
    unsigned long *pixel;
    SylKeymap **keymap;

    SylText *text;
    int size;
    int left;
    int cursor;
    int right;
    int dragging;
    int left_dragged;
    int right_dragged;
    int pointed;
    int focus;
    int ic_focus;
    int frame_width;
    int grabbed;
    int redraw;
    SylPreedit preedit;    /* ON_THE_SPOT: $BA0JT=8J8;zNs(B $B6&DL>pJs(B */
    int preedit_drawing;   /* ON_THE_SPOT: $B%U%#!<%I%P%C%/$NIA2h>uBV(B */
    int preedit_begin;     /* ON_THE_SPOT: $BA0JT=83+;O0LCV(B */
    Time stamp;            /* $B%;%l%/%7%g%s3MF@$K;HMQ$7$?%?%$%`%9%?%s%W(B */
    Atom property;
    Atom text_atom;
    Atom compound_text_atom;
    Atom targets_atom;
    Atom timestamp_atom;
    void (*callback)(int);
} SylTextLine;

SylTextLine * CreateSylTextLine(Display *, Window, char *, void (*)(int));
void FreeSylTextLine(SylTextLine *);
void SendSylTextLine(SylTextLine *, XEvent *);
int NiceSylTextLine(SylTextLine *);
void SetFieldOrderSylTextLine(SylTextLine *, Window, Window);
void SetICSylTextLine(SylTextLine *, XIC, XIMStyle);
int GetMBStringSylTextLine(SylTextLine *, char *);
void SetMBStringSylTextLine(SylTextLine *, char *); /* added */
