/*
        Preedit.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999, 2000 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Preedit.h"

#define ON_THE_SPOT
#if 0
#define USE_KINPUT2
#endif

void
ReserveSylPreedit(SylPreedit *ped)
{
    ped->ic = NULL;
    ped->style = XIMPreeditNone | XIMStatusNone;
    ped->n_chars = 0;
    ped->caret = 0;
    ped->feedback = NULL;
}

void
SetICAndStyleToSylPreedit(SylPreedit *ped, XIC ic, XIMStyle style)
{
    ped->ic = ic;
    ped->style = style;
}

void
PutbackSylPreedit(SylPreedit *ped)
{
    if (ped->feedback != NULL)
	free(ped->feedback);
}

void
ResetSylPreedit(SylPreedit *ped, void *cb_data,
		void (*delete)(void *, int, int))
{
    char *mbs;

    /*
       XwcResetIC()$B$NLa$jCM$r(BXFree()$B$9$k$H<!$N%a%C%;!<%8$,I=<($5$l$k!#(B
       in free(): warning: junk pointer, too high to make sense

       $B$7$+$?$J$$$N$G!"(BXmbResetIC()$B$r;H$&!#(B
    */
    if ((mbs = XmbResetIC(ped->ic)) != NULL) {
#ifdef DEBUG
	printf("Preedit: ResetIC(): %s\n", mbs);
#endif
	XFree(mbs);
    }
#if defined(ON_THE_SPOT) && defined(USE_KINPUT2)
    /*
      2000-02-07: kinput2$B$O!"(BXmbResetIC()$B$N8e$KA0JT=8IA2h%3!<%k%P%C%/$r(B
      $B8F$S=P$5$:!"$=$N7k2L%/%i%$%"%s%HB&$NA0JT=8J8;zNs$r>C5n$7$J$$$?$a!"(B
      $B$3$3$G<+H/E*$K>C5n$7$F$*$/!#A0JT=8IA2h%3!<%k%P%C%/$r8F$S=P$7$F(B
      $B%/%i%$%"%s%HB&$NA0JT=8J8;zNs$r>C5n$9$k(BIM$B%5!<%P$K$H$C$F!"$3$N=hCV$O(B
      $BITMW$G$"$j!"A0JT=8J8;zNs$NIT@09g$N860x$H$J$j$&$k$,!"A0JT=8IA2h(B
      $B%3!<%k%P%C%/B&$N2sI|=hM}$G<BMQ>eLdBj$J$/BP=h$7$F$$$k!#(B
    */
    if (ped->n_chars > 0) {
	delete(cb_data, 0, ped->n_chars);
	ped->n_chars = 0;
	ped->caret = 0;
	if (ped->feedback != NULL)
	    free(ped->feedback);
	ped->feedback = NULL;
    }
#endif /* #if defined(ON_THE_SPOT) && defined(USE_KINPUT2) */
}

#ifdef ON_THE_SPOT
/*
  StartSylPreedit:

  static void
  InitCB(void *cb_data)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
    .
  }

  static int
  MyPreeditStart(XIC ic, MyObject *obj, void *call_data)
  {
    return (StartSylPreedit(&obj->preedit, ic, call_data, obj, InitCB));
  }
*/

int
StartSylPreedit(SylPreedit *ped, XIC ic, void *call_data,
		void *cb_data, void (*init)(void *))
{
#ifdef DEBUG
    printf("Preedit: Start\n");
#endif
    if (ped->ic != ic) {
#ifdef DEBUG
	printf("Preedit: Start: invalid arguments (invalid ic)\n");
#endif
	return (0);
    }
    if (call_data != NULL) {
#ifdef DEBUG
	printf("Preedit: Start: invalid arguments (invalid call_data)\n");
#endif
	return (0);
    }
    ped->n_chars = 0;
    ped->caret = 0;
    ped->feedback = NULL;
    init(cb_data);
    return (-1);
}

/*
  DoneSylPreedit:

  static void
  DeleteCB(void *cb_data, int first, int length)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
    .
  }

  static void
  MyPreeditDone(XIC ic, MyObject *obj, void *call_data)
  {
    DoneSylPreedit(&obj->preedit, ic, call_data, obj, DeleteCB);
  }
*/

void
DoneSylPreedit(SylPreedit *ped, XIC ic, void *call_data,
	       void *cb_data, void (*delete)(void *, int, int))
{
#ifdef DEBUG
    printf("Preedit: Done\n");
#endif
    if (ped->ic != ic) {
#ifdef DEBUG
	printf("Preedit: Done: invalid arguments (invalid ic)\n");
#endif
	return;
    }
    if (call_data != NULL) {
#ifdef DEBUG
	printf("Preedit: Start: invalid arguments (invalid call_data)\n");
#endif
	return;
    }
    if (ped->n_chars > 0) {
	delete(cb_data, 0, ped->n_chars);
	ped->n_chars = 0;
	ped->caret = 0;
	if (ped->feedback != NULL)
	    free(ped->feedback);
	ped->feedback = NULL;
    }
}

static void
DeletePreedit(SylPreedit *ped, XIMPreeditDrawCallbackStruct *dcs,
	      void *cb_data, void (*delete)(void *, int, int))
{
    int n, len;
    XIMFeedback *fb;

    if (dcs->chg_length <= 0)
	return;
    if (dcs->chg_first < 0 || dcs->chg_first > ped->n_chars
	|| dcs->chg_first + dcs->chg_length > ped->n_chars) {
#ifdef DEBUG
	printf("Preedit: Draw: invalid chg_first, chg_length\n");
#endif
	return;
    }
    delete(cb_data, dcs->chg_first, dcs->chg_length);
    ped->caret = dcs->chg_first;
    ped->n_chars -= dcs->chg_length;
	    
    if ((len = ped->n_chars) == 0) {
	if (ped->feedback != NULL)
	    free(ped->feedback);
	ped->feedback = NULL;
    }
    else {
	if ((fb = (XIMFeedback *)malloc(sizeof(XIMFeedback) * len)) != NULL) {
	    for (n = 0; n < dcs->chg_first; ++n)
		fb[n] = ped->feedback[n];
	    for (; n < len; ++n)
		fb[n] = ped->feedback[n + dcs->chg_length];
	}
	if (ped->feedback != NULL)
	    free(ped->feedback);
	ped->feedback = fb;
    }
}

#ifdef DEBUG
static void
PrintFeedbackChar(long c)
{
    switch (c) {
    case XIMReverse:
	printf("R");
	break;
    case XIMUnderline:
	printf("U");
	break;
    case XIMHighlight:
	printf("H");
	break;
    case XIMPrimary:
	printf("P");
	break;
    case XIMSecondary:
	printf("S");
	break;
    case XIMTertiary:
	printf("T");
	break;
    default:
	printf("%ld", c);
	break;
    }
}

static void
PrintFeedback(XIMPreeditDrawCallbackStruct *dcs)
{
    int n;

    printf("Preedit: Draw: text->feedback:");
    for (n = 0; n < dcs->text->length; ++n) {
	printf(" [%d]", n);
	PrintFeedbackChar(dcs->text->feedback[n]);
    }
    printf("\n");
}

static void
PrintAllFeedback(SylPreedit *ped)
{
    int n;

    printf("Preedit: Draw: feedback(all):");
    for (n = 0; n < ped->n_chars; ++n) {
	printf(" [%d]", n);
	PrintFeedbackChar(ped->feedback[n]);
    }
    printf("\n");
}
#endif

static void
InsertPreedit(SylPreedit *ped, XIMPreeditDrawCallbackStruct *dcs,
	      void *cb_data, void (*insert)(void *, wchar_t *))
{
    int m, n, len;
    wchar_t *wcs;
    XIMFeedback *fb;

    if (dcs->text == NULL) {
#ifdef DEBUG
	printf("Preedit: Draw: text=NULL\n");
#endif
	return;
    }
    len = dcs->text->length;
#ifdef DEBUG
    printf("Preedit: Draw: text->length=%d\n", len);
#endif
    if (dcs->text->encoding_is_wchar == False) {
#ifdef DEBUG
	printf("Preedit: Draw: text->string.multi_byte=%s\n",
	       dcs->text->string.multi_byte);
#endif
	if (dcs->text->string.multi_byte == NULL) {
	    wcs = NULL;
	}
	else if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * (len + 1)))
		 != NULL) {
	    mbstowcs(wcs, dcs->text->string.multi_byte, len + 1);
	}
	else {
#ifdef DEBUG
	    printf("Preedit: Draw: alloca() failed\n");
#endif
	    return;
	}
    }
    else {
	wcs = dcs->text->string.wide_char;
    }
    if (wcs != NULL) {
#ifdef DEBUG
	printf("Preedit: Draw: insert %d widechar(s)\n", len);
#endif
	insert(cb_data, wcs);
	ped->n_chars += len;
	ped->caret += len;
    }
    if (dcs->text->feedback == NULL)
	return;
#ifdef DEBUG
    PrintFeedback(dcs);
#endif
    if (wcs == NULL) {
	for (n = dcs->chg_first; n < dcs->text->length; ++n)
	    ped->feedback[n] = dcs->text->feedback[n];
    }
    else if ((fb = (XIMFeedback *)malloc(sizeof(XIMFeedback)
					 * ped->n_chars)) == NULL) {
	if (ped->feedback == NULL)
	    free(ped->feedback);
	ped->feedback = NULL;
    }
    else if (ped->feedback == NULL) {
	for (n = 0; n < dcs->text->length; ++n)
	    fb[n] = dcs->text->feedback[n];
	ped->feedback = fb;
    }
    else {
	for (n = 0; n < dcs->chg_first; ++n)
	    fb[n] = ped->feedback[n];
	for (m = 0; m < dcs->text->length; ++m)
	    fb[n + m] = dcs->text->feedback[m];
	for (; n + m < ped->n_chars; ++n)
	    fb[n + m] = ped->feedback[n];
	free(ped->feedback);
	ped->feedback = fb;
    }
#ifdef DEBUG
    PrintAllFeedback(ped);
#endif
}

/*
  DrawSylPreedit:

  static void
  InitCB(void *cb_data)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
  }

  static void
  DeleteCB(void *cb_data, int first, int length)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
    .
  }

  static void
  InsertCB(void *cb_data, wchar_t *wcs)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
    .
  }

  static void
  CaretCB(void *cb_data, int position)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
    .
  }

  static void
  MyPreeditDraw(XIC ic, MyObject *obj, XIMPreeditDrawCallbackStruct *dcs)
  {
    DrawSylPreedit(&obj->preedit, ic, dcs, obj, InitCB, DeleteCB, InsertCB,
    CaretCB);
  }
*/

void
DrawSylPreedit(SylPreedit *ped, XIC ic, XIMPreeditDrawCallbackStruct *dcs,
	       void *cb_data, void (*init)(void *),
	       void (*delete)(void *, int, int),
	       void (*insert)(void *, wchar_t *), void (*caret)(void *, int))
{
#ifdef DEBUG
    printf("Preedit: Draw: enter\n");
#endif
    if (ped->ic != ic) {
#ifdef DEBUG
	printf("Preedit: Draw: invalid arguments (invalid ic)\n");
#endif
	return;
    } 
    /* init */
    if (ped->n_chars == 0)
	init(cb_data);

#ifdef DEBUG
    printf("Preedit: Draw: caret=%d, chg_first=%d, chg_length=%d\n",
	   dcs->caret, dcs->chg_first, dcs->chg_length);
#endif
    /* delete */
    DeletePreedit(ped, dcs, cb_data, delete);

    /* insert */
    InsertPreedit(ped, dcs, cb_data, insert);

    /* caret */
    ped->caret = dcs->caret;
    caret(cb_data, ped->caret);
}

/*
  CaretSylPreedit:

  static void
  CaretCB(void *cb_data, int position)
  {
    MyObject obj = (MyObject *)cb_data;
    .
    .
    .
  }

  static void
  MyPreeditCaret(XIC ic, MyObject *obj, XIMPreeditCaretCallbackStruct *ccs)
  {
    CaretSylPreedit(&obj->preedit, ic, dcs, obj, CaretCB);
  }
*/

void
CaretSylPreedit(SylPreedit *ped, XIC ic, XIMPreeditCaretCallbackStruct *ccs,
		void *cb_data, void (*caret)(void *, int))
{
#ifdef DEBUG
    printf("Preedit: Caret: enter\n");
#endif
    if (ped->ic != ic) {
#ifdef DEBUG
	printf("Preedit: Caret: invalid arguments (invalid ic)\n");
#endif
	return;
    }
#ifdef DEBUG
    printf("Preedit: Caret: position=%d, direction=%d, style=%d\n",
	   ccs->position, ccs->direction, ccs->style);
#endif
    switch (ccs->direction) {
    case XIMForwardChar:
	if (ped->caret >= ped->n_chars)
	    break;
	++(ped->caret);
	caret(cb_data, ped->caret);
	break;
    case XIMBackwardChar:
	if (ped->caret <= 0)
	    break;
	--(ped->caret);
	caret(cb_data, ped->caret);
	break;
    case XIMAbsolutePosition:
	if (ccs->position < 0 || ccs->position > ped->n_chars)
	    break;
	ped->caret = ccs->position;
	caret(cb_data, ped->caret);
	break;
    case XIMForwardWord:
    case XIMBackwardWord:
    case XIMCaretUp:
    case XIMCaretDown:
    case XIMPreviousLine:
    case XIMNextLine:
    case XIMLineStart:
    case XIMLineEnd:
    case XIMDontChange:
    default:
	break;
    }
    ccs->position = ped->caret;
}
#endif /* #ifdef ON_THE_SPOT */
