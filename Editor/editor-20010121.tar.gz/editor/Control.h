/*
        Control.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

typedef struct SylControl {
    int type;
    void *control;
    struct SylControl *next;
} SylControl;

typedef struct SylControlManager {
    Display *disp;
    Window parent;
    SylControl *top;
    SylControl *last;
    XContext context_id; /* from (SylControl *c)->window to (SylPane *) */
    SylLayoutManager *layout;
} SylControlManager;

#define SYL_CONTROL_NULL     0
#define SYL_CONTROL_TEXTAREA 1
#define SYL_CONTROL_TEXTLINE 2
#define SYL_CONTROL_BUTTON   3
#define SYL_CONTROL_LISTBOX  4
#define SYL_CONTROL_PLATE    5

SylControlManager * CreateSylControlManager(Display *, Window);
void FreeSylControlManager(SylControlManager *);
SylPane * SylPaneOfSylControlManager(SylControlManager *, Window w);
int NiceSylControlManager(SylControlManager *);
void SendSylControlManager(SylControlManager *, XEvent *);

SylTextArea * CreateSylControlOfSylTextArea(SylControlManager *, char *);
SylTextLine * CreateSylControlOfSylTextLine(SylControlManager *, char *,
					    void (*)(int));
SylButton * CreateSylControlOfSylButton(SylControlManager *, char *,
					void (*)(void *), void *);
SylListBox * CreateSylControlOfSylListBox(SylControlManager *, char *,
					  void (*)(void *, char *), void *);
SylPlate * CreateSylControlOfSylPlate(SylControlManager *, char *, int);
SylNull * CreateSylControlOfSylNull(SylControlManager *, char *,
				    int, int, int, int);
