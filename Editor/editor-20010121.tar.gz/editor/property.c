/*
        property.c 1.3 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>

#include "property.h"

#define max(a, b) (((a) < (b)) ? (b) : (a))

static Atom WM_PROTOCOLS, WM_REQUEST[2], WM_DELETE_WINDOW, WM_TAKE_FOCUS;
static Window FocusWindow = PointerRoot;

static int
IsMatchIconSize(XIconSize *s, int req_w, int req_h)
{
    if (s->max_width < req_w || s->min_width > req_w
	|| (req_w - s->min_width) % s->width_inc
	|| s->max_height < req_h || s->min_height > req_h
	|| (req_h - s->min_height) % s->height_inc)
	return (0);
    return (1);
}

static int
IconCheck(Display *disp, Drawable d)
{
    int x, y, width, height, border, depth, n, n_icons_sizes;
    Window root;
    XIconSize *icon_size;

    XGetGeometry(disp, d, &root, &x, &y, &width, &height, &border, &depth);
    if (XGetIconSizes(disp, root, &icon_size, &n_icons_sizes) == 0)
	return (0); /* XXX */
    for (n = 0; n < n_icons_sizes; ++n) {
#if 0
	printf("%dx%d, %dx%d, %d:%d\n",
	       icon_size[n].min_width, icon_size[n].min_height,
	       icon_size[n].max_width, icon_size[n].max_height,
	       icon_size[n].width_inc, icon_size[n].height_inc);
#endif
	if (IsMatchIconSize(&icon_size[n], width, height)) {
	    break;
	}
    }
    XFree(icon_size);
    return ((n >= n_icons_sizes) ? 1 : 0);
}

void
SetProperties(Display *disp, Window w, char *title, char *name, char *class,
	      int ac, char **av, XSizeHints *xsize, Pixmap face, Pixmap mask,
	      Window icon)
{
    XClassHint xclass;
    XWMHints xwm;

    xwm.flags = InputHint /* | XUrgencyHint */;
    xwm.input = True;
    xwm.flags |= WindowGroupHint;
    xwm.window_group = w;
    if (face != None) {
	if (IconCheck(disp, face))
	    fprintf(stderr, "%s: icon pixmap size is not matched.\n", av[0]);
	xwm.icon_pixmap = face;	/* ICCCM$B$G$O(Bicon_pixmap$B$N%G%W%9$O(B1$B!#(B */
	xwm.flags |= IconPixmapHint;
    }
    if (mask != None) {
	if (IconCheck(disp, mask))
	    fprintf(stderr, "%s: icon mask size is not matched.\n", av[0]);
	xwm.icon_mask = mask; /* ICCCM$B$G$O(Bicon_msak$B$N%G%W%9$O(B1$B!#(B */
	xwm.flags |= IconMaskHint;
    }
    if (icon != None) {
	if (IconCheck(disp, icon))
	    fprintf(stderr, "%s: icon window size is not matched.\n", av[0]);
	xwm.icon_window = icon;
	xwm.flags |= IconWindowHint;
    }
    xclass.res_name = name;
    xclass.res_class = class;
    XmbSetWMProperties(disp, w, title, title, av, ac, xsize, &xwm, &xclass);

    WM_PROTOCOLS = XInternAtom(disp, "WM_PROTOCOLS", False);
    WM_TAKE_FOCUS = XInternAtom(disp, "WM_TAKE_FOCUS", False);
    WM_DELETE_WINDOW = XInternAtom(disp, "WM_DELETE_WINDOW", False);
    WM_REQUEST[0] = WM_TAKE_FOCUS;
    WM_REQUEST[1] = WM_DELETE_WINDOW;
    XSetWMProtocols(disp, w, WM_REQUEST, 2);
}

int
IsWMCloseMessage(XEvent *ev)
{
    XWindowAttributes attr;

    if (ev->type == FocusIn) {
	if (ev->xfocus.detail != NotifyPointer)
	    FocusWindow = ev->xfocus.window;
         return (0);
    }
    if (ev->type == DestroyNotify) {
	if (ev->xdestroywindow.window == FocusWindow)
	    FocusWindow = PointerRoot;
        return (0);
    }
    if (ev->type == ClientMessage
	&& ev->xclient.message_type == WM_PROTOCOLS) {
	if (ev->xclient.data.l[0] == (signed)WM_DELETE_WINDOW)
	    return (1);
	if (ev->xclient.data.l[0] == (signed)WM_TAKE_FOCUS
	    && FocusWindow != PointerRoot) {
	    XGetWindowAttributes(ev->xclient.display, FocusWindow, &attr);
	    if (attr.map_state == IsViewable) {
		XSetInputFocus(ev->xclient.display, FocusWindow,
		    RevertToParent, ev->xclient.data.l[1]);
	    }
	}
    }
    return (0);
}

void
SetDefaultFocusWindow(Window w)
{
    FocusWindow = w;
}
