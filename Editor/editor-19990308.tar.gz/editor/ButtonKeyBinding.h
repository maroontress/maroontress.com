static SylSetting
  KeyBinding0 = {"pressButton", "PressButton", "Return, Control-m", NULL},
  KeyBinding1 = {"nextField", "NextField", "Control-Tab", NULL},
  KeyBinding2 = {"previousField", "PreviousField", "Control-Shift-Tab", NULL},
  *KeyBinding[] = {
    &KeyBinding0,
    &KeyBinding1,
    &KeyBinding2,
    NULL};
