/*
        Layout.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

typedef union SylPane *SylPanePtr;

typedef struct SylPanedAny {
    int type;
    SylPanePtr next;
    int min_width;
    int min_height;
    int max_width;
    int max_height;
    int expanding;
} SylPanedAny;

typedef struct SylPanedWindow {
    int type;
    SylPanePtr next;
    int min_width;
    int min_height;
    int max_width;
    int max_height;
    int expanding;

    Display *disp;
    Window parent;
    Window window;
} SylPanedWindow;

typedef struct SylPanedList {
    int type;
    SylPanePtr next;
    int min_width;
    int min_height;
    int max_width;
    int max_height;
    int expanding;

    SylPanePtr top;
    SylPanePtr last;
    int (*is_variable)(SylPanePtr);
    int (*minimum)(SylPanePtr);
    int (*maximum)(SylPanePtr);
} SylPanedList;

typedef union SylPane {
    int type;
    SylPanedAny any;
    SylPanedWindow pane;
    SylPanedList list;
} SylPane;

#define SYL_PANED_WINDOW 0
#define SYL_PANED_VERTICAL 1
#define SYL_PANED_HORIZONTAL 2

typedef struct SylLayoutManager {
    Display *disp;
    Window parent;
    SylPane *pane;
} SylLayoutManager;

#define SYL_LAYOUT_SEP 2

SylLayoutManager * CreateSylLayoutManager(Display *, Window);
void SendSylLayoutManager(SylLayoutManager *, XEvent *);
void FreeSylLayoutManager(SylLayoutManager *);

SylPane * CreateSylPane(Display *, Window, char *);
void SetSizeSylPane(SylPane *, int, int, int, int);
SylPane * SylVLayout(SylPane *, ...);
SylPane * SylHLayout(SylPane *, ...);
void SetOrderSylLayoutManager(SylLayoutManager *, SylPane *);

#define WindowOfSylPane(p) ((p)->pane.window)
