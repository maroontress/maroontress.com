/*
        TextArea.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#define SYL_TA_LINES_PER_BLOCK 4

typedef struct SylTextBlock {
    struct SylTextBlock *next;
    struct SylTextBlock *prev;
    SylText *body[SYL_TA_LINES_PER_BLOCK];
    int n_bodies;
} SylTextBlock;

typedef struct SylTextBlockSet {
    struct SylTextBlock *top;
    struct SylTextBlock *cur;
    struct SylTextBlock *last;
    int current_block;         /* nth block */
    int current_line;          /* nth block begin at this line */
    int n_lines;               /* total lines */
} SylTextBlockSet;

typedef struct SylLocation {
    int x;
    int y;
} SylLocation;

typedef struct SylTextArea {
    Display *disp;
    XIC ic;
    Window parent;
    Window window;
    Window next_field;
    Window prev_field;
    Pixmap pixmap;
    Pixmap wallpaper;
    Pixmap mark_lf;
    Pixmap mark_eof;
    Pixmap mark_tab;
    GC gc;
    GC xgc;
    SylFontSet fontset;
    int parent_width;
    int parent_height;
    int width;
    int height;
    int sidemargin;
    int depth;
    unsigned long pixel[6];
    SylKeymap **keymap;

    SylTextBlockSet *tbs;
    wchar_t *buf;           /* $B%d%s%/$5$l$?%F%-%9%H(B */
    SylLocation current;
    SylLocation started;
    SylLocation pasting;
    int saved_width;
    
    SylVScrollbar *vsb;
    int baseline_skip;
    int visible_begin;
    int visible_cols;

    int pointed;
    int focus;
    int focus_delay;
    int grabbed;
    int selected;
    int redraw;
    int format;
    int converting;
    Time stamp;             /* $B%;%l%/%7%g%s3MF@$K;HMQ$7$?%?%$%`%9%?%s%W(B */
    Atom property;
    Atom text_atom;
    Atom compound_text_atom;
    Atom targets_atom;
    Atom timestamp_atom;
} SylTextArea;

SylTextArea * CreateSylTextArea(Display *, XIC, Window, char *);
void FreeSylTextArea(SylTextArea *);
void SendSylTextArea(SylTextArea *, XEvent *);
int NiceSylTextArea(SylTextArea *);

int ReadSylTextArea(SylTextArea *, char *);
int WriteSylTextArea(SylTextArea *, char *);
void ResetSylTextArea(SylTextArea *);
void SetFieldOrderSylTextArea(SylTextArea *, Window, Window);
