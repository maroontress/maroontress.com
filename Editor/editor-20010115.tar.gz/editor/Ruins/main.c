#include "Keymap.h"
#include "load_keymap.h"

static char *
CreatePathOfConfigFile(char *rc)
{
    char *path, *home;

    home = getenv("HOME");
    if ((path = (char *)malloc(strlen(home) + strlen(rc) + 1)) != NULL)
        sprintf(path, "%s%s", home, rc);
    return (path);
}

static void
LoadKeymapError(char *file)
{
    switch (KeymapErrorCode) {
    case KEYMAP_PARSE_ERROR:
        fprintf(stderr, "%s: file %s, parse error `%s' at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
                KeymapErrorWord, KeymapErrorLine);
        break;
    case KEYMAP_TOO_SHORT_MEMORY:
        fprintf(stderr, "%s: file %s, too short memory, while reading"
                "at %d line.\n", GlobalAv[0],
                (file != NULL) ? file : "<stdin>", KeymapErrorLine);
            break;
    case KEYMAP_CANNOT_OPEN:
        fprintf(stderr, "%s: cannot open file `%s'.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>");
        break;
    case KEYMAP_UNKNOWN_FUNCTION:
        fprintf(stderr, "%s: file %s, unknown function `%s' at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
                KeymapErrorWord, KeymapErrorLine);
        break;
    case KEYMAP_EMPTY:
        fprintf(stderr, "%s: no menu defined in file %s.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>");
        break;
    case KEYMAP_UNEXPECTED_EOF:
        fprintf(stderr, "%s: file %s, unexpected EOF at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
		KeymapErrorLine);
        break;
    case KEYMAP_NO_KEYSYM:
        fprintf(stderr, "%s: file %s, undefined KeySym `%s' at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
		KeymapErrorWord, KeymapErrorLine);
        break;
    }
}

int
main(void)
{
    Keymap *keymap;
    char *mapfile;

    if ((mapfile = CreatePathOfConfigFile("/.editor_keymap")) == NULL) {
        fprintf(stderr, "%s: can't create a path of config file.\n", av[0]);
        exit(1);
    }
    if (LoadKeymap(mapfile, &keymap) != EOF) {
	LoadKeymapError(mapfile);
	exit(1);
    }
    free(mapfile);
}
