/*
	Button.h 2.0 for X11R6 & GNU C Compiler

	Copyright (C) 1995, 1996, 1999 Syllabub
	Maroontress Fast Software.
*/

typedef struct SylButton {
    Display *disp;
    Window parent;
    Window window;
    Window plate;
    Window next_field;
    Window prev_field;
    Pixmap grayout;
    GC gc;
    SylFontSet fontset;
    int width;
    int height;
    int sidemargin;
    unsigned long *pixel;
    SylKeymap **keymap;

    SylText *text;
    int pointed;
    int focus;
    int frame_width;
    int grabbed;
    int enabled;
    int pressed;
    int redraw;
    void (*callback_func)(void *);
    void *callback_data;
} SylButton;

SylButton * CreateSylButton(Display *, Window, char *,
			    void (*)(void *), void *);
void FreeSylButton(SylButton *);
void EnableSylButton(SylButton *);
void DisableSylButton(SylButton *);
void SendSylButton(SylButton *, XEvent *);
int NiceSylButton(SylButton *);
void SetFieldOrderSylButton(SylButton *, Window, Window);
