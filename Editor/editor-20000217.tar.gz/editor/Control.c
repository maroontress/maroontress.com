/*
        Control.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Layout.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Button.h"
#include "Preedit.h"
#include "TextLine.h"
#include "TextArea.h"
#include "PixmapQueue.h"
#include "ListBox.h"
#include "Plate.h"
#include "Null.h"
#include "Control.h"

static SylControl *
CreateSylControl(void)
{
    SylControl *c;

    if ((c = (SylControl *)malloc(sizeof(SylControl))) == NULL)
	return (NULL);
    c->next = NULL;
    return (c);
}

static int
IsFocusable(SylControl *c)
{
    switch (c->type) {
    case SYL_CONTROL_TEXTAREA:
    case SYL_CONTROL_TEXTLINE:
    case SYL_CONTROL_BUTTON:
    case SYL_CONTROL_LISTBOX:
	return (True);
    }
    return (False);
}

static void
GetFocusOrder(SylControl *c, Window *prev, Window *next)
{
    switch (c->type) {
    case SYL_CONTROL_TEXTAREA:
	*prev = ((SylTextArea *)c->control)->prev_field;
	*next = ((SylTextArea *)c->control)->next_field;
	break;
    case SYL_CONTROL_TEXTLINE:
	*prev = ((SylTextLine *)c->control)->prev_field;
	*next = ((SylTextLine *)c->control)->next_field;
	break;
    case SYL_CONTROL_BUTTON:
	*prev = ((SylButton *)c->control)->prev_field;
	*next = ((SylButton *)c->control)->next_field;
	break;
    case SYL_CONTROL_LISTBOX:
	*prev = ((SylListBox *)c->control)->prev_field;
	*next = ((SylListBox *)c->control)->next_field;
	break;
    default:
	*prev = None;
	*next = None;
	break;
    }
}

static void
SetFocusOrder(SylControl *c, Window prev, Window next)
{
    switch (c->type) {
    case SYL_CONTROL_TEXTAREA:
	SetFieldOrderSylTextArea((SylTextArea *)c->control, prev, next);
	break;
    case SYL_CONTROL_TEXTLINE:
	SetFieldOrderSylTextLine((SylTextLine *)c->control, prev, next);
	break;
    case SYL_CONTROL_BUTTON:
	SetFieldOrderSylButton((SylButton *)c->control, prev, next);
	break;
    case SYL_CONTROL_LISTBOX:
	SetFieldOrderSylListBox((SylListBox *)c->control, prev, next);
	break;
    }
}

static Window
FocusWindow(SylControl *c)
{
    switch (c->type) {
    case SYL_CONTROL_TEXTAREA:
	return (((SylTextArea *)c->control)->window);
	break;
    case SYL_CONTROL_TEXTLINE:
	return (((SylTextLine *)c->control)->window);
	break;
    case SYL_CONTROL_BUTTON:
	return (((SylButton *)c->control)->window);
	break;
    case SYL_CONTROL_LISTBOX:
	return (((SylListBox *)c->control)->target);
	break;
    }
    return (None);
}

static void
UpdateFocusOrder(SylControlManager *mgr, SylControl *c)
{
    SylControl *p, *head, *tail;
    Window next, prev;

    for (p = mgr->top; p != NULL && !IsFocusable(p); p = p->next)
	;
    if ((head = p) == NULL)
	return;
    for (tail = NULL, p = p->next; p != NULL; p = p->next) {
	if (IsFocusable(p)) {
	    tail = p;
	}
    }
    if (tail == NULL) {
	SetFocusOrder(head, FocusWindow(c), FocusWindow(c));
	SetFocusOrder(c, FocusWindow(head), FocusWindow(head));
    }
    else {
	GetFocusOrder(head, &prev, &next);
	SetFocusOrder(head, FocusWindow(c), next);
	GetFocusOrder(tail, &prev, &next);
	SetFocusOrder(tail, prev, FocusWindow(c));
	SetFocusOrder(c, FocusWindow(tail), FocusWindow(head));
    }
}

static void
AddSylControl(SylControlManager *mgr, SylControl *c)
{
    if (IsFocusable(c))
	UpdateFocusOrder(mgr, c);
    if (mgr->top == NULL)
        mgr->top = c;
    else
        mgr->last->next = c;
    mgr->last = c;

}

SylTextArea *
CreateSylControlOfSylTextArea(SylControlManager *mgr, char *component)
{
    SylControl *c;
    SylPane *pane;
    SylTextArea *txt;

    if ((c = CreateSylControl()) == NULL)
	goto no_control;
    if ((pane = CreateSylPane(mgr->disp, mgr->parent, component,
			      True)) == NULL)
	goto no_pane;
    if ((txt = CreateSylTextArea(mgr->disp, WindowOfSylPane(pane),
				 "text")) == NULL)
	goto no_textarea;
    if (XSaveContext(mgr->disp, txt->window, mgr->context_id, (XPointer)pane))
	goto no_context;
    SetSizeSylPane(pane, (2 * txt->sidemargin), txt->baseline_skip, 0, 0);
    c->type = SYL_CONTROL_TEXTAREA;
    c->control = (void *)txt;
    AddSylControl(mgr, c);
    return (txt);

no_context:
    FreeSylTextArea(txt);
no_textarea:
    FreeSylPane(pane);
no_pane:
    free(c);
no_control:
    return (NULL);
}

SylTextLine *
CreateSylControlOfSylTextLine(SylControlManager *mgr, char *component,
			      void (*cb)(int))
{
    SylControl *c;
    SylPane *pane;
    SylTextLine *txl;

    if ((c = CreateSylControl()) == NULL)
	goto no_control;
    if ((pane = CreateSylPane(mgr->disp, mgr->parent, component,
			      True)) == NULL)
	goto no_pane;
    if ((txl = CreateSylTextLine(mgr->disp, WindowOfSylPane(pane), "text",
				 cb)) == NULL)
	goto no_textline;
    if (XSaveContext(mgr->disp, txl->window, mgr->context_id, (XPointer)pane))
	goto no_context;
    SetSizeSylPane(pane, (2 * txl->sidemargin), txl->height, 0, txl->height);
    c->type = SYL_CONTROL_TEXTLINE;
    c->control = (void *)txl;
    AddSylControl(mgr, c);
    return (txl);

no_context:
    FreeSylTextLine(txl);
no_textline:
    FreeSylPane(pane);
no_pane:
    free(c);
no_control:
    return (NULL);
}

SylButton *
CreateSylControlOfSylButton(SylControlManager *mgr, char *component,
			    void (*cb_func)(void *), void *cb_data)
{
    SylControl *c;
    SylPane *pane;
    SylButton *btn;

    if ((c = CreateSylControl()) == NULL)
	goto no_control;
    if ((pane = CreateSylPane(mgr->disp, mgr->parent, component,
			      True)) == NULL)
	goto no_pane;
    if ((btn = CreateSylButton(mgr->disp, WindowOfSylPane(pane), "button",
			       cb_func, (void *)cb_data)) == NULL)
	goto no_button;
    if (XSaveContext(mgr->disp, btn->window, mgr->context_id, (XPointer)pane))
	goto no_context;
    SetSizeSylPane(pane, btn->width, btn->height, btn->width, btn->height);
    c->type = SYL_CONTROL_BUTTON;
    c->control = (void *)btn;
    AddSylControl(mgr, c);
    return (btn);

no_context:
    FreeSylButton(btn);
no_button:
    FreeSylPane(pane);
no_pane:
    free(c);
no_control:
    return (NULL);
}

SylListBox *
CreateSylControlOfSylListBox(SylControlManager *mgr, char *component,
			     void (*cb_func)(void *, char *), void *cb_data)
{
    SylControl *c;
    SylPane *pane;
    SylListBox *box;

    if ((c = CreateSylControl()) == NULL)
	goto no_control;
    if ((pane = CreateSylPane(mgr->disp, mgr->parent, component,
			      True)) == NULL)
	goto no_pane;
    if ((box = CreateSylListBox(mgr->disp, WindowOfSylPane(pane), "listBox",
				cb_func, (void *)cb_data)) == NULL)
	goto no_listbox;
    if (XSaveContext(mgr->disp, box->target, mgr->context_id, (XPointer)pane))
	goto no_context;
    SetSizeSylPane(pane, (2 * box->sidemargin), box->baseline_skip, 0, 0);
    c->type = SYL_CONTROL_LISTBOX;
    c->control = (void *)box;
    AddSylControl(mgr, c);
    return (box);

no_context:
    FreeSylListBox(box);
no_listbox:
    FreeSylPane(pane);
no_pane:
    free(c);
no_control:
    return (NULL);
}

SylPlate *
CreateSylControlOfSylPlate(SylControlManager *mgr, char *component, int mode)
{
    SylControl *c;
    SylPane *pane;
    SylPlate *plt;

    if ((c = CreateSylControl()) == NULL)
	goto no_control;
    if ((pane = CreateSylPane(mgr->disp, mgr->parent, component,
			      True)) == NULL)
	goto no_pane;
    if ((plt = CreateSylPlate(mgr->disp, WindowOfSylPane(pane),
			      "plate")) == NULL)
	goto no_plate;
    if (XSaveContext(mgr->disp, plt->window, mgr->context_id, (XPointer)pane))
	goto no_context;
#if 0
    SetSizeSylPane(pane, plt->width, plt->height,
		   (mode & 1) ? 0 : plt->width, (mode & 2) ? 0 : plt->height);
#else
    SetSizeSylPane(pane, 0, 0,
		   (mode & 1) ? 0 : plt->width, (mode & 2) ? 0 : plt->height);
#endif
    c->type = SYL_CONTROL_PLATE;
    c->control = (void *)plt;
    AddSylControl(mgr, c);
    return (plt);

no_context:
    FreeSylPlate(plt);
no_plate:
    FreeSylPane(pane);
no_pane:
    free(c);
no_control:
    return (NULL);
}

SylNull *
CreateSylControlOfSylNull(SylControlManager *mgr, char *component,
			  int min_w, int min_h, int max_w, int max_h)
{
    SylControl *c;
    SylPane *pane;
    SylNull *nul;

    if ((c = CreateSylControl()) == NULL)
	goto no_control;
    if ((pane = CreateSylPane(mgr->disp, mgr->parent, component,
			      False)) == NULL)
	goto no_pane;
    if ((nul = CreateSylNull(mgr->disp, WindowOfSylPane(pane))) == NULL)
	goto no_null;
    if (XSaveContext(mgr->disp, nul->parent, mgr->context_id, (XPointer)pane))
	goto no_context;
    SetSizeSylPane(pane, min_w, min_h, max_w, max_h);
    c->type = SYL_CONTROL_NULL;
    c->control = (void *)nul;
    AddSylControl(mgr, c);
    return (nul);

no_context:
    FreeSylNull(nul);
no_null:
    FreeSylPane(pane);
no_pane:
    free(c);
no_control:
    return (NULL);
}

void
SendSylControlManager(SylControlManager *mgr, XEvent *ev)
{
    SylControl *c;

    for (c = mgr->top; c != NULL; c = c->next) {
	switch (c->type) {
	case SYL_CONTROL_TEXTAREA:
	    SendSylTextArea((SylTextArea *)c->control, ev);
	    break;
	case SYL_CONTROL_TEXTLINE:
	    SendSylTextLine((SylTextLine *)c->control, ev);
	    break;
	case SYL_CONTROL_BUTTON:
	    SendSylButton((SylButton *)c->control, ev);
	    break;
	case SYL_CONTROL_LISTBOX:
	    SendSylListBox((SylListBox *)c->control, ev);
	    break;
	case SYL_CONTROL_PLATE:
	    SendSylPlate((SylPlate *)c->control, ev);
	    break;
	}
    }
    SendSylLayoutManager(mgr->layout, ev);
}

int
NiceSylControlManager(SylControlManager *mgr)
{
    int flag;
    SylControl *c;

    flag = 0;
    for (c = mgr->top; c != NULL; c = c->next) {
	switch (c->type) {
	case SYL_CONTROL_TEXTAREA:
	    flag |= NiceSylTextArea((SylTextArea *)c->control);
	    break;
	case SYL_CONTROL_TEXTLINE:
	    flag |= NiceSylTextLine((SylTextLine *)c->control);
	    break;
	case SYL_CONTROL_BUTTON:
	    flag |= NiceSylButton((SylButton *)c->control);
	    break;
	case SYL_CONTROL_LISTBOX:
	    flag |= NiceSylListBox((SylListBox *)c->control);
	    break;
	case SYL_CONTROL_PLATE:
	    flag |= NiceSylPlate((SylPlate *)c->control);
	    break;
	}
    }
    return (flag);
}

void
FreeSylControlManager(SylControlManager *mgr)
{
    SylControl *c, *next;
    SylTextArea *txt;
    SylTextLine *txl;
    SylButton *btn;
    SylListBox *box;
    SylPlate *plt;
    SylNull *nul;

    for (c = mgr->top; c != NULL; c = next) {
        next = c->next;
	switch (c->type) {
	case SYL_CONTROL_TEXTAREA:
	    txt = (SylTextArea *)c->control;
	    (void)XDeleteContext(mgr->disp, txt->window, mgr->context_id);
	    FreeSylTextArea(txt);
	    break;
	case SYL_CONTROL_TEXTLINE:
	    txl = (SylTextLine *)c->control;
	    (void)XDeleteContext(mgr->disp, txl->window, mgr->context_id);
	    FreeSylTextLine(txl);
	    break;
	case SYL_CONTROL_BUTTON:
	    btn = (SylButton *)c->control;
	    (void)XDeleteContext(mgr->disp, btn->window, mgr->context_id);
	    FreeSylButton(btn);
	    break;
	case SYL_CONTROL_LISTBOX:
	    box = (SylListBox *)c->control;
	    (void)XDeleteContext(mgr->disp, box->target, mgr->context_id);
	    FreeSylListBox(box);
	    break;
	case SYL_CONTROL_PLATE:
	    plt = (SylPlate *)c->control;
	    (void)XDeleteContext(mgr->disp, plt->window, mgr->context_id);
	    FreeSylPlate(plt);
	    break;
	case SYL_CONTROL_NULL:
	    nul = (SylNull *)c->control;
	    (void)XDeleteContext(mgr->disp, nul->parent, mgr->context_id);
	    FreeSylNull(nul);
	    break;
	}
    }
    FreeSylLayoutManager(mgr->layout); /* $B:G8e(B */
}

SylControlManager *
CreateSylControlManager(Display *disp, Window w)
{
    SylControlManager *mgr;
    
    if ((mgr = (SylControlManager *)malloc(sizeof(SylControlManager))) == NULL)
	goto no_control_manager;
    if ((mgr->layout = CreateSylLayoutManager(disp, w)) == NULL)
	goto no_layout_manager;
    mgr->disp = disp;
    mgr->parent = w;
    mgr->top = NULL;
    mgr->last = NULL;
    mgr->context_id = XUniqueContext();
    return (mgr);

no_layout_manager:
    free(mgr);
no_control_manager:
    return (NULL);
}

SylPane *
SylPaneOfSylControlManager(SylControlManager *mgr, Window w)
{
    SylPane *pane;

    if (XFindContext(mgr->disp, w, mgr->context_id, (XPointer *)&pane))
        return (NULL);
    return (pane);
}
