/*
        Preedit.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999, 2000 Syllabub
        Maroontress Fast Software.
*/

typedef struct {
    XIC ic;
    XIMStyle style;
    int n_chars;
    int caret;
    XIMFeedback *feedback;
} SylPreedit;

void ReserveSylPreedit(SylPreedit *);
void SetICAndStyleToSylPreedit(SylPreedit *, XIC, XIMStyle);
void PutbackSylPreedit(SylPreedit *);

void ResetSylPreedit(SylPreedit *, void *, void (*)(void *, int, int));

int StartSylPreedit(SylPreedit *, XIC, void *,
		    void *, void (*)(void *));
void DoneSylPreedit(SylPreedit *, XIC, void *,
		    void *, void (*)(void *, int, int));
void DrawSylPreedit(SylPreedit *, XIC, XIMPreeditDrawCallbackStruct *dcs,
		    void *, void (*)(void *), void (*)(void *, int, int),
		    void (*)(void *, wchar_t *), void (*)(void *, int));
void CaretSylPreedit(SylPreedit *, XIC, XIMPreeditCaretCallbackStruct *,
		     void *, void (*)(void *, int));
