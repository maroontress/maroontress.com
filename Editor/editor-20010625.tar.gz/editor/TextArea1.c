/*
        TextArea1.c 1.2 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#ifdef HAS_WCHAR_H
#include <wchar.h>
#endif
#ifdef HAS_WCTYPE_H
#include <wctype.h> /* widec.h������˸ƤФ�� */
#endif

#include "Resource.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Preedit.h"
#include "TextArea.h"
#include "TextArea3.h"
#include "TextArea2.h"
#include "TextArea1.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#ifdef HAS_ISW_FUNCS
#define ispunct_w iswpunct
#define isspace_w iswspace
#else
#define ispunct_w ispunct
#define isspace_w isspace
#endif

void
GetSelectedRegion(SylTextArea *txt, SylLocation *left, SylLocation *right)
{
    if (txt->started.y < txt->current.y) {
	*left = txt->started;
	*right = txt->current;
    }
    else if (txt->started.y > txt->current.y) {
	*left = txt->current;
	*right = txt->started;
    }
    else if (txt->started.x < txt->current.x) {
	*left = txt->started;
	*right = txt->current;
    }
    else {
	*left = txt->current;
	*right = txt->started;
    }
}

unsigned int
SizeOfRegion(SylTextArea *txt, SylLocation *left, SylLocation *right)
{
    int n, m, size;

    if (left->y == right->y)
	return (right->x - left->x);

    size = GetLengthAtLine(txt->tbs, left->y) - left->x;
    if (IsEndOfLineAtLine(txt->tbs, left->y))
	++size;
    for (n = left->y + 1, m = right->y; n < m; ++n) {
	size += GetLengthAtLine(txt->tbs, n);
	if (IsEndOfLineAtLine(txt->tbs, n))
	    ++size;
    }
    size += right->x;
    return (size);
}

void
CopyRegionToWCString(SylTextArea *txt, SylLocation *left, SylLocation *right,
		     wchar_t *wcs)
{
    int y, n, m, len;
    SylTextBlock *tb;
    wchar_t *str;

    if (left->y == right->y) {
	tb = SeekSylTextBlockAtLine(txt->tbs, left->y);
	n = left->y - txt->tbs->current_line;
	str = CreateWCStringFromSylText(tb->body[n], left->x, right->x);
	wstrcpy(wcs, str);
	free(str);
	return;
    }

    tb = SeekSylTextBlockAtLine(txt->tbs, left->y);
    n = left->y - txt->tbs->current_line;
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], left->x, len);
    wstrcpy(wcs, str);
    free(str);
    wcs += len - left->x;
    if (EndOfLineSylText(tb->body[n]))
	*wcs++ = '\n';
    for (y = left->y + 1, m = right->y; y < m; ++y) {
	tb = SeekSylTextBlockAtLine(txt->tbs, y);
	n = y - txt->tbs->current_line;
	len = LengthOfSylText(tb->body[n]);
	str = CreateWCStringFromSylText(tb->body[n], 0, len);
	wstrcpy(wcs, str);
	free(str);
	wcs += len;
	if (EndOfLineSylText(tb->body[n]))
	    *wcs++ = '\n';
    }
    tb = SeekSylTextBlockAtLine(txt->tbs, right->y);
    n = right->y - txt->tbs->current_line;
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], 0, right->x);
    wstrcpy(wcs, str);
    free(str);
}

void
SetSelectionOwner(SylTextArea *txt, Time tm)
{
#if 0
    SylLocation left, right;
    unsigned int len, bytes;
    wchar_t *wcs;
    char *mbs;
#endif

    XSetSelectionOwner(txt->disp, XA_PRIMARY, txt->window, tm);
    if (XGetSelectionOwner(txt->disp, XA_PRIMARY) != txt->window)
	txt->selected = False;
    txt->stamp = tm;
#if 0    
    /*
      XXX ͥ���٤ι⤤TODO:
      �ʲ��Υ��åȥХåե������˴ؤ�������ϡ��ؿ�NiceSylTextArea()����
      ����ƤӽФ�����������ѹ������ۤ����褤��������txt->cutbuffer_ready
      == False��txt->selected == True�ʤ�аʲ��ν�����Ԥ��褦�ˡ�����
      �Ȥ����ϥ��åȥХåե����Ф��������̵�뤹�뤳�Ȥˤ��Ƥ�����
    */
    GetSelectedRegion(txt, &left, &right);
    len = SizeOfRegion(txt, &left, &right);
    /*
      CopyRegionToWCString()�ϺǸ�˥̥�ʸ�����ղä���Τǡ�1ʸ��ʬ¿��
      ���ݤ��Ƥ�����
    */
    if ((wcs = (wchar_t *)malloc(sizeof(wchar_t) * (len + 1))) == NULL)
	return;
    CopyRegionToWCString(txt, &left, &right, wcs);
#ifdef TRACE
    printf("SetSelectionOwner: len=%d, wstrlen()=%d\n", len, wstrlen(wcs));
#endif
    if ((mbs = (char *)malloc(len * sizeof(MB_LEN_MAX))) != NULL) {
	if ((bytes = wcstombs(mbs, wcs, len * sizeof(MB_LEN_MAX))) >= 0)
	    XStoreBuffer(txt->disp, mbs, bytes, 0);
	free(mbs);
    }
    free(wcs);
#endif
}

void
ResetSelectionOwner(SylTextArea *txt)
{
    XSetSelectionOwner(txt->disp, XA_PRIMARY, None, txt->stamp);
    txt->selected = False;
}

int
IsEqualSylLocation(SylLocation *p, SylLocation *q)
{
    return ((p->x == q->x) && (p->y == q->y));
}

static void
ChangeSelectionOwner(SylTextArea *txt, Time tm)
{
    Window owner;

    txt->selected = !IsEqualSylLocation(&txt->current, &txt->started);
    if ((owner = XGetSelectionOwner(txt->disp, XA_PRIMARY)) == txt->window) {
	if (txt->selected == False)
	    ResetSelectionOwner(txt);
	return;
    }
    if (owner != None) {
        /*
	  Bug?: ���쥯�������ͭ���륦����ɥ����ȥåץ�٥륦����ɥ�
	  �Ǥʤ����ᤫ��Ʊ�쥢�ץꥱ�������֤Ǵؿ�XSetSelectionOwner()
	  ��ƤӽФ��Ƥ�SelectionClear���٥�Ȥ����ʤ����Ȥ����롣�к���
	  ���ơ����ٶ���Ū�˥��쥯�����Υ����ʤǤʤ��ʤ�褦�ˤ�����

	  ��ȯŪ����������櫓�ǤϤʤ��Τǡ������ॹ����פ�tm�Ǥ褤��
        */
	XSetSelectionOwner(txt->disp, XA_PRIMARY, None, tm);
	/*
	  �¤ϼ��Τ褦�ʥ����ɤǤ�褤�����٥�Ȥ�txt->window������Τ�
	  �츫���������褦�����ɡ�Ʊ�쥢�ץꥱ�������Ǥϥ��٥�Ȥ���İ
	  ���Ƥ���Τǡ����Ū�ˤ��ޤ�������

	  XEvent ev;
	  
	  ev.xselectionclear.type = SelectionClear;
	  ev.xselectionclear.window = owner;
	  ev.xselectionclear.selection = XA_PRIMARY;
	  ev.xselectionclear.time = tm;
	  XSendEvent(txt->disp, txt->window, False, 0, &ev);
	*/
    }
    SetSelectionOwner(txt, tm);
}

void
DeleteRegion(SylTextArea *txt, SylLocation *left, SylLocation *right)
{
    int y, len, new_x, new_y, width;

    width = txt->textwidth;
    len = SizeOfRegion(txt, left, right);
    InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
				      right->x, right->y, &new_x, &new_y);
    InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
				      left->x, left->y, &new_x, &new_y);
    ++len;
    while (len > 0) {
	for (y = new_y; IsEndOfLineAtLine(txt->tbs, y) == False; ++y)
	    len -= GetLengthAtLine(txt->tbs, y);
	len -= GetLengthAtLine(txt->tbs, y) + 1;
	DeleteToLineEndSylTextBlockSet(txt->tbs, &txt->fontset, width,
				       new_x, new_y, &new_x, &new_y);
	DeleteNextCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
					new_x, new_y, &new_x, &new_y);
    }
    DeletePrevCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
				    new_x, new_y, &new_x, &new_y);
    txt->current.x = new_x;
    txt->current.y = new_y;
}

static void
DeleteSelectedRegion(SylTextArea *txt)
{
#if 0
    SylLocation left, right;
    int len, new_x, new_y, width;

    width = txt->textwidth;
    GetSelectedRegion(txt, &left, &right);
    len = SizeOfRegion(txt, &left, &right);
    for (txt->current = right; len > 0; --len) {
	if (txt->current.x > 0) {
	    DeleteLeftCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
					    txt->current.x, txt->current.y,
					    &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
	else if (txt->current.x == 0 && txt->current.y > 0) {
	    DeletePrevCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
					    txt->current.x, txt->current.y,
					    &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
    }
#else
    SylLocation left, right;

    GetSelectedRegion(txt, &left, &right);
    DeleteRegion(txt, &left, &right);
#endif
}

static int
GetLimitAtLine(SylTextBlockSet *tbs, int y)
{
    /*
      TextArea2.c�˰ܹԤ����ۤ����褤�Ǥ��礦��
    */
    int len;

    len = GetLengthAtLine(tbs, y);
    if (IsEndOfLineAtLine(tbs, y) == False && !IsBottomAtLine(tbs, y))
	--len;
    return (len);
}

SylLocation
LocationOfDestination(SylTextArea *txt, SylLocation *origin, int len)
{
    SylLocation goal;
    int x, y, limit;

    x = origin->x;
    y = origin->y;
    for (limit = GetLimitAtLine(txt->tbs, y); len > 0; --len) {
	if (++x > limit) {
	    ++y;
	    limit = GetLimitAtLine(txt->tbs, y);
	    x = 0;
	}
    }
    goal.x = x;
    goal.y = y;
    return (goal);
}

SylLocation
LocationPointed(SylTextArea *txt, int w, int h)
{
    SylLocation p;
    int leftmargin = txt->sidemargin;

    p.y = txt->visible_begin + h / txt->baseline_skip;
    if (p.y < txt->tbs->n_lines) {
	w -= leftmargin;
	p.x = GetRowsAtLine(txt->tbs, &txt->fontset, w, p.y);
	if (p.x == GetLengthAtLine(txt->tbs, p.y)
	    && IsEndOfLineAtLine(txt->tbs, p.y) == False
	    && !IsBottomAtLine(txt->tbs, p.y))
	    --(p.x);
    }
    else {
	p.y = txt->tbs->n_lines - 1;
	p.x = GetLengthAtLine(txt->tbs, p.y);
    }
    return (p);
}

static void
BackSpace(SylTextArea *txt, Time tm __unused)
{
    int new_x, new_y, width;

    if (txt->selected) {
	DeleteSelectedRegion(txt);
	ResetSelectionOwner(txt);
    }
    else if (txt->current.x > 0) {
	width = txt->textwidth;
	DeleteLeftCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
					txt->current.x, txt->current.y,
					&new_x, &new_y);
	txt->current.x = new_x;
	txt->current.y = new_y;
    }
    else if (txt->current.x == 0 && txt->current.y > 0) {
	width = txt->textwidth;
	DeletePrevCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
					txt->current.x, txt->current.y,
					&new_x, &new_y);
	txt->current.x = new_x;
	txt->current.y = new_y;
    }
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
				      txt->current.x, txt->current.y);
    txt->redraw = True;
}

static void
Delete(SylTextArea *t, Time tm)
{
    /*
      �����ȤĤ��ä��ۤ����褤�Ǥ��礦���ؿ�DeleteRightCharInSylText
      BlockSet()��TextArea2.c��ɬ�פǤ��͡�
    */
    if (t->selected) {
	DeleteSelectedRegion(t);
	ResetSelectionOwner(t);
	t->saved_width = GetWidthAtLine(t->tbs, &t->fontset, t->current.x,
					t->current.y);
	t->redraw = True;
    }
    else {
	if (IsBottomAtLine(t->tbs, t->current.y)
	    && t->current.x >= GetLengthAtLine(t->tbs, t->current.y))
	    return;
	if (++(t->current.x) > GetLimitAtLine(t->tbs, t->current.y)) {
	    ++(t->current.y);
	    t->current.x = 0;
	}
	BackSpace(t, tm);
    }
}

static void
MoveCursorWithSavingWidth(SylTextArea *txt, int x, int y)
{
    txt->current.x = x;
    txt->current.y = y;
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset, x, y);
    txt->redraw = True;
}

static void
CommonYankLine(SylTextArea *txt)
{
    int x, y, new_x, new_y, width;
    wchar_t *ptr;

    x = txt->current.x;
    y = txt->current.y;
    width = txt->textwidth;
    for (ptr = txt->buf; *ptr != 0; ++ptr) {
	if (*ptr >= ' ' || *ptr == '\t') {
            InsertCharIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					  x, y, *ptr, &new_x, &new_y);
        }
	else if (*ptr == '\n') {
            InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					      x, y, &new_x, &new_y);
	}
	else {
            InsertCharIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					  x, y, ' ', &new_x, &new_y);
	}
	x = new_x;
	y = new_y;
    }
    MoveCursorWithSavingWidth(txt, x, y);
}

static void
YankLine(SylTextArea *txt, Time tm __unused)
{

    if (txt->buf == NULL)
	return;
    if (txt->selected)
	ResetSelectionOwner(txt);
    CommonYankLine(txt);
}

static void
YankLineWithShift(SylTextArea *txt, Time tm)
{
    if (txt->buf == NULL)
	return;
    if (txt->selected == False)
	txt->started = txt->current;
    CommonYankLine(txt);
    ChangeSelectionOwner(txt, tm);
}


static wchar_t *
CreateWCStringOfLineTobeKilled(SylTextArea *txt)
{
    SylLocation head, tail;
    unsigned int len;
    wchar_t *wcs;

    head.x = txt->current.x;
    head.y = txt->current.y;
    for (tail.y = head.y; !IsBottomAtLine(txt->tbs, tail.y)
	     && IsEndOfLineAtLine(txt->tbs, tail.y) == False; ++tail.y)
	;
    tail.x = GetLengthAtLine(txt->tbs, tail.y);

    len = SizeOfRegion(txt, &head, &tail);
    if ((wcs = (wchar_t *)malloc(sizeof(wchar_t) * (len + 1))) == NULL)
	return (NULL);
    CopyRegionToWCString(txt, &head, &tail, wcs);
    return (wcs);
}

static wchar_t *
CreateWCStringOfLineFeed(void)
{
    wchar_t *wcs;

    if ((wcs = (wchar_t *)malloc(sizeof(wchar_t) * 2)) != NULL) {
	wcs[0] = '\n';
	wcs[1] = 0;
    }
    return (wcs);
}

static void
KillLine(SylTextArea *txt, Time tm __unused)
{
    int new_x, new_y, width;

    if (txt->selected) {
	/*
	  1998-11-23: �ϰϻ������KillLine()�������ϰϤ������ƥХåե���
	  ���ԡ�����褦�ˤ��Ƥߤ���
	*/
	wchar_t *wcs;
	unsigned int len;
	SylLocation left, right;

	GetSelectedRegion(txt, &left, &right);
	len = SizeOfRegion(txt, &left, &right);
	/*
	  CopyRegionToWCString()�ϺǸ�˥̥�ʸ�����ղä���Τǡ�1ʸ��ʬ¿��
	  ���ݤ��Ƥ�����
	*/
	if ((wcs = (wchar_t *)malloc(sizeof(wchar_t) * (len + 1))) == NULL)
	    return;
	CopyRegionToWCString(txt, &left, &right, wcs);
	if (txt->buf != NULL)
	    free(txt->buf);
	txt->buf = wcs;
	DeleteSelectedRegion(txt);
	ResetSelectionOwner(txt);
	txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
					  txt->current.x, txt->current.y);
	txt->redraw = True;
	return;
    }
    width = txt->textwidth;
    if (IsBottomAtLine(txt->tbs, txt->current.y)
	&& txt->current.x >= GetLengthAtLine(txt->tbs, txt->current.y))
	return;
    if (txt->buf != NULL)
	free(txt->buf);
    if (txt->current.x >= GetLengthAtLine(txt->tbs, txt->current.y)
	&& IsEndOfLineAtLine(txt->tbs, txt->current.y) == True) {
	txt->buf = CreateWCStringOfLineFeed();
	DeleteNextCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
					txt->current.x, txt->current.y,
					&new_x, &new_y);
    }
    else {
	txt->buf = CreateWCStringOfLineTobeKilled(txt);
	DeleteToLineEndSylTextBlockSet(txt->tbs, &txt->fontset, width,
				       txt->current.x, txt->current.y,
				       &new_x, &new_y);
    }
    MoveCursorWithSavingWidth(txt, new_x, new_y);
}

static int
GetHeadLineOfLine(SylTextBlockSet *tbs, int y)
{
    while (y > 0 && IsEndOfLineAtLine(tbs, y - 1) == False)
	--y;
    return (y);
}

static int
GetTailLineOfLine(SylTextBlockSet *tbs, int y)
{
    int n = tbs->n_lines - 1;

    while (y < n && IsEndOfLineAtLine(tbs, y) == False)
	++y;
    return (y);
}

static void
CursorBeginingOfLine(SylTextArea *txt, Time tm __unused)
{
    int y;

    y = GetHeadLineOfLine(txt->tbs, txt->current.y);
    if (txt->current.y == y && txt->current.x == 0)
	return;
    if (txt->selected)
	ResetSelectionOwner(txt);
    MoveCursorWithSavingWidth(txt, 0, y);
}

static void
CursorBeginingOfLineWithShift(SylTextArea *txt, Time tm)
{
    int y;

    y = GetHeadLineOfLine(txt->tbs, txt->current.y);
    if (txt->current.y == y && txt->current.x == 0)
	return;
    if (txt->selected == False)
	txt->started = txt->current;
    MoveCursorWithSavingWidth(txt, 0, y);
    ChangeSelectionOwner(txt, tm);
}

static void
CursorEndOfLine(SylTextArea *txt, Time tm __unused)
{
    int y, s;

    y = GetTailLineOfLine(txt->tbs, txt->current.y);
    s = GetLimitAtLine(txt->tbs, y);
    if (txt->current.y == y && txt->current.x == s)
	return;
    if (txt->selected)
	ResetSelectionOwner(txt);
    MoveCursorWithSavingWidth(txt, s, y);
}

static void
CursorEndOfLineWithShift(SylTextArea *txt, Time tm)
{
    int y, s;

    y = GetTailLineOfLine(txt->tbs, txt->current.y);
    s = GetLimitAtLine(txt->tbs, y);
    if (txt->current.y == y && txt->current.x == s)
	return;
    if (txt->selected == False)
	txt->started = txt->current;
    MoveCursorWithSavingWidth(txt, s, y);
    ChangeSelectionOwner(txt, tm);
}

static int
IsSeparator(wchar_t c)
{
    return (ispunct_w(c) || isspace_w(c));
}

static int
IsContinuedForwardDelim(SylTextBlockSet *tbs, int *x, int y)
{
    int n, len;
    SylTextBlock *tb;
    wchar_t *str;

    tb = SeekSylTextBlockAtLine(tbs, y);
    n = y - tbs->current_line;
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], 0, len);
    while (*x < len && IsSeparator(str[*x]))
	++(*x);
    free(str);
    return (*x == len);
}

static int
IsContinuedForwardWord(SylTextBlockSet *tbs, int *x, int y)
{
    int n, len;
    SylTextBlock *tb;
    wchar_t *str;

    tb = SeekSylTextBlockAtLine(tbs, y);
    n = y - tbs->current_line;
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], 0, len);
    while (*x < len && !IsSeparator(str[*x]))
	++(*x);
    free(str);
    return (*x == len && IsEndOfLineAtLine(tbs, y) == False);
}

static void
CommonCursorNextWord(SylTextArea *txt, int x, int y)
{
    SylTextBlockSet *tbs = txt->tbs;

    while (IsContinuedForwardDelim(tbs, &x, y) && !IsBottomAtLine(tbs, y)) {
	++y;
	x = 0;
    }
    while (IsContinuedForwardWord(tbs, &x, y) && !IsBottomAtLine(tbs, y)) {
	++y;
	x = 0;
    }
    if (x == GetLengthAtLine(tbs, y) && IsEndOfLineAtLine(tbs, y) == False
	&& IsBottomAtLine(tbs, y) == False) {
	/* NEVER (���르�ꥺ��Ū�ˤ��ꤨ�ʤ�) */
	++y;
	x = 0;
    }
    MoveCursorWithSavingWidth(txt, x, y);
}

static void
CursorNextWord(SylTextArea *txt, Time tm __unused)
{
    if (IsBottomAtLine(txt->tbs, txt->current.y)
	&& txt->current.x >= GetLengthAtLine(txt->tbs, txt->current.y))
	return; 
    if (txt->selected)
	ResetSelectionOwner(txt);
    CommonCursorNextWord(txt, txt->current.x, txt->current.y);
}

static void
CursorNextWordWithShift(SylTextArea *txt, Time tm)
{
    if (IsBottomAtLine(txt->tbs, txt->current.y)
	&& txt->current.x >= GetLengthAtLine(txt->tbs, txt->current.y))
	return; 
    if (txt->selected == False)
	txt->started = txt->current;
    CommonCursorNextWord(txt, txt->current.x, txt->current.y);
    ChangeSelectionOwner(txt, tm);
}

static int
IsContinuedBackwardDelim(SylTextBlockSet *tbs, int *x, int y)
{
    int n, len;
    SylTextBlock *tb;
    wchar_t *str;

    tb = SeekSylTextBlockAtLine(tbs, y);
    n = y - tbs->current_line;
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], 0, len);
    while (*x > 0 && IsSeparator(str[*x - 1]))
	--(*x);
    free(str);
    return (*x == 0);
}

static int
IsContinuedBackwardWord(SylTextBlockSet *tbs, int *x, int y)
{
    int n, len;
    SylTextBlock *tb;
    wchar_t *str;

    tb = SeekSylTextBlockAtLine(tbs, y);
    n = y - tbs->current_line;
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], 0, len);
    while (*x > 0 && !IsSeparator(str[*x - 1]))
	--(*x);
    free(str);
    return (*x == 0 && y > 0 && IsEndOfLineAtLine(tbs, y - 1) == False);
}

static void
CommonCursorPrevWord(SylTextArea *txt, int x, int y)
{
    SylTextBlockSet *tbs = txt->tbs;

    while (IsContinuedBackwardDelim(tbs, &x, y) && y > 0) {
	--y;
	x = GetLengthAtLine(tbs, y);
    }
    while (IsContinuedBackwardWord(tbs, &x, y) && y > 0) {
	--y;
	x = GetLengthAtLine(tbs, y);
    }
    if (x == GetLengthAtLine(tbs, y) && IsEndOfLineAtLine(tbs, y) == False
	&& IsBottomAtLine(tbs, y) == False) {
	++y;
	x = 0;
    }
    MoveCursorWithSavingWidth(txt, x, y);
}

static void
CursorPrevWord(SylTextArea *txt, Time tm __unused)
{
    if (txt->current.y <= 0 && txt->current.x <= 0)
	return; 
    if (txt->selected)
	ResetSelectionOwner(txt);
    CommonCursorPrevWord(txt, txt->current.x, txt->current.y);
}

static void
CursorPrevWordWithShift(SylTextArea *txt, Time tm)
{
    if (txt->current.y <= 0 && txt->current.x <= 0)
	return; 
    if (txt->selected == False)
	txt->started = txt->current;
    CommonCursorPrevWord(txt, txt->current.x, txt->current.y);
    ChangeSelectionOwner(txt, tm);
}

static void
CommonCursorLeft(SylTextArea *txt)
{
    if (--(txt->current.x) < 0) {
	--(txt->current.y);
	txt->current.x = GetLimitAtLine(txt->tbs, txt->current.y);
    }
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
				      txt->current.x, txt->current.y);
    txt->redraw = True;
}

static void
CursorLeft(SylTextArea *txt, Time tm __unused)
{
    if (txt->current.y <= 0 && txt->current.x <= 0)
	return;
    if (txt->selected)
	ResetSelectionOwner(txt);
    CommonCursorLeft(txt);
}

static void
CursorLeftWithShift(SylTextArea *txt, Time tm)
{
    if (txt->current.y <= 0 && txt->current.x <= 0)
	return;
    if (txt->selected == False)
	txt->started = txt->current;
    CommonCursorLeft(txt);
    ChangeSelectionOwner(txt, tm);
}

static void
CommonCursorRight(SylTextArea *txt)
{
    if (++(txt->current.x) > GetLimitAtLine(txt->tbs, txt->current.y)) {
	++(txt->current.y);
	txt->current.x = 0;
    }
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
				      txt->current.x, txt->current.y);
    txt->redraw = True;
}

static void
CursorRight(SylTextArea *txt, Time tm __unused)
{
    if (IsBottomAtLine(txt->tbs, txt->current.y)
	&& txt->current.x >= GetLengthAtLine(txt->tbs, txt->current.y))
	return; 
    if (txt->selected)
	ResetSelectionOwner(txt);
    CommonCursorRight(txt);
}

static void
CursorRightWithShift(SylTextArea *txt, Time tm)
{
    if (IsBottomAtLine(txt->tbs, txt->current.y)
	&& txt->current.x >= GetLengthAtLine(txt->tbs, txt->current.y))
	return; 
    if (txt->selected == False)
	txt->started = txt->current;
    CommonCursorRight(txt);
    ChangeSelectionOwner(txt, tm);
}

void
InsertWCharIntoSylTextArea(SylTextArea *txt, wchar_t c)
{
    int new_x, new_y, width;

    if (txt->selected) {
	DeleteSelectedRegion(txt);
	ResetSelectionOwner(txt);
    }
    width = txt->textwidth;
    if (c != '\n') {
	InsertCharIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
				      txt->current.x, txt->current.y, c,
				      &new_x, &new_y);
    }
    else {
	InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					  txt->current.x, txt->current.y,
					  &new_x, &new_y);
    }
    MoveCursorWithSavingWidth(txt, new_x, new_y);
}

static void
LineFeed(SylTextArea *txt, Time tm __unused)
{
    int new_x, new_y, width;

    if (txt->selected) {
	DeleteSelectedRegion(txt);
	ResetSelectionOwner(txt);
    }
    width = txt->textwidth;
    InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
				      txt->current.x, txt->current.y,
				      &new_x, &new_y);
    MoveCursorWithSavingWidth(txt, new_x, new_y);
}

static void
CommonEdge(SylTextArea *txt, int x)
{
    txt->current.x = x;
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
				      txt->current.x, txt->current.y);
    txt->redraw = True;
}

static void
CursorLeftEdge(SylTextArea *txt, Time tm __unused)
{
    if (txt->current.x > 0) {
	if (txt->selected)
	    ResetSelectionOwner(txt);
	CommonEdge(txt, 0);
    }    
}

static void
CursorLeftEdgeWithShift(SylTextArea *txt, Time tm)
{
    if (txt->current.x > 0) {
	if (txt->selected == False)
	    txt->started = txt->current;
	CommonEdge(txt, 0);
	ChangeSelectionOwner(txt, tm);
    }    
}

static void
CursorRightEdge(SylTextArea *txt, Time tm __unused)
{
    int s = GetLimitAtLine(txt->tbs, txt->current.y);

    if (txt->current.x < s) {
	if (txt->selected)
	    ResetSelectionOwner(txt);
	CommonEdge(txt, s);
    }    
}

static void
CursorRightEdgeWithShift(SylTextArea *txt, Time tm)
{
    int s = GetLimitAtLine(txt->tbs, txt->current.y);

    if (txt->current.x < s) {
	if (txt->selected == False)
	    txt->started = txt->current;
	CommonEdge(txt, s);
	ChangeSelectionOwner(txt, tm);
    }    
}

int
RowsAfterMovingVertically(SylTextArea *txt)
{
    int x;

    x = GetRowsAtLine(txt->tbs, &txt->fontset, txt->saved_width,
		      txt->current.y);
    if (x == GetLengthAtLine(txt->tbs, txt->current.y)
	&& IsEndOfLineAtLine(txt->tbs, txt->current.y) == False
	&& !IsBottomAtLine(txt->tbs, txt->current.y))
	--x;
    return (x);
}

static void
CommonCursorUp(SylTextArea *txt)
{
    --(txt->current.y);
    txt->current.x = RowsAfterMovingVertically(txt);
    txt->redraw = True;
}

static void
CursorUp(SylTextArea *txt, Time tm __unused)
{
    if (txt->current.y > 0) {
	if (txt->selected)
	    ResetSelectionOwner(txt);
	CommonCursorUp(txt);
    }
}

static void
CursorUpWithShift(SylTextArea *txt, Time tm)
{
    if (txt->current.y > 0) {
	if (txt->selected == False)
	    txt->started = txt->current;
	CommonCursorUp(txt);
	ChangeSelectionOwner(txt, tm);
    }
}

static void
CommonCursorDown(SylTextArea *txt)
{
    ++(txt->current.y);
    txt->current.x = RowsAfterMovingVertically(txt);
    txt->redraw = True;
}

static void
CursorDown(SylTextArea *txt, Time tm __unused)
{
    if (!IsBottomAtLine(txt->tbs, txt->current.y)) {
	if (txt->selected)
	    ResetSelectionOwner(txt);
	CommonCursorDown(txt);
    }
}

static void
CursorDownWithShift(SylTextArea *txt, Time tm)
{
    if (!IsBottomAtLine(txt->tbs, txt->current.y)) {
	if (txt->selected == False)
	    txt->started = txt->current;
	CommonCursorDown(txt);
	ChangeSelectionOwner(txt, tm);
    }
}

void
GrabbedCursorUp(SylTextArea *txt)
{
    if (txt->current.y > 0)
	CommonCursorUp(txt);
}

void
GrabbedCursorDown(SylTextArea *txt)
{
    if (!IsBottomAtLine(txt->tbs, txt->current.y))
	CommonCursorDown(txt);
}

static void
SetFocusToNextField(SylTextArea *txt, Time tm)
{
    if (txt->next_field != None)
	XSetInputFocus(txt->disp, txt->next_field, RevertToParent, tm);
}

static void
SetFocusToPrevField(SylTextArea *txt, Time tm)
{
    if (txt->prev_field != None)
	XSetInputFocus(txt->disp, txt->prev_field, RevertToParent, tm);
}

static void
CommonScrollUp(SylTextArea *txt)
{
    txt->visible_begin = max(0, txt->visible_begin - txt->visible_cols);
    txt->current.y = max(0, txt->current.y - txt->visible_cols);
    txt->current.x = RowsAfterMovingVertically(txt);
    txt->redraw = True;
}

static void
ScrollUp(SylTextArea *txt, Time tm __unused)
{
    if (txt->current.y > 0) {
	if (txt->selected)
	    ResetSelectionOwner(txt);
	CommonScrollUp(txt);
    }
}

static void
ScrollUpWithShift(SylTextArea *txt, Time tm)
{
    if (txt->current.y > 0) {
	if (txt->selected == False)
	    txt->started = txt->current;
	CommonScrollUp(txt);
	ChangeSelectionOwner(txt, tm);
    }
}

static void
CommonScrollDown(SylTextArea *txt)
{
    txt->visible_begin = max(0, min(txt->tbs->n_lines - txt->visible_cols,
				    txt->visible_begin + txt->visible_cols));
    txt->current.y = min(txt->tbs->n_lines - 1,
			 txt->current.y + txt->visible_cols);
    txt->current.x = RowsAfterMovingVertically(txt);
    txt->redraw = True;
}

static void
ScrollDown(SylTextArea *txt, Time tm __unused)
{
    if (!IsBottomAtLine(txt->tbs, txt->current.y)) {
	if (txt->selected)
	    ResetSelectionOwner(txt);
	CommonScrollDown(txt);
    }
}

static void
ScrollDownWithShift(SylTextArea *txt, Time tm)
{
    if (!IsBottomAtLine(txt->tbs, txt->current.y)) {
	if (txt->selected == False)
	    txt->started = txt->current;
	CommonScrollDown(txt);
	ChangeSelectionOwner(txt, tm);
    }
}

void (*BranchSylTextArea[])(SylTextArea *, Time) = {
#include "TextArea.branch"
};
