/*
        $Id$

        Copyright (C) 2001 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Layout.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Button.h"
#include "Preedit.h"
#include "TextLine.h"
#include "TextArea.h"
#include "property.h"
#include "PixmapQueue.h"
#include "ListBox.h"
#include "Plate.h"
#include "Null.h"
#include "Control.h"

#include "editor.color"

#define THIS_CLASS "IMStyle"
#define TOPLEVEL_DEFAULT_GEOMETRY "320x240"
#define DEFAULT_WM_NAME "Choose a IM style"

static SylSetting
    Geometry = {"geometry", "Geometry", "", NULL},
    Headline = {"headline", "Headline", DEFAULT_WM_NAME, NULL};

static int MainPower = True;
static int ChosenStyle = 0;

extern char **GlobalAv;
extern int GlobalAc;

static void
GetToplevelPreferences(Display *disp, char *name, char *class,
		       unsigned long *pixel)
{
    LoadSylColors(disp, name, class, ColorSet, pixel);
    GetSylSetting(disp, name, class, &Geometry);
    GetSylSetting(disp, name, class, &Headline);
}

static XSizeHints
GetToplevelWindowGeometry(Display *disp, char *u_geom, char *d_geom,
		      int *x, int *y, int *w, int *h)
{
    XSizeHints xsize;
    int geom_mask, width, height, gravity;

    /*
      ICCCM���XSizeHints��¤�ΤΥ���x, y, width, height��̵�뤷�Ƥ��롣
      xprop�ǰ۾���ͤ�ɽ�������Τ�xprop������ICCCM��̵�뤷�Ƥ��뤿�ᡣ
    */
    xsize.flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    &xsize, x, y ,&width, &height, &gravity);
    if (geom_mask & (XValue | YValue))
	xsize.flags |= USPosition;
    xsize.flags |= (geom_mask & (WidthValue | HeightValue)) ? USSize : PSize;
    if (width && height) {
	*w = width;
	*h = height;
    }
    xsize.win_gravity = gravity;
    xsize.flags |= PWinGravity;
    return (xsize);
}

static void
ChoiceCB(void *cb_data __unused, char *key)
{
    ChosenStyle = atoi(key);
    MainPower = False;
}

int
ChoiceIMStyle(XIM im)
{
    Display *disp = XDisplayOfIM(im);
    Window window;
    XIMStyle style;
    XIMStyles *supported;
    XSizeHints size_hint;
    int n, x, y, width, height;
    SylControlManager *mgr;
    SylPlate *label;
    SylListBox *choice;
    unsigned long *pixel;

    if ((pixel = CreateSylColors(ColorSet)) == NULL) {
        fprintf(stderr, "%s: cannot create colorset.\n", GlobalAv[0]);
        exit(1);
    }
    GetToplevelPreferences(disp, "imstyle", THIS_CLASS, pixel);
    size_hint = GetToplevelWindowGeometry(disp, Geometry.spec,
	TOPLEVEL_DEFAULT_GEOMETRY, &x, &y, &width, &height);
    window = XCreateSimpleWindow(disp, DefaultRootWindow(disp), x, y,
	width, height, 1, pixel[Foreground], pixel[MediumGray]);
    SetProperties(disp, window, Headline.spec, "imstyle", THIS_CLASS,
	GlobalAc, GlobalAv, &size_hint, None, None, None);
    XSelectInput(disp, window, StructureNotifyMask);

    if ((mgr = CreateSylControlManager(disp, window)) == NULL) {
        fprintf(stderr, "%s: cannot create SylControlManager.\n", GlobalAv[0]);
        exit(1);
    }
    label = CreateSylControlOfSylPlate(mgr, "styleList", 1);
    choice = CreateSylControlOfSylListBox(mgr, "styleList", ChoiceCB, NULL);
    if (label == NULL || choice == NULL) {
        fprintf(stderr, "%s: cannot create SylControl.\n", GlobalAv[0]);
        exit(1);
    }

    XGetIMValues(im, XNQueryInputStyle, &supported, NULL);
    for (n = 0; n < supported->count_styles; ++n) {
	char *preedit, *status, key[64], val[64];
        style = supported->supported_styles[n];

	if (style & XIMPreeditArea)
	    preedit = "PreeditArea";
	else if (style & XIMPreeditCallbacks)
	    preedit = "PreeditCallbacks";
	else if (style & XIMPreeditPosition)
	    preedit = "PreeditPosition";
	else if (style & XIMPreeditNothing)
	    preedit = "PreeditNothing";
	else if (style & XIMPreeditNone)
	    preedit = "PreeditNone";
	else
	    preedit = "PreeditUnknown";

	if (style & XIMStatusArea)
	    status = "StatusArea";
	else if (style & XIMStatusCallbacks)
	    status = "StatusCallbacks";
	else if (style & XIMStatusNothing)
	    status = "StatusNothing";
	else if (style & XIMStatusNone)
	    status = "StatusNone";
	else
	    status = "StatusUnknown";

	sprintf(key, "%ld", style);
	sprintf(val, "%s/%s", preedit, status);
	AppendToSylListBox(choice, key, val);
    }
    XFree(supported);

    SetOrderSylLayoutManager(mgr->layout, SylHLayout(
	SylVRule(),
	SylVLayout(
	    SylHRule(),
	    SylPaneOfSylControlManager(mgr, label->window),
	    SylPaneOfSylControlManager(mgr, choice->target),
	    SylHRule(),
	    NULL),
	SylVRule(),
	NULL));
    SetDefaultFocusWindow(choice->target);

    XMapRaised(disp, window);
    while (MainPower) {
	XEvent ev;

        while (XEventsQueued(disp, QueuedAfterReading) == 0
               && NiceSylControlManager(mgr)) {
            ;
	}
	XNextEvent(disp, &ev); 
	if (IsWMCloseMessage(&ev))
	    break;
	if (ev.type == MappingNotify)
	    XRefreshKeyboardMapping(&(ev.xmapping));
        SendSylControlManager(mgr, &ev);
    }

    FreeSylControlManager(mgr);
    FreeSylColors(pixel);
    XDestroyWindow(disp, window);
    return (ChosenStyle);
}
