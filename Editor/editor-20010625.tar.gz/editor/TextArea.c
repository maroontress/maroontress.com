/*
        TextArea.c 1.5 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999, 2000, 2001 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#ifdef HAS_WCHAR_H
#include <wchar.h>
#endif
#ifdef HAS_WCTYPE_H
#include <wctype.h> /* widec.h������˸ƤФ�� */
#endif

#include "Selection.h"
#include "Resource.h"
#include "FontStack.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Preedit.h"
#include "TextArea.h"
#include "TextArea1.h"
#include "TextArea2.h"
#include "TextArea3.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#ifdef HAS_ISW_FUNCS
#define isprint_w iswprint
#else
#define isprint_w isprint
#endif

#define THIS_CLASS "TextArea"
#define DRAGGING_SCROLL_DELAY (20 * 1000) /* microseconds */
#define DECORATE_FOCUS_IN
#define ON_THE_SPOT

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    FontSet0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

#include "TextArea.color"
#include "TextArea.bind"

static SylSetting
    Gravity0 = {"gravity", "Gravity", "Center", NULL},
    *Gravity[] = {&Gravity0, NULL};

static SylSetting
    RippleWidth = {"focusRippleWidth", "LineWidth", "1", NULL},
    FrameWidth = {"focusFrameWidth", "LineWidth", "1", NULL};

static SylFontStack DownArrowStack[] = {
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
    {SYL_FS_DESCENT},
    {SYL_FS_STACK, 0},
    {SYL_FS_HEIGHT}, {SYL_FS_SUB}, {SYL_FS_DESCENT},
        {SYL_FS_SUB}, {SYL_FS_CONST, 1},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_DRAW_SEGMENT}, {SYL_FS_CLEAR_STACKS},
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},
        {SYL_FS_DIV}, {SYL_FS_CONST, 4},
    {SYL_FS_MIN}, {SYL_FS_CONST, 1}, {SYL_FS_MUL}, {SYL_FS_CONST, 2},
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_HEIGHT}, {SYL_FS_SUB}, {SYL_FS_DESCENT},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_SUB}, {SYL_FS_CONST, 1}, {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_STACK, 0},
    {SYL_FS_STACK, 0},
    {SYL_FS_STACK, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_DRAW_LINES}, {SYL_FS_CONST, 3}, {SYL_FS_EOF}};

static SylFontStack LeftStopStack[] = {
    {SYL_FS_HEIGHT}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},
        {SYL_FS_DIV}, {SYL_FS_CONST, 8},
    {SYL_FS_ADD}, {SYL_FS_CONST, 1}, {SYL_FS_MIN}, {SYL_FS_CONST, 1},
    {SYL_FS_HEIGHT}, {SYL_FS_SUB}, {SYL_FS_DESCENT},
        {SYL_FS_SUB}, {SYL_FS_CONST, 1},
    {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 2},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 0}, {SYL_FS_ADD}, {SYL_FS_STACK, 2},
    {SYL_FS_DRAW_SEGMENT},
    {SYL_FS_STACK, 1}, {SYL_FS_ADD}, {SYL_FS_CONST, 1},
    {SYL_FS_STACK, 0},
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_STACK, 1},
        {SYL_FS_SUB}, {SYL_FS_STACK, 1},
    {SYL_FS_SUB}, {SYL_FS_CONST, 1},
    {SYL_FS_STACK, 2},
    {SYL_FS_CONST, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 2},
        {SYL_FS_MUL}, {SYL_FS_CONST, 2},
    {SYL_FS_FILL_POLYGON}, {SYL_FS_CONST, 3}, {SYL_FS_EOF}};

static SylFontStack CenterLDotStack[] = {
    {SYL_FS_WIDTH}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},
        {SYL_FS_DIV}, {SYL_FS_CONST, 4},
    {SYL_FS_MIN}, {SYL_FS_CONST, 1}, {SYL_FS_MUL}, {SYL_FS_CONST, 2},
    {SYL_FS_STACK, 0}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0}, {SYL_FS_ADD}, {SYL_FS_STACK, 1},
    {SYL_FS_HEIGHT}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},
        {SYL_FS_SUB}, {SYL_FS_STACK, 0},
    {SYL_FS_MIN}, {SYL_FS_CONST, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_CONST, 0},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 1},
    {SYL_FS_CONST, 0},
    {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 4},
    {SYL_FS_CONST, 0},
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_STACK, 1},
    {SYL_FS_STACK, 4},
    {SYL_FS_STACK, 4},
    {SYL_FS_FILL_POLYGON}, {SYL_FS_CONST, 8}, {SYL_FS_EOF}};

#ifdef ON_THE_SPOT
static SylLocation
PreeditLocation(SylTextArea *txt, int len)
{
    /*
      1999-10-14: ���Խ����ϰ��֤������˶᤯�����Խ�ʸ����������ˤ��줬
      ���ιԤ���Ƭ�ذ�ư���Ƥ��ޤ��褦�ʾ�硢���Խ�ʸ������ΰ�ȥ����å�
      ���֤�����Ƥ��ޤ��Х����������쥯�������ΰ�ȤϰۤʤꡢưŪ���Ѳ�
      �������Խ�ʸ�����ΰ�Ǥϡ������åȰ��֤��������η�̤��θ���ʤ����
      �ʤ�ʤ��ä��Τˡ��߷��ʳ��Ǥϵ��դ��Ƥ��ʤ��ä���
      
      ����Ū�ˤ��δؿ�������txt->preedit_begin�� ``����'' ���Ƥ褤���㳰Ū�ˡ�
      ����⥸�塼��ϡ�txt->preedit_begin���������Ȥ��ƻ��Ѥ��ʤ��פ��ᡢ
      ��Ψ��ͤ���ľ�ܻ��Ȥ��Ƥ��뤬�����Խ�ʸ�������˴ط�����ؿ��Ϥ��٤ơ�
      ���δؿ����������������ʤ���Фʤ�ʤ���
    */
    SylLocation origin;

    if (txt->preedit_begin.x >= GetLengthAtLine(txt->tbs, txt->preedit_begin.y)
	&& IsEndOfLineAtLine(txt->tbs, txt->preedit_begin.y) == False
	&& !IsBottomAtLine(txt->tbs, txt->preedit_begin.y)) {
	origin.x = 0;
	origin.y = txt->preedit_begin.y + 1;
    }
    else {
	origin = txt->preedit_begin;
    }
    return (LocationOfDestination(txt, &origin, len));
}

static void
InitCB(void *cb_data)
{
    SylTextArea *txt = (SylTextArea *)cb_data;

    txt->preedit_begin = txt->current;
}

static void
DeleteCB(void *cb_data, int first, int length)
{
    SylTextArea *txt = (SylTextArea *)cb_data;
    SylLocation left, right;
    
    left = PreeditLocation(txt, first);
    right = LocationOfDestination(txt, &left, length);
    DeleteRegion(txt, &left, &right);
}

static void
InsertCB(void *cb_data, wchar_t *wcs)
{
    SylTextArea *txt = (SylTextArea *)cb_data;
    SylLocation left, right;
    int len;

    if (txt->selected) {
	GetSelectedRegion(txt, &left, &right);
	DeleteRegion(txt, &left, &right);
	ResetSelectionOwner(txt);
	txt->preedit_begin = txt->current;
    }
    left = txt->current;
    InsertStringIntoSylTextBlockSet(txt->tbs, &txt->fontset, txt->textwidth,
				    txt->current.x, txt->current.y, wcs,
				    &(txt->current.x), &(txt->current.y));
    right = txt->current;
    /*
      2001-06-09: ���Խ����ϰ��֤���Ƭ�ǡ����Խ�ʸ����������ˤ��줬
      ���ιԤι����ذ�ư���Ƥ��ޤ��褦�ʾ�硢���Խ�ʸ������ΰ�ȥ����å�
      ���֤�����Ƥ��ޤ��Х�������PreeditLocation()���������Ȥ���
      ����Ȥ��Ƥ�����

      ���δؿ���PreeditLocation()��Ʊ�ͤ�txt->preedit_begin��ľ�ܻ��Ȥ��롣
    */
    if (left.x == 0 && left.y > 0
	&& IsEqualSylLocation(&left, &txt->preedit_begin)
	&& (len = wstrlen(wcs) - SizeOfRegion(txt, &left, &right)) > 0) {
	txt->preedit_begin.x = GetLengthAtLine(txt->tbs, left.y - 1) - len;
	txt->preedit_begin.y = left.y - 1;
    }
}

static void
CaretCB(void *cb_data, int pos)
{
    SylTextArea *txt = (SylTextArea *)cb_data;

    txt->current = PreeditLocation(txt, pos);
}

static void
PreeditRedraw(SylTextArea *txt)
{
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
                                      txt->current.x, txt->current.y);
    txt->redraw = True;
}

static int
PreeditStart(XIC ic, SylTextArea *txt, void *call_data)
{
    return (StartSylPreedit(&txt->preedit, ic, call_data, txt, InitCB));
}

static void
PreeditDone(XIC ic, SylTextArea *txt, void *call_data)
{
    DoneSylPreedit(&txt->preedit, ic, call_data, txt, DeleteCB);
    PreeditRedraw(txt);
}

static void
PreeditDraw(XIC ic, SylTextArea *txt, XIMPreeditDrawCallbackStruct *dcs)
{
    DrawSylPreedit(&txt->preedit, ic, dcs, txt, InitCB, DeleteCB, InsertCB,
		   CaretCB);
    PreeditRedraw(txt);
}

static void
PreeditCaret(XIC ic, SylTextArea *txt, XIMPreeditCaretCallbackStruct *ccs)
{
    CaretSylPreedit(&txt->preedit, ic, ccs, txt, CaretCB);
    PreeditRedraw(txt);
}

static void
SetICPreeditCallbacks(XIC ic, SylTextArea *txt)
{
    XVaNestedList list;
    XIMCallback Start, Done, Draw, Caret;

    Start.client_data = (XPointer)txt;
    Start.callback = (XIMProc)PreeditStart;
    Done.client_data = (XPointer)txt;
    Done.callback = (XIMProc)PreeditDone;
    Draw.client_data = (XPointer)txt;
    Draw.callback = (XIMProc)PreeditDraw;
    Caret.client_data = (XPointer)txt;
    Caret.callback = (XIMProc)PreeditCaret;
    list = XVaCreateNestedList(0, XNPreeditStartCallback, &Start,
			       XNPreeditDoneCallback, &Done,
			       XNPreeditDrawCallback, &Draw,
			       XNPreeditCaretCallback, &Caret, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}
#endif /* #ifdef ON_THE_SPOT */

static void
ResetIC(SylTextArea *txt)
{
    ResetSylPreedit(&txt->preedit, txt, DeleteCB);
    PreeditRedraw(txt);
}

static void
GetWindowPointer(Display *disp, Window w, int *x, int *y)
{
    Window root, child;
    int rx, ry, kb;

    XQueryPointer(disp, w, &root, &child, &rx, &ry, x, y, &kb);
}

static void
MoveCursorDragged(SylTextArea *txt)
{
    int x, y;

    GetWindowPointer(txt->disp, txt->window, &x, &y);
    if (y < 0) {
	y = 0;
	x = 0;
    }
    txt->current = LocationPointed(txt, x, y);
}

static void
CursorJumpAtLine(SylTextArea *txt, int n) /* added 1999-10-09 */
{
#ifdef ON_THE_SPOT
    if (txt->preedit.ic != NULL && txt->preedit.style & XIMPreeditCallbacks)
	ResetIC(txt);
#endif
    txt->current.y = min(n, txt->tbs->n_lines - 1);
    txt->current.x = RowsAfterMovingVertically(txt);
    if (txt->selected)
	ResetSelectionOwner(txt);
}

static void
adjustcallback(void *cb_data, int n)
{
    SylTextArea *txt = (SylTextArea *)cb_data;

    txt->visible_begin = n;
    if (txt->vsb->grabbed == True) {
	if (txt->current.y < n) {
	    CursorJumpAtLine(txt, n);
	}
	else if (txt->current.y >= n + txt->visible_cols) {
	    CursorJumpAtLine(txt, n + txt->visible_cols - 1);
	}
    }
    txt->redraw = True;
}

static void
scrollcallback(void *cb_data, int n, int m)
{
    adjustcallback(cb_data, n + m);
}

static Pixmap
CreateMark(Display *disp, Window win, XFontSet fs, int w, int h,
	   SylFontStack *s)
{
    GC gc;
    Pixmap d;

    d = XCreatePixmap(disp, win, w, h, 1);
    gc = XCreateGC(disp, d, 0, 0);
    XSetForeground(disp, gc, 0);
    XFillRectangle(disp, d, gc, 0, 0, w, h);
    XSetForeground(disp, gc, 1);
    DrawSylFontStack(disp, d, gc, fs, 0, 0, s);
    XFreeGC(disp, gc);
    return (d);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
		  SylTextArea *txt)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
	return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
	FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
	FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
	return (1);

    LoadSylColors(disp, fq_name, fq_class, ColorSet, txt->pixel);
    LoadSylFontSets(disp, fq_name, fq_class, FontSet, &txt->fontset);
    LoadSylKeymap(disp, fq_name, fq_class, KeyBinding, txt->keymap);
    LoadSylGravities(disp, fq_name, fq_class, Gravity, &txt->gravity);
    GetSylSetting(disp, fq_name, fq_class, &RippleWidth);
    txt->ripple_width = atoi(RippleWidth.spec);
    GetSylSetting(disp, fq_name, fq_class, &FrameWidth);
    txt->frame_width = min(atoi(FrameWidth.spec), txt->fontset.descent);
    return (0);
}

SylTextArea *
CreateSylTextArea(Display *disp, Window parent, char *component)
{
    XWindowAttributes attr;
    SylTextArea *txt;
    Pixmap background;
    static char tile_bits[] = {0x0f, 0x0f, 0x0f, 0x0f, 0xf0, 0xf0, 0xf0, 0xf0};

    if ((txt = (SylTextArea *)malloc(sizeof(SylTextArea))) == NULL)
        goto no_text_area;
    if ((txt->tbs = CreateSylTextBlockSet()) == NULL)
	goto no_text_block_set;
    if ((txt->pixel = CreateSylColors(ColorSet)) == NULL)
	goto no_colorset;
    if ((txt->keymap = CreateSylKeymap()) == NULL)
	goto no_keymap;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, txt))
	goto no_preferences;
    txt->buf = NULL;
    txt->sidemargin = (txt->fontset.width + 2) / 2 + txt->frame_width;
    txt->baseline_skip = (2 * txt->fontset.descent) + txt->fontset.height;
    XGetWindowAttributes(disp, parent, &attr);
    txt->parent_width = attr.width;
    txt->parent_height = attr.height;
    txt->visible_begin = 0;
    txt->visible_cols = max(1, txt->parent_height / txt->baseline_skip);
    txt->width = attr.width;
    txt->textwidth = txt->width - txt->sidemargin * 2;
    txt->height = txt->visible_cols * txt->baseline_skip;
    txt->depth = attr.depth;
    txt->window = XCreateSimpleWindow(disp, parent,
	0, Syl_Y(attr.height, txt->height, txt->gravity),
	txt->width, txt->height,
        0, txt->pixel[Foreground], txt->pixel[MediumGray]);
    background = XCreatePixmapFromBitmapData(disp, txt->window, tile_bits,
	8, 8, txt->pixel[MediumGray], txt->pixel[DimGray], attr.depth);
    XSetWindowBackgroundPixmap(disp, txt->window, background);
    XFreePixmap(disp, background);
    XSelectInput(disp, txt->window, ExposureMask | KeyPressMask
        | ButtonPressMask | OwnerGrabButtonMask | ButtonReleaseMask
        | FocusChangeMask | EnterWindowMask | LeaveWindowMask
	| StructureNotifyMask); 
    SetFQClassHint(disp, parent, component, THIS_CLASS, txt->window);
    XMapRaised(disp, txt->window);
    txt->next_field = None;
    txt->prev_field = None;
    if ((txt->vsb = ReserveSylVScrollbar(disp, txt->window,
        "verticalScrollbar", 0, 0, txt->baseline_skip,
	scrollcallback, adjustcallback, (void *)txt)) == NULL)
	goto no_vscrollbar;
    txt->pixmap = XCreatePixmap(disp, parent,
	txt->width, txt->height, txt->depth);
    txt->wallpaper = None;
    txt->mark_lf = CreateMark(disp, txt->window, txt->fontset.id,
	txt->fontset.width, txt->fontset.height, DownArrowStack);
    txt->mark_eof = CreateMark(disp, txt->window, txt->fontset.id,
	txt->fontset.width, txt->fontset.height, LeftStopStack);
    txt->mark_tab = CreateMark(disp, txt->window, txt->fontset.id,
	txt->fontset.width, txt->fontset.height, CenterLDotStack);
    txt->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, txt->gc, False);
    txt->xgc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, txt->xgc, False);
    XSetBackground(disp, txt->xgc, 0);
    txt->disp = disp;
    txt->parent = parent;
    txt->current.x = 0;
    txt->current.y = 0;
    txt->started = txt->current;
    txt->pasting = txt->current;
    txt->saved_width = 0;
    txt->pointed = False;
    txt->focus = False;
    txt->ic_focus = False;
#ifdef DECORATE_FOCUS_IN
    txt->ripple_delay = 0;
#endif
    txt->grabbed = False;
    txt->selected = False;
    txt->stamp = CurrentTime;
    txt->redraw = True;
    txt->format = False;
    ReserveSylPreedit(&txt->preedit);
#ifdef ON_THE_SPOT
    txt->preedit_begin = txt->current;
    txt->preedit_drawing = 0;
#endif
    txt->property = XInternAtom(disp, "TextAreaProperty", False);
    txt->text_atom = XInternAtom(disp, "TEXT", False);
    txt->compound_text_atom = XInternAtom(disp, "COMPOUND_TEXT", False);
    txt->targets_atom = XInternAtom(disp, "TARGETS", False);
    txt->timestamp_atom = XInternAtom(disp, "TIMESTAMP", False);
    return (txt);

no_vscrollbar:    
    XDestroyWindow(disp, txt->window);
    XFreeFontSet(disp, txt->fontset.id);
no_preferences:
    FreeSylKeymap(txt->keymap);
no_keymap:
    FreeSylColors(txt->pixel);
no_colorset:
    FreeSylTextBlockSet(txt->tbs);
no_text_block_set:
    free(txt);
no_text_area:
    return (NULL);
}

void
FreeSylTextArea(SylTextArea *txt)
{
    PutbackSylPreedit(&txt->preedit);
    XFreePixmap(txt->disp, txt->mark_lf);
    XFreePixmap(txt->disp, txt->mark_eof);
    XFreePixmap(txt->disp, txt->mark_tab);
    XFreePixmap(txt->disp, txt->pixmap);
    if (txt->wallpaper != None)
	XFreePixmap(txt->disp, txt->wallpaper);
    XFreeGC(txt->disp, txt->xgc);
    XFreeGC(txt->disp, txt->gc);
    PutbackSylVScrollbar(txt->vsb);
    XDestroyWindow(txt->disp, txt->window);
    XFreeFontSet(txt->disp, txt->fontset.id);
    FreeSylKeymap(txt->keymap);
    FreeSylColors(txt->pixel);
    FreeSylTextBlockSet(txt->tbs);
    if (txt->buf != NULL)
	free(txt->buf);
    free(txt);
}

static void
SetICSpotLocation(XIC ic, int x, int y)
{
    XVaNestedList list;
    XPoint spot;
    
    spot.x = x;
    spot.y = y;
    list = XVaCreateNestedList(0, XNSpotLocation, &spot, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}

static void
SetICFontSet(XIC ic, XFontSet fs, int h)
{
    XVaNestedList list;
    
    list = XVaCreateNestedList(0, XNFontSet, fs, XNLineSpace, h, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}

static void
DrawCursor(SylTextArea *txt, int cx, int cy)
{
    int rx, lx, ty, by;

    if (txt->focus == False)
	return;
    lx = cx - ((txt->fontset.width / 3) & ~1);
    rx = cx + ((txt->fontset.width / 3) & ~1);
    ty = cy + txt->fontset.descent;
    by = cy + txt->fontset.descent + txt->fontset.height - 1;
    XSetLineAttributes(txt->disp, txt->gc, 0, LineSolid, CapButt, JoinRound);
    XDrawLine(txt->disp, txt->pixmap, txt->gc, cx, ty + 1, cx, by - 1);
    XDrawLine(txt->disp, txt->pixmap, txt->gc, lx, ty, cx - 1, ty);
    XDrawLine(txt->disp, txt->pixmap, txt->gc, lx, by, cx - 1, by);
    XDrawLine(txt->disp, txt->pixmap, txt->gc, cx + 1, ty, rx, ty);
    XDrawLine(txt->disp, txt->pixmap, txt->gc, cx + 1, by, rx, by);
    if (txt->preedit.ic != NULL && txt->preedit.style & XIMPreeditPosition) {
	SetICSpotLocation(txt->preedit.ic, cx, ty + txt->fontset.ascent);
    }
}

/**/

static void
DrawImageMark(SylTextArea *txt, unsigned int bg, int x, int y, Pixmap m)
{
    XSetForeground(txt->disp, txt->gc, bg);
    XSetBackground(txt->disp, txt->gc, txt->pixel[Highlighted]);
    XCopyPlane(txt->disp, m, txt->pixmap, txt->gc,
	       0, 0, txt->fontset.width, txt->fontset.height,
	       x, y - txt->fontset.ascent, 1);
}

static void
DrawXparentMark(SylTextArea *txt, int x, int y, Pixmap m)
{
    XSetFunction(txt->disp, txt->xgc, GXandInverted);
    XSetForeground(txt->disp, txt->xgc, ~0);
    XCopyPlane(txt->disp, m, txt->pixmap, txt->xgc,
	       0, 0, txt->fontset.width, txt->fontset.height,
	       x, y - txt->fontset.ascent, 1);
    XSetFunction(txt->disp, txt->xgc, GXor);
    XSetForeground(txt->disp, txt->xgc, txt->pixel[Highlighted]);
    XCopyPlane(txt->disp, m, txt->pixmap, txt->xgc,
	       0, 0, txt->fontset.width, txt->fontset.height,
	       x, y - txt->fontset.ascent, 1);
}

/**/

static int
DrawSpan(SylTextArea *t, unsigned int fg,
	 int x, int y, wchar_t *str, int len, int *w)
{
    int n, m = 0;

    for (n = 0; n < len && str[n] != '\t'; ++n)
	;
    if (n > 0) {
	XSetForeground(t->disp, t->gc, fg);
	XwcDrawString(t->disp, t->pixmap, t->fontset.id, t->gc,
		      x, y, str, n);
	m = abs(XwcTextEscapement(t->fontset.id, str, n));
	*w += m;
    }
    if (n < len) {
	*w += t->fontset.width - 1 + t->fontset.tabsep;
	*w /= t->fontset.tabsep;
	*w *= t->fontset.tabsep;
	DrawXparentMark(t, x + m, y, t->mark_tab);
	++n;
    }
    return (n);
}

static void
DrawText(SylTextArea *t, unsigned int fg,
	 int x, int w, int y, wchar_t *str, int len)
{
    int n;

    while ((n = DrawSpan(t, fg, x + w, y, str, len, &w)) < len) {
	str += n;
	len -= n;
    }	
}

static void
DrawTextWithUnderline(SylTextArea *t, unsigned int fg,
		      int x, int w, int y, wchar_t *str, int len)
{
    int m, n;

    m = w;
    while ((n = DrawSpan(t, fg, x + w, y, str, len, &w)) < len) {
	str += n;
	len -= n;
    }	
    y += t->fontset.descent / 2;
    XSetLineAttributes(t->disp, t->gc, t->fontset.descent / 2,
		       LineSolid, CapButt, JoinRound);
    XDrawLine(t->disp, t->pixmap, t->gc, x + m, y, x + w, y);
}

static int
DrawImageSpan(SylTextArea *t, unsigned int fg, unsigned int bg,
	      int x, int y, wchar_t *str, int len, int *w)
{
    int n, d, m = 0;

    for (n = 0; n < len && str[n] != '\t'; ++n)
	;
    if (n > 0) {
	XSetForeground(t->disp, t->gc, fg);
	XSetBackground(t->disp, t->gc, bg);
	XwcDrawImageString(t->disp, t->pixmap, t->fontset.id, t->gc,
			   x, y, str, n);
	m = abs(XwcTextEscapement(t->fontset.id, str, n));
	*w += m;
    }
    if (n < len) {
	d = *w;
	*w += t->fontset.width - 1 + t->fontset.tabsep;
	*w /= t->fontset.tabsep;
	*w *= t->fontset.tabsep;
	d = *w - d;
	XSetForeground(t->disp, t->gc, t->pixel[Highlighted]);
	XFillRectangle(t->disp, t->pixmap, t->gc, x + m, y - t->fontset.ascent,
		       d, t->fontset.height);
	DrawImageMark(t, fg, x + m, y, t->mark_tab);
	++n;
    }
    return (n);
}

static void
DrawImageText(SylTextArea *t, unsigned int fg, unsigned int bg,
	      int x, int w, int y, wchar_t *str, int len)
{
    int n;

    while ((n = DrawImageSpan(t, fg, bg, x + w, y, str, len, &w))
	   < len) {
	str += n;
	len -= n;
    }	
}

/**/

static void
DrawNormalText(SylTextArea *txt, int x, int w, int y, wchar_t *s, int n)
{
    /*
      XSetForeground(txt->disp, txt->gc, txt->pixel[0]);
      DrawText(txt->disp, txt->pixmap, &txt->fontset, txt->gc, x, w, y, s, n);
    */
    DrawText(txt, txt->pixel[Foreground], x, w, y, s, n);
}

static void
DrawReverseText(SylTextArea *txt, int x, int w, int y, wchar_t *s, int n,
		unsigned long bg_pixel)
{
    /*
      XSetForeground(txt->disp, txt->gc, bg_pixel);
      XSetBackground(txt->disp, txt->gc, txt->pixel[0]);
      DrawImageText(txt->disp, txt->pixmap, &txt->fontset, txt->gc, x, w, y,
      s, n);
    */
    DrawImageText(txt, bg_pixel, txt->pixel[Foreground], x, w, y, s, n);
}

static void
DrawReverseDumb(SylTextArea *txt, int x, int w, int y, wchar_t *s, int n)
{
    /*
      XSetBackground(txt->disp, txt->gc, txt->pixel[2]);
      DrawImageText(txt->disp, txt->pixmap, &txt->fontset, txt->gc, x, w, y,
      s, n);
    */
    DrawImageText(txt, txt->pixel[Foreground], txt->pixel[MediumGray],
		  x, w, y, s, n);
}

static void
DrawTextBody(SylTextArea *txt, SylTextBlock *tb, int m, int n, int cy, 
	     int leftmargin, int topmargin, unsigned long bg,
	     SylLocation *head, SylLocation *tail)
{
    static wchar_t cl_mark[] = {' '};
    wchar_t *str;
    int x, w, y, len, continued = False;

    x = leftmargin;
    y = cy + topmargin;
    len = LengthOfSylText(tb->body[m]);
    str = CreateWCStringFromSylText(tb->body[m], 0, len);

#ifdef ON_THE_SPOT
    if (txt->preedit_drawing < txt->preedit.n_chars
	&& n >= txt->preedit_begin.y) {
	int i;

	if (n == txt->preedit_begin.y && txt->preedit_begin.x > 0) {
	    DrawNormalText(txt, x, 0, y, str, txt->preedit_begin.x);
	    w = TextEscapement(&txt->fontset, str, txt->preedit_begin.x);
	    i = txt->preedit_begin.x;
	}
	else {
	    w = 0;
	    i = 0;
	}
	for (; i < len && txt->preedit_drawing < txt->preedit.n_chars; ++i) {
	    switch(txt->preedit.feedback[txt->preedit_drawing]) {
	    case XIMReverse:
		DrawImageText(txt, bg, txt->pixel[Preedited],
			      x, w, y, str + i, 1);
		break;
	    case XIMUnderline:
		DrawTextWithUnderline(txt, txt->pixel[Preedited],
				      x, w, y, str + i, 1);
		break;
	    default:
		DrawText(txt, txt->pixel[Preedited], x, w, y, str + i, 1);
		break;
	    }
	    w = TextEscapement(&txt->fontset, str, i + 1);
	    ++(txt->preedit_drawing);
	}
	if (i < len)
	    DrawNormalText(txt, x, w, y, str + i, len - i);
	continued = False;
    }
    else
#endif /* #ifdef ON_THE_SPOT */
    if (!txt->selected || n < head->y || tail->y < n) {
	DrawNormalText(txt, x, 0, y, str, len);
	continued = False;
    }
    else if (head->y < n && n < tail->y) {
	DrawReverseText(txt, x, 0, y, str, len, bg);
	continued = True;
    }
    else if (head->y == n && n == tail->y) {
	DrawNormalText(txt, x, 0, y, str, head->x);
	w = TextEscapement(&txt->fontset, str, head->x);
	DrawReverseText(txt, x, w, y, str + head->x, tail->x - head->x, bg);
	w = TextEscapement(&txt->fontset, str, tail->x);
	DrawNormalText(txt, x, w, y, str + tail->x, len - tail->x);
	continued = False;
    }
    else if (head->y == n) {
	DrawNormalText(txt, x, 0, y, str, head->x);
	w = TextEscapement(&txt->fontset, str, head->x);
	DrawReverseText(txt, x, w, y, str + head->x, len - head->x, bg);
	continued = True;
    }
    else if (tail->y == n) {
	DrawReverseText(txt, x, 0, y, str, tail->x, bg);
	w = TextEscapement(&txt->fontset, str, tail->x);
	DrawNormalText(txt, x, w, y, str + tail->x, len - tail->x);
	continued = False;
    }

    w = TextEscapement(&txt->fontset, str, len);
    if (EndOfLineSylText(tb->body[m])) {
	if (continued)
	    DrawImageMark(txt, bg, x + w, y, txt->mark_lf);
	else
	    DrawXparentMark(txt, x + w, y, txt->mark_lf);
    }
    else if (tb->next == NULL && m + 1 == tb->n_bodies) {
	DrawXparentMark(txt, x + w, y, txt->mark_eof);
    }
    else
	DrawReverseDumb(txt, x, w, y, cl_mark, 1);
    if (n == txt->current.y) {
	w = TextEscapement(&txt->fontset, str, txt->current.x);
	XSetForeground(txt->disp, txt->gc, txt->pixel[CaretColor]);
	DrawCursor(txt, x + w, cy);
    }
    free(str);
}

#ifdef DECORATE_FOCUS_IN
static void
DrawSpot(SylTextArea *txt, int r)
{
    int x, y;

    x = txt->sidemargin;
    y = txt->fontset.descent + txt->fontset.ascent;
    x += GetWidthAtLine(txt->tbs, &txt->fontset,
			txt->current.x, txt->current.y);
    y += (txt->current.y - txt->visible_begin) * txt->baseline_skip;
    XSetForeground(txt->disp, txt->gc, txt->pixel[RippleColor]);
    XSetLineAttributes(txt->disp, txt->gc, txt->ripple_width,
		       LineSolid, CapButt, JoinRound);
    XDrawArc(txt->disp, txt->pixmap, txt->gc,
	     x - r, y - r - txt->fontset.descent, 2 * r,  2 * r,
	     0, 360 * 64);
}
#endif /* #ifdef DECORATE_FOCUS_IN */

#ifdef SHADED_BACKGROUND
static unsigned long
MaskToMult(unsigned long m)
{
    unsigned long r;

    for (r = 1; m && (m & 0x01) == 0; r <<= 1)
        m >>= 1;
    return (r);
}

static void
DrawShadedBackground(SylTextArea *txt, unsigned long bg_pixel)
{
    Visual *v = DefaultVisual(txt->disp, DefaultScreen(txt->disp));
    unsigned long r_mult, g_mult, b_mult;
    int sr, sg, sb, dr, dg, db, y, y1, y2, y3, dy, dw, pixel;

    if (v->class != TrueColor)
	return;

    r_mult = MaskToMult(v->red_mask);
    g_mult = MaskToMult(v->green_mask);
    b_mult = MaskToMult(v->blue_mask);

    sr = (bg_pixel & v->red_mask) / r_mult;
    sg = (bg_pixel & v->green_mask) / g_mult;
    sb = (bg_pixel & v->blue_mask) / b_mult;
    dr = sr * 80 / 100;
    dg = sg * 80 / 100;
    db = sb * 80 / 100;

    y1 = (txt->current.y - txt->visible_begin) * txt->baseline_skip;
    y2 = y1 + txt->baseline_skip;
    y3 = txt->height;
    dy = 4;
    dw = y3 - y2;
    for (y = 0; y < y1; y += dy) {
	int r = ((y1 - y) * dr + y * sr) / y1;
	int g = ((y1 - y) * dg + y * sg) / y1;
	int b = ((y1 - y) * db + y * sb) / y1;
	pixel = r * r_mult + g * g_mult + b * b_mult;
	XSetForeground(txt->disp, txt->gc, pixel);
	XFillRectangle(txt->disp, txt->pixmap, txt->gc, 0, y, txt->width, dy);
    }
    XSetForeground(txt->disp, txt->gc, bg_pixel);
    XFillRectangle(txt->disp, txt->pixmap, txt->gc,
		   0, y1, txt->width, txt->baseline_skip);
    for (y = y2; y < y3; y += dy) {
	int r = ((y - y2) * dr + (y3 - y) * sr) / dw;
	int g = ((y - y2) * dg + (y3 - y) * sg) / dw;
	int b = ((y - y2) * db + (y3 - y) * sb) / dw;
	pixel = r * r_mult + g * g_mult + b * b_mult;
	XSetForeground(txt->disp, txt->gc, pixel);
	XFillRectangle(txt->disp, txt->pixmap, txt->gc, 0, y, txt->width, dy);
    }
}
#endif

static void
DrawTextArea(SylTextArea *txt)
{
    SylTextBlock *tb;
    SylLocation left, right;
    int n, y, m, n_lim, offset, leftmargin, topmargin;
    unsigned long bg_pixel;

    leftmargin = txt->sidemargin;
    topmargin = txt->fontset.descent + txt->fontset.ascent;
    bg_pixel = ((txt->pointed == True)
		? txt->pixel[Illuminated] : txt->pixel[Background]);
    if (txt->visible_begin + txt->visible_cols > txt->tbs->n_lines)
	txt->visible_begin = max(0, txt->tbs->n_lines - txt->visible_cols);
    if (txt->current.y < txt->visible_begin)
	txt->visible_begin = txt->current.y;
    else if (txt->current.y >= txt->visible_begin + txt->visible_cols)
	txt->visible_begin = txt->current.y - txt->visible_cols + 1;
    n = txt->visible_begin;
    n_lim = txt->visible_begin + txt->visible_cols;
#ifdef SHADED_BACKGROUND
    DrawShadedBackground(txt, bg_pixel);
#else
    if (txt->wallpaper == None) {
	XSetForeground(txt->disp, txt->gc, bg_pixel);
	XFillRectangle(txt->disp, txt->pixmap, txt->gc,
		       0, 0, txt->width, txt->height);
    }
    else {
	XSetTile(txt->disp, txt->gc, txt->wallpaper);
	XSetFillStyle(txt->disp, txt->gc, FillTiled);
	XFillRectangle(txt->disp, txt->pixmap, txt->gc,
		       0, 0, txt->width, txt->height);
	XSetFillStyle(txt->disp, txt->gc, FillSolid);
    }
#endif
#ifdef ON_THE_SPOT
    if (txt->preedit.n_chars > 0) {
	SylLocation preedit_begin;
	
	preedit_begin = PreeditLocation(txt, 0);
	if (preedit_begin.y < n) {
	    SylLocation top;
	    
	    top.x = 0;
	    top.y = n;
	    txt->preedit_drawing = SizeOfRegion(txt, &preedit_begin, &top);
	}
	else {
	    txt->preedit_drawing = 0;
	}
    }
#endif /* #ifdef ON_THE_SPOT */
    y = 0;
    tb = SeekSylTextBlockAtLine(txt->tbs, n);
    offset = txt->tbs->current_line;
    GetSelectedRegion(txt, &left, &right);
    for (; tb != NULL && n < n_lim; tb = tb->next) {
	for (m = n - offset; n < n_lim && m < tb->n_bodies; ++m) {
	    DrawTextBody(txt, tb, m, n, y, leftmargin, topmargin, bg_pixel,
			 &left, &right);
	    ++n;
	    y += txt->baseline_skip;
	}
	offset += tb->n_bodies;
    }
    if (txt->focus == True) {
	XSetForeground(txt->disp, txt->gc, txt->pixel[FrameColor]);
	XSetLineAttributes(txt->disp, txt->gc, 0,
			   LineSolid, CapButt, JoinRound);
	for (n = 0; n < txt->frame_width; ++n) {
	    XDrawRectangle(txt->disp, txt->pixmap, txt->gc, n, n,
			   txt->width - 1 - 2 * n, txt->height - 1 - 2 * n);
	}
    }
}

static void
FormatAll(SylTextArea *txt)
{
    SylText *cur, *next;
    SylTextBlock *tb;
    SylTextBlockSet *tbs;
    int y, width, n, len;

    width = txt->textwidth;
    tbs = txt->tbs;
    for (y = 0; (tb = SeekSylTextBlockAtLine(tbs, y)) != NULL; ++y) {
	if (tb->n_bodies >= SYL_TEXTBLOCK_SIZE) {
	    (void) SplitSylTextBlock(txt->tbs);
	    tb = SeekSylTextBlockAtLine(txt->tbs, y);
	}
	n = y - tbs->current_line;
	while (tb != NULL && EndOfLineSylText(tb->body[n]) == False
	       && (next = NextLineSylTextBlock(tb, n)) != NULL) {
	    len = LengthOfSylText(tb->body[n]);
	    cur = ConcatAndCreateSylText(tb->body[n], next);
	    FreeSylText(tb->body[n]);
	    tb->body[n] = cur;
	    FreeNextLine(tbs, tb, n);
	    if (y < txt->current.y) {
		--(txt->current.y);
		if (y == txt->current.y)
		    txt->current.x += len;
	    }
	}
	if (AdjustAfterInserted(tb->body, n, tb->n_bodies,
				&txt->fontset, width)) {
	    ++(tb->n_bodies);
	    ++(tbs->n_lines);
	    if (y < txt->current.y)
		++(txt->current.y);
	    else if ((y == txt->current.y)
		     && ((len = LengthOfSylText(tb->body[n]))
			 <= txt->current.x)) {
		++(txt->current.y);
		txt->current.x -= len;
	    }
	}
    }
}

static void
FormatTextArea(SylTextArea *txt)
{
    int preedit_offset;
    SylLocation preedit_begin;

    /*
      2000-08-13: ���Խ�ʸ���󤬤�����ϥ���������֤����Խ�ʸ���󳫻�
      ���֤˰�ư���ơ����������褢��٤����֤��᤹��
    */
    if (txt->preedit.n_chars > 0) {
        preedit_begin = PreeditLocation(txt, 0);
        preedit_offset = SizeOfRegion(txt, &preedit_begin, &txt->current);
        txt->current = preedit_begin;
	FormatAll(txt);
        txt->preedit_begin = txt->current;
        txt->current = PreeditLocation(txt, preedit_offset);
    }
    else {
	FormatAll(txt);
    }
}

int
NiceSylTextArea(SylTextArea *txt)
{
    int x, y;
    
    XFlush(txt->disp);
    if (txt->ic_focus == True) {
	XSetICValues(txt->preedit.ic, XNFocusWindow, txt->window, NULL);
	if (txt->preedit.style & XIMPreeditPosition) {
	    SetICFontSet(txt->preedit.ic, txt->fontset.id,
			 txt->fontset.height);
	}
#ifdef ON_THE_SPOT
	else if (txt->preedit.style & XIMPreeditCallbacks) {
	    SetICPreeditCallbacks(txt->preedit.ic, txt);
	}
#endif
	txt->ic_focus = False;
	return (1);
    }
    if (txt->format == True) {
	FormatTextArea(txt);
	if (txt->width < txt->parent_width
	    && txt->visible_cols >= txt->tbs->n_lines
	    && txt->parent_width > 0) {
	    txt->width = txt->parent_width;
	    txt->textwidth = txt->width - txt->sidemargin * 2;
	}
	else if (txt->width >= txt->parent_width
		 && txt->visible_cols < txt->tbs->n_lines
		 && txt->parent_width > SYL_VSB_SEP + SYL_VSB_WIDTH) {
	    txt->width = txt->parent_width - (SYL_VSB_SEP + SYL_VSB_WIDTH);
	    txt->textwidth = txt->width - txt->sidemargin * 2;
	}
	else {
	    txt->format = False;
	    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
					      txt->current.x, txt->current.y);
	    XResizeWindow(txt->disp, txt->window, txt->width, txt->height);
	    XFreePixmap(txt->disp, txt->pixmap);
	    txt->pixmap = XCreatePixmap(txt->disp, txt->parent,
					txt->width, txt->height, txt->depth);
	    RangeSylVScrollbar(txt->vsb, txt->tbs->n_lines);
	    txt->redraw = True;
	}
	return (1);
    }
    if (txt->redraw == True) {
	if (txt->width < txt->parent_width
	    && txt->visible_cols >= txt->tbs->n_lines
	    && txt->parent_width > 0) {
	    txt->width = txt->parent_width;
	    txt->textwidth = txt->width - txt->sidemargin * 2;
	    txt->format = True;
	    return (1);
	}
	else if (txt->width >= txt->parent_width
		 && txt->visible_cols < txt->tbs->n_lines
		 && txt->parent_width > SYL_VSB_SEP + SYL_VSB_WIDTH) {
	    txt->width = txt->parent_width - (SYL_VSB_SEP + SYL_VSB_WIDTH);
	    txt->textwidth = txt->width - txt->sidemargin * 2;
	    txt->format = True;
	    return (1);
	}
#ifdef DECORATE_FOCUS_IN
	else if (txt->ripple_delay > 0) {
	    DrawTextArea(txt);
	    DrawSpot(txt, txt->ripple_delay);
	    XCopyArea(txt->disp, txt->pixmap, txt->window, txt->gc,
		      0, 0, txt->width, txt->height, 0, 0);
	    XSync(txt->disp, False);
	    txt->ripple_delay /= 2;
	    return (1);
	}
#endif /* #ifdef DECORATE_FOCUS_IN */
	else {
	    DrawTextArea(txt);
	    XCopyArea(txt->disp, txt->pixmap, txt->window, txt->gc,
		      0, 0, txt->width, txt->height, 0, 0);
	    RangeSylVScrollbar(txt->vsb, txt->tbs->n_lines);
	    if (txt->vsb->grabbed == False) {
		JumpSylVScrollbar(txt->vsb, txt->visible_begin);
	    }
	    txt->redraw = False;
	}
    }
    if (txt->grabbed == True) {
	GetWindowPointer(txt->disp, txt->window, &x, &y);
	if (y < 0) {
	    GrabbedCursorUp(txt);
	    XFlush(txt->disp);
	    usleep(DRAGGING_SCROLL_DELAY);
	    return (1);
	}
	else if (y >= txt->height) {
	    GrabbedCursorDown(txt); 
	    XFlush(txt->disp);
	    usleep(DRAGGING_SCROLL_DELAY);
	    return (1);
	}
    }
    return (0);
}

static void
LookupKey(SylTextArea *txt, XKeyEvent *key, wchar_t c)
{
    SylKeymap *ptr;

    if (key->state & Mod3Mask) {
	/* NEC PC-98xx: GRPH���� (Mod3Mask) ��Alt�����Ȥ��Ʋ�ᤵ���롣*/
	key->state &= ~Mod3Mask;
	key->state |= Mod1Mask;
    }
    if (key->keycode == 0 && c == '\n') {
	/*
	  kinput2: �С������2.0.1�Ǥϡ�Return/Tab�Υ������ࡢ���������ɡ�
	  ���������ξ��֤��ΤƤ��Ƥ��ޤ���vje�ʤ������ư���Τˡ�
	  Control-m�ʤ��̤�Τǡ������̣����Ϥʤ��������...��
	*/
	fprintf(stderr, "warning: the current IM does not pass the keycode"
		" of `Return' key.\n");
	InsertWCharIntoSylTextArea(txt, '\n');
	return;
    }
    key->state &= (ShiftMask | ControlMask | Mod1Mask);
    for (ptr = txt->keymap[key->keycode]; ptr != NULL; ptr = ptr->next) {
	if (key->state == ptr->mod) {
	    (BranchSylTextArea[ptr->func])(txt, key->time);
	    return;
	}
    }
    if (isprint_w(c) || c == '\t')
	InsertWCharIntoSylTextArea(txt, c);
}

static void
LookupPressedKeyWithIC(SylTextArea *txt, XKeyEvent *key)
{
    int n, n_lookups;
    KeySym ks;
    Status lookup_status;
    char *drain;
#if 0
    /*
      ���ͤ��Ȥ��ä��Ǥ����Ϥ��ʤΤ�... ���ơ�������XBufferOverflow��
      �Ȥ�XwcLookupString()���֤��ͤϡ�ɬ�פʥХåե����礭���פΤϤ�
      ���������ϥ᥽�åɤˤ�äƤϾ�������ϥ���ƥ����Ȥ��ڤ�ͤ�롣
    */
    wchar_t buf[1], *str = buf;

    n_lookups = XwcLookupString(txt->preedit.ic, key, str, 1,
				&ks, &lookup_status);
    if (lookup_status == XBufferOverflow) {
        if ((str = (wchar_t *)alloca(sizeof(wchar_t) * n_lookups)) == NULL) {
            if ((drain = XmbResetIC(txt->preedit.ic)) != NULL)
                XFree(drain);
            return;
        }
        n_lookups = XwcLookupString(txt->preedit.ic, key, str, n_lookups,
				    &ks, &lookup_status);
    }
#else
    wchar_t str[1024];

    n_lookups = XwcLookupString(txt->preedit.ic, key, str, 1024,
				&ks, &lookup_status);
#endif
    switch (lookup_status) {
    case XBufferOverflow:
        if ((drain = XmbResetIC(txt->preedit.ic)) != NULL)
            XFree(drain);
        break;
    case XLookupKeySym:
	/*
	  X11R6.4�Ǥϡ�XwcLookupString()��Ⱦ�ѥ������ʤ��֤��ʤ��褦��
	  �ѹ����줿�褦�Ǥ��ʥ���������֤�ˡ�
	*/
        LookupKey(txt, key, 0);
        break;
    case XLookupChars:
        for (n = 0; n < n_lookups; ++n)
            LookupKey(txt, key, str[n]);
        break;
    case XLookupBoth:
        LookupKey(txt, key, str[0]);
        for (n = 1; n < n_lookups; ++n)
            LookupKey(txt, key, str[n]);
        break;
    }
}

static void
SendSelectionReply(SylTextArea *txt, XEvent *ev)
{
    XSelectionRequestEvent *req = &(ev->xselectionrequest);
    SylLocation left, right;
    wchar_t *wcs;
    unsigned int len;

    GetSelectedRegion(txt, &left, &right);
    len = SizeOfRegion(txt, &left, &right);
    /*
      CopyRegionToWCString()�ϺǸ�˥̥�ʸ�����ղä���Τǡ�1ʸ��ʬ¿��
      ���ݤ��Ƥ�����
    */
    if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * (len + 1))) != NULL)
	CopyRegionToWCString(txt, &left, &right, wcs);
    SylRespondSelectionRequestWithWCString(req, wcs, txt->stamp,
        txt->targets_atom, txt->timestamp_atom, XA_STRING, txt->text_atom,
	txt->compound_text_atom);
}

static void
GetPixmapProperty(SylTextArea *txt, XEvent *ev)
{
    Pixmap *contents;
    Atom property_type;
    int format, x, y, w, h, border_width, depth;
    long n_items, remain;
    XSelectionEvent *sel = &(ev->xselection);
    Window root;

    if (XGetWindowProperty(sel->display, sel->requestor, sel->property,
			   0, 8192, False, AnyPropertyType,
			   &property_type, &format, &n_items,
			   &remain, (void *)&contents) != Success) {
	return;
    }
    if (property_type == XA_PIXMAP && format == 32 && n_items > 0
	&& (XGetGeometry(txt->disp, contents[0], &root, &x, &y, &w, &h,
			 &border_width, &depth), txt->depth) == depth) {
	if (txt->wallpaper != None)
	    XFreePixmap(txt->disp, txt->wallpaper);
	txt->wallpaper = XCreatePixmap(txt->disp, txt->window, w, h, depth);
	XCopyArea(txt->disp, contents[0], txt->wallpaper, txt->gc,
		  0, 0, w, h, 0, 0);
	txt->redraw = True;
    }
    XFree(contents);
    XDeleteProperty(sel->display, sel->requestor, sel->property);
}

static void
GetWindowProperty(SylTextArea *txt, XEvent *ev)
{
    XTextProperty text;
    wchar_t **list;
    int n_lists, n;
    XSelectionEvent *sel = &(ev->xselection);

    if (sel->property == XA_PIXMAP) {
	GetPixmapProperty(txt, ev);
	return;
    }
    if (sel->property != txt->property) {
#ifdef DEBUG	
	printf("property is different from the requested\n");
#endif
	XDeleteProperty(sel->display, sel->requestor, sel->property);
	return;
    }
    if (XGetTextProperty(sel->display, sel->requestor, &text, sel->property)
	== 0) {
#ifdef DEBUG	
	char *atom = XGetAtomName(txt->disp, sel->target);
	printf("target is %s(%ld), XGetTextProperty failed\n",
	       atom, sel->target);
	XFree(atom);
#endif
	return;
    }
    XDeleteProperty(sel->display, sel->requestor, sel->property);
    if ((n = XwcTextPropertyToTextList(txt->disp, &text, &list, &n_lists))
	< 0) {
#ifdef DEBUG	
	printf("text.value is %s(%ld), XwcTextPropertyToTextList failed\n",
	       text.value, text.nitems);
#endif
	XFree(text.value);
	return;
    }
    XFree(text.value);
    /*
      Bug?: text.value��JIS�����ɤ����ܸ줬��Ǽ����Ƥ��ơ�text.value��
      �Ǹ��3�Х��Ȥ�KanjiOut(0x1b 0x28 0x42)�ΤȤ����ؿ�XwcTextProperty
      ToTextList()�Ϥʤ���3���֤��������ǤϤȤꤢ���������n�� (0�ΤȤ���
      �������) ���ΤȤ��������³�Ԥ��롣
    */
    if (txt->selected)
	ResetSelectionOwner(txt);
    XClearWindow(txt->disp, txt->window); /* �����ߤǤɤ�����*/
    XFlush(txt->disp);
    txt->current = txt->pasting;
    if (n_lists > 0) {
	int m, size, width, new_x, new_y;
	wchar_t *wcs;

	width = txt->textwidth;
	InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
	    txt->current.x, txt->current.y, &new_x, &new_y);
	wcs = *list;
	size = wstrlen(wcs);
	for (m = 0; m < size; m = n + 1) {
	    for (n = m; n < size && wcs[n] != '\n'; ++n) {
		if (!(isprint_w(wcs[n]) || wcs[n] == '\t'))
		    wcs[n] = ' ';
	    }
	    wcs[n] = 0;
	    InsertStringIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
	        txt->current.x, txt->current.y, wcs + m, &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	    if (n < size) {
		InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset,
		    width, txt->current.x, txt->current.y, &new_x, &new_y);
		txt->current.x = new_x;
		txt->current.y = new_y;
	    }
	}
	DeleteNextCharInSylTextBlockSet(txt->tbs, &txt->fontset, width,
	    txt->current.x, txt->current.y, &new_x, &new_y);
	txt->current.x = new_x;
	txt->current.y = new_y;
    }
    XwcFreeStringList(list);
    txt->redraw = True;
}

void
SendSylTextArea(SylTextArea *txt, XEvent *ev)
{
    if (SendSylVScrollbar(txt->vsb, ev) == 0)
        return;

    switch (ev->type) {
    case Expose:
        if (ev->xexpose.window != txt->window || txt->format == True)
            return;
        XCopyArea(txt->disp, txt->pixmap, txt->window, txt->gc,
            ev->xexpose.x, ev->xexpose.y,
            ev->xexpose.width, ev->xexpose.height,
            ev->xexpose.x, ev->xexpose.y);
        break;
    case EnterNotify:
        if (ev->xcrossing.window != txt->window)
            return;
        txt->pointed = True;
        txt->redraw = True;
        break;
    case LeaveNotify:
        if (ev->xcrossing.window != txt->window)
            return;
        txt->pointed = False;
        txt->redraw = True;
        break;
    case ButtonPress:
        if (ev->xbutton.window != txt->window)
            return;
	if (txt->focus == False) {
	    XSetInputFocus(txt->disp, txt->window, RevertToParent,
			   ev->xbutton.time);
	}
#ifdef ON_THE_SPOT
	/*
	  ���Խ�ʸ���󤬤�����ϤɤΤ褦�ˤ���Τ��褤�Τ�? �Ȥꤢ������
	  �ޥ������٥�Ȥ�̵�뤹��褦�ˤ�����
	*/
	if (txt->preedit.n_chars > 0)
	    return;
#endif	
	if (ev->xbutton.button == 1) {
	    XGrabPointer(txt->disp, txt->window, False, ButtonMotionMask
		| ButtonReleaseMask | PointerMotionHintMask,
		GrabModeAsync, GrabModeSync, DefaultRootWindow(txt->disp),
		None, ev->xbutton.time);
	    txt->grabbed = True;
	    txt->current = LocationPointed(txt, ev->xbutton.x, ev->xbutton.y);
	    txt->started = txt->current;
	    txt->redraw = True;
	}
        else if (ev->xbutton.button == 2) {
	    txt->pasting = LocationPointed(txt, ev->xbutton.x, ev->xbutton.y);
	    XConvertSelection(txt->disp, XA_PRIMARY, txt->text_atom,
			      txt->property, txt->window, ev->xbutton.time);
	    XConvertSelection(txt->disp, XA_PRIMARY, XA_PIXMAP,
			      XA_PIXMAP, txt->window, ev->xbutton.time);
	    txt->redraw = True;
        }
	break;
    case MotionNotify:
        if (txt->grabbed != True)
            return;
        /*
	  Bug?: ���쥯�������ͭ���륦����ɥ����ȥåץ�٥륦����ɥ�
	  �Ǥʤ����ᤫ��Ʊ�쥢�ץꥱ�������֤Ǵؿ�XSetSelectionOwner()
	  ��ƤӽФ��Ƥ�SelectionClear���٥�Ȥ����ʤ����Ȥ����롣�к���
	  ���ơ�MotionNotify�������äƤ���Ȥ��˿�����ʸ���󤬥ɥ�å�
	  ���줿�顢owner��None�Ȥ��ƴؿ�XSetSelectionOwner()��ƤӽФ���
	  ���ٶ���Ū�˥��쥯�����Υ����ʤǤʤ��ʤ�褦�ˤ�����
        */
	if (txt->selected)
	    XSetSelectionOwner(txt->disp, XA_PRIMARY, None, ev->xmotion.time);
	MoveCursorDragged(txt);
	txt->selected = !IsEqualSylLocation(&txt->current, &txt->started);
        txt->redraw = True;
	break;
    case ButtonRelease:
        if (txt->grabbed != True)
            return;
        XUngrabPointer(txt->disp, ev->xbutton.time);
        txt->grabbed = False;
	txt->selected = !IsEqualSylLocation(&txt->current, &txt->started);
	if (txt->selected)
	    SetSelectionOwner(txt, ev->xbutton.time);
	else if (XGetSelectionOwner(txt->disp, XA_PRIMARY) == txt->window)
	    ResetSelectionOwner(txt);
	txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
					  txt->current.x, txt->current.y);
        txt->redraw = True;
        break;
    case FocusIn:
        if (ev->xfocus.window != txt->window
            || ev->xfocus.detail == NotifyPointer)
            return;
        txt->focus = True;
        if (txt->preedit.ic != NULL) {
	    XSetICFocus(txt->preedit.ic);
	    txt->ic_focus = True;
	}
#ifdef DECORATE_FOCUS_IN
	if (txt->ripple_width > 0)
	    txt->ripple_delay = max(txt->width, txt->height);
#endif
        txt->redraw = True;
        break;
    case FocusOut:
        if (ev->xfocus.window != txt->window
            || ev->xfocus.detail == NotifyPointer)
            return;
        txt->focus = False;
        if (txt->preedit.ic != NULL) {
	    ResetIC(txt);
	    XUnsetICFocus(txt->preedit.ic);
	    txt->ic_focus = False;
	}
#ifdef DECORATE_FOCUS_IN
        txt->ripple_delay = 0;
#endif
        txt->redraw = True;
        break;
    case KeyPress:
        if (ev->xkey.window != txt->window || txt->focus == False)
            return;
#ifdef ON_THE_SPOT
	if (txt->preedit.n_chars > 0)
	    return; /* ���Խ�ʸ���󤬤�����ϥ������٥�Ȥ�̵�뤹�롣 */
#endif
        if (txt->preedit.ic != NULL)
            LookupPressedKeyWithIC(txt, &(ev->xkey));
        break;
    case SelectionNotify:
        if (ev->xselection.selection != XA_PRIMARY
	    || ev->xselection.requestor != txt->window)
	    break;
	if (ev->xselection.property != None)
	    GetWindowProperty(txt, ev);
	break;
    case SelectionClear:
        if (ev->xselectionclear.window != txt->window)
	    break;
	txt->selected = False;
	txt->redraw = True;
        break;
    case SelectionRequest:
        if (ev->xselectionrequest.owner == txt->window && txt->selected)
            SendSelectionReply(txt, ev);
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != txt->parent)
            return;
	txt->parent_width = ev->xconfigure.width;
	txt->parent_height = ev->xconfigure.height;
	txt->visible_cols = max(1, txt->parent_height / txt->baseline_skip);
	/*
	  txt->width�ˤĤ��Ƥϥ���������С��������ȷ�ᤦ����������
	  ���롣�ե����ޥåȸ塢������˼��ޤꤽ���ʤ�⤦������������
	  ��«�����롣
	*/
	txt->width = max(1, txt->parent_width - (SYL_VSB_SEP + SYL_VSB_WIDTH));
	txt->textwidth = txt->width - txt->sidemargin * 2;
	txt->height = txt->visible_cols * txt->baseline_skip;
	XMoveResizeWindow(txt->disp, txt->window,
	    0, Syl_Y(txt->parent_height, txt->height, txt->gravity),
	    txt->width, txt->height);
	if (txt->selected)
	    ResetSelectionOwner(txt);
        if (txt->preedit.ic != NULL)
	    ResetIC(txt);
	XClearWindow(txt->disp, txt->window); /* �����ߤǤɤ�����*/
	txt->format = True;
        break;
    }
}

int
ReadSylTextArea(SylTextArea *txt, char *name)
{
    int n, m, len, new_x, new_y, width;
    wchar_t *str, *ptr;
    unsigned char *buffer;
    FILE *fp;
    long size;

    XClearWindow(txt->disp, txt->window);
    XFlush(txt->disp);
    if ((fp = fopen(name, "r")) == NULL)
	return (1);
    fseek(fp, 0, SEEK_END);
    size = ftell(fp);
    rewind(fp);
    if ((buffer = (unsigned char *)malloc(size + 1)) == NULL) {
	fclose(fp);
	return (1);
    }
    fread(buffer, size, 1, fp);
    fclose(fp);
    width = txt->textwidth;
    for (m = 0; m < size; m = n + 1) {
	for (n = m; n < size && buffer[n] != '\n'; ++n)
	    ;
	buffer[n] = 0;
	len = n - m + 1;
	if ((str = (wchar_t *)malloc(len * sizeof(wchar_t))) == NULL) {
	    free(buffer);
	    return (1);
	}
	mbstowcs(str, buffer + m, len);
	for (ptr = str; *ptr != 0; ++ptr) {
	    if (!(isprint_w(*ptr) || *ptr == '\t'))
		*ptr = ' ';
	}
	InsertStringIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					txt->current.x, txt->current.y,
					str, &new_x, &new_y);
	txt->current.x = new_x;
	txt->current.y = new_y;
	if (n < size) {
	    InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					      txt->current.x, txt->current.y,
					      &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
	free(str);
    }
    free(buffer);
    txt->current.x = 0;
    txt->current.y = 0;
    txt->saved_width = 0;
    txt->redraw = True;
    return (0);
}

int
WriteSylTextArea(SylTextArea *txt, char *name)
{
    SylTextBlock *tb;
    int y, n, m, s, t, len;
    wchar_t *str;
    unsigned char buffer[MB_LEN_MAX];
    FILE *fp;

    XFlush(txt->disp);
    if ((fp = fopen(name, "w")) == NULL)
	return (1);
    y = 0;
    for (tb = txt->tbs->top; tb != NULL; tb = tb->next) {
	for (m = 0; m < tb->n_bodies; ++m) {
	    len = LengthOfSylText(tb->body[m]);
	    str = CreateWCStringFromSylText(tb->body[m], 0, len);
	    for (n = 0; n < len; ++n) {
		if ((t = wctomb(buffer, str[n])) > 0) {
		    for (s = 0; s < t; ++s)
			putc((int)buffer[s], fp);
		}
	    }
	    if (EndOfLineSylText(tb->body[m]))
		putc('\n', fp);
	    free(str);
	    ++y;
	}
    }
    fclose(fp);
    return (0);
}

void
ResetSylTextArea(SylTextArea *txt)
{
    if (txt->buf != NULL) {
	free(txt->buf);
	txt->buf = NULL;
    }
    FreeSylTextBlockSet(txt->tbs);
    txt->tbs = CreateSylTextBlockSet();
    txt->visible_begin = 0;
    txt->current.x = 0;
    txt->current.y = 0;
    txt->saved_width = 0;
    txt->redraw = True;
    txt->format = False;
#if 1 /* 1999/03/20: added */
    if (XGetSelectionOwner(txt->disp, XA_PRIMARY) == txt->window)
	ResetSelectionOwner(txt);
#endif
}

void
SetFieldOrderSylTextArea(SylTextArea *txt, Window prev, Window next)
{
    txt->prev_field = prev;
    txt->next_field = next;
}

void
SetICSylTextArea(SylTextArea *txt, XIC ic, XIMStyle style)
{
    SetICAndStyleToSylPreedit(&txt->preedit, ic, style);
}

int
SetMBStringSylTextArea(SylTextArea *txt, unsigned char *mbs) /* added */
{
    int n, m, len, new_x, new_y, width;
    wchar_t c, *str, *ptr;
    unsigned char *buffer;
    long size;

    XClearWindow(txt->disp, txt->window);
    XFlush(txt->disp);
    if ((buffer = strdup(mbs)) == NULL)
	return (1);
    size = strlen(mbs);
    width = txt->textwidth;
    for (m = 0; m < size; m = n + 1) {
	for (n = m; n < size && buffer[n] != '\n'; ++n)
	    ;
	buffer[n] = 0;
	len = n - m + 1;
	if ((str = (wchar_t *)malloc(len * sizeof(wchar_t))) == NULL) {
	    free(buffer);
	    return (1);
	}
	mbstowcs(str, buffer + m, len);
	for (ptr = str; *ptr != 0; ++ptr) {
	    c = ((isprint_w(*ptr) || *ptr == '\t') ? *ptr : ' ');
	    InsertCharIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					  txt->current.x, txt->current.y, c,
					  &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
	if (n < size) {
	    InsertLineFeedIntoSylTextBlockSet(txt->tbs, &txt->fontset, width,
					      txt->current.x, txt->current.y,
					      &new_x, &new_y);
	    txt->current.x = new_x;
	    txt->current.y = new_y;
	}
	free(str);
    }
    free(buffer);
    txt->saved_width = GetWidthAtLine(txt->tbs, &txt->fontset,
                                      txt->current.x, txt->current.y);
    txt->redraw = True;
    return (0);
}
