/*
        editor.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Layout.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Button.h"
#include "Preedit.h"
#include "TextLine.h"
#include "TextArea.h"
#include "property.h"
#include "PixmapQueue.h"
#include "ListBox.h"
#include "Plate.h"
#include "Null.h"
#include "Control.h"
#include "editor_face.xbm"
#include "editor_mask.xbm"

#ifdef SHAPE_ICON
#include <X11/extensions/shape.h>
#include <X11/xpm.h>
#include "editor_icon.xpm"
#endif

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define THIS_CLASS "Editor"
#define TOPLEVEL_DEFAULT_GEOMETRY "320x500"

char **GlobalAv;
int GlobalAc;

static int MainPower = True;

#include "editor.color"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    FontSet0 = {"fontset",  "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

#define DEFAULT_XIMSTYLE "PreeditNothing,StatusNothing"
static SylSetting
    IMStyle = {"ximStyle", "XIMStyle", DEFAULT_XIMSTYLE, NULL},
    *IMStyleSet[] = {&IMStyle, NULL};

#define DEFAULT_WM_NAME "Internationalized editor"
static SylSetting
    Modifier = {"localeModifier", "LocaleModifier", "", NULL},
    Geometry = {"geometry", "Geometry", "", NULL},
    Headline = {"headline", "Headline", DEFAULT_WM_NAME, NULL};

#if 0 /* �ȼ��˥�������ԥ����ޥåפ����� */
static SylSetting
    IconColor0  = {"iconColor0", "IconColor0", "#FFFFEBADB6DA", NULL},
    IconColor1  = {"iconColor1", "IconColor1", "#BEFBA69969A6", NULL},
    IconColor2  = {"iconColor2", "IconColor2", "#00000000FFFF", NULL},
    IconColor3  = {"iconColor3", "IconColor3", "#FFFFFFFFFFFF", NULL},
    IconColor4  = {"iconColor4", "IconColor4", "#000000000000", NULL},
    *IconColorset[] = {&IconColor0, &IconColor1, &IconColor2, &IconColor3,
		       &IconColor4, NULL};
#endif

static XIMStyle
FindBestStyle(XIM im, XIMStyle request)
{
    int n;
    XIMStyle best_style, style;
    XIMStyles *supported;

    XGetIMValues(im, XNQueryInputStyle, &supported, NULL);
    best_style = 0;
#if 0
    printf("request_styles: %lx\n", request);
    printf("supported->count_styles: %d\n", supported->count_styles);
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        printf("supported->supported_styles[%d]: %lx;", n, style);
	if (style & XIMPreeditArea)
	    printf(" XIMPreeditArea");
	if (style & XIMPreeditCallbacks)
	    printf(" XIMPreeditCallbacks");
	if (style & XIMPreeditPosition)
	    printf(" XIMPreeditPosition");
	if (style & XIMPreeditNothing)
	    printf(" XIMPreeditNothing");
	if (style & XIMPreeditNone)
	    printf(" XIMPreeditNone");
	if (style & XIMStatusArea)
	    printf(" XIMStatusArea");
	if (style & XIMStatusCallbacks)
	    printf(" XIMStatusCallbacks");
	if (style & XIMStatusNothing)
	    printf(" XIMStatusNothing");
	if (style & XIMStatusNone)
	    printf(" XIMStatusNone");
	printf("\n");
    }
#endif
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        if (style == request) {
            best_style = style;
            break;
        }
    }
    if (supported->count_styles > 0 && n == supported->count_styles) {
	extern int ChoiceIMStyle(XIM);

	best_style = ChoiceIMStyle(im);
#if 0
        best_style = supported->supported_styles[0];
#endif
    }
    XFree(supported);
    return (best_style);
}

#define ON_THE_SPOT

static XIC
CreateIC(XIM im, XIMStyle request, Window win, XFontSet fs,
	 unsigned long fore, unsigned long back)
{
    XIC ic;
    XVaNestedList preedit, status;
    XPoint Origin = {0, 0};

#ifdef ON_THE_SPOT
    XIMCallback Start = {NULL, (XIMProc)NULL};
    XIMCallback Done = {NULL, (XIMProc)NULL};
    XIMCallback Draw = {NULL, (XIMProc)NULL};
    XIMCallback Caret = {NULL, (XIMProc)NULL};
    preedit = XVaCreateNestedList(0, XNFontSet, fs,
				  XNForeground, fore,
				  XNBackground, back,
				  XNSpotLocation, &Origin,
				  XNPreeditStartCallback, &Start,
				  XNPreeditDoneCallback, &Done,
				  XNPreeditDrawCallback, &Draw,
				  XNPreeditCaretCallback, &Caret, NULL);
#else
    preedit = XVaCreateNestedList(0, XNFontSet, fs,
				  XNForeground, fore,
				  XNBackground, back,
				  XNSpotLocation, &Origin, NULL);
#endif
    status = XVaCreateNestedList(0, XNFontSet, fs,
				 XNForeground, fore,
				 XNBackground, back,
				 NULL);
    ic = XCreateIC(im, XNInputStyle, request, XNClientWindow, win,
                   XNPreeditAttributes, preedit, XNStatusAttributes, status,
                   NULL);
    XFree(preedit);
    XFree(status);
    return (ic);
}

static void
SetGeometry(XIC ic, char *name, XRectangle *area)
{
    XVaNestedList list;
#if 0
    XRectangle request;

    list = XVaCreateNestedList(0, XNAreaNeeded, &request, NULL);
    if (XGetICValues(ic, name, list, NULL) == NULL)
	printf("%d %d\n", request.width, request.height);
    XFree(list);
#endif

    list = XVaCreateNestedList(0, XNArea, area, NULL);
    XSetICValues(ic, name, list, NULL);
    XFree(list);
}

static XSizeHints
GetToplevelWindowGeometry(Display *disp, char *u_geom, char *d_geom,
		      int *x, int *y, int *w, int *h)
{
    XSizeHints xsize;
    int geom_mask, width, height, gravity;

#if 0
    if (incw > 0 || inch > 0) {
	xsize.width_inc = incw;
	xsize.height_inc = inch;
	xsize.flags |= PResizeInc;
    }
    if (minw > 0 && minh > 0) {
	xsize.min_width = minw;
	xsize.min_height = minh; 
	xsize.flags |= PMinSize;
    }
    if (maxw > 0 && maxh > 0) {
	xsize.max_width = max(maxw, minw);
	xsize.max_height = max(maxh, minh);
	xsize.flags |= PMaxSize;
    }
#endif
    /*
      ICCCM���XSizeHints��¤�ΤΥ���x, y, width, height��̵�뤷�Ƥ��롣
      xprop�ǰ۾���ͤ�ɽ�������Τ�xprop������ICCCM��̵�뤷�Ƥ��뤿�ᡣ
    */
    xsize.flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    &xsize, x, y ,&width, &height, &gravity);
    if (geom_mask & (XValue | YValue))
	xsize.flags |= USPosition;
    xsize.flags |= (geom_mask & (WidthValue | HeightValue)) ? USSize : PSize;
    if (width && height) {
	*w = width;
	*h = height;
    }
    xsize.win_gravity = gravity;
    xsize.flags |= PWinGravity;
    return (xsize);
}

typedef struct {
    Display *disp;
    int x;
    int y;
    int width;
    int height;
    Window window;
    Pixmap icon_face;
    Pixmap icon_mask;
#ifdef SHAPE_ICON
    Window icon_window;
    Pixmap icon_pixmap;
    Pixmap icon_shape;
#endif
    XSizeHints size_hint;
    XIC ic;
    XIMStyle style;
    unsigned long *pixel;
    SylFontSet fs;
    SylTextArea *edit;
    SylTextLine *name;
    SylButton *save;
    SylButton *load;
    SylNull *status;
} Editor;

static void
GetToplevelPreferences(Display *disp, char *name, char *class, Editor *ed)
{
    LoadSylColors(disp, name, class, ColorSet, ed->pixel);
    LoadSylFontSets(disp, name, class, FontSet, &ed->fs);
    LoadSylIMStyles(disp, name, class, IMStyleSet, &ed->style);
    GetSylSetting(disp, name, class, &Modifier);
    GetSylSetting(disp, name, class, &Geometry);
    GetSylSetting(disp, name, class, &Headline);
}

static void
SendToplevel(Editor *e, XEvent *ev)
{
    XWindowAttributes attr;
    XRectangle region;
    
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
#ifdef SHAPE_ICON
    case Expose:
        if (ev->xexpose.window != e->icon_window)
            return;
	{
	    GC gc = XCreateGC(e->disp, e->icon_window, 0, 0);
	    XShapeCombineMask(e->disp, e->icon_window, ShapeBounding, 0, 0,
			      e->icon_shape, ShapeSet);
	    XCopyArea(e->disp, e->icon_pixmap, e->icon_window, gc,
		      ev->xexpose.x, ev->xexpose.y,
		      ev->xexpose.width, ev->xexpose.height,
		      ev->xexpose.x, ev->xexpose.y);
	    XFreeGC(e->disp, gc);
 	}
	break;
#endif
    case ConfigureNotify:
	if (ev->xconfigure.window != e->window)
            break;
	e->width = ev->xconfigure.width;
	e->height = ev->xconfigure.height;
	XGetWindowAttributes(e->disp, e->status->parent, &attr);
	if (e->style & XIMPreeditArea) {
	    region.width = max(ev->xconfigure.width - e->fs.height * 6, 1);
	    region.height = attr.height;
	    region.x = ev->xconfigure.width - region.width;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(e->ic, XNPreeditAttributes, &region);
	}
	if (e->style & XIMStatusArea) {
	    region.width = min(ev->xconfigure.width, e->fs.height * 6);
	    region.height = attr.height;
	    region.x = 0;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(e->ic, XNStatusAttributes, &region);
	}
	break;
    }
}

static void
SetMBStringIconName(Display *disp, Window window, char *name)
{
    XTextProperty t;

    if (XmbTextListToTextProperty(disp, &name, 1, XCompoundTextStyle, &t) < 0)
	return;
    XSetWMIconName(disp, window, &t);
    XFree(t.value);
}

static void
SaveCB(void *callback_data)
{
    Editor *e = (Editor *)callback_data;
    int len;
    char *buf;

    if ((len = GetMBStringSylTextLine(e->name, NULL)) <= 0) {
        fprintf(stderr, "%s: empty filename.\n", GlobalAv[0]);
	return;
    }
    if ((buf = (char *)alloca(len + 1)) == NULL) {
        fprintf(stderr, "%s: cannot allocate filename.\n", GlobalAv[0]);
	return;
    }
    (void)GetMBStringSylTextLine(e->name, buf);
    if (WriteSylTextArea(e->edit, buf)) {
        fprintf(stderr, "%s: cannot write file `%s'.\n", GlobalAv[0], buf);
	perror(GlobalAv[0]);
	return;
    }
    SetMBStringIconName(e->disp, e->window, buf);
}

static void
LoadCB(void *callback_data)
{
    Editor *e = (Editor *)callback_data;
    int len;
    char *buf;

    if ((len = GetMBStringSylTextLine(e->name, NULL)) <= 0) {
        fprintf(stderr, "%s: empty filename.\n", GlobalAv[0]);
	return;
    }
    if ((buf = (char *)alloca(len + 1)) == NULL) {
        fprintf(stderr, "%s: cannot allocate filename.\n", GlobalAv[0]);
	return;
    }
    (void)GetMBStringSylTextLine(e->name, buf);
    ResetSylTextArea(e->edit);
    if (ReadSylTextArea(e->edit, buf)) {
        fprintf(stderr, "%s: cannot read file `%s'.\n", GlobalAv[0], buf);
	perror(GlobalAv[0]);
	return;
    }
    SetMBStringIconName(e->disp, e->window, buf);
}

int
main(int ac, char **av)
{
    XIM im;
    XrmDatabase xrdb;
    long toplevel_mask, ic_mask = 0;
    XEvent ev;
    Editor e;
    SylControlManager *mgr;

    GlobalAc = ac;
    GlobalAv = av;
    if (ac != 2) {
	printf("usage: %s filename\n", av[0]);
	exit(1);
    }
    if ((e.disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    XrmInitialize();
    xrdb = SylMergedResourceDatabase(e.disp);
    if ((e.pixel = CreateSylColors(ColorSet)) == NULL) {
        fprintf(stderr, "%s: cannot create colorset.\n", av[0]);
        exit(1);
    }
    GetToplevelPreferences(e.disp, "editor", THIS_CLASS, &e);
    if (e.fs.id == None) {
        fprintf(stderr, "%s: cannot create fontset.\n", av[0]);
        exit(1);
    }
    if (XSetLocaleModifiers(Modifier.spec) == NULL) {
        fprintf(stderr, "%s: cannot set locale modifiers.\n", av[0]);
        exit(1);
    }
    if ((im = XOpenIM(e.disp, xrdb, "editor", THIS_CLASS)) == NULL) {
        fprintf(stderr, "%s: cannot open input method.\n", av[0]);
        exit(1);
    }
    if ((e.style = FindBestStyle(im, e.style)) == 0) {
        fprintf(stderr, "%s: no available style of input method.\n", av[0]);
        exit(1);
    }

    e.size_hint = GetToplevelWindowGeometry(e.disp, Geometry.spec,
	TOPLEVEL_DEFAULT_GEOMETRY, &e.x, &e.y, &e.width, &e.height);
    e.window = XCreateSimpleWindow(e.disp, DefaultRootWindow(e.disp), e.x, e.y,
	e.width, e.height, 1, e.pixel[Foreground], e.pixel[MediumGray]);
    e.icon_face = XCreateBitmapFromData(e.disp, e.window, editor_face_bits,
	editor_face_width, editor_face_height); 
    e.icon_mask = XCreateBitmapFromData(e.disp, e.window, editor_mask_bits,
	editor_mask_width, editor_mask_height);
#ifdef SHAPE_ICON
    e.icon_window = XCreateSimpleWindow(e.disp, DefaultRootWindow(e.disp),
	0, 0, editor_mask_width, editor_mask_height, 0,
        e.pixel[Foreground], e.pixel[MediumGray]);
    XSelectInput(e.disp, e.icon_window, ExposureMask);
    XpmCreatePixmapFromData(e.disp, e.icon_window, editor_icon_xpm,
	&e.icon_pixmap, &e.icon_shape, NULL);
    SetProperties(e.disp, e.window, Headline.spec, "editor", THIS_CLASS,
	ac, av, &e.size_hint, e.icon_face, e.icon_mask, e.icon_window);
#else
    SetProperties(e.disp, e.window, Headline.spec, "editor", THIS_CLASS,
	ac, av, &e.size_hint, e.icon_face, e.icon_mask, None);
#endif
    if ((e.ic = CreateIC(im, e.style, e.window, e.fs.id, e.pixel[Foreground],
			 e.pixel[MediumGray])) == NULL) {
        fprintf(stderr, "%s: cannot create input context.\n", av[0]);
        exit(1);
    }
    toplevel_mask = StructureNotifyMask;
    if (XGetICValues(e.ic, XNFilterEvents, &ic_mask, NULL) == NULL)
	toplevel_mask |= ic_mask;
    else
	fprintf(stderr, "%s: warning: the current IM has no specification"
		" of the `XNFilterEvents' value.\n", av[0]);
    XSelectInput(e.disp, e.window, toplevel_mask);

    if ((mgr = CreateSylControlManager(e.disp, e.window)) == NULL) {
        fprintf(stderr, "%s: cannot create SylControlManager.\n", av[0]);
        exit(1);
    }
    if ((e.edit = CreateSylControlOfSylTextArea(mgr, "edit")) == NULL) {
        fprintf(stderr, "%s: cannot create SylTextArea.\n", av[0]);
	exit(1);
    }
    if ((e.save = CreateSylControlOfSylButton(mgr, "save", SaveCB,
					      (void *)&e)) == NULL) {
        fprintf(stderr, "%s: cannot create SylButton.\n", av[0]);
	exit(1);
    }
    if ((e.load = CreateSylControlOfSylButton(mgr, "load", LoadCB,
					      (void *)&e)) == NULL) {
        fprintf(stderr, "%s: cannot create SylButton.\n", av[0]);
	exit(1);
    }
    if ((e.name = CreateSylControlOfSylTextLine(mgr, "filename",
						NULL)) == NULL) {
        fprintf(stderr, "%s: cannot create SylTextLine.\n", av[0]);
	exit(1);
    }
    if ((e.status = CreateSylControlOfSylNull(mgr, "status", 0, e.fs.height,
					      0, e.fs.height)) == NULL) {
        fprintf(stderr, "%s: cannot create SylNull.\n", av[0]);
	exit(1);
    }
    SetOrderSylLayoutManager(mgr->layout, SylHLayout(
	SylVRule(),
	SylVLayout(
	    SylHRule(),
	    SylPaneOfSylControlManager(mgr, e.edit->window),
	    SylHRule(),
	    SylHLayout(
		SylPaneOfSylControlManager(mgr, e.save->window),
		SylPaneOfSylControlManager(mgr, e.load->window),
		SylPaneOfSylControlManager(mgr, e.name->window),
		NULL),
	    SylPaneOfSylControlManager(mgr, e.status->parent),
	    NULL),
	SylVRule(),
	NULL));
    SetICSylTextArea(e.edit, e.ic, e.style);
    if (ReadSylTextArea(e.edit, av[1]))
        fprintf(stderr, "%s: cannot read file `%s'.\n", av[0], av[1]);
    SetMBStringIconName(e.disp, e.window, av[1]);
    SetICSylTextLine(e.name, e.ic, e.style);
    SetMBStringSylTextLine(e.name, av[1]);
    SetDefaultFocusWindow(e.edit->window);

    XMapRaised(e.disp, e.window);
    while (MainPower) {
        while (XEventsQueued(e.disp, QueuedAfterReading) == 0
               && NiceSylControlManager(mgr)) {
            ;
        }
        XNextEvent(e.disp, &ev);
        if (XFilterEvent(&ev, None))
            continue;
        if (IsWMCloseMessage(&ev))
            break;
        SendSylControlManager(mgr, &ev);
        SendToplevel(&e, &ev);
    }
    FreeSylControlManager(mgr);
    XrmDestroyDatabase(xrdb);
    FreeSylColors(e.pixel);
    XDestroyWindow(e.disp, e.window);
    XCloseDisplay(e.disp);
    exit(0);
}
