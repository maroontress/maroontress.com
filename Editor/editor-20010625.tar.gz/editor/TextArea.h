/*
        TextArea.h 1.5 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999, 2000, 2001 Syllabub
        Maroontress Fast Software.
*/

#define SYL_TEXTBLOCK_SIZE 4

typedef struct SylTextBlock {
    struct SylTextBlock *next;
    struct SylTextBlock *prev;
    SylText *body[SYL_TEXTBLOCK_SIZE];
    int n_bodies;
} SylTextBlock;

typedef struct SylTextBlockSet {
    struct SylTextBlock *top;
    struct SylTextBlock *cur;
    struct SylTextBlock *last;
    int current_block;         /* nth block */
    int current_line;          /* nth block begin at this line */
    int n_lines;               /* total lines */
} SylTextBlockSet;

typedef struct SylLocation {
    int x;
    int y;
} SylLocation;

typedef struct SylTextArea {
    Display *disp;
    Window parent;
    Window window;
    Window next_field;
    Window prev_field;
    Pixmap pixmap;
    Pixmap wallpaper;
    Pixmap mark_lf;
    Pixmap mark_eof;
    Pixmap mark_tab;
    GC gc;
    GC xgc;
    SylFontSet fontset;
    int parent_width;
    int parent_height;
    int width;
    int height;
    int sidemargin;
    int textwidth;
    int depth;
    int gravity;
    unsigned long *pixel;
    SylKeymap **keymap;

    SylTextBlockSet *tbs;
    wchar_t *buf;              /* ��󥯤��줿�ƥ����� */
    SylLocation current;
    SylLocation started;
    SylLocation pasting;
    int saved_width;
    
    SylVScrollbar *vsb;
    int baseline_skip;
    int visible_begin;
    int visible_cols;

    int pointed;
    int focus;
    int ic_focus;
    int frame_width;
    int ripple_delay;          /* DECORATE_FOCUS_IN: �Ĥ���������? */
    int ripple_width;          /* DECORATE_FOCUS_IN: ���������� */
    int grabbed;
    int selected;
    int redraw;
    int format;
    SylPreedit preedit;        /* ON_THE_SPOT: ���Խ�ʸ���� ���̾��� */
    int preedit_drawing;       /* ON-THE_SPOT: �ե����ɥХå���������� */
    SylLocation preedit_begin; /* ON_THE_SPOT: ���Խ����ϰ��� */
    Time stamp;                /* ���쥯���������˻��Ѥ��������ॹ����� */
    Atom property;
    Atom text_atom;
    Atom compound_text_atom;
    Atom targets_atom;
    Atom timestamp_atom;
} SylTextArea;

SylTextArea * CreateSylTextArea(Display *, Window, char *);
void FreeSylTextArea(SylTextArea *);
void SendSylTextArea(SylTextArea *, XEvent *);
int NiceSylTextArea(SylTextArea *);

int ReadSylTextArea(SylTextArea *, char *);
int WriteSylTextArea(SylTextArea *, char *);
void ResetSylTextArea(SylTextArea *);
void SetFieldOrderSylTextArea(SylTextArea *, Window, Window);
void SetICSylTextArea(SylTextArea *txt, XIC, XIMStyle);

int SetMBStringSylTextArea(SylTextArea *, unsigned char *); /* added */
