/*
        Plate.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1999, 2000 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "Plate.h"

#define THIS_CLASS "Plate"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    FontSet0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

#include "Plate.color"

static SylSetting
    Gravity0 = {"gravity", "Gravity", "Center", NULL},
    *Gravity[] = {&Gravity0, NULL};

static SylSetting
    LabelStr = {"label", "Label", "", NULL};

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return (abs(XwcTextEscapement(fs->id, str, len)));
}

static int
TextEscapementOfSylText(SylFontSet *fs, SylText *txt)
{
    int len, width;
    wchar_t *wcs;
    
    len = LengthOfSylText(txt);
    wcs = CreateWCStringFromSylText(txt, 0, len);
    width = TextEscapement(fs, wcs, len);
    free(wcs);
    return (width);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  SylPlate *plt)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    GetSylSetting(disp, fq_name, fq_class, &LabelStr);
    if ((plt->text = CreateSylTextFromMBString(LabelStr.spec, True)) == NULL)
        return(1);

    LoadSylColors(disp, fq_name, fq_class, ColorSet, plt->pixel);
    LoadSylFontSets(disp, fq_name, fq_class, FontSet, &plt->fontset);
    LoadSylGravities(disp, fq_name, fq_class, Gravity, &plt->gravity);
    return (0);
}

SylPlate *
CreateSylPlate(Display *disp, Window parent, char *component)
{
    XWindowAttributes attr;
    SylPlate *plt;

    if ((plt = (SylPlate *)malloc(sizeof(SylPlate))) == NULL)
        goto no_plate;
    if ((plt->pixel = CreateSylColors(ColorSet)) == NULL)
        goto no_colorset;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, plt))
        goto no_preferences;
    plt->sidemargin = 1;
    XGetWindowAttributes(disp, parent, &attr);
    plt->width = TextEscapementOfSylText(&plt->fontset, plt->text)
	+ plt->sidemargin * 2;
    plt->height = plt->fontset.height + plt->sidemargin * 2;
    plt->window = XCreateSimpleWindow(disp, parent,
	Syl_X(attr.width, plt->width, plt->gravity),
	Syl_Y(attr.height, plt->height, plt->gravity),
        plt->width, plt->height,
        0, plt->pixel[Foreground], plt->pixel[MediumGray]);
    XSelectInput(disp, plt->window, ExposureMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, plt->window);
    XMapRaised(disp, plt->window);
    plt->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, plt->gc, False);
    plt->disp = disp;
    plt->parent = parent;
    plt->redraw = False;
    return (plt);

no_preferences:
    FreeSylColors(plt->pixel);
no_colorset:
    free(plt);
no_plate:
    return (NULL);
}

void
FreeSylPlate(SylPlate *plt)
{
    XDestroyWindow(plt->disp, plt->window);
    XFreeGC(plt->disp, plt->gc);
    XFreeFontSet(plt->disp, plt->fontset.id);
    FreeSylText(plt->text);
    FreeSylColors(plt->pixel);
    free(plt);
}

void
SendSylPlate(SylPlate *plt, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
        if (ev->xexpose.window != plt->window || ev->xexpose.count > 0)
            break;
	plt->redraw = True;
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != plt->parent)
            return;
        XMoveWindow(plt->disp, plt->window,
		    Syl_X(ev->xconfigure.width, plt->width, plt->gravity),
		    Syl_Y(ev->xconfigure.height, plt->height, plt->gravity));
        plt->redraw = True;
        break;
    }
}

static void
DrawWindow(SylPlate *plt)
{
    int len;
    wchar_t *wcs;

    len = LengthOfSylText(plt->text);
    wcs = CreateWCStringFromSylText(plt->text, 0, len);
    XSetForeground(plt->disp, plt->gc, plt->pixel[Foreground]);
    XwcDrawString(plt->disp, plt->window, plt->fontset.id, plt->gc,
                  plt->sidemargin, plt->fontset.ascent + plt->sidemargin,
		  wcs, len);
    free(wcs);
}

int
NiceSylPlate(SylPlate *plt)
{
    XFlush(plt->disp);
    if (plt->redraw == True) {
        DrawWindow(plt);
        plt->redraw = False;
    }
    return (0);
}
