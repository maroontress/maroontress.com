/*
        Keymap.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

typedef struct Keymap {
    struct Keymap *next;
    KeySym sym;
    unsigned int mod;
    unsigned int func;
} Keymap;
