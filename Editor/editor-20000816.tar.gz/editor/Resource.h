/*
        Resource.h 1.2 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

typedef struct {
    char *name;
    char *class;
    char *orig;
    char *spec;
} SylSetting;

typedef struct SylKeymap {
    unsigned int mod;
    unsigned int func;
    struct SylKeymap *next;
} SylKeymap;

typedef struct {
    XFontSet id;
    int width;
    int height;
    int ascent;
    int descent;
    int tabsep;
} SylFontSet;

XrmDatabase SylMergedResourceDatabase(Display *);
void GetSylSetting(Display *, char *, char *, SylSetting *);

/*XXX*/ int FQLength(char *, char *c);
/*XXX*/ void FQCompose(char *, char *, char *);
/*XXX*/ void SetFQClassHint(Display *, Window, char *, char *, Window);

void LoadSylColors(Display *, char *, char *, SylSetting **, unsigned long *);
unsigned long * CreateSylColors(SylSetting **);
void FreeSylColors(unsigned long *);

void LoadSylKeymap(Display *, char *, char *, SylSetting **, SylKeymap **);
SylKeymap ** CreateSylKeymap(void);
void FreeSylKeymap(SylKeymap **);

void LoadSylFontSets(Display *, char *, char *, SylSetting **, SylFontSet *);
void LoadSylIMStyles(Display *, char *, char *, SylSetting **, XIMStyle *);

void LoadSylGravities(Display *, char *, char *, SylSetting **, int *);
int Syl_X(int parent_width, int width, int gravity);
int Syl_Y(int parent_height, int height, int gravity);

#ifdef PASSIVE_FOCUS_MODEL
#define XSetInputFocus SylSetInputFocus
void SylSetInputFocus(Display *, Window, int, Time);
void SylSendKeyEvent(XKeyEvent *);
#endif
