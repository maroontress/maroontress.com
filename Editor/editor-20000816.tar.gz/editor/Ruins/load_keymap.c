/*
        load_keymap.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Keymap.h"

#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "TextArea.h"

#include "parse.h"
#include "load_keymap.h"

int KeymapErrorCode;
int KeymapErrorLine;
char KeymapErrorWord[64];

static char *Reserved[] = {NULL};

typedef struct {
    char *name;
    unsigned int code;
} MapTable;

static MapTable Functions[] = {
    {"backward_char", AREA_BACKWARD_CHAR},
    {"backward_char_with_mark", AREA_BACKWARD_CHAR_WITH_MARK},
    {"backward_word", AREA_BACKWARD_WORD},
    {"backward_word_with_mark", AREA_BACKWARD_WORD_WITH_MARK},
    {"beginning_of_line", AREA_BEGINNING_OF_LINE},
    {"beginning_of_line_with_mark", AREA_BEGINNING_OF_LINE_WITH_MARK},
    {"delete_backward_char", AREA_DELETE_BACKWARD_CHAR},
    {"delete_char", AREA_DELETE_CHAR},
    {"end_of_line", AREA_END_OF_LINE},
    {"end_of_line_with_mark", AREA_END_OF_LINE_WITH_MARK},
    {"forward_char", AREA_FORWARD_CHAR},
    {"forward_char_with_mark", AREA_FORWARD_CHAR_WITH_MARK},
    {"forward_word", AREA_FORWARD_WORD},
    {"forward_word_with_mark", AREA_FORWARD_WORD_WITH_MARK},
    {"kill_line", AREA_KILL_LINE},
    {"left_edge", AREA_LEFT_EDGE},
    {"left_edge_with_mark", AREA_LEFT_EDGE_WITH_MARK},
    {"newline", AREA_NEWLINE},
    {"next_line", AREA_NEXT_LINE},
    {"next_line_with_mark", AREA_NEXT_LINE_WITH_MARK},
    {"previous_line", AREA_PREVIOUS_LINE},
    {"previous_line_with_mark", AREA_PREVIOUS_LINE_WITH_MARK},
    {"right_edge", AREA_RIGHT_EDGE},
    {"right_edge_with_mark", AREA_RIGHT_EDGE_WITH_MARK},
    {"yank", AREA_YANK},
    {"yank_with_mark", AREA_YANK_WITH_MARK},
    {NULL, -1}};

static MapTable Modifiers[] = {
    {"Shift", ShiftMask},
    {"Control", ControlMask},
    {"Meta", Mod1Mask},
    {NULL, -1}};

static int
GetFunction(char *name, int *func)
{
    int n;

    for (n = 0; Functions[n].name != NULL; ++n) {
	if (strcmp(Functions[n].name, name) == 0) {
	    *func = Functions[n].code;
	    return (1);
	}
    }
    return (0);
}

static int
GetModifier(char *name, int *mod)
{
    int n;

    for (n = 0; Modifiers[n].name != NULL; ++n) {
	if (strcmp(Modifiers[n].name, name) == 0) {
	    *mod |= Modifiers[n].code;
	    return (1);
	}
    }
    return (0);
}

static void
ErrorNoKeySym(Parse *p, char *w)
{
    KeymapErrorCode = KEYMAP_NO_KEYSYM;
    KeymapErrorLine = ParseLine(p);
    strcpy(KeymapErrorWord, w);
}

static void
ErrorUnknownFunction(Parse *p, char *w)
{
    KeymapErrorCode = KEYMAP_UNKNOWN_FUNCTION;
    KeymapErrorLine = ParseLine(p);
    strcpy(KeymapErrorWord, w);
}

#if 0
static void
ErrorUnterminatedString(Parse *p)
{
    KeymapErrorCode = KEYMAP_UNTERMINATED_STRING;
    KeymapErrorLine = ParseLine(p);
}
#endif

static void
ErrorUnexpectedEOF(Parse *p)
{
    KeymapErrorCode = KEYMAP_UNEXPECTED_EOF;
    KeymapErrorLine = ParseLine(p);
}

static void
ErrorTooShortMemory(Parse *p)
{
    KeymapErrorCode = KEYMAP_TOO_SHORT_MEMORY;
    KeymapErrorLine = ParseLine(p);
}

static void
ErrorParseError(Parse *p, char *w)
{
    KeymapErrorCode = KEYMAP_PARSE_ERROR;
    KeymapErrorLine = ParseLine(p);
    strcpy(KeymapErrorWord, w);
}

#define STRING_MAX 256

static int
IgnoreComment(Parse *p)
{
    int c;

    while ((c = GetChar(p)) != EOF && c != '\n')
	;
    return (c);
}

#if 0
static int
GetString(Parse *p, char *str, int limit)
{
    int n, c;

    for (n = 0; (c = GetChar(p)) != EOF && n < limit; ++n) {
	if (c == '"')
	    break;
	else if (c == '\\') {
	    if ((c = GetChar(p)) == EOF)
		return (EOF);
	    else if (c != '\n')
		str[n] = c;
	}
	else if (c == '\n')
	    return (c);
	else
	    str[n] = c;
    }
    str[n] = 0;
    return ((c == EOF) ? EOF : 0);
}
#endif

static int
NextWord(Parse *p, char *w)
{
    int type;

    while ((type = GetToken(p, w, NULL)) == PARSE_EMPTYLINES
	   || (type == PARSE_CPPCMD && IgnoreComment(p) == '\n'))
	;
    return (type);
}

static int
AddKeymap(Keymap **org, KeySym sym, unsigned int func, unsigned int mod)
{
    Keymap *cur;

    if ((cur = (Keymap *)malloc(sizeof(Keymap))) == NULL)
	return (1);
    cur->sym = sym;
    cur->func = func;
    cur->mod = mod;
    cur->next = *org;
    *org = cur;
    return (0);
}

static int
GetKeymap(Parse *p, Keymap **map)
{
    int type;
    unsigned int func, mod;
    KeySym sym;
    char w[64]; /* they need (32 + 1) bytes at least. */

    while ((type = NextWord(p, w)) == PARSE_KEYWORD) {
	if (!GetFunction(w, &func)) {
	    ErrorUnknownFunction(p, w);
	    return (1);
	}
	do {
	    mod = 0;
	    while ((type = NextWord(p, w)) == PARSE_KEYWORD
		   && GetModifier(w, &mod)) {
		if ((type = NextWord(p, w)) == EOF) {
		    ErrorUnexpectedEOF(p);
		    return (1);
		}
		else if (strcmp(w, "-") != 0) {
		    printf("a: %s\n", w);
		    ErrorParseError(p, w);
		    return (1);
		}
	    }
	    if (type == EOF) {
		ErrorUnexpectedEOF(p);
		return (1);
	    }
	    else if (type != PARSE_KEYWORD) {
		printf("b: %s\n", w);
		ErrorParseError(p, w);
		return (1);
	    }
	    else if ((sym = XStringToKeysym(w)) == NoSymbol) {
		ErrorNoKeySym(p, w);
		return (1);
	    }
	    else if (AddKeymap(map, sym, func, mod)) {
		ErrorTooShortMemory(p);
		return (1);
	    }
	    else if ((type = NextWord(p, w)) == EOF) {
		ErrorUnexpectedEOF(p);
		return (1);
	    }
	} while (strcmp(w, ",") == 0);
	if (strcmp(w, ";") != 0) {
	    printf("c: %s\n", w);
	    ErrorParseError(p, w);
	    return (1);
	}
    }
    if (type != EOF) {
	ErrorParseError(p, w);
	return (1);
    }
    return (EOF);
}

int
LoadKeymap(char *file, Keymap **map)
{
    Parse *p;
    int err;

    (*map) = (Keymap *)NULL;
    if ((p = OpenParse(file, Reserved)) == NULL) {
	KeymapErrorCode = KEYMAP_CANNOT_OPEN;
	return (0);
    }
    KeymapErrorCode = KEYMAP_EMPTY;
    err = GetKeymap(p, map);
    CloseParse(p);
    return ((*map == NULL) ? 0 : err);
}
