/*
        WCString.h 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

int wstrlen(wchar_t *str);
wchar_t * wstrcpy(wchar_t *d, wchar_t *s);
wchar_t * wstrncpy(wchar_t *d, wchar_t *s, int n);
int wstrcmp(wchar_t *s, wchar_t *t);
