/*
	Button.c 2.1 for X11R6 & GNU C Compiler

	Copyright (C) 1995, 1996, 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "Button.h"

#define THIS_CLASS "Button"

#include "Button.color"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    FontSet0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

static SylSetting
    Gravity0 = {"gravity", "Gravity", "Center", NULL},
    *Gravity[] = {&Gravity0, NULL};

static SylSetting
    FrameWidth = {"focusFrameWidth", "LineWidth", "1", NULL};

static SylSetting
    LabelStr = {"label", "Label", "", NULL};

static char GrayOutMask[] = {0x55, 0xaa, 0x55, 0xaa, 0x55, 0xaa, 0x55, 0xaa};

static void
DrawLabel(SylButton *btn)
{
    int n, len, margin = btn->fontset.descent + 1;
    wchar_t *wcs;

    XSetFunction(btn->disp, btn->gc, GXcopy);
    XSetFillStyle(btn->disp, btn->gc, FillSolid);
    XSetForeground(btn->disp, btn->gc, 
	(btn->pointed) ? btn->pixel[Illuminated] : btn->pixel[Background]);
    XFillRectangle(btn->disp, btn->plate, btn->gc, margin, margin,
	btn->width - 2 * margin - 1, btn->height - 2 * margin - 1);

    len = LengthOfSylText(btn->text);
    wcs = CreateWCStringFromSylText(btn->text, 0, len);
    if (btn->focus) {
	XSetForeground(btn->disp, btn->gc, btn->pixel[FrameColor]);
        for (n = 0; n < btn->frame_width; ++n) {
            XDrawRectangle(btn->disp, btn->plate, btn->gc,
			   margin + n, margin + n,
			   btn->width - 2 * (margin + n) - 2,
			   btn->height - 2 * (margin + n) - 2);
        }
    }
    XSetForeground(btn->disp, btn->gc, btn->pixel[Foreground]);
    XSetBackground(btn->disp, btn->gc, 
	(btn->pointed) ? btn->pixel[Illuminated] : btn->pixel[Background]);
    XSetFillStyle(btn->disp, btn->gc,
		  (btn->enabled) ? FillSolid : FillOpaqueStippled);
    XwcDrawString(btn->disp, btn->plate, btn->fontset.id, btn->gc,
		  margin + btn->sidemargin, margin + btn->fontset.height,
		  wcs, len);
    free(wcs);
}

static void
DrawWindow(SylButton *btn)
{
    int	xtail = btn->width - 1, ytail = btn->height - 1;

    XSetFunction(btn->disp, btn->gc, GXcopy);
    XSetFillStyle(btn->disp, btn->gc, FillSolid);

    XSetForeground(btn->disp, btn->gc, btn->pixel[Darkest]);
    XDrawPoint(btn->disp, btn->window, btn->gc, 0, 0);
    XDrawPoint(btn->disp, btn->window, btn->gc, xtail, ytail);
}

static void
DrawPlate(SylButton *btn)
{
    int	xtail = btn->width - 2, ytail = btn->height - 2;

    XSetFunction(btn->disp, btn->gc, GXcopy);
    XSetFillStyle(btn->disp, btn->gc, FillSolid);

    XSetForeground(btn->disp, btn->gc, btn->pixel[Brightest]);
    XDrawPoint(btn->disp, btn->plate, btn->gc, 0, 0);

    XSetForeground(btn->disp, btn->gc, btn->pixel[LightGray]);
    XDrawLine(btn->disp, btn->plate, btn->gc, 1, 0, xtail - 1, 0);
    XDrawLine(btn->disp, btn->plate, btn->gc, 0, 1, 0, ytail - 1);

    XSetForeground(btn->disp, btn->gc, btn->pixel[DarkGray]);
    XDrawLine(btn->disp, btn->plate, btn->gc, 1, ytail, xtail - 1, ytail);
    XDrawLine(btn->disp, btn->plate, btn->gc, xtail, 1, xtail, ytail - 1);

    XSetForeground(btn->disp, btn->gc, btn->pixel[Darkest]);
    XDrawPoint(btn->disp, btn->plate, btn->gc, xtail, ytail);
    DrawLabel(btn);
}

static void
PressButton(SylButton *btn, Time tm __unused)
{
    XMoveWindow(btn->disp, btn->plate, 1, 1);
    btn->redraw = True;
    btn->pressed = True;
}

static void
SetFocusToNextField(SylButton *btn, Time tm)
{
    if (btn->next_field != None)
        XSetInputFocus(btn->disp, btn->next_field, RevertToParent, tm);
}

static void
SetFocusToPrevField(SylButton *btn, Time tm)
{
    if (btn->prev_field != None)
        XSetInputFocus(btn->disp, btn->prev_field, RevertToParent, tm);
}

#include "Button.bind"

static void (*Branch[])(SylButton *, Time) = {
#include "Button.branch"
};

static void
LookupKey(SylButton *btn, XKeyEvent *key, wchar_t c)
{
    SylKeymap *ptr;

    if (key->state & Mod3Mask) {
        /* NEC PC-98xx: GRPH$B%-!<(B (Mod3Mask) $B$r(BAlt$B%-!<$H$7$F2r<a$5$;$k!#(B*/
        key->state &= ~Mod3Mask;
        key->state |= Mod1Mask;
    }
    if (key->keycode == 0 && c == '\n') {
        /*
          kinput2: $B%P!<%8%g%s(B2.0.1$B$G$O!"(BReturn/Tab$B$N%-!<%7%`!"%-!<%3!<%I!"(B
          $B=$>~%-!<$N>uBV$,<N$F$i$l$F$7$^$&!#(Bvje$B$J$i$A$c$s$HF0$/$N$K!#(B
          Control-m$B$J$iDL$k$N$G!"$"$k0UL#LdBj$O$J$$$s$@$1$I(B...$B!#(B
        */
        fprintf(stderr, "warning: the current IM does not pass the keycode"
                " of `Return' key.\n");
        return;
    }
    key->state &= (ShiftMask | ControlMask | Mod1Mask);
    for (ptr = btn->keymap[key->keycode]; ptr != NULL; ptr = ptr->next) {
        if (key->state == ptr->mod) {
            (Branch[ptr->func])(btn, key->time);
        }
    }
}

static void
LookupPressedKey(SylButton *btn, XKeyEvent *key)
{
    KeySym ks;
    unsigned char p[64];
    wchar_t c;

    p[XLookupString(key, p, 64, NULL, NULL)] = 0;
    if ((ks = XLookupKeysym(key, 0)) == NoSymbol)
        return;
    LookupKey(btn, key, (mbtowc(&c, p, 1) > 0) ? c : 0);
}

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return (abs(XwcTextEscapement(fs->id, str, len)));
}

static int
TextEscapementOfSylText(SylFontSet *fs, SylText *txt)
{
    int len, width;
    wchar_t *wcs;
    
    len = LengthOfSylText(txt);
    wcs = CreateWCStringFromSylText(txt, 0, len);
    width = TextEscapement(fs, wcs, len);
    free(wcs);
    return (width);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  SylButton *btn)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    GetSylSetting(disp, fq_name, fq_class, &LabelStr);
    if ((btn->text = CreateSylTextFromMBString(LabelStr.spec, True)) == NULL)
        return (1);

    LoadSylColors(disp, fq_name, fq_class, ColorSet, btn->pixel);
    LoadSylFontSets(disp, fq_name, fq_class, FontSet, &btn->fontset);
    LoadSylKeymap(disp, fq_name, fq_class, KeyBinding, btn->keymap);
    LoadSylGravities(disp, fq_name, fq_class, Gravity, &btn->gravity);
    GetSylSetting(disp, fq_name, fq_class, &FrameWidth);
    btn->frame_width = atoi(FrameWidth.spec);
    return (0);
}

SylButton *
CreateSylButton(Display *disp, Window parent, char *component,
		void (*callback_func)(void *), void *callback_data)
{
    XWindowAttributes attr;
    SylButton *btn;

    if ((btn = (SylButton *)malloc(sizeof(SylButton))) == NULL)
        goto no_button;
    if ((btn->pixel = CreateSylColors(ColorSet)) == NULL)
        goto no_colorset;
    if ((btn->keymap = CreateSylKeymap()) == NULL)
        goto no_keymap;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, btn))
        goto no_preferences;
    btn->sidemargin = (btn->fontset.width + 2) / 2 + 1;
    XGetWindowAttributes(disp, parent, &attr);
    btn->width = TextEscapementOfSylText(&btn->fontset, btn->text)
	+ btn->sidemargin * 2 + btn->fontset.descent * 2 + 3;
    btn->height = btn->fontset.height + btn->fontset.descent * 4 + 3;
    btn->window = XCreateSimpleWindow(disp, parent,
	Syl_X(attr.width, btn->width, btn->gravity),
	Syl_Y(attr.height, btn->height, btn->gravity),
        btn->width, btn->height,
	0, btn->pixel[Foreground], btn->pixel[DarkGray]);
    XSelectInput(disp, btn->window,
        ExposureMask | FocusChangeMask | KeyPressMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, btn->window);
    XMapRaised(disp, btn->window);
    btn->plate = XCreateSimpleWindow(disp, btn->window, 0, 0,
	btn->width - 1, btn->height - 1, 0,
	btn->pixel[Foreground], btn->pixel[MediumGray]);
    XSelectInput(disp, btn->plate, ExposureMask | ButtonPressMask
	| OwnerGrabButtonMask | ButtonReleaseMask
        | EnterWindowMask | LeaveWindowMask);
    XMapRaised(disp, btn->plate);
    btn->next_field = None;
    btn->prev_field = None;
    btn->grayout = XCreateBitmapFromData(disp, btn->window, GrayOutMask, 8, 8);
    btn->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, btn->gc, False);
    XSetStipple(disp, btn->gc, btn->grayout);
    btn->disp = disp;
    btn->parent = parent;
    btn->callback_func = callback_func;
    btn->callback_data = callback_data;
    btn->grabbed = False;
    btn->pointed = False;
    btn->focus = False;
    btn->enabled = True;
    btn->pressed = False;
    btn->redraw = False;
    return (btn);

no_preferences:
    FreeSylKeymap(btn->keymap);    
no_keymap:
    FreeSylColors(btn->pixel);
no_colorset:
    free(btn);
no_button:
    return (NULL);
}

void
FreeSylButton(SylButton *btn)
{
    XFreePixmap(btn->disp, btn->grayout);
    XDestroyWindow(btn->disp, btn->window);
    XFreeGC(btn->disp, btn->gc);
    XFreeFontSet(btn->disp, btn->fontset.id);
    FreeSylText(btn->text); 
    FreeSylKeymap(btn->keymap);    
    FreeSylColors(btn->pixel);
    free(btn);    
}

void
EnableSylButton(SylButton *btn)
{
    if (btn->enabled)
	return;
    btn->enabled = True;
    btn->redraw = True;
}

void
DisableSylButton(SylButton *btn)
{
    if (!btn->enabled)
	return;
    btn->enabled = False;
    btn->redraw = True;
}

void
SetFieldOrderSylButton(SylButton *btn, Window prev, Window next)
{
    btn->prev_field = prev;
    btn->next_field = next;
}

void
SendSylButton(SylButton *btn, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
        if ((ev->xexpose.window != btn->window
	     && ev->xexpose.window != btn->plate) || ev->xexpose.count > 0)
	    break;
	btn->redraw = True;
        break;
    case EnterNotify:
        if (ev->xcrossing.window != btn->plate)
	    break;
	btn->pointed = True;
	btn->redraw = True;
	break;
    case LeaveNotify:
        if (ev->xcrossing.window != btn->plate)
	    break;
	btn->pointed = False;
	btn->redraw = True;
	break;
    case ButtonPress:
        if (ev->xbutton.window != btn->plate || !btn->enabled)
	    break;
        if (btn->focus == False) {
            XSetInputFocus(btn->disp, btn->window, RevertToParent,
                           ev->xbutton.time);
        }
        XGrabPointer(btn->disp, btn->plate, False,
	    ButtonReleaseMask | EnterWindowMask | LeaveWindowMask,
	    GrabModeAsync, GrabModeSync, DefaultRootWindow(btn->disp),
	    None, ev->xbutton.time);
	XMoveWindow(btn->disp, btn->plate, 1, 1);
	btn->grabbed = True;
	btn->redraw = True;
	break;
    case ButtonRelease:
	if (!btn->grabbed)
	    break;
	XMoveWindow(btn->disp, btn->plate, 0, 0);
        XUngrabPointer(btn->disp, ev->xbutton.time);
	btn->grabbed = False;
	btn->redraw = True;
	if (btn->pointed && btn->callback_func != NULL)
	    btn->callback_func(btn->callback_data);
	break;
    case FocusIn:
        if (ev->xfocus.window != btn->window
            || ev->xfocus.detail == NotifyPointer)
            return;
        btn->focus = True;
        btn->redraw = True;
        break;
    case FocusOut:
        if (ev->xfocus.window != btn->window
            || ev->xfocus.detail == NotifyPointer)
            return;
        btn->focus = False;
        btn->redraw = True;
        break;
    case KeyPress:
        if (ev->xkey.window != btn->window || btn->focus == False)
            return;
	LookupPressedKey(btn, &(ev->xkey));
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != btn->parent)
            return;
        XMoveWindow(btn->disp, btn->window,
		    Syl_X(ev->xconfigure.width, btn->width, btn->gravity),
		    Syl_Y(ev->xconfigure.height, btn->height, btn->gravity));
        btn->redraw = True;
        break;
    }
}

int
NiceSylButton(SylButton *btn)
{
    XFlush(btn->disp);
    if (btn->redraw == True) {
	DrawWindow(btn);
        DrawPlate(btn);
        btn->redraw = False;
    }
    if (btn->pressed == True) {
	XFlush(btn->disp);
	if (btn->focus && btn->callback_func != NULL)
	    btn->callback_func(btn->callback_data);
	XMoveWindow(btn->disp, btn->plate, 0, 0);
	btn->pressed = False;
	btn->redraw = True;
    }
    return (0);
}
