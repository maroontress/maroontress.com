/*
        load_keymap.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#define AREA_BACKWARD_CHAR                1
#define AREA_BACKWARD_CHAR_WITH_MARK      2
#define AREA_BACKWARD_WORD                3
#define AREA_BACKWARD_WORD_WITH_MARK      4
#define AREA_BEGINNING_OF_LINE            5
#define AREA_BEGINNING_OF_LINE_WITH_MARK  6
#define AREA_DELETE_BACKWARD_CHAR         7
#define AREA_DELETE_CHAR                  8
#define AREA_END_OF_LINE                  9
#define AREA_END_OF_LINE_WITH_MARK       10
#define AREA_FORWARD_CHAR                11
#define AREA_FORWARD_CHAR_WITH_MARK      12
#define AREA_FORWARD_WORD                13
#define AREA_FORWARD_WORD_WITH_MARK      14
#define AREA_KILL_LINE                   15
#define AREA_LEFT_EDGE                   16
#define AREA_LEFT_EDGE_WITH_MARK         17
#define AREA_NEWLINE                     18
#define AREA_NEXT_LINE                   19
#define AREA_NEXT_LINE_WITH_MARK         20
#define AREA_PREVIOUS_LINE               21
#define AREA_PREVIOUS_LINE_WITH_MARK     22
#define AREA_RIGHT_EDGE                  23
#define AREA_RIGHT_EDGE_WITH_MARK        24
#define AREA_YANK                        25
#define AREA_YANK_WITH_MARK              26

#define KEYMAP_PARSE_ERROR 0
#define KEYMAP_UNTERMINATED_STRING 1
#define KEYMAP_TOO_SHORT_MEMORY 2
#define KEYMAP_CANNOT_OPEN 3
#define KEYMAP_UNKNOWN_FUNCTION 4
#define KEYMAP_EMPTY 5
#define KEYMAP_UNEXPECTED_EOF 6
#define KEYMAP_NO_KEYSYM 7

extern int KeymapErrorCode;
extern int KeymapErrorLine;
extern char KeymapErrorWord[];

int LoadKeymap(char *, Keymap **);
