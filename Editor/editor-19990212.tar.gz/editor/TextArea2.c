/*
        TextArea2.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "TextArea.h"
#include "TextArea3.h"
#include "TextArea2.h"

static void
GetSylTextBlockAndIndexAtLine(SylTextBlockSet *tbs, int y,
			      SylTextBlock **tb_return, int *n_return)
{
    SylTextBlock *tb;

    tb = SeekSylTextBlockAtLine(tbs, y);
    if (tb->n_bodies >= AREA_LINES_PER_BLOCK) {
	(void) SplitSylTextBlock(tbs);
	tb = SeekSylTextBlockAtLine(tbs, y);
    }
    *tb_return = tb;
    *n_return = y - tbs->current_line;
}

/*
  tbs$B$N(By$B9TL\$NJ8;z?t$rJV$9!#(By$B9TL\$,=jB0$7$F$$$k(BSylTextBlock$B$N%a%s%P(B
  n_bodies$B$,(BAREA_LINES_PER_BLOCK$B$h$j$bBg$-$$$H$-$O(BSylTextBlock$B$NJ,3d$r(B
  $BH<$&!#(B
*/
int
GetLengthAtLine(SylTextBlockSet *tbs, int y)
{
    int n;
    SylTextBlock *tb;
    
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    if (n >= tb->n_bodies)
	return (0);
    return (LengthOfSylText(tb->body[n]));
}

/*
  tbs$B$N(By$B9TL\$N(BEOL$B$rJV$9!#(By$B9TL\$,=jB0$7$F$$$k(BSylTextBlock$B$N%a%s%P(Bn_bodies
  $B$,(BAREA_LINES_PER_BLOCK$B$h$j$bBg$-$$$H$-$O(BSylTextBlock$B$NJ,3d$rH<$&!#(B
*/
int
IsEndOfLineAtLine(SylTextBlockSet *tbs, int y)
{
    int n;
    SylTextBlock *tb;
    
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    if (n >= tb->n_bodies)
	return (False);
    return (EndOfLineSylText(tb->body[n]));
}

/*
  tbs$B$N(By$B9TL\$,:G=*9T$J$i$P(BTrue$B$r!"$=$&$G$J$1$l$P(BFalse$B$rJV$9!#(By$B9TL\$,(B
  $B=jB0$7$F$$$k(BSylTextBlock$B$N%a%s%P(Bn_bodies$B$,(BAREA_LINES_PER_BLOCK$B$h$j(B
  $B$bBg$-$$$H$-$O(BSylTextBlock$B$NJ,3d$rH<$&!#(B
*/
int
IsBottomAtLine(SylTextBlockSet *tbs, int y)
{
    int n;
    SylTextBlock *tb;
    
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    return (tbs->cur->next == NULL && n >= tbs->cur->n_bodies - 1);
}

/*
  tbs$B$N(By$B9TL\$N9TF,$+$i(Bx$BJ8;zL\$^$G$r(Bfs$B$GIA2h$7$?$H$-$N%T%/%;%k?t$rJV$9!#(B
  y$B9TL\$,=jB0$7$F$$$k(BSylTextBlock$B$N%a%s%P(Bn_bodies$B$,(BAREA_LINES_PER_BLOCK
  $B$h$j$bBg$-$$$H$-$O(BSylTextBlock$B$NJ,3d$rH<$&!#(B
*/
int
GetWidthAtLine(SylTextBlockSet *tbs, SylFontSet *fs, int x, int y)
{
    int n, w;
    SylTextBlock *tb;
    wchar_t *str; 
  
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    str = CreateWCStringFromSylText(tb->body[n], 0, x);
    w = TextEscapement(fs, str, x);
    free(str);
    return (w);
}

/*
  tbs$B$N(By$B9TL\$r(Bfs$B$GIA2h$7$?$H$-!"9TF,$+$i(Bw$B%T%/%;%k$^$G$N$H$3$m$K$"$k(B
  $BJ8;z?t$rJV$9!#(By$B9TL\$,=jB0$7$F$$$k(BSylTextBlock$B$N%a%s%P(Bn_bodies$B$,(B
  AREA_LINES_PER_BLOCK$B$h$j$bBg$-$$$H$-$O(BSylTextBlock$B$NJ,3d$rH<$&!#(B
*/
int
GetRowsAtLine(SylTextBlockSet *tbs, SylFontSet *fs, int w, int y)
{
    int n, len, len_max, len_min;
    SylTextBlock *tb;
    wchar_t *str; 

    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    len = LengthOfSylText(tb->body[n]);
    str = CreateWCStringFromSylText(tb->body[n], 0, len);
    if (TextEscapement(fs, str, len) > w) {
        len_max = len;
        len_min = 0;
        len = (len_max + len_min + 1) / 2;
        while (len_max - len_min > 1) {
            if (TextEscapement(fs, str, len) > w)
                len_max = len;
            else
                len_min = len;
            len = (len_max + len_min + 1) / 2;
        }
        len = len_min;
    }
    free(str);
    return (len);
}

void
InsertCharIntoSylTextBlockSet(SylTextBlockSet *tbs, SylFontSet *fs, int width,
			      int x, int y, wchar_t c, int *new_x, int *new_y)
{
    int n;
    SylTextBlock *tb;
    SylText *prev;

    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    if (x > LengthOfSylText(tb->body[n]))
	x = LengthOfSylText(tb->body[n]);
    InsertWCharIntoSylText(tb->body[n], x, c);
    if (x == 0 && y > 0 && (prev = PrevLineSylTextBlock(tb, n)) != NULL
	&& EndOfLineSylText(prev) == False) {
	x = LengthOfSylText(prev);
	Reformat(tbs, y - 1, fs, width);
	/*
	  $B$A$g$C$H$d$d$3$7$$>u67(B:
	  $B$3$N;~E@$G$b$O$d(Bprev$B$OL58z$J%]%$%s%?$G$"$k!#$5$i$K!"(B(tb, n)$B$b(B
	  $BL58z$G$"$k!J4X?t(BReformat()$B$G(BSylTextBlock$B$,J,3d!":o=|$5$l$?>l9g(B
	  $B$O(Btb$B$,;X$9%]%$%s%?$O2rJ|$5$l$F$7$^$C$F$$$k!K!#(B
	*/
	GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
	prev = PrevLineSylTextBlock(tb, n);
	*new_x = (x < LengthOfSylText(prev)) ? 0 : 1;
	*new_y = y;
    }
    else if (AdjustAfterInserted(tb->body, n, tb->n_bodies, fs, width)) {
	if (++x < LengthOfSylText(tb->body[n])) {
	    *new_x = x;
	    *new_y = y;
	}
	else {
	    *new_x = x - LengthOfSylText(tb->body[n]);
	    *new_y = y + 1;
	}
	++(tb->n_bodies);
	++(tbs->n_lines);
	Reformat(tbs, y + 1, fs, width);
    }
    else {
	*new_x = x + 1;
	*new_y = y;
    }
}

void
InsertLineFeedIntoSylTextBlockSet(SylTextBlockSet *tbs,
				  SylFontSet *fs, int width,
				  int x, int y, int *new_x, int *new_y)
{
    int n;
    SylTextBlock *tb;
    SylText *prev;

#ifdef TRACE
    printf("InsertLineFeedIntoSylTextBlockSet: entered\n");
#endif
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    if (x > LengthOfSylText(tb->body[n]))
	x = LengthOfSylText(tb->body[n]);
    if (x == 0 && y > 0 && (prev = PrevLineSylTextBlock(tb, n)) != NULL
	&& EndOfLineSylText(prev) == False) {
	ChangeEndOfLineSylText(prev, True);
	*new_x = x;
	*new_y = y;
    }
    else {
	InsertLineFeedIntoSylTextBlock(tb->body, n, x, tb->n_bodies);
	++(tb->n_bodies);
	++(tbs->n_lines);
	Reformat(tbs, y + 1, fs, width);
	*new_x = 0;
	*new_y = y + 1;
    }
#ifdef TRACE
    printf("InsertLineFeedIntoSylTextBlockSet: leaved\n");
#endif
}

void
DeleteLeftCharInSylTextBlockSet(SylTextBlockSet *tbs,
				SylFontSet *fs, int width,
				int x, int y, int *new_x, int *new_y)
{
    int n, len;
    SylTextBlock *tb;
    SylText *prev;

    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    if (x > LengthOfSylText(tb->body[n]))
	x = LengthOfSylText(tb->body[n]);
    DeleteWCharOfSylText(tb->body[n], x - 1);
    len = LengthOfSylText(tb->body[n]);
    if (x == 1 && y > 0 && (prev = PrevLineSylTextBlock(tb, n)) != NULL
	&& EndOfLineSylText(prev) == False) {
	x = LengthOfSylText(prev);
	Reformat(tbs, y - 1, fs, width);
	/*
	  $B$d$d$3$7$$>u67(B:
	  $B$3$N;~E@$G$b$O$d(Bprev$B$OL58z$J%]%$%s%?$G$"$k!#$5$i$K!"(B(tb, n)$B$b(B
	  $BL58z$G$"$k!J4X?t(BReformat()$B$G(BSylTextBlock$B$,J,3d!":o=|$5$l$?>l9g(B
	  $B$O(Btb$B$,;X$9%]%$%s%?$O2rJ|$5$l$F$7$^$C$F$$$k!K!#$^$?!":o=|D>A0$N(B
	  $B%+!<%=%k$,:G=*9T$K$"$j!":o=|8e$K%+!<%=%k$N$"$C$?9T$,>CLG$9$k(B
	  $B>l9g$O!"(B(tbs, y)$B$bL58z$G$"$k!#(B
	*/
	if (y >= tbs->n_lines) {
	    GetSylTextBlockAndIndexAtLine(tbs, y - 1, &tb, &n);
	    prev = tb->body[n];
	}
	else {
	    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
	    prev = PrevLineSylTextBlock(tb, n);
	}
	if (x < LengthOfSylText(prev) || len == 0) {
	    *new_x = x;
	    *new_y = y - 1;
	}
	else {
	    *new_x = 0;
	    *new_y = y;
	}
    }
    else {
	Reformat(tbs, y, fs, width);
	*new_x = x - 1;
	*new_y = y;
    }
}

/*
  $B%+!<%=%k$,9TF,$K$"$k$H$-!"%+!<%=%k$N:8B&$r:o=|$9$k!#(B
*/
void
DeletePrevCharInSylTextBlockSet(SylTextBlockSet *tbs,
				SylFontSet *fs, int width,
				int x, int y, int *new_x, int *new_y)
{
    int n;
    SylTextBlock *tb;

    --y;
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    x = LengthOfSylText(tb->body[n]);
    if (EndOfLineSylText(tb->body[n]) == True) {
	ChangeEndOfLineSylText(tb->body[n], False);
	Reformat(tbs, y, fs, width);
	if (x == 0 || EndOfLineSylText(tb->body[n]) == True
	    || x < LengthOfSylText(tb->body[n]) || y >= tbs->n_lines - 1) {
	    *new_x = x;
	    *new_y = y;
	}
	else {
	    *new_x = 0;
	    *new_y = y + 1;
	}
    }
    else {
	--x;
	DeleteWCharOfSylText(tb->body[n], x);
	Reformat(tbs, y, fs, width);
	if (x < LengthOfSylText(tb->body[n])) {
	    *new_x = x;
	    *new_y = y;
	}
	else {
	    *new_x = 0;
	    *new_y = y + 1;
	}
    }
}

void
DeleteToLineEndSylTextBlockSet(SylTextBlockSet *tbs,
			       SylFontSet *fs, int width,
			       int x, int y, int *new_x, int *new_y)
{
    int n;
    SylTextBlock *tb;
    SylText *prev, *next;
    
    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    DeleteWCStringOfSylText(tb->body[n], x, LengthOfSylText(tb->body[n]));
    if (EndOfLineSylText(tb->body[n]) == False) {
	while ((next = NextLineSylTextBlock(tb, n)) != NULL
	       && EndOfLineSylText(next) == False) {
	    if (n + 1 < tbs->n_lines)
		FreeNextLine(tbs, tb, n);
	}
	if (next != NULL)
	    DeleteWCStringOfSylText(next, 0, LengthOfSylText(next));
    }
    if (x == 0 && y > 0 && (prev = PrevLineSylTextBlock(tb, n)) != NULL
	&& EndOfLineSylText(prev) == False) {
	x = LengthOfSylText(prev);
	--y;
    }
    Reformat(tbs, y, fs, width);
    *new_x = x;
    *new_y = y;
}

/*
  $B%+!<%=%k$,9TKv$K$"$k$H$-!"%+!<%=%k$N1&B&$N0lJ8;z$r:o=|$9$k!#(B
*/
void
DeleteNextCharInSylTextBlockSet(SylTextBlockSet *tbs,
				SylFontSet *fs, int width,
				int x, int y, int *new_x, int *new_y)
{
    int n;
    SylTextBlock *tb;

    GetSylTextBlockAndIndexAtLine(tbs, y, &tb, &n);
    x = LengthOfSylText(tb->body[n]);
    ChangeEndOfLineSylText(tb->body[n], False);
    Reformat(tbs, y, fs, width);
    if (x == 0 || EndOfLineSylText(tb->body[n]) == True
	|| x < LengthOfSylText(tb->body[n]) || y == tbs->n_lines - 1) {
	*new_x = x;
	*new_y = y;
    }
    else {
	*new_x = 0;
	*new_y = y + 1;
    }
}	
