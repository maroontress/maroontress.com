/*
        TextArea2.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

int GetLengthAtLine(SylTextBlockSet *tbs, int y);
int IsEndOfLineAtLine(SylTextBlockSet *tbs, int y);
int IsBottomAtLine(SylTextBlockSet *tbs, int y);

int GetWidthAtLine(SylTextBlockSet *tbs, SylFontSet *fs, int x, int y);
int GetRowsAtLine(SylTextBlockSet *tbs, SylFontSet *fs, int w, int y);

void InsertCharIntoSylTextBlockSet(SylTextBlockSet *, SylFontSet *, int,
				   int, int, wchar_t, int *, int *);
void InsertLineFeedIntoSylTextBlockSet(SylTextBlockSet *, SylFontSet *, int,
				       int, int, int *, int *);
void DeleteLeftCharInSylTextBlockSet(SylTextBlockSet *, SylFontSet *, int,
				     int, int, int *, int *);
void DeletePrevCharInSylTextBlockSet(SylTextBlockSet *, SylFontSet *, int,
				     int, int, int *, int *);
void DeleteToLineEndSylTextBlockSet(SylTextBlockSet *, SylFontSet *, int,
				    int, int, int *, int *);
void DeleteNextCharInSylTextBlockSet(SylTextBlockSet *, SylFontSet *, int,
				     int, int, int *, int *);
