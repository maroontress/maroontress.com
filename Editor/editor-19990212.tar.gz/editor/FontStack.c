/*
        FontStack.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997, 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include "FontStack.h"

#define FONTSTACK_SIZE 128

static void
PointsCopy(XPoint *xp, short *sp, int v)
{
    while (v > 0) {
	xp->x = sp[0];
	xp->y = sp[1];
	++xp;
	sp += 2;
	--v;
    }
}

typedef struct Figure {
    short width, height, descent, ascent;
} Figure;

static short
ValueOfFontStack(Figure *f, FontStack *s, short *well)
{
    switch (s->type) {
    case FS_STACK:
	return (well[s->body]);
    case FS_WIDTH:
	return (f->width);
    case FS_HEIGHT:
	return (f->height);
    case FS_ASCENT:
	return (f->ascent);
    case FS_DESCENT:
	return (f->descent);
    }
    return (s->body);
}

static int
GetFontFigure(XFontSet fs, Figure *f)
{
    int n_fontinfos;
    char **fontname;
    XFontStruct **fontinfo;

    if ((n_fontinfos = XFontsOfFontSet(fs, &fontinfo, &fontname)) < 1)
	return (1);
    f->ascent = fontinfo[0]->ascent;
    f->descent = fontinfo[0]->descent;
    f->width = abs(XmbTextEscapement(fs, "x", 1));
    f->height = f->ascent + f->descent;
    return (0);
}

int
DrawFontStack(Display *disp, Drawable d, GC gc, XFontSet fs,
	      int x, int y, FontStack *s)
{
    short v, well[FONTSTACK_SIZE], *p, *q;
    XPoint points[FONTSTACK_SIZE];
    Figure f;

    if (GetFontFigure(fs, &f))
	return (FS_INVALID_XFONTSET);
    for (p = well, q = p + FONTSTACK_SIZE; s->type != FS_EOF; ++s) {
	if (p >= q)
	    return (FS_STACK_OVERFLOW);
	switch (s->type) {
	case FS_CONST:
	    *p++ = s->body;
	    break;
	case FS_STACK:
	    *p++ = well[s->body];
	    break;
	case FS_WIDTH:
	    *p++ = f.width;
	    break;
	case FS_HEIGHT:
	    *p++ = f.height;
	    break;
	case FS_ASCENT:
	    *p++ = f.ascent;
	    break;
	case FS_DESCENT:
	    *p++ = f.descent;
	    break;
	case FS_ADD:
	    *(p - 1) += ValueOfFontStack(&f, ++s, well);
	    break;
	case FS_SUB:
	    *(p - 1) -= ValueOfFontStack(&f, ++s, well);
	    break;
	case FS_MUL:
	    *(p - 1) *= ValueOfFontStack(&f, ++s, well);
	    break;
	case FS_DIV:
	    *(p - 1) /= ValueOfFontStack(&f, ++s, well);
	    break;
	case FS_MIN:
	    if ((v = ValueOfFontStack(&f, ++s, well)) > *(p - 1))
		*(p - 1) = v;
	    break;
	case FS_MAX:
	    if ((v = ValueOfFontStack(&f, ++s, well)) < *(p - 1))
		*(p - 1) = v;
	    break;
	case FS_CLEAR_STACKS:
	    p = well;
	    break;
	case FS_FILL_CIRCLE:
	    XFillArc(disp, d, gc, x + p[-4], y + p[-3], p[-2], p[-1],
		     0, 360 * 64);
	    break;
	case FS_FILL_POLYGON:
	    v = ValueOfFontStack(&f, ++s, well);
	    PointsCopy(points, p - (v * 2), v);
	    points->x += x;
	    points->y += y;
	    XFillPolygon(disp, d, gc, points, v, Complex, CoordModePrevious);
	    XDrawLines(disp, d, gc, points, v, CoordModePrevious);
	    break;
	case FS_DRAW_LINES:
	    v = ValueOfFontStack(&f, ++s, well);
	    PointsCopy(points, p - (v * 2), v);
	    points->x += x;
	    points->y += y;
	    XDrawLines(disp, d, gc, points, v, CoordModePrevious);
	    break;
	case FS_DRAW_SEGMENT:
	    XDrawLine(disp, d, gc, x + p[-4], y + p[-3], x + p[-2], y + p[-1]);
	    break;
	default:
	    return (FS_INVALID_STACK);
	}
    }
    return (FS_SUCCESS);
}
