/*
        editor.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "TextArea.h"
#include "property.h"
#include "editor_face.xbm"
#include "editor_mask.xbm"

#ifdef SHAPE_ICON
#include <X11/extensions/shape.h>
#include <X11/xpm.h>
#include "editor_icon.xpm"
#endif

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

char **GlobalAv;
int GlobalAc;

#define THIS_CLASS "Editor"

static SylSetting
    Foreground  = {"foreground", "Foreground", "black",  NULL},
    MediumGray  = {"mediumGray", "MediumGray", "gray70", NULL},
    *ColorSet[] = {&Foreground, &MediumGray, NULL};

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset",  "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

#define DEFAULT_XIMSTYLE "PreeditNothing,StatusNothing"
static SylSetting
    IMStyle = {"ximStyle", "XIMStyle", DEFAULT_XIMSTYLE, NULL},
    *IMStyleSet[] = {&IMStyle, NULL};

#define DEFAULT_WM_NAME "Internationalized editor"
static SylSetting
    Modifier = {"localeModifier", "LocaleModifier", "", NULL},
    Geometry = {"geometry", "Geometry", "320x500", NULL},
    Headline = {"headline", "Headline", DEFAULT_WM_NAME, NULL};

#if 0 /* $BFH<+$K%"%$%3%s%T%/%9%^%C%W$r@8@.(B */
static SylSetting
    IconColor0  = {"iconColor0", "IconColor0", "#FFFFEBADB6DA", NULL},
    IconColor1  = {"iconColor1", "IconColor1", "#BEFBA69969A6", NULL},
    IconColor2  = {"iconColor2", "IconColor2", "#00000000FFFF", NULL},
    IconColor3  = {"iconColor3", "IconColor3", "#FFFFFFFFFFFF", NULL},
    IconColor4  = {"iconColor4", "IconColor4", "#000000000000", NULL},
    *IconColorset[] = {&IconColor0, &IconColor1, &IconColor2, &IconColor3,
		       &IconColor4, NULL};
#endif

static int MainPower = 1;
static Display *Disp;
static int BaseWindowX = 0;
static int BaseWindowY = 0;
static int BaseWindowWidth = 320;
static int BaseWindowHeight = 500;
static Window BaseWindow;
static Window MainWindow;
static int MainWindowWidth;
static int MainWindowHeight;
static Pixmap IconFace;
static Pixmap IconMask;

#if SHAPE_ICON
static Window IconWindow;
static Pixmap IconPixmap;
static Pixmap IconShape;
#endif

static XIMStyle
FindBestStyle(XIM im, XIMStyle request)
{
    int n;
    XIMStyle best_style, style;
    XIMStyles *supported;

    XGetIMValues(im, XNQueryInputStyle, &supported, NULL);
    best_style = 0;
#if 0
    printf("request_styles: %lx\n", request);
    printf("supported->count_styles: %d\n", supported->count_styles);
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        printf("supported->supported_styles[%d]: %lx;", n, style);
	if (style & XIMPreeditArea)
	    printf(" XIMPreeditArea");
	if (style & XIMPreeditCallbacks)
	    printf(" XIMPreeditCallbacks");
	if (style & XIMPreeditPosition)
	    printf(" XIMPreeditPosition");
	if (style & XIMPreeditNothing)
	    printf(" XIMPreeditNothing");
	if (style & XIMPreeditNone)
	    printf(" XIMPreeditNone");
	if (style & XIMStatusArea)
	    printf(" XIMStatusArea");
	if (style & XIMStatusCallbacks)
	    printf(" XIMStatusCallbacks");
	if (style & XIMStatusNothing)
	    printf(" XIMStatusNothing");
	if (style & XIMStatusNone)
	    printf(" XIMStatusNone");
	printf("\n");
    }
#endif
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        if (style == request) {
            best_style = style;
            break;
        }
    }
    XFree(supported);
    return (best_style);
}

static XIC
CreateIC(XIM im, XIMStyle request, Window win, XFontSet fs,
	 unsigned long fore, unsigned long back)
{
    XIC ic;
    XVaNestedList preedit, status;
    XPoint Origin = {0, 0};

    preedit = XVaCreateNestedList(0, XNFontSet, fs,
				  XNForeground, fore,
				  XNBackground, back,
				  XNSpotLocation, &Origin, NULL);
    status = XVaCreateNestedList(0, XNFontSet, fs,
				 XNForeground, fore,
				 XNBackground, back,
				 NULL);
    ic = XCreateIC(im, XNInputStyle, request, XNClientWindow, win,
                   XNPreeditAttributes, preedit, XNStatusAttributes, status,
                   NULL);
    XFree(preedit);
    XFree(status);
    return (ic);
}

static void
SetGeometry(XIC ic, char *name, XRectangle *area)
{
    XVaNestedList list;
#if 0
    XRectangle request;

    list = XVaCreateNestedList(0, XNAreaNeeded, &request, NULL);
    if (XGetICValues(ic, name, list, NULL) != NULL)
	printf("%d %d\n", request.width, request.height);
    XFree(list);
#endif

    list = XVaCreateNestedList(0, XNArea, area, NULL);
    XSetICValues(ic, name, list, NULL);
    XFree(list);
}

static void
WindowMain(XEvent *ev, XIC ic, XIMStyle style, SylFontSet *font)
{
    XRectangle region;
    
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
#ifdef SHAPE_ICON
    case Expose:
        if (ev->xexpose.window != IconWindow)
            return;
	{
	    GC gc = XCreateGC(Disp, IconWindow, 0, 0);
	    XShapeCombineMask(Disp, IconWindow, ShapeBounding, 0, 0,
			      IconShape, ShapeSet);
	    XCopyArea(Disp, IconPixmap, IconWindow, gc,
		      ev->xexpose.x, ev->xexpose.y,
		      ev->xexpose.width, ev->xexpose.height,
		      ev->xexpose.x, ev->xexpose.y);
	    XFreeGC(Disp, gc);
 	}
	break;
#endif
    case ConfigureNotify:
	if (ev->xconfigure.window != BaseWindow)
            break;
	BaseWindowWidth = ev->xconfigure.width;
	BaseWindowHeight = ev->xconfigure.height;
	if (style & XIMPreeditArea) {
	    region.width = max(ev->xconfigure.width - font->height * 6, 1);
	    region.height = font->height;
	    region.x = ev->xconfigure.width - region.width;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(ic, XNPreeditAttributes, &region);
	}
	if (style & XIMStatusArea) {
	    region.width = min(ev->xconfigure.width, font->height * 6);
	    region.height = font->height;
	    region.x = 0;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(ic, XNStatusAttributes, &region);
	}
	MainWindowWidth = BaseWindowWidth;
	MainWindowHeight = BaseWindowHeight - font->height;
	if (MainWindowHeight > 0)
	    XResizeWindow(Disp, MainWindow, MainWindowWidth, MainWindowHeight);
	break;
    }
}

static void
GetToplevelPreferences(Display *disp, char *name, char *class,
		       unsigned long *pixel, SylFontSet *fs, XIMStyle *style)
{
    LoadColorset(disp, name, class, ColorSet, pixel);
    LoadFontset(disp, name, class, FontSet, fs);
    LoadIMStyleset(disp, name, class, IMStyleSet, style);
    GetPreference(disp, name, class, &Modifier);
    GetPreference(disp, name, class, &Geometry);
    GetPreference(disp, name, class, &Headline);
}

static XSizeHints
GetBaseWindowGeometry(Display *disp, char *u_geom, char *d_geom,
		      int *x, int *y, int *w, int *h)
{
    XSizeHints xsize;
    int geom_mask, width, height, gravity;

    xsize.flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    &xsize, x, y ,&width, &height, &gravity);
    if (width)
	*w = width;
    if (height)
	*h = height;
    xsize.flags |= (geom_mask & (XValue | YValue)) ? USPosition : 0;
    xsize.flags |= (geom_mask & (WidthValue | HeightValue)) ? USSize : PSize;
#if 0
    if (incw > 0 || inch > 0) {
	xsize.width_inc = incw;
	xsize.height_inc = inch;
	xsize.flags |= PResizeInc;
    }
    if (minw > 0 && minh > 0) {
	xsize.min_width = minw;
	xsize.min_height = minh; 
	xsize.flags |= PMinSize;
    }
    if (maxw > 0 && maxh > 0) {
	xsize.max_width = max(maxw, minw);
	xsize.max_height = max(maxh, minh);
	xsize.flags |= PMaxSize;
    }
#endif
    xsize.win_gravity = gravity;
    xsize.flags |= PWinGravity;
    return (xsize);
}

int
main(int ac, char **av)
{
    XIM im;
    XIC ic;
    XIMStyle style;
    XrmDatabase xrdb;
    long BaseWindowMask, EventMask = 0;
    XEvent ev;
    SylFontSet fs;
    SylTextArea *region;
    unsigned long pixels[2];
    XSizeHints BaseSizeHint;

    GlobalAc = ac;
    GlobalAv = av;
    if (ac != 3) {
	printf("usage: %s read-file write-file\n", av[0]);
	exit(1);
    }
    if ((Disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    XrmInitialize();
    xrdb = MergedResourceDatabase(Disp);
    GetToplevelPreferences(Disp, "editor", THIS_CLASS, pixels, &fs, &style);
    if (fs.id == None) {
        fprintf(stderr, "%s: cannot create fontset.\n", av[0]);
        exit(1);
    }
    if (XSetLocaleModifiers(Modifier.spec) == NULL) {
        fprintf(stderr, "%s: cannot set locale modifiers.\n", av[0]);
        exit(1);
    }
    if ((im = XOpenIM(Disp, xrdb, "editor", THIS_CLASS)) == NULL) {
        fprintf(stderr, "%s: cannot open input method.\n", av[0]);
        exit(1);
    }
    if ((style = FindBestStyle(im, style)) == 0) {
        fprintf(stderr, "%s: no available style of input method.\n", av[0]);
        exit(1);
    }

    BaseSizeHint = GetBaseWindowGeometry(Disp, Geometry.spec, Geometry.orig,
        &BaseWindowX, &BaseWindowY, &BaseWindowWidth, &BaseWindowHeight);
    BaseWindow = XCreateSimpleWindow(Disp, DefaultRootWindow(Disp),
        BaseWindowX, BaseWindowY, BaseWindowWidth, BaseWindowHeight, 1,
        pixels[0], pixels[1]);
    IconFace = XCreateBitmapFromData(Disp, BaseWindow, editor_face_bits,
	editor_face_width, editor_face_height); 
    IconMask = XCreateBitmapFromData(Disp, BaseWindow, editor_mask_bits,
	editor_mask_width, editor_mask_height);
#ifdef SHAPE_ICON
    IconWindow = XCreateSimpleWindow(Disp, DefaultRootWindow(Disp), 0, 0,
	editor_mask_width, editor_mask_height, 0, pixels[0], pixels[1]);
    XSelectInput(Disp, IconWindow, ExposureMask);
    XpmCreatePixmapFromData(Disp, IconWindow, editor_icon_xpm,
			    &IconPixmap, &IconShape, NULL);
    SetProperties(Disp, BaseWindow, Headline.spec, "editor", THIS_CLASS,
	ac, av, &BaseSizeHint, IconFace, IconMask, IconWindow);
#else
    SetProperties(Disp, BaseWindow, Headline.spec, "editor", THIS_CLASS,
	ac, av, &BaseSizeHint, IconFace, IconMask, None);
#endif
    if ((ic = CreateIC(im, style, BaseWindow, fs.id, pixels[0], pixels[1]))
	== NULL) {
        fprintf(stderr, "%s: cannot create input context.\n", av[0]);
        exit(1);
    }
    BaseWindowMask = StructureNotifyMask;
    if (XGetICValues(ic, XNFilterEvents, &EventMask, NULL) == NULL)
	BaseWindowMask |= EventMask;
    else
	fprintf(stderr, "%s: warning: the current IM has no specification"
		" of the `XNFilterEvents' value.\n", av[0]);
    XSelectInput(Disp, BaseWindow, BaseWindowMask);
    XSetICFocus(ic);
    XMapRaised(Disp, BaseWindow);

    MainWindow = XCreateSimpleWindow(Disp, BaseWindow, 0, 0,
        BaseWindowWidth, BaseWindowHeight, 0, pixels[0], pixels[1]);
    XSetWindowBackgroundPixmap(Disp, MainWindow, ParentRelative);
    XSelectInput(Disp, MainWindow, StructureNotifyMask);
    SetFQClassHint(Disp, BaseWindow, "edit", "Paned", MainWindow);
    XMapRaised(Disp, MainWindow);

    if ((region = CreateSylTextArea(Disp, ic, MainWindow, "text")) == NULL) {
        fprintf(stderr, "%s: cannot create SylTextArea.\n", av[0]);
	exit(1);
    }
    if (ReadSylTextArea(region, av[1])) {
        fprintf(stderr, "%s: cannot read file `%s'.\n", av[0], av[1]);
    }
    while (MainPower) {
        while (XEventsQueued(Disp, QueuedAfterReading) == 0
               && (NiceSylTextArea(region))) {
            ;
	}
	XNextEvent(Disp, &ev);
	if (XFilterEvent(&ev, None))
            continue;
	if (IsWMCloseMessage(&ev))
	    break;
	SendSylTextArea(region, &ev);
        WindowMain(&ev, ic, style, &fs);
    }
    if (WriteSylTextArea(region, av[2])) {
        fprintf(stderr, "%s: cannot write file `%s'.\n", av[0], av[2]);
    }
    FreeSylTextArea(region);
    XrmDestroyDatabase(xrdb);  
    XDestroyWindow(Disp, BaseWindow);
    XCloseDisplay(Disp);
    exit(0);
}
