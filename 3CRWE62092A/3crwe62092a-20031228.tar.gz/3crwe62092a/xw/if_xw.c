/*
	$Id: if_xw.c,v 1.3 2003/12/27 22:48:53 syl Exp $

	Copyright (C) 2002, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/sockio.h>
#include <sys/mbuf.h>
#include <sys/malloc.h>
#include <sys/kernel.h>
#include <sys/proc.h>
#include <sys/ucred.h>
#include <sys/socket.h>
#include <sys/module.h>
#include <sys/bus.h>
#include <sys/syslog.h>
#include <sys/sysctl.h>

#include <machine/bus.h>
#include <machine/resource.h>
#include <machine/clock.h>
#include <machine/md_var.h>
#include <machine/bus_pio.h>
#include <sys/rman.h>

#include <net/if.h>
#include <net/if_arp.h>
#include <net/ethernet.h>
#include <net/if_dl.h>
#include <net/if_media.h>
#include <net/if_types.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/in_var.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>

#include <net/bpf.h>

#if 0
#define TRACE
#endif

#define SNWNMP_GET	0
#define SNWNMP_SET	1
#define SNWNMP_RESPONSE	2
#define SNWNMP_ERROR	3
#define SNWNMP_TRAP	4
#define SNWNMP_LONG_AT(n, k) \
	ntohl(*((long *)((n) + sizeof(struct snwnmp_header)) + (k)))

#define ETHERTYPE_SNWNMP	0x8828
#define BSS_CHANGE_TRAP		0xff0101d5
#define RESETTRAP_3COM          0xff0103ff

#define CSR_READ_1(sc, reg) \
	bus_space_read_1(sc->btag, sc->bhandle, reg)
#define CSR_READ_MULTI_1(sc, reg, addr, count) \
	bus_space_read_multi_1(sc->btag, sc->bhandle, reg, addr, count);
#define CSR_WRITE_1(sc, reg, val) \
	bus_space_write_1(sc->btag, sc->bhandle, reg, val)
#define CSR_WRITE_MULTI_1(sc, reg, addr, count) \
	bus_space_write_multi_1(sc->btag, sc->bhandle, reg, addr, count)

/* base + 0x07: status */
#define XW_RST_ACK    0x80
#define XW_SEQ        0x20
#define XW_CTS        0x10
#define XW_RST_CARD   0x08
#define XW_INT_STATUS 0x04

/* base + 0x08: interrupt control */
#define XW_INT_EN     0x80

/* base + 0x09: reset control */
#define XW_RST_DRVR   0x80
#define XW_URG        0x40

struct xw_softc	{
    struct arpcom arpcom; /* Ethernet common part */
    int gone;
    struct resource *iobase;
    struct resource *irq;
    device_t dev;
    int unit;
    int io_addr;    
    bus_space_handle_t bhandle;
    bus_space_tag_t btag;
    void *intrhand;
    struct mbuf *packet;
    struct callout_handle stat_ch;
    unsigned char mac[ETHER_ADDR_LEN];
    int sequence;
};

struct snwnmp_header {
    unsigned char dst[ETHER_ADDR_LEN];
    unsigned char src[ETHER_ADDR_LEN];
    unsigned short type;
    unsigned char version;
    unsigned char operation;
    unsigned long oid __attribute__ ((packed));
    unsigned char index;
    unsigned char flags;
    unsigned long length __attribute__ ((packed));
};

static void
xw_free(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    
    if (sc->iobase != NULL)
	bus_release_resource(dev, SYS_RES_IOPORT, 0, sc->iobase);
    if (sc->irq != NULL)
	bus_release_resource(dev, SYS_RES_IRQ, 0, sc->irq);
    if (sc->packet != NULL)
	m_freem(sc->packet);
}

static int
xw_alloc(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    int rid;

    rid = 0;
    if ((sc->iobase = bus_alloc_resource(dev, SYS_RES_IOPORT, &rid,
					 0, ~0, 1, RF_ACTIVE)) == 0) {
	device_printf(dev, "No I/O space?!\n");
	return (ENXIO);
    }
    rid = 0;
    if ((sc->irq = bus_alloc_resource(dev, SYS_RES_IRQ, &rid,
				      0, ~0, 1, RF_ACTIVE)) == 0) {
	device_printf(dev, "No irq?!\n");
	return (ENXIO);
    }
    sc->dev = dev;
    sc->unit = device_get_unit(dev);
    sc->io_addr = rman_get_start(sc->iobase);
    sc->btag = rman_get_bustag(sc->iobase);
    sc->bhandle = rman_get_bushandle(sc->iobase);
    sc->packet = NULL;
    return (0);
}

static void
enable_interrupts(struct xw_softc *sc)
{
    int s;

    s = CSR_READ_1(sc, 8) | XW_INT_EN;
    CSR_WRITE_1(sc, 8, s);
}

static void
disable_interrupts(struct xw_softc *sc)
{
    int s;

    s = CSR_READ_1(sc, 8) & ~XW_INT_EN;
    CSR_WRITE_1(sc, 8, s);
}

static int
xw_pccard_probe(device_t dev)
{
    struct xw_softc *sc;
    int error;

#ifdef TRACE
    device_printf(dev, "%s: enter\n", __FUNCTION__);
#endif
    sc = device_get_softc(dev);
    sc->gone = 0;
    sc->packet = NULL;
    sc->sequence = 0;

    if ((error = xw_alloc(dev)) != 0)
	return (error);
    device_set_desc(dev, "3Com 3CRWE62092A");
    xw_free(dev);

    disable_interrupts(sc);
    return (0);
}

static void 
xw_reset(struct xw_softc *sc)
{
    int s;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    s = CSR_READ_1(sc, 9) | XW_RST_DRVR;
    CSR_WRITE_1(sc, 9, s);

    if (sc->packet != NULL) {
	m_freem(sc->packet);
	sc->packet = NULL;
    }
    sc->sequence = 0;
}

static void
snwnmp_handle_error(struct xw_softc *sc, unsigned char *data, int size)
{
#ifdef TRACE
    struct snwnmp_header *h = (struct snwnmp_header *)data;

    device_printf(sc->dev, "%s: oid=%lx length=%lx\n", __FUNCTION__,
		  ntohl(h->oid), ntohl(h->length));
#endif
}

static void
snwnmp_handle_trap(struct xw_softc *sc, unsigned char *data, int size)
{
    struct snwnmp_header *h = (struct snwnmp_header *)data;
    unsigned int k, n;

#ifdef TRACE
    device_printf(sc->dev, "%s: oid=%lx length=%lx\n", __FUNCTION__,
		  ntohl(h->oid), ntohl(h->length));
#endif
    switch (ntohl(h->oid)) {
    case BSS_CHANGE_TRAP:
	device_printf(sc->dev, "BSS_CHANGE_TRAP\n");
	for (k = 0, n = ntohl(h->length) / sizeof(long); k < n; ++k) {
	    device_printf(sc->dev, "[%d] 0x%lx\n", k, SNWNMP_LONG_AT(data, k));
	}
	break;
    case RESETTRAP_3COM:
	device_printf(sc->dev, "RESETTRAP_3COM\n");
	for (k = 0, n = ntohl(h->length) / sizeof(long); k < n; ++k) {
	    device_printf(sc->dev, "[%d] 0x%lx\n", k, SNWNMP_LONG_AT(data, k));
	}
	break;
    default:
	device_printf(sc->dev, "Unknown trap (oid=%lx, length=%lx)\n",
		      htonl(h->oid), htonl(h->length));
    }
}

static void
process_snwnmp(struct xw_softc *sc, unsigned char *data, int size)
{
    struct snwnmp_header *h = (struct snwnmp_header *)data;

    switch (h->operation) {
    case SNWNMP_ERROR:
	snwnmp_handle_error(sc, data, size);
	break;
    case SNWNMP_TRAP:
	snwnmp_handle_trap(sc, data, size);
	break;
    case SNWNMP_RESPONSE:
	break;
    default:
#ifdef TRACE
	device_printf(sc->dev, "%s: invalid operation (%d)\n", __FUNCTION__,
		      h->operation);
#endif
	break;
    }
}

static void
xw_rxeof(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    struct ether_header	*eh;
    struct mbuf	*m;
    unsigned char *frame;
    int pkt_len, version;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    pkt_len = CSR_READ_1(sc, 10);
    pkt_len |= CSR_READ_1(sc, 10) << 8;

    version = CSR_READ_1(sc, 10);
    version |= CSR_READ_1(sc, 10) << 8;
    if (version != 0xa503) {
	device_printf(sc->dev, "Unknown version: 0x%x\n", version);
	xw_reset(sc);
	++(ifp->if_ierrors);
	return;
    }

    MGETHDR(m, M_DONTWAIT, MT_DATA);
    if (m == NULL) {
	++(ifp->if_ierrors);
	return;
    }
    MCLGET(m, M_DONTWAIT);
    if (!(m->m_flags & M_EXT)) {
	m_freem(m);
	++(ifp->if_ierrors);
	return;
    }
    eh = mtod(m, struct ether_header *);
    m->m_pkthdr.rcvif = ifp;

    if (pkt_len > MCLBYTES) {
	device_printf(sc->dev, "Oversized packet received (pkt_len=%d)\n",
		      pkt_len);
	m_freem(m);
	++(ifp->if_ierrors);
	return;
    }
    m->m_pkthdr.len = m->m_len = pkt_len;

#ifdef TRACE
    device_printf(sc->dev, "%s: pkt_len=%d\n", __FUNCTION__, pkt_len);
#endif
    frame = mtod(m, caddr_t);
    CSR_READ_MULTI_1(sc, 10, frame, pkt_len);
#ifdef TRACE
    device_printf(sc->dev, "dst=%6D src=%6D type=%d\n",
		  eh->ether_dhost, ":", eh->ether_shost, ":",
		  htons(eh->ether_type));
#endif
    if (htons(eh->ether_type) == ETHERTYPE_SNWNMP) {
	process_snwnmp(sc, frame, pkt_len);
    }
    ++(ifp->if_ipackets);

    m_adj(m, sizeof(struct ether_header));
    ether_input(ifp, eh, m);
}

static void 
xw_start_pre(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    struct mbuf *m0;
    struct ether_header	*eh;
    int s, pkt_len;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    if (sc->gone || ifp->if_snd.ifq_head == NULL)
	return;
    if (CSR_READ_1(sc, 0) == 0xff) {
	device_printf(sc->dev, "Illegal state\n", __FUNCTION__);
	xw_reset(sc);
	return;
    }

    IF_DEQUEUE(&ifp->if_snd, m0);
    if (m0 == NULL)
	return;
    sc->packet = m0;

    eh = mtod(m0, struct ether_header *);
#ifdef TRACE
    device_printf(sc->dev, "dst=%6D src=%6D type=%d\n",
		  eh->ether_dhost, ":", eh->ether_shost, ":",
		  htons(eh->ether_type));
#endif

    if (htons(eh->ether_type) == ETHERTYPE_SNWNMP) {
	s = CSR_READ_1(sc, 9) | XW_URG;
	CSR_WRITE_1(sc, 9, s);
    }
#ifdef TRACE
    device_printf(sc->dev, "%s: m_pkthdr.len=%d, m_len=%d\n", __FUNCTION__,
		  m0->m_pkthdr.len, m0->m_len);
#endif
    pkt_len = m0->m_pkthdr.len;
    CSR_WRITE_1(sc, 10, pkt_len & 0xff);
    CSR_WRITE_1(sc, 10, (pkt_len >> 8) & 0xff);
    CSR_WRITE_1(sc, 10, 0xa5);
    CSR_WRITE_1(sc, 10, 0x03);

    ifp->if_timer = 5;
    ifp->if_flags |= IFF_OACTIVE;
}

static void 
xw_start_post(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    struct mbuf *m0 = sc->packet, *m;
    struct ether_header	*eh;
    int d;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    for (m = m0; m != NULL; m = m->m_next) {
	CSR_WRITE_MULTI_1(sc, 10, mtod(m, caddr_t), m->m_len);
    }

    eh = mtod(m0, struct ether_header *);
    if (htons(eh->ether_type) == ETHERTYPE_SNWNMP) {
	d = CSR_READ_1(sc, 9) & ~XW_URG;
	CSR_WRITE_1(sc, 9, d);
    }

    /* If there's a BPF listner, bounce a copy of this frame to him. */
    if (ifp->if_bpf)
	bpf_mtap(ifp, m0);
    
    m_freem(m0);
    sc->packet = NULL;

    ++(ifp->if_opackets);
    
    ifp->if_timer = 0;
    ifp->if_flags &= ~IFF_OACTIVE;
}

static void 
xw_start(struct ifnet *ifp)
{
    struct xw_softc *sc = ifp->if_softc;
    int s;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    s = splimp();
    disable_interrupts(sc);
    if (sc->packet == NULL && (CSR_READ_1(sc, 7) & XW_CTS) != 0) {
	xw_start_pre(sc);
    }
    enable_interrupts(sc);
    splx(s);
}

static void
xw_intr(void *xsc)
{
    struct xw_softc *sc = xsc;
    struct ifnet *ifp = &sc->arpcom.ac_if;
    unsigned char status;
    int s, d;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    s = splimp();
    if ((ifp->if_flags & IFF_UP) == 0) {
	disable_interrupts(sc);
	splx(s);
	return;
    }
    disable_interrupts(sc);
    status = CSR_READ_1(sc, 7);
#ifdef TRACE
    device_printf(sc->dev, "%s: status 0x%x\n", __FUNCTION__, status);
#endif
    if (status & XW_RST_CARD) {
	xw_reset(sc);
    }
    else if (status & XW_RST_ACK) {
	d = CSR_READ_1(sc, 9) & ~XW_RST_DRVR;
	CSR_WRITE_1(sc, 9, d);
    }
    else {
	if ((status & XW_SEQ) != (sc->sequence & XW_SEQ)) {
	    xw_rxeof(sc);
	    sc->sequence = status & XW_SEQ;
	    status = CSR_READ_1(sc, 7);
	}
	if (sc->packet != NULL && (status & XW_CTS) == 0) {
	    xw_start_post(sc);
	    status = CSR_READ_1(sc, 7);
	}
	if (sc->packet == NULL && (status & XW_CTS) != 0) {
	    xw_start_pre(sc);
	    status = CSR_READ_1(sc, 7);
	}
    }
    enable_interrupts(sc);
    splx(s);
}

static void
xw_inquire(void *xsc)
{
    struct xw_softc *sc = xsc;

    sc->stat_ch = timeout(xw_inquire, sc, hz * 60);
}

static void
xw_stop(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;

    if (sc->gone)
	return;
#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    ifp->if_flags &= ~(IFF_RUNNING | IFF_OACTIVE);
    untimeout(xw_inquire, sc, sc->stat_ch);
    disable_interrupts(sc);
}

static void
xw_init(void *xsc)
{
    struct xw_softc *sc = xsc;
    struct ifnet *ifp = &sc->arpcom.ac_if;
    int s;

    if (sc->gone)
	return;
    s = splimp();
    if (ifp->if_flags & IFF_RUNNING)
	xw_stop(sc);
#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    xw_reset(sc);
    enable_interrupts(sc);

    ifp->if_flags |= IFF_RUNNING;
    ifp->if_flags &= ~IFF_OACTIVE;
    sc->stat_ch = timeout(xw_inquire, sc, hz * 60);

    splx(s);
}

static void
xw_watchdog(struct ifnet *ifp)
{
    struct xw_softc *sc = ifp->if_softc;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    device_printf(sc->dev, "Timeout\n");
    xw_init(sc);
    ifp->if_oerrors++;
    return;
}

static int
xw_ioctl(struct ifnet *ifp, u_long command, caddr_t data)
{
    struct xw_softc *sc = ifp->if_softc;
    int	s, status;

#ifdef TRACE
    device_printf(sc->dev, "%s: enter\n", __FUNCTION__);
#endif
    s = splimp();
    if (sc->gone) {
	splx(s);
	return (ENODEV);
    }

    switch (command) {
    case SIOCSIFADDR:
    case SIOCGIFADDR:
    case SIOCSIFMTU:
	status = ether_ioctl(ifp, command, data);
	break;
    default:
	status = EINVAL;
	break;
    }
    splx(s);
    return (status);
}

static int
xw_pccard_attach(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    struct ifnet *ifp = &sc->arpcom.ac_if;
    int	k, v, s, error;
    
#ifdef TRACE
    device_printf(dev, "%s: enter\n", __FUNCTION__);
#endif
    if ((error = xw_alloc(dev)) != 0) {
	device_printf(dev, "xw_alloc() failed! (%d)\n", error);
	return (error);
    }
    if ((error = bus_setup_intr(dev, sc->irq, INTR_TYPE_NET,
				xw_intr, sc, &sc->intrhand)) != 0) {
	device_printf(dev, "bus_setup_intr() failed! (%d)\n", error);
	xw_free(dev);
	return (error);
    }

    s = splimp();
    disable_interrupts(sc);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_INT_STATUS) != 0; ++k) {
	DELAY(1000);
    }
    if (k == 100) {
#ifdef TRACE
	device_printf(dev, "%s: interrupt not disabled\n", __FUNCTION__);
#endif
    }
    CSR_WRITE_1(sc, 9, XW_RST_DRVR | 0x11);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_RST_ACK) == 0; ++k) {
	DELAY(1000);
    }
    if (k == 100) {
#ifdef TRACE
	device_printf(dev, "%s: reset timeout\n", __FUNCTION__);
#endif
    }
    for (k = 0; k < 6; ++k) {
	v = CSR_READ_1(sc, k);
	sc->mac[k] = v;
    }
    for (k = 0; k < 100 && (v = CSR_READ_1(sc, 6)) != 0xa0; ++k) {
	DELAY(1000);
    }
    if (k == 100) {
#ifdef TRACE
	device_printf(dev, "%s: version timeout\n", __FUNCTION__);
#endif
    }
    v = CSR_READ_1(sc, 9) & ~XW_RST_DRVR;
    CSR_WRITE_1(sc, 9, v);
    splx(s);

    bcopy(sc->mac, (char *)&sc->arpcom.ac_enaddr, ETHER_ADDR_LEN);
    device_printf(dev, "Ethernet address: %6D\n", sc->arpcom.ac_enaddr, ":");

    ifp->if_softc = sc;
    ifp->if_unit = sc->unit;
    ifp->if_name = "xw";
    ifp->if_mtu = ETHERMTU;
    ifp->if_flags = IFF_BROADCAST | IFF_SIMPLEX | IFF_MULTICAST;
    ifp->if_ioctl = xw_ioctl;
    ifp->if_output = ether_output;
    ifp->if_start = xw_start;
    ifp->if_watchdog = xw_watchdog;
    ifp->if_init = xw_init;
    ifp->if_baudrate = 10000000;
    ifp->if_snd.ifq_maxlen = IFQ_MAXLEN;

    xw_init(sc);

    /* Call MI attach routine. */
    ether_ifattach(ifp, ETHER_BPF_SUPPORTED);
    callout_handle_init(&sc->stat_ch);

    return (0);
}

static int
xw_pccard_detach(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    struct ifnet *ifp = &sc->arpcom.ac_if;
    int	s;

#ifdef TRACE
    device_printf(dev, "%s: enter\n", __FUNCTION__);
#endif
    s = splimp();
    if (sc->gone) {
	splx(s);
	device_printf(dev, "Already unloaded\n");
	return(ENODEV);
    }

    xw_stop(sc);
    ether_ifdetach(ifp, ETHER_BPF_SUPPORTED);
    bus_teardown_intr(dev, sc->irq, sc->intrhand);
    xw_free(dev);
    sc->gone = 1;
    
    splx(s);
    device_printf(dev, "Unload\n");
    return (0);
}

static void
xw_shutdown(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);

#ifdef TRACE
    device_printf(dev, "%s: enter\n", __FUNCTION__);
#endif
    xw_stop(sc);
}

static device_method_t xw_pccard_methods[] = {
    /* Device interface */
    DEVMETHOD(device_probe, xw_pccard_probe),
    DEVMETHOD(device_attach, xw_pccard_attach),
    DEVMETHOD(device_detach, xw_pccard_detach),
    DEVMETHOD(device_shutdown, xw_shutdown),
    {0, 0}};

static driver_t xw_pccard_driver = {
    "xw", xw_pccard_methods, sizeof(struct xw_softc)};

static devclass_t xw_pccard_devclass;

DRIVER_MODULE(if_xw, pccard, xw_pccard_driver, xw_pccard_devclass, 0, 0);
