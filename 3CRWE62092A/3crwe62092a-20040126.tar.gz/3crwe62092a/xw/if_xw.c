/*
	$Id: if_xw.c,v 1.5 2004/01/25 19:52:17 syl Exp $

	Copyright (C) 2002, 2003, 2004 Syllabub
	Maroontress Fast Software.
*/

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/sockio.h>
#include <sys/mbuf.h>
#include <sys/proc.h>
#include <sys/kernel.h>
#include <sys/socket.h>
#include <sys/module.h>
#include <sys/bus.h>
#include <sys/random.h>
#include <sys/syslog.h>
#include <sys/sysctl.h>

#include <machine/bus.h>
#include <machine/resource.h>
#include <machine/clock.h>
#include <sys/rman.h>

#include <net/if.h>
#include <net/if_arp.h>
#include <net/ethernet.h>
#include <net/if_dl.h>
#include <net/if_media.h>
#include <net/if_types.h>
#include <net/if_ieee80211.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/in_var.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>

#include <net/bpf.h>

#include <dev/pccard/pccardvar.h>

#include "card_if.h"

#define XW_LOCK(_sc, _s)        s = splimp()
#define XW_UNLOCK(_sc, _s)      splx(s)

#define SNWNMP_GET	0
#define SNWNMP_SET	1
#define SNWNMP_RESPONSE	2
#define SNWNMP_ERROR	3
#define SNWNMP_TRAP	4
#define SNWNMP_LONG_AT(n, k) \
	ntohl(*((long *)((n) + sizeof(struct snwnmp_header)) + (k)))

#define ETHERTYPE_SNWNMP	0x8828

#define MAX_RETRY_COUNT 5

#define DOT11_POWER_MANAGEMENT_MODE     0xff010107
#define DOT11_AUTH_ALGORITHMS_ENABLE    0xff010115
#define DOT11_WEP_DEFAULT_KEY           0xff010116
#define DOT11_PRIVACY_INVOKED           0xff01011a
#define DOT11_WEP_DEFAULT_KEY_ID        0xff01011b
#define DOT11_EXCLUDE_UNENCRYPTED       0xff01011d
#define DOT11_RTS_THRESHOLD             0xff010121
#define DOT11_FRAGMENTATION_THRESHOLD   0xff010124
#define DOT11_CURRENT_CHANNEL           0xff01014c
#define DOT11_DESIRED_BSS_TYPE          0xff010109
#define DOT11_DESIRED_SSID              0xff010108
#define SMT_PUBLIC_KEY_ENABLE           0xff0101a9
#define BSS_CHANGE_TRAP                 0xff0101d5
#define ADHOC_3COM                      0xff010210
#define INFRASTRUCTURE_3COM             0xff010211
#define HIGH_PERFORMACE                 0xff010308
#define ACTIVE_PROBING                  0xff010309
#define RESETTRAP_3COM                  0xff0103ff

#define CSR_READ_1(sc, reg) \
	bus_space_read_1(sc->btag, sc->bhandle, reg)
#define CSR_READ_MULTI_1(sc, reg, addr, count) \
	bus_space_read_multi_1(sc->btag, sc->bhandle, reg, addr, count);
#define CSR_WRITE_1(sc, reg, val) \
	bus_space_write_1(sc->btag, sc->bhandle, reg, val)
#define CSR_WRITE_MULTI_1(sc, reg, addr, count) \
	bus_space_write_multi_1(sc->btag, sc->bhandle, reg, addr, count)

/* base + 0x07: status */
#define XW_RST_ACK    0x80
#define XW_SEQ        0x20
#define XW_CTS        0x10
#define XW_RST_CARD   0x08
#define XW_INT_STATUS 0x04

/* base + 0x08: interrupt control */
#define XW_INT_EN     0x80

/* base + 0x09: reset control */
#define XW_RST_DRVR   0x80
#define XW_URG        0x40

struct xw_softc	{
    struct arpcom arpcom; /* Ethernet common part */
    struct ifmedia ifmedia;
    int gone;
    struct resource *iobase;
    struct resource *irq;
    device_t dev;
    int unit;
    int io_addr;    
    bus_space_handle_t bhandle;
    bus_space_tag_t btag;
    void *intrhand;
    struct mbuf *packet;
    struct callout_handle stat_ch;
    unsigned char mac[ETHER_ADDR_LEN];
    int sequence;
    int reset_trap_3com;
    int associated;
    unsigned char ssid[IEEE80211_NWID_LEN];
    unsigned char wepkey[14 * 4];
    unsigned long wepkey_len[4];
    unsigned long algorithms_enable[3];
    unsigned long infra_3com;
    unsigned long privacy_invoked;
    unsigned long powersave;
    unsigned long bsstype;
    unsigned long exclude_unencrypted;
    unsigned long public_key_enable;
    unsigned long wepkey_id;
};

struct snwnmp_header {
    unsigned char dst[ETHER_ADDR_LEN];
    unsigned char src[ETHER_ADDR_LEN];
    unsigned short type;
    unsigned char version;
    unsigned char operation;
    unsigned long oid __attribute__ ((packed));
    unsigned char index;
    unsigned char flags;
    unsigned long length __attribute__ ((packed));
};

static void
enable_interrupts(struct xw_softc *sc)
{
    int s;

    s = CSR_READ_1(sc, 8) | XW_INT_EN;
    CSR_WRITE_1(sc, 8, s);
}

static void
disable_interrupts(struct xw_softc *sc)
{
    int s;

    s = CSR_READ_1(sc, 8) & ~XW_INT_EN;
    CSR_WRITE_1(sc, 8, s);
}

static void
xw_reset(struct xw_softc *sc)
{
    CSR_WRITE_1(sc, 9, XW_RST_DRVR | 0x11);

    if (sc->packet != NULL) {
        m_freem(sc->packet);
        sc->packet = NULL;
    }
    sc->sequence = 0;
}

static int
snwnmp_recv(struct xw_softc *sc, void *data, size_t *size)
{
    int k, s, seq = sc->sequence & XW_SEQ;
    unsigned int pkt_len, version;

    for (k = 0; k < 100 && (s = CSR_READ_1(sc, 7) & XW_SEQ) == seq; ++k)
        DELAY(1000);
    if (k == 100)
	return (-1);
    pkt_len = CSR_READ_1(sc, 10);
    pkt_len |= CSR_READ_1(sc, 10) << 8;
    version = CSR_READ_1(sc, 10);
    version |= CSR_READ_1(sc, 10) << 8;
    if (pkt_len > *size || version != 0xa503)
	return (-1);
    CSR_READ_MULTI_1(sc, 10, data, pkt_len);
    *size = pkt_len;
    sc->sequence = s;
    enable_interrupts(sc);
    return (0);
}

static int
snwnmp_send(struct xw_softc *sc, void *data, size_t size)
{
    int v, k;

    disable_interrupts(sc);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_INT_STATUS) != 0; ++k) {
        DELAY(1000);
    }
    if (k == 100)
	return (-1);

    xw_reset(sc);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_RST_ACK) == 0; ++k)
        DELAY(1000);
    if (k == 100)
	return (-1);
    v = CSR_READ_1(sc, 9) & ~XW_RST_DRVR;
    CSR_WRITE_1(sc, 9, v);

    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_CTS) == 0; ++k)
        DELAY(1000);
    if (k == 100)
	return (-1);
    if (CSR_READ_1(sc, 0) == 0xff)
	return (-1);

    CSR_WRITE_1(sc, 9, CSR_READ_1(sc, 9) | XW_URG);
    CSR_WRITE_1(sc, 10, size & 0xff);
    CSR_WRITE_1(sc, 10, (size >> 8) & 0xff);
    CSR_WRITE_1(sc, 10, 0xa5);
    CSR_WRITE_1(sc, 10, 0x03);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_CTS) != 0; ++k)
        DELAY(1000);
    if (k == 100)
	return (-1);
    CSR_WRITE_MULTI_1(sc, 10, data, size);
    CSR_WRITE_1(sc, 9, CSR_READ_1(sc, 9) & ~XW_URG);
    return (0);
}

static int
snwnmp_request(struct xw_softc *sc, int operation, unsigned int oid,
	       void *data, size_t size)
{
    const size_t h_size = sizeof(struct snwnmp_header);
    size_t p_size = h_size;
    struct snwnmp_header *h;
    unsigned char *d, buf[1500 + h_size];
    
    if (operation == SNWNMP_SET)
	p_size += size;
    if (p_size >= sizeof(buf))
	return (-1);
    h = (struct snwnmp_header *)buf;
    d = (unsigned char *)h + h_size;
    bcopy(sc->mac, &h->dst, ETHER_ADDR_LEN);
    bcopy(sc->mac, &h->src, ETHER_ADDR_LEN);
    h->type = htons(ETHERTYPE_SNWNMP);
    h->version = 1;
    h->operation = operation;
    h->oid = htonl(oid);
    h->index = 0;
    h->flags = 0;
    h->length = htonl(size);
    if (size > 0 && operation == SNWNMP_SET)
	bcopy(data, d, size);
    if (snwnmp_send(sc, h, p_size) < 0)
	return (-1);

    p_size = sizeof(buf);
    if (snwnmp_recv(sc, h, &p_size) < 0 || p_size < h_size + size
	|| h->type != htons(ETHERTYPE_SNWNMP)
	|| h->operation != SNWNMP_RESPONSE || h->oid != htonl(oid)
	|| h->length != htonl(size)) {
	return (-1);
    }
    if (size > 0 && operation == SNWNMP_GET)
	bcopy(d, data, size);
    return (0);
}

static int
snwnmp_set(struct xw_softc *sc, unsigned int oid, void *data, size_t size)
{
    int n;

    for (n = 0; n < MAX_RETRY_COUNT
	     && snwnmp_request(sc, SNWNMP_SET, oid, data, size) < 0; ++n)
	;
    if (n == MAX_RETRY_COUNT) {
	device_printf(sc->dev, "snwnmp_request() failed.\n");
	return (-1);
    }
    return (0);
}

static int
snwnmp_get(struct xw_softc *sc, unsigned int oid, void *data, size_t size)
{
    int n;

    for (n = 0; n < MAX_RETRY_COUNT
	     && snwnmp_request(sc, SNWNMP_GET, oid, data, size) < 0; ++n)
	;
    if (n == MAX_RETRY_COUNT) {
	device_printf(sc->dev, "snwnmp_request() failed.\n");
	return (-1);
    }
    return (0);
}

static void
snwnmp_set_long(struct xw_softc *sc, unsigned int oid, long data)
{
    snwnmp_set(sc, oid, &data, sizeof(data));
}

static void
xw_inquire(void	*xsc)
{
    struct xw_softc *sc = xsc;
    struct ifnet *ifp = &sc->arpcom.ac_if;
    int s;

    sc->stat_ch = timeout(xw_inquire, sc, hz * 60);

    /* Don't do this while we're transmitting */
    if (ifp->if_flags & IFF_OACTIVE)
	return;

    XW_LOCK(sc, s);
    xw_reset(sc);
    XW_UNLOCK(sc, s);
}

static void
xw_stop(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    int s;

    XW_LOCK(sc, s);
    
    if (sc->gone) {
	XW_UNLOCK(sc, s);
	return;
    }
    disable_interrupts(sc);
    untimeout(xw_inquire, sc, sc->stat_ch);
    ifp->if_flags &= ~(IFF_RUNNING | IFF_OACTIVE);
    if (sc->packet != NULL) {
        m_freem(sc->packet);
	sc->packet = NULL;
    }

    XW_UNLOCK(sc, s);
}

static void
xw_init(void *xsc)
{
    struct xw_softc *sc = xsc;
    struct ifnet *ifp = &sc->arpcom.ac_if;
    unsigned long rts_threshold = htonl(2339);
    unsigned long frag_threshold = htonl(2338);
    unsigned long high_performance = htonl(1);
    unsigned long active_probing = htonl(0);
    int k, v, s;

    XW_LOCK(sc, s);

    if (sc->gone) {
	XW_UNLOCK(sc, s);
	return;
    }

    if (ifp->if_flags & IFF_RUNNING)
	xw_stop(sc);

    xw_reset(sc);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_RST_ACK) == 0; ++k)
        DELAY(1000);
    if (k == 100)
        device_printf(sc->dev, "reset failed\n");
    v = CSR_READ_1(sc, 9) & ~XW_RST_DRVR;
    CSR_WRITE_1(sc, 9, v);

    snwnmp_set_long(sc, 0xff010313, ntohl(1));
    snwnmp_set_long(sc, 0xff010314, ntohl(1));
    snwnmp_set_long(sc, HIGH_PERFORMACE, high_performance);
    snwnmp_set_long(sc, ACTIVE_PROBING, active_probing);
    snwnmp_set_long(sc, DOT11_POWER_MANAGEMENT_MODE, sc->powersave);
    snwnmp_set_long(sc, DOT11_RTS_THRESHOLD, rts_threshold);
    snwnmp_set_long(sc, DOT11_FRAGMENTATION_THRESHOLD, frag_threshold);
    snwnmp_set_long(sc, DOT11_DESIRED_BSS_TYPE, sc->bsstype);
    snwnmp_set_long(sc, INFRASTRUCTURE_3COM, sc->infra_3com);
    snwnmp_set(sc, DOT11_AUTH_ALGORITHMS_ENABLE, sc->algorithms_enable,
	       sizeof(sc->algorithms_enable));
    snwnmp_set(sc, DOT11_WEP_DEFAULT_KEY, sc->wepkey, sizeof(sc->wepkey));
    snwnmp_set_long(sc, DOT11_PRIVACY_INVOKED, sc->privacy_invoked);
    snwnmp_set_long(sc, DOT11_WEP_DEFAULT_KEY_ID, sc->wepkey_id);
    snwnmp_set_long(sc, DOT11_EXCLUDE_UNENCRYPTED, sc->exclude_unencrypted);
    snwnmp_set_long(sc, SMT_PUBLIC_KEY_ENABLE, sc->public_key_enable);
    snwnmp_set(sc, DOT11_DESIRED_SSID, sc->ssid, sizeof(sc->ssid));

    enable_interrupts(sc);

    ifp->if_flags |= IFF_RUNNING;
    ifp->if_flags &= ~IFF_OACTIVE;
    sc->stat_ch = timeout(xw_inquire, sc, hz * 60);

    XW_UNLOCK(sc, s);
}

static void
snwnmp_handle_error(struct xw_softc *sc, unsigned char *data, int size)
{
#ifdef TRACE
    struct snwnmp_header *h = (struct snwnmp_header *)data;

    device_printf(sc->dev, "%s: oid=%lx length=%lx\n", __FUNCTION__,
		  ntohl(h->oid), ntohl(h->length));
#endif
}

static void
snwnmp_handle_trap(struct xw_softc *sc, unsigned char *data, int size)
{
    struct snwnmp_header *h = (struct snwnmp_header *)data;
    unsigned int k, n;

#ifdef TRACE
    device_printf(sc->dev, "%s: oid=%lx length=%lx\n", __FUNCTION__,
		  ntohl(h->oid), ntohl(h->length));
#endif
    switch (ntohl(h->oid)) {
    case BSS_CHANGE_TRAP:
	device_printf(sc->dev, "BSS_CHANGE_TRAP\n");
#ifdef TRACE
	for (k = 0, n = ntohl(h->length) / sizeof(long); k < n; ++k) {
	    device_printf(sc->dev, "[%d] 0x%lx\n", k, SNWNMP_LONG_AT(data, k));
	}
#endif
	if ((n = ntohl(h->length) / sizeof(long)) < 2)
	    break;
	if ((k = SNWNMP_LONG_AT(data, 0)) == 0)
	    device_printf(sc->dev, "associated.\n");
	else if (k == 1)
	    device_printf(sc->dev, "disassociated.\n");
	sc->associated = (k == 0);
	break;
    case RESETTRAP_3COM:
	device_printf(sc->dev, "RESETTRAP_3COM\n");
#ifdef TRACE
	for (k = 0, n = ntohl(h->length) / sizeof(long); k < n; ++k) {
	    device_printf(sc->dev, "[%d] 0x%lx\n", k, SNWNMP_LONG_AT(data, k));
	}
#endif
	xw_reset(sc);
	sc->reset_trap_3com = 1;
	break;
    default:
	device_printf(sc->dev, "unknown trap (oid=%lx, length=%lx)\n",
		      htonl(h->oid), htonl(h->length));
    }
}

static void
process_snwnmp(struct xw_softc *sc, unsigned char *data, int size)
{
    struct snwnmp_header *h = (struct snwnmp_header *)data;

    switch (h->operation) {
    case SNWNMP_ERROR:
	snwnmp_handle_error(sc, data, size);
	break;
    case SNWNMP_TRAP:
	snwnmp_handle_trap(sc, data, size);
	break;
    case SNWNMP_RESPONSE:
	break;
    default:
#ifdef TRACE
	device_printf(sc->dev, "%s: invalid operation (%d)\n", __FUNCTION__,
		      h->operation);
#endif
	break;
    }
}

static void
xw_rxeof(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    struct ether_header *eh;
    struct mbuf *m;
    unsigned char *frame;
    int pkt_len, version;

    /* First read in the frame header */
    pkt_len = CSR_READ_1(sc, 10);
    pkt_len |= CSR_READ_1(sc, 10) << 8;
    if (pkt_len > MCLBYTES) {
        device_printf(sc->dev, "oversized packet received (pkt_len=%d)\n",
                      pkt_len);
        xw_reset(sc);
        ++(ifp->if_ierrors);
	return;
    }

    version = CSR_READ_1(sc, 10);
    version |= CSR_READ_1(sc, 10) << 8;
    if (version != 0xa503) {
        device_printf(sc->dev, "unknown version: 0x%x\n", version);
        xw_reset(sc);
        ++(ifp->if_ierrors);
	return;
    }

    MGETHDR(m, M_DONTWAIT, MT_DATA);
    if (m == NULL) {
	++(ifp->if_ierrors);
	return;
    }
    MCLGET(m, M_DONTWAIT);
    if (!(m->m_flags & M_EXT)) {
	m_freem(m);
	++(ifp->if_ierrors);
	return;
    }
    eh = mtod(m, struct ether_header *);
    m->m_pkthdr.rcvif = ifp;
    m->m_pkthdr.len = m->m_len = pkt_len;

    frame = mtod(m, caddr_t);
    CSR_READ_MULTI_1(sc, 10, frame, pkt_len);
    if (htons(eh->ether_type) == ETHERTYPE_SNWNMP) {
        process_snwnmp(sc, frame, pkt_len);
    }

    ++(ifp->if_ipackets);

    /* Receive packet. */
    m_adj(m, sizeof(struct ether_header));
    ether_input(ifp, eh, m);
}

static void
xw_start_pre(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    struct mbuf *m0;
    struct ether_header *eh;
    int s, pkt_len;

    if (CSR_READ_1(sc, 0) == 0xff) {
        device_printf(sc->dev, "illegal state\n");
        xw_reset(sc);
	return;
    }

    IF_DEQUEUE(&ifp->if_snd, m0);
    if (m0 == NULL) {
	return;
    }
    sc->packet = m0;

    eh = mtod(m0, struct ether_header *);

    if (htons(eh->ether_type) == ETHERTYPE_SNWNMP) {
        s = CSR_READ_1(sc, 9) | XW_URG;
        CSR_WRITE_1(sc, 9, s);
    }
    pkt_len = m0->m_pkthdr.len;
    CSR_WRITE_1(sc, 10, pkt_len & 0xff);
    CSR_WRITE_1(sc, 10, (pkt_len >> 8) & 0xff);
    CSR_WRITE_1(sc, 10, 0xa5);
    CSR_WRITE_1(sc, 10, 0x03);

    ifp->if_timer = 5;
    ifp->if_flags |= IFF_OACTIVE;
}

static void
xw_start_post(struct xw_softc *sc)
{
    struct ifnet *ifp = &sc->arpcom.ac_if;
    struct mbuf *m0 = sc->packet, *m;
    struct ether_header *eh;
    int d;

    for (m = m0; m != NULL; m = m->m_next) {
        CSR_WRITE_MULTI_1(sc, 10, mtod(m, caddr_t), m->m_len);
    }

    eh = mtod(m0, struct ether_header *);
    if (htons(eh->ether_type) == ETHERTYPE_SNWNMP) {
        d = CSR_READ_1(sc, 9) & ~XW_URG;
        CSR_WRITE_1(sc, 9, d);
    }

    /* If there's a BPF listner, bounce a copy of this frame to him. */
    if (ifp->if_bpf)
        bpf_mtap(ifp, m0);
    
    m_freem(m0);
    sc->packet = NULL;

    ifp->if_timer = 0;
    ifp->if_flags &= ~IFF_OACTIVE;
    ++(ifp->if_opackets);
}

static void
xw_start(struct ifnet *ifp)
{
    struct xw_softc *sc = ifp->if_softc;
    int s;
    
    XW_LOCK(sc, s);

    if (!sc->gone && (ifp->if_flags & IFF_OACTIVE) == 0
	&& (CSR_READ_1(sc, 7) & XW_CTS) != 0) {
	xw_start_pre(sc);
    }

    XW_UNLOCK(sc, s);
}

static void
xw_intr(void *xsc)
{
    struct xw_softc *sc = xsc;
    struct ifnet *ifp = &sc->arpcom.ac_if;
    unsigned char status;
    int s, d;

    XW_LOCK(sc, s);

    if (sc->gone || !(ifp->if_flags & IFF_UP)) {
        disable_interrupts(sc);
	XW_UNLOCK(sc, s);
	return;
    }

    /* Disable interrupts. */
    disable_interrupts(sc);

    if ((status = CSR_READ_1(sc, 7)) & XW_RST_CARD) {
	xw_reset(sc);
    }
    else {
	if (status & XW_RST_ACK) {
	    d = CSR_READ_1(sc, 9) & ~XW_RST_DRVR;
	    CSR_WRITE_1(sc, 9, d);
	    if (sc->reset_trap_3com == 1) {
		xw_init(sc);
		sc->reset_trap_3com = 0;
	    }
            status = CSR_READ_1(sc, 7);
	}
        if ((status & XW_SEQ) != (sc->sequence & XW_SEQ)) {
            xw_rxeof(sc);
            sc->sequence = status & XW_SEQ;
            status = CSR_READ_1(sc, 7);
        }
        if (sc->packet != NULL && (status & XW_CTS) == 0) {
            xw_start_post(sc);
            status = CSR_READ_1(sc, 7);
        }
    }

    /* Re-enable interrupts. */
    enable_interrupts(sc);

    if (ifp->if_snd.ifq_head != NULL && (ifp->if_flags & IFF_OACTIVE) == 0
	&& (status & XW_CTS) != 0) {
	xw_start_pre(sc);
    }
    
    XW_UNLOCK(sc, s);
}

static int
get80211(struct xw_softc *sc, struct ieee80211req *req)
{
    long channel;
    u_int8_t tmpkey[14];

    switch (req->i_type) {
    case IEEE80211_IOC_SSID:
	if (req->i_val < -1 && req->i_val > 0)
	    return (EINVAL);
	req->i_len = IEEE80211_NWID_LEN;
	return (copyout(sc->ssid, req->i_data, IEEE80211_NWID_LEN));
    case IEEE80211_IOC_NUMSSIDS:
	req->i_val = 1;
	return (0);
    case IEEE80211_IOC_WEP:
	if (sc->algorithms_enable[0] == ntohl(1))
	    req->i_val = IEEE80211_WEP_OFF;
	else
	    req->i_val = IEEE80211_WEP_ON;
	return (0);
    case IEEE80211_IOC_WEPKEY:
	if (req->i_val < 0 || req->i_val > 3)
	    return (EINVAL);
	if (suser(curproc))
	    bcopy(sc->wepkey + req->i_val * 14, tmpkey, 14);
	else
	    bzero(tmpkey, sizeof(tmpkey));
	req->i_len = sc->wepkey_len[req->i_val];
	return (copyout(tmpkey, req->i_data, sizeof(tmpkey)));
    case IEEE80211_IOC_NUMWEPKEYS:
	req->i_val = 4;
	return (0);
    case IEEE80211_IOC_WEPTXKEY:
	req->i_val = ntohl(sc->wepkey_id);
	return (0);
    case IEEE80211_IOC_AUTHMODE:
	req->i_val = IEEE80211_AUTH_OPEN; /*XXX*/
	return (0);
    case IEEE80211_IOC_STATIONNAME:
	return (EINVAL);
    case IEEE80211_IOC_CHANNEL:
	if (snwnmp_get(sc, DOT11_CURRENT_CHANNEL, &channel, sizeof(long)) < 0)
	    return (EINVAL);
	req->i_val = ntohl(channel);
	return (0);
    case IEEE80211_IOC_POWERSAVE:
	if (ntohl(sc->powersave) == 0)
	    req->i_val = IEEE80211_POWERSAVE_ON;
	else
	    req->i_val = IEEE80211_POWERSAVE_OFF;
	return (0);
    case IEEE80211_IOC_POWERSAVESLEEP:
	return (EINVAL);
    }
    return (EINVAL);
}

static int
set80211(struct xw_softc *sc, struct ieee80211req *req)
{
    int s;
    char ssid[IEEE80211_NWID_LEN];

    switch (req->i_type) {
    case IEEE80211_IOC_SSID:
	if (req->i_val != 0 || req->i_len > IEEE80211_NWID_LEN)
	    return (EINVAL);
	bzero(ssid, IEEE80211_NWID_LEN);
	if ((s = copyin(req->i_data, ssid, req->i_len)) != 0)
	    return (s);
	if (bcmp(ssid, sc->ssid, IEEE80211_NWID_LEN) != 0) {
	    bcopy(ssid, sc->ssid, IEEE80211_NWID_LEN);
	    snwnmp_set(sc, DOT11_DESIRED_SSID, sc->ssid, sizeof(sc->ssid));
	}
	return (0);
    case IEEE80211_IOC_WEP:
	if (req->i_val == IEEE80211_WEP_OFF) {
	    sc->algorithms_enable[0] = htonl(1);
	    sc->algorithms_enable[1] = htonl(2);
	    sc->algorithms_enable[2] = htonl(2);
	    sc->privacy_invoked = htonl(2);
	    sc->infra_3com = htonl(2);
	}
	else {
	    sc->algorithms_enable[0] = htonl(2);
	    sc->algorithms_enable[1] = htonl(1);
	    sc->algorithms_enable[2] = htonl(2);
	    sc->privacy_invoked = htonl(1);
	    sc->infra_3com = htonl(1);
	}
	snwnmp_set(sc, DOT11_AUTH_ALGORITHMS_ENABLE, sc->algorithms_enable,
		   sizeof(sc->algorithms_enable));
	snwnmp_set_long(sc, DOT11_PRIVACY_INVOKED, sc->privacy_invoked);
	snwnmp_set_long(sc, INFRASTRUCTURE_3COM, sc->infra_3com);
	return (0);
    case IEEE80211_IOC_WEPKEY:
	if (req->i_val < 0 || req->i_val > 3 || req->i_len > 13)
	    return (EINVAL);
	bzero(sc->wepkey + req->i_val * 14, 14);
	sc->wepkey_len[req->i_val] = 0;
	if ((s = copyin(req->i_data, sc->wepkey + req->i_val * 14,
			req->i_len)) != 0)
	    return (s);
	sc->wepkey_len[req->i_val] = req->i_len;
	snwnmp_set(sc, DOT11_WEP_DEFAULT_KEY, sc->wepkey, sizeof(sc->wepkey));
	return (0);
    case IEEE80211_IOC_WEPTXKEY:
	if (req->i_val < 0 || req->i_val > 3)
	    return (EINVAL);
	sc->wepkey_id = ntohl(req->i_val);
	snwnmp_set_long(sc, DOT11_WEP_DEFAULT_KEY_ID, sc->wepkey_id);
	return (0);
    case IEEE80211_IOC_AUTHMODE:
	return (EINVAL);
    case IEEE80211_IOC_STATIONNAME:
	return (EINVAL);
    case IEEE80211_IOC_CHANNEL:
	return (EINVAL);
    case IEEE80211_IOC_POWERSAVE:
	if (req->i_val == IEEE80211_POWERSAVE_OFF)
	    sc->powersave = htonl(1);
	else if (req->i_val == IEEE80211_POWERSAVE_ON)
	    sc->powersave = htonl(0);
	else
	    return (EINVAL);
	snwnmp_set_long(sc, DOT11_POWER_MANAGEMENT_MODE, sc->powersave);
	return (0);
    case IEEE80211_IOC_POWERSAVESLEEP:
	return (EINVAL);
    }
    return (EINVAL);
}

static int
xw_ioctl(struct ifnet *ifp, u_long command, caddr_t data)
{
    int	error = 0;
    struct xw_softc *sc = ifp->if_softc;
    int s;

    XW_LOCK(sc, s);

    if (sc->gone) {
	XW_UNLOCK(sc, s);
	return (ENODEV);
    }

    switch (command) {
    case SIOCSIFADDR:
    case SIOCGIFADDR:
    case SIOCSIFMTU:
	error = ether_ioctl(ifp, command, data);
	break;
    case SIOCSIFFLAGS:
	if (ifp->if_flags & IFF_UP) {
	    xw_init(sc);
	}
	else if (ifp->if_flags & IFF_RUNNING) {
	    xw_stop(sc);
	}
	error = 0;
	break;
    case SIOCSIFMEDIA:
    case SIOCGIFMEDIA:
	error = ifmedia_ioctl(ifp, (struct ifreq *)data, &sc->ifmedia,
			      command);
	break;
    case SIOCG80211:
	error = get80211(sc, (struct ieee80211req *)data);
	break;
    case SIOCS80211:
	if ((error = suser(curproc)))
	    break;
	error = set80211(sc, (struct ieee80211req *)data);
	break;
    default:
	error = EINVAL;
	break;
    }

    XW_UNLOCK(sc, s);
    return (error);
}

static void
xw_watchdog(struct ifnet *ifp)
{
    struct xw_softc *sc = ifp->if_softc;
    
    device_printf(sc->dev, "watchdog timeout\n");
    xw_init(sc);
    ifp->if_oerrors++;
}

static void
xw_free(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    
    if (sc->intrhand != NULL) {
	bus_teardown_intr(dev, sc->irq, sc->intrhand);
	sc->intrhand = NULL;
    }
    if (sc->iobase != NULL) {
	bus_release_resource(dev, SYS_RES_IOPORT, 0, sc->iobase);
	sc->iobase = NULL;
    }
    if (sc->irq != NULL) {
	bus_release_resource(dev, SYS_RES_IRQ, 0, sc->irq);
	sc->irq = NULL;
    }
    if (sc->packet != NULL) {
        m_freem(sc->packet);
	sc->packet = NULL;
    }
}

static int
xw_alloc(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    u_long count = (1 << 6);
    u_int flags = rman_make_alignment_flags(count) | RF_ACTIVE;
    int rid;
    
    rid = 0;
    if ((sc->iobase = bus_alloc_resource(dev, SYS_RES_IOPORT, &rid,
					 0, ~0, count, flags)) == 0) {
	device_printf(dev, "No I/O space?!\n");
	return (ENXIO);
    }
    rid = 0;
    if ((sc->irq = bus_alloc_resource(dev, SYS_RES_IRQ, &rid,
				      0, ~0, 1, RF_ACTIVE)) == 0) {
	xw_free(dev);
	device_printf(dev, "No irq?!\n");
	return (ENXIO);
    }
    sc->dev = dev;
    sc->unit = device_get_unit(dev);
    sc->io_addr = rman_get_start(sc->iobase);
    sc->btag = rman_get_bustag(sc->iobase);
    sc->bhandle = rman_get_bushandle(sc->iobase);
    sc->packet = NULL;
    return (0);
}

static void
xw_shutdown(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);

    xw_stop(sc);
}

static int
xw_media_change(struct ifnet *ifp)
{
    struct xw_softc *sc = ifp->if_softc;
    int bsstype = sc->bsstype;

    switch (sc->ifmedia.ifm_cur->ifm_media & IFM_OMASK) {
    case 0:
	sc->bsstype = htonl(1);
	break;
    case IFM_IEEE80211_ADHOC:
	sc->bsstype = htonl(2);
	break;
    default:
	/* Invalid combination. */
	return (EINVAL);
    }

    if (bsstype != sc->bsstype) {
	xw_init(sc);
    }
    return (0);
}

static void
xw_media_status(struct ifnet *ifp, struct ifmediareq *imr)
{
    struct xw_softc *sc = ifp->if_softc;

    imr->ifm_active = IFM_IEEE80211 | IFM_AUTO;
    imr->ifm_active |= ((sc->bsstype == htonl(1)) ? 0 : IFM_IEEE80211_ADHOC);
    /*imr->ifm_active |= IFM_IEEE80211_DS11;*/

    imr->ifm_status = IFM_AVALID;
    imr->ifm_status |= ((sc->associated) ? IFM_ACTIVE : 0);
}

static int
xw_generic_detach(device_t dev)
{
    struct xw_softc *sc;
    struct ifnet *ifp;
    int s;

    sc = device_get_softc(dev);
    XW_LOCK(sc, s);
    ifp = &sc->arpcom.ac_if;

    if (sc->gone) {
	device_printf(dev, "already unloaded\n");
	XW_UNLOCK(sc, s);
	return (ENODEV);
    }

    xw_stop(sc);

    /* Delete all remaining media. */
    ifmedia_removeall(&sc->ifmedia);

    ether_ifdetach(ifp, ETHER_BPF_SUPPORTED);
    xw_free(dev);
    sc->gone = 1;

    XW_UNLOCK(sc, s);

    return (0);
}

static int
xw_generic_attach(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    struct ifnet *ifp = &sc->arpcom.ac_if;
    int	k, error, s, v;

    if ((error = bus_setup_intr(dev, sc->irq, INTR_TYPE_NET,
				xw_intr, sc, &sc->intrhand)) != 0) {
	device_printf(dev, "bus_setup_intr() failed! (%d)\n", error);
	xw_free(dev);
	return (error);
    }

    XW_LOCK(sc, s);

    /* Reset the NIC. */
    disable_interrupts(sc);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_INT_STATUS) != 0; ++k) {
        DELAY(1000);
    }
    if (k == 100) {
	XW_UNLOCK(sc, s);
        device_printf(dev, "interrupt not disabled\n");
	xw_free(dev);
	return (EIO);
    }
    CSR_WRITE_1(sc, 9, XW_RST_DRVR | 0x11);
    for (k = 0; k < 100 && (CSR_READ_1(sc, 7) & XW_RST_ACK) == 0; ++k) {
        DELAY(1000);
    }
    if (k == 100) {
	XW_UNLOCK(sc, s);
        device_printf(dev, "reset failed\n");
	xw_free(dev);
	return (EIO);
    }

    /* Read the station address. */
    for (k = 0; k < 6; ++k) {
        v = CSR_READ_1(sc, k);
        sc->mac[k] = v;
    }
    for (k = 0; k < 100 && (v = CSR_READ_1(sc, 6)) != 0xa0; ++k) {
        DELAY(1000);
    }
    if (k == 100) {
	XW_UNLOCK(sc, s);
	device_printf(dev, "mac read failed\n");
	xw_free(dev);
	return (EIO);
    }
    v = CSR_READ_1(sc, 9) & ~XW_RST_DRVR;
    CSR_WRITE_1(sc, 9, v);

    bcopy(sc->mac, (char *)&sc->arpcom.ac_enaddr, ETHER_ADDR_LEN);
    device_printf(dev, "802.11 address: %6D\n", sc->arpcom.ac_enaddr, ":");

    ifp->if_softc = sc;
    ifp->if_unit = sc->unit;
    ifp->if_name = "xw";
    ifp->if_mtu = ETHERMTU;
    ifp->if_flags = IFF_BROADCAST | IFF_SIMPLEX | IFF_MULTICAST;
    ifp->if_ioctl = xw_ioctl;
    ifp->if_output = ether_output;
    ifp->if_start = xw_start;
    ifp->if_watchdog = xw_watchdog;
    ifp->if_init = xw_init;
    ifp->if_baudrate = 10000000;
    ifp->if_snd.ifq_maxlen = IFQ_MAXLEN;

    bzero(sc->ssid, sizeof(sc->ssid));
    bzero(sc->wepkey, sizeof(sc->wepkey));
    sc->algorithms_enable[0] = htonl(1);
    sc->algorithms_enable[1] = htonl(2);
    sc->algorithms_enable[2] = htonl(2);
    sc->infra_3com = htonl(2);
    sc->privacy_invoked = htonl(2);
    sc->powersave = htonl(1);
    sc->bsstype = htonl(1);
    sc->exclude_unencrypted = htonl(2);
    sc->public_key_enable = htonl(2);
    sc->wepkey_id = htonl(0);
    for (k = 0; k < sizeof(sc->wepkey_len) / sizeof(sc->wepkey_len[0]); ++k)
	sc->wepkey_len[k] = 0;
    sc->reset_trap_3com = 0;
    sc->associated = 0;

    xw_init(sc);
    xw_stop(sc);
    
    ifmedia_init(&sc->ifmedia, 0, xw_media_change, xw_media_status);
#define ADD(m, c)       ifmedia_add(&sc->ifmedia, (m), (c), NULL)
    ADD(IFM_MAKEWORD(IFM_IEEE80211, IFM_AUTO, IFM_IEEE80211_ADHOC, 0), 0);
    ADD(IFM_MAKEWORD(IFM_IEEE80211, IFM_AUTO, 0, 0), 0);
#undef ADD
    ifmedia_set(&sc->ifmedia, IFM_MAKEWORD(IFM_IEEE80211, IFM_AUTO, 0, 0));

    /* Call MI attach routine. */
    ether_ifattach(ifp, ETHER_BPF_SUPPORTED);
    callout_handle_init(&sc->stat_ch);
    XW_UNLOCK(sc, s);

    return (0);
}

static int
xw_pccard_probe(device_t dev)
{
    struct xw_softc *sc = device_get_softc(dev);
    int error;

    sc->gone = 0;

    if ((error = xw_alloc(dev)) != 0) {
	return (error);
    }
    xw_free(dev);

    /* Make sure interrupts are disabled. */
    disable_interrupts(sc);
    
    return (0);
}

static int
xw_pccard_attach(device_t dev)
{
    int error;

    if ((error = xw_alloc(dev)) != 0) {
	device_printf(dev, "xw_alloc() failed! (%d)\n", error);
	return (error);
    }
    return (xw_generic_attach(dev));
}

static device_method_t xw_pccard_methods[] = {
    /* Device interface */
    DEVMETHOD(device_probe, xw_pccard_probe),
    DEVMETHOD(device_attach, xw_pccard_attach),
    DEVMETHOD(device_detach, xw_generic_detach),
    DEVMETHOD(device_shutdown, xw_shutdown),
    {0, 0}};

static driver_t xw_pccard_driver = {
    "xw",
    xw_pccard_methods,
    sizeof(struct xw_softc)};

devclass_t xw_devclass;

DRIVER_MODULE(if_xw, pccard, xw_pccard_driver, xw_devclass, 0, 0);
