/*
	$Id: xwcontrol.c,v 1.3 2004/01/25 19:08:49 syl Exp $

	Copyright (C) 2002, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/sysctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <net/bpf.h>
#include <net/ethernet.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <net/if_types.h>
#include <net/route.h>
#include <err.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_RETRY_COUNT 5

#define SNWNMP_GET      0
#define SNWNMP_SET      1
#define SNWNMP_RESPONSE 2
#define SNWNMP_ERROR    3
#define SNWNMP_TRAP     4
#define SNWNMP_STRING(n) ((unsigned char *)(n + sizeof(struct snwnmp_header)))
#define SNWNMP_MAC(n) ((struct ether_addr *)(n + sizeof(struct snwnmp_header)))
#define SNWNMP_SHORT(n) ntohs(*((short *)(n + sizeof(struct snwnmp_header))))
#define SNWNMP_LONG(n) ntohl(*((long *)(n + sizeof(struct snwnmp_header))))
#define SNWNMP_LONG_AT(n, k) \
	ntohl(*((long *)(n + sizeof(struct snwnmp_header)) + k))

#define ETHERTYPE_SNWNMP        0x8828

#define DOT11_STATION_ID                0xff010100
#define DOT11_POWER_MANAGEMENT_MODE     0xff010107
#define DOT11_DESIRED_SSID              0xff010108
#define DOT11_DESIRED_BSS_TYPE          0xff010109
#define DOT11_OPERATIONAL_RATE_SET      0xff01010a
#define DOT11_DISASSOCIATE_REASON       0xff01010e
#define DOT11_DEAUTHENTICATE_REASON     0xff010110
#define DOT11_AUTH_ALGORITHMS_ENABLE    0xff010115
#define DOT11_WEP_DEFAULT_KEY           0xff010116
#define DOT11_PRIVACY_INVOKED           0xff01011a
#define DOT11_WEP_DEFAULT_KEY_ID        0xff01011b
#define DOT11_EXCLUDE_UNENCRYPTED       0xff01011d
#define DOT11_MAC_ADDRESS               0xff010120
#define DOT11_RTS_THRESHOLD             0xff010121
#define DOT11_SHORT_RETRY_LIMIT         0xff010122
#define DOT11_LONG_RETRY_LIMIT          0xff010123
#define DOT11_FRAGMENTATION_THRESHOLD   0xff010124
#define DOT11_MANUFACTURER_ID           0xff010127
#define DOT11_PRODUCT_ID                0xff010128
#define DOT11_SUPPORTED_POWER_LEVELS    0xff010142
#define DOT11_TX_POWER_LEVEL_1          0xff010143
#define DOT11_CURRENT_TX_POWER_LEVEL    0xff01014b
#define DOT11_CURRENT_CHANNEL           0xff01014c
#define DOT11_SUPPORTED_DATA_RATES_TX   0xff010154
#define DOT11_SUPPORTED_DATA_RATES_RX   0xff010155
#define SMT_CAPABILITY_INFO             0xff0101a1
#define SMT_POWER_SAVE_INTERVAL         0xff0101a2
#define SMT_LISTEN_INTERVAL             0xff0101a3
#define SMT_ATIM_WINDOW                 0xff0101a4
#define SMT_OPERATIONAL_CHANNELS        0xff0101a5
#define SMT_CURRENT_BSSID               0xff0101a6
#define SMT_CURRENT_SSID                0xff0101a7
#define SMT_CURRENT_BSS_TYPE            0xff0101a8
#define SMT_PUBLIC_KEY_ENABLE           0xff0101a9
#define NWN_ROAMTABLELENGTH             0xff0101bf
#define NWN_ROAMBSSID                   0xff0101c0
#define NWN_ROAMSSID                    0xff0101c1
#define BSS_CHANGE_TRAP                 0xff0101d5
#define SMT_QUALITY_INDICATOR           0xff0101d6

#define ADHOC_3COM                      0xff010210
#define INFRASTRUCTURE_3COM             0xff010211

#define HIGH_PERFORMACE                 0xff010308
#define ACTIVE_PROBING                  0xff010309

struct snwnmp_header {
    unsigned char dst[ETHER_ADDR_LEN];
    unsigned char src[ETHER_ADDR_LEN];
    unsigned short type;
    unsigned char version;
    unsigned char operation;
    unsigned long oid __attribute__ ((packed));
    unsigned char index;
    unsigned char flags;
    unsigned long length __attribute__ ((packed));
};

static void
snwnmp_send(int fd, const char *dst_mac, const char *src_mac, int operation,
	    unsigned long oid, void *data, size_t size)
{
    size_t h_size = sizeof(struct snwnmp_header);
    size_t p_size = h_size;
    struct snwnmp_header *h;
    unsigned char *d;

    if (data != NULL) {
	p_size += size;
    }
    if ((h = malloc(p_size)) == NULL) {
    	err(1, "malloc");
    }
    d = (unsigned char *)h + h_size;
    bcopy(dst_mac, &h->dst, ETHER_ADDR_LEN);
    bcopy(src_mac, &h->src, ETHER_ADDR_LEN);
    h->type = htons(ETHERTYPE_SNWNMP);
    h->version = 1;
    h->operation = operation;
    h->oid = htonl(oid);
    h->index = 0;
    h->flags = 0;
    h->length = htonl(size);
    if (size > 0 && data != NULL) {
	bcopy(data, d, size);
    }
    if (write(fd, h, p_size) < 0) {
    	err(1, "write");
    }
}

static int
snwnmp_print(unsigned char *p, int size)
{
    struct snwnmp_header *h = (struct snwnmp_header *)p;
    int op, len;
    unsigned int oid;
#ifdef DEBUG
    unsigned int offset;
    char *operation[] = {"GET", "SET", "RESPONSE", "ERROR", "TRAP", "?"};
#endif
    
    if ((op = h->operation) < 0 || op > 4) {
	op = 5;
    }
    len = htonl(h->length);
    oid = htonl(h->oid);

#ifdef DEBUG
    printf("\
snwnmp:\n\
  dst: %.2x:%.2x:%.2x:%.2x:%.2x:%.2x\n\
  src: %.2x:%.2x:%.2x:%.2x:%.2x:%.2x\n\
  type: %.2x  version:%.2x  operation: %s(%d)\n\
  oid: %.4x  index:%.2x  flags:%.2x  length:%.4x\n",
	   h->dst[0], h->dst[1], h->dst[2], h->dst[3], h->dst[4], h->dst[5],
	   h->src[0], h->src[1], h->src[2], h->src[3], h->src[4], h->src[5],
	   htons(h->type), h->version, operation[op], h->operation,
	   oid, h->index, h->flags, len);
#endif

    size -= sizeof(*h);
    if (len > size)
	len = size;
    p += sizeof(*h);

#ifdef DEBUG
    offset = 0;
    while (len > 0) {
	int k;
	printf("  [%.4x]", offset);
	for (k = 0; k < 16 && len > 0; ++p, --len, ++k) {
	    printf(" %.2x", *p);
	}
	offset += k;
	printf("\n");
    }
#endif
    return (op);
}

static void
snwnmp_print_response(unsigned char *data, int size)
{
    struct snwnmp_header *h = (struct snwnmp_header *)data;
    const char *bsstype_name[] = {"Unknown", "Managed", "Ad-hoc"};

#ifdef DEBUG
    printf("%s: length=%lx\n", __FUNCTION__, ntohl(h->length));
#endif
    if (ntohl(h->length) != size - sizeof(*h))
	errx(1, "packet size incorrect");

    switch (ntohl(h->oid)) {
    case SMT_PUBLIC_KEY_ENABLE:
	printf("Public key enable: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_EXCLUDE_UNENCRYPTED:
	printf("Exclude unencrypted: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_PRIVACY_INVOKED:
	printf("Privacy invoked: %ld\n", SNWNMP_LONG(data));
	break;
    case SMT_CURRENT_BSS_TYPE:
        {
	    int s = SNWNMP_LONG(data);
	    int k = (s < 1 || s > 2) ? 0 : s;
	    printf("Current BSS type: %s\n", bsstype_name[k]);
	}
	break;
    case DOT11_DESIRED_BSS_TYPE:
        {
	    int k;
	    if ((k = SNWNMP_LONG(data)) < 1 || k > 2)
		k = 0;
	    printf("Desired BSS type: %s\n", bsstype_name[k]);
	}
	break;
    case SMT_CURRENT_SSID:
	printf("Current SSID: %s\n", SNWNMP_STRING(data));
	break;
    case DOT11_STATION_ID:
	printf("Station ID: %s\n", ether_ntoa(SNWNMP_MAC(data)));
	break;
    case DOT11_MAC_ADDRESS:
	printf("MAC address: %s\n", ether_ntoa(SNWNMP_MAC(data)));
	break;
    case SMT_CURRENT_BSSID:
	printf("Current BSSID: %s\n", ether_ntoa(SNWNMP_MAC(data)));
	break;
    case SMT_CAPABILITY_INFO:
	printf("Capability info: %d\n", SNWNMP_SHORT(data));
	break;
    case SMT_POWER_SAVE_INTERVAL:
	printf("Power save interval: %d\n", SNWNMP_SHORT(data));
	break;
    case SMT_LISTEN_INTERVAL:
	printf("Listen interval: %d\n", SNWNMP_SHORT(data));
	break;
    case SMT_ATIM_WINDOW:
	printf("ATIM Window: %d\n", SNWNMP_SHORT(data));
	break;
    case SMT_OPERATIONAL_CHANNELS:
	{
	    int i, num = htonl(h->length);
	    for (i = 0; i < num; ++i) {
		printf("Operational channels[%d]: %d\n",
		       i, *SNWNMP_STRING(data + i));
	    }
	}
	break;
    case DOT11_DISASSOCIATE_REASON:
	printf("Station disassociated: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_DEAUTHENTICATE_REASON:
	printf("Station deauthenticated: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_DESIRED_SSID:
        {
	    char *str = SNWNMP_STRING(data);
	    printf("Desiered SSID: %s\n", *str == 0 ? "Any" : str);
	}
	break;
    case DOT11_POWER_MANAGEMENT_MODE:
	printf("Power management mode: %s mode\n",
	       (SNWNMP_LONG(data) == 1 ? "Active" : "Power save"));
	break;
    case DOT11_CURRENT_CHANNEL:
	printf("Current channel: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_LONG_RETRY_LIMIT:
	printf("Long retry limit: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_SHORT_RETRY_LIMIT:
	printf("Short retry limit: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_RTS_THRESHOLD:
	printf("RTS threshold: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_FRAGMENTATION_THRESHOLD:
	printf("Fragmentation threshold: %ld\n", SNWNMP_LONG(data));
	break;
    case INFRASTRUCTURE_3COM:
	printf("Infrastructure: %s\n",
	       (SNWNMP_LONG(data) == 1) ? "WEP encryption" : "Open system");
	break;
    case ADHOC_3COM:
	printf("Adhoc: %s\n",
	       (SNWNMP_LONG(data) == 1) ? "WEP encryption" : "Open system");
	break;
    case NWN_ROAMTABLELENGTH:
	printf("Roaming table length: %ld\n", SNWNMP_LONG(data));
	break;
    case NWN_ROAMSSID:
	{
	    int i, num = htonl(h->length) / 32;
	    for (i = 0; i < num; ++i) {
		printf("Roaming SSID[%d]: '%s'\n",
		       i, SNWNMP_STRING(data) + 32 * i);
	    }
	}
	break;
    case NWN_ROAMBSSID:
	{
	    int i, num = htonl(h->length) / 6;
	    for (i = 0; i < num; ++i) {
		printf("Roaming BSSID[%d]: %s\n",
		       i, ether_ntoa(SNWNMP_MAC(data) + i));
	    }
	}
	break;
    case BSS_CHANGE_TRAP:
	if (htonl(h->length) / sizeof(long) == 2) {
	    printf("BSS change trap: %ld, %ld\n",
		   SNWNMP_LONG_AT(data, 0), SNWNMP_LONG_AT(data, 1));
	}
	break;
    case DOT11_AUTH_ALGORITHMS_ENABLE:
	if (htonl(h->length) / sizeof(long) == 3) {
	    const char *s;
	    if (SNWNMP_LONG_AT(data, 0) == 2
		&& SNWNMP_LONG_AT(data, 1) == 1
		&& SNWNMP_LONG_AT(data, 2) == 2) {
		s = "On";
	    }
	    else if (SNWNMP_LONG_AT(data, 0) == 1
		&& SNWNMP_LONG_AT(data, 1) == 2
		&& SNWNMP_LONG_AT(data, 2) == 2) {
		s = "Off";
	    }
	    else {
		s = "?";
	    }
	    printf("WEP: %s\n", s);
	}
	break;
    case DOT11_SUPPORTED_POWER_LEVELS:
	printf("Power levels: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_TX_POWER_LEVEL_1:
	printf("TX power level 1: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_CURRENT_TX_POWER_LEVEL:
	printf("Current TX power level: %ld\n", SNWNMP_LONG(data));
	break;
    case DOT11_OPERATIONAL_RATE_SET:
	{
	    int i, num = htonl(h->length);
	    for (i = 0; i < num; ++i) {
		printf("Operational rate set[%d]: %d\n",
		       i, SNWNMP_STRING(data)[i]);
	    }
	}
	break;
    case DOT11_SUPPORTED_DATA_RATES_TX:
	{
	    int i, num = htonl(h->length) / sizeof(long);
	    for (i = 0; i < num; ++i) {
		printf("Supported data rates TX[%d]: %ld\n",
		       i, SNWNMP_LONG_AT(data, i));
	    }
	}
	break;
    case DOT11_SUPPORTED_DATA_RATES_RX:
	{
	    int i, num = htonl(h->length) / sizeof(long);
	    for (i = 0; i < num; ++i) {
		printf("Supported data rates RX[%d]: %ld\n",
		       i, SNWNMP_LONG_AT(data, i));
	    }
	}
	break;
    case DOT11_WEP_DEFAULT_KEY:
	{
	    int i, num = htonl(h->length) / 14;
	    for (i = 0; i < num; ++i) {
		printf("WEP key[%d]: %s\n",
		       i, SNWNMP_STRING(data) + i * 14);
	    }
	}
	break;
    case DOT11_WEP_DEFAULT_KEY_ID:
	printf("WEP key ID: %ld\n", SNWNMP_LONG(data));
	break;
    case 0xff010313:
	printf("0xff010313: %ld\n", SNWNMP_LONG(data));
	break;
    case 0xff010314:
	printf("0xff010314: %ld\n", SNWNMP_LONG(data));
	break;
    case ACTIVE_PROBING:
	printf("Active probing: %ld\n", SNWNMP_LONG(data));
	break;
    case HIGH_PERFORMACE:
	printf("High performance: %ld\n", SNWNMP_LONG(data));
	break;
    case 0xff010212:
	printf("User name: %s\n", SNWNMP_STRING(data));
	break;
    case 0xff010214:
	printf("Session word: %s\n", SNWNMP_STRING(data));
	break;
    case DOT11_MANUFACTURER_ID:
	printf("Manufacture ID: %s\n", SNWNMP_STRING(data));
	break;
    case DOT11_PRODUCT_ID:
	printf("Product ID: %s\n", SNWNMP_STRING(data));
	break;
    case SMT_QUALITY_INDICATOR:
	printf("Quality indicator: %ld\n", SNWNMP_LONG(data));
	break;
    default:
	printf("%s: oid=%lx\n", __FUNCTION__, ntohl(h->oid));
    }
}

static int
snwnmp_recv(int fd)
{
    unsigned char buf[4096];
    struct bpf_hdr *h = (struct bpf_hdr *)buf;
    int op, n;
    fd_set readfds;
    struct timeval timeout = {0L, 100 * 1000L};

    do {
	FD_ZERO(&readfds);
	FD_SET(fd, &readfds);
	if ((n = select(fd + 1, &readfds, NULL, NULL, &timeout)) < 0) {
	    err(1, "select");
	}
	if (n == 0) {
	    return (-1);
	}
	if ((n = read(fd, buf, sizeof(buf))) < 0) {
	    err(1, "read");
	}
	if ((unsigned int)n < sizeof(struct bpf_hdr)
	    || (unsigned int)n < h->bh_caplen + h->bh_hdrlen) {
	    errx(1, "too small packet");
	}
    } while ((op = snwnmp_print(buf + h->bh_hdrlen, h->bh_caplen)) <= 1);
    if (op != SNWNMP_RESPONSE) {
	return (-1);
    }
    snwnmp_print_response(buf + h->bh_hdrlen, h->bh_caplen);
    return (0);
}

static int
snwnmp_request(int fd, const char *mac, int operation,
	       unsigned int oid, void *data, size_t size)
{
    snwnmp_send(fd, mac, mac, operation, oid, data, size);
    return (snwnmp_recv(fd));
}

static void
snwnmp_set(int fd, const char *mac, unsigned int oid, void *data, size_t size)
{
    int n;

    for (n = 0; n < MAX_RETRY_COUNT
	     && snwnmp_request(fd, mac, SNWNMP_SET, oid, data, size) < 0; ++n)
	;
    if (n == MAX_RETRY_COUNT)
	errx(1, "no response");
}

static void
snwnmp_get(int fd, const char *mac, unsigned int oid, void *data, size_t size)
{
    int n;

    for (n = 0; n < MAX_RETRY_COUNT
	     && snwnmp_request(fd, mac, SNWNMP_GET, oid, data, size) < 0; ++n)
	;
    if (n == MAX_RETRY_COUNT)
	errx(1, "no response");
}

typedef struct {
    char *lim;
    char *ptr;
} sdl_list;

static void
open_sdl_list(sdl_list *s, char *data, size_t size)
{
    s->lim = data + size;
    s->ptr = data;
}

static struct sockaddr_dl *
get_sdl(sdl_list *s)
{
    struct if_msghdr *ifm;
    struct sockaddr_dl *sdl;

    if (s->ptr >= s->lim)
	return NULL;
    ifm = (struct if_msghdr *)s->ptr;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    s->ptr += ifm->ifm_msglen;
    while (s->ptr < s->lim
	   && (ifm = (struct if_msghdr *)s->ptr)->ifm_type == RTM_NEWADDR) {
	s->ptr += ifm->ifm_msglen;
    }
#ifdef DEBUG
    {
	char name[32];
	strncpy(name, sdl->sdl_data, sdl->sdl_nlen);
	name[sdl->sdl_nlen] = 0;
	printf("%s\n", name);
    }
#endif
    return sdl;
}

static void
get_mac_addr(const char *if_name, char *mac)
{
    struct sockaddr_dl *sdl;
    int mib[6];
    char *data;
    size_t len, size;
    sdl_list s;
 
    len = strlen(if_name);
    mib[0] = CTL_NET;
    mib[1] = PF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_INET;
    mib[4] = NET_RT_IFLIST;
    mib[5] = 0;
    if (sysctl(mib, 6, NULL, &size, NULL, 0) < 0)
	errx(1, "iflist-sysctl-estimate");
    if ((data = (char *)malloc(size)) == NULL)
	err(1, "malloc");
    if (sysctl(mib, 6, data, &size, NULL, 0) < 0)
	errx(1, "actual retrieval of interface table");

    open_sdl_list(&s, data, size);
    while ((sdl = get_sdl(&s)) != NULL
	   && (sdl->sdl_nlen != len || strncmp(if_name, sdl->sdl_data, len))) {
	continue;
    }	
    if (sdl == NULL)
	errx(1, "interface %s not found", if_name);
    if (sdl->sdl_alen == 0
	|| sdl->sdl_type != IFT_ETHER
	|| sdl->sdl_alen != ETHER_ADDR_LEN)
	errx(1, "malformed link-level address");
    bcopy((struct ether_addr *)LLADDR(sdl), mac, ETHER_ADDR_LEN);
    free(data);
}

static void
configure(int fd, const char *mac, const char *arg_ssid,
	  const char *arg_wepkey)
{
    unsigned long powersave = htonl(1);
    unsigned long rts_threshold = htonl(2339);
    unsigned long frag_threshold = htonl(2338);
    unsigned long bsstype = htonl(1);
    unsigned long infra_3com;
    unsigned char ssid[0x20];
    unsigned long exclude_unencrypted = htonl(2);
    unsigned long public_key_enable = htonl(2);
    unsigned long privacy_invoked;
    unsigned long algorithms_enable[3];
    unsigned long wepkey_id = htonl(0);
    unsigned char wepkey[14 * 4];
    unsigned long high_performance = htonl(1);
    unsigned long active_probing = htonl(0);
    unsigned long one = htonl(1);

    bzero(ssid, sizeof(ssid));
    if (arg_ssid != NULL) {
	strncpy(ssid, arg_ssid, sizeof(ssid));
    }

    bzero(wepkey, sizeof(wepkey));
    if (arg_wepkey == NULL) {
        algorithms_enable[0] = htonl(1);
	algorithms_enable[1] = htonl(2);
	algorithms_enable[2] = htonl(2);
	privacy_invoked = htonl(2);
	infra_3com = htonl(2);
    }
    else {
	strncpy(wepkey, arg_wepkey, sizeof(wepkey));
        algorithms_enable[0] = htonl(2);
	algorithms_enable[1] = htonl(1);
	algorithms_enable[2] = htonl(2);
	privacy_invoked = htonl(1);
	infra_3com = htonl(1);
    }

    snwnmp_set(fd, mac, 0xff010313, &one, sizeof(one));
    snwnmp_set(fd, mac, 0xff010314, &one, sizeof(one));
    snwnmp_set(fd, mac, HIGH_PERFORMACE,
	       &high_performance, sizeof(high_performance));
    snwnmp_set(fd, mac, ACTIVE_PROBING,
	       &active_probing, sizeof(active_probing));
    snwnmp_set(fd, mac, DOT11_POWER_MANAGEMENT_MODE,
	       &powersave, sizeof(powersave));
    snwnmp_set(fd, mac, DOT11_RTS_THRESHOLD,
	       &rts_threshold, sizeof(rts_threshold));
    snwnmp_set(fd, mac, DOT11_FRAGMENTATION_THRESHOLD,
	       &frag_threshold, sizeof(frag_threshold));
    snwnmp_set(fd, mac, DOT11_DESIRED_BSS_TYPE, &bsstype, sizeof(bsstype));
    snwnmp_set(fd, mac, INFRASTRUCTURE_3COM, &infra_3com, sizeof(infra_3com));
    snwnmp_set(fd, mac, DOT11_AUTH_ALGORITHMS_ENABLE,
	       algorithms_enable, sizeof(algorithms_enable));
    snwnmp_set(fd, mac, DOT11_WEP_DEFAULT_KEY, wepkey, sizeof(wepkey));
    snwnmp_set(fd, mac, DOT11_PRIVACY_INVOKED,
	       &privacy_invoked, sizeof(privacy_invoked));
    snwnmp_set(fd, mac, DOT11_WEP_DEFAULT_KEY_ID,
	       &wepkey_id, sizeof(wepkey_id));
    snwnmp_set(fd, mac, DOT11_EXCLUDE_UNENCRYPTED,
	       &exclude_unencrypted, sizeof(exclude_unencrypted));
    snwnmp_set(fd, mac, SMT_PUBLIC_KEY_ENABLE,
	       &public_key_enable, sizeof(public_key_enable));
    snwnmp_set(fd, mac, DOT11_DESIRED_SSID, ssid, sizeof(ssid));
    
    snwnmp_get(fd, mac, BSS_CHANGE_TRAP, NULL, 8);
}

static void
status(int fd, const char *mac)
{
    snwnmp_get(fd, mac, SMT_CURRENT_BSSID, NULL, 6);
    snwnmp_get(fd, mac, SMT_CURRENT_SSID, NULL, 0x20);
    snwnmp_get(fd, mac, SMT_CURRENT_BSS_TYPE, NULL, 4);
    snwnmp_get(fd, mac, SMT_PUBLIC_KEY_ENABLE, NULL, 4);
    snwnmp_get(fd, mac, DOT11_AUTH_ALGORITHMS_ENABLE, NULL, 0x0c);
    snwnmp_get(fd, mac, DOT11_PRIVACY_INVOKED, NULL, 4);
    snwnmp_get(fd, mac, DOT11_EXCLUDE_UNENCRYPTED, NULL, 4);
    snwnmp_get(fd, mac, DOT11_WEP_DEFAULT_KEY_ID, NULL, 4);
    snwnmp_get(fd, mac, DOT11_MANUFACTURER_ID, NULL, 0x3f);
    snwnmp_get(fd, mac, DOT11_PRODUCT_ID, NULL, 0x3f);
    snwnmp_get(fd, mac, DOT11_CURRENT_CHANNEL, NULL, 4);
    snwnmp_get(fd, mac, SMT_QUALITY_INDICATOR, NULL, 4);
    snwnmp_get(fd, mac, DOT11_CURRENT_TX_POWER_LEVEL, NULL, 4);
    snwnmp_get(fd, mac, DOT11_LONG_RETRY_LIMIT, NULL, 4);
    snwnmp_get(fd, mac, DOT11_SHORT_RETRY_LIMIT, NULL, 4);
}

static struct bpf_insn snwnmp_filter[] = {
    BPF_STMT(BPF_LD | BPF_H | BPF_ABS, 12),
    BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, ETHERTYPE_SNWNMP, 0, 2),
    BPF_STMT(BPF_LD | BPF_W | BPF_LEN, 0),
    BPF_STMT(BPF_RET | BPF_A, 0),
    BPF_STMT(BPF_RET | BPF_K, 0)
};

static void
usage(void)
{
    fprintf(stderr, "\
usage: xwcontrol [-f bpf-device] [-i interface] [-s ssid] [-w wepkey]\n
       xwcontrol [-f bpf-device] [-i interface] -v\n");
    exit(0);
}

int
main(int ac, char **av)
{
    char *bpfdev = "/dev/bpf0";
    char *if_name = "xw0";
    char *ssid = NULL;
    char *wepkey = NULL;
    struct ifreq nic;
    const int one = 1;
    char mac[ETHER_ADDR_LEN];
    int fd, ch, show = 0;
    struct bpf_program prog;

    while ((ch = getopt(ac, av, "vf:i:s:w:")) != -1) {
	switch (ch) {
	case 'v':
	    show = 1;
	    break;
	case 'i':
	    if_name = optarg;
	    break;
	case 's':
	    ssid = optarg;
	    break;
	case 'w':
	    wepkey = optarg;
	    break;
	case 'f':
	    bpfdev = optarg;
	    break;
	case '?':
	default:
	    usage();
	    /* NOTREACHED */
	}
    }
    ac -= optind;
    av += optind;
    if (ac == 1) {
	usage();
	/* NOTREACHED */
    }

    get_mac_addr(if_name, mac);
    snprintf(nic.ifr_name, sizeof(nic.ifr_name), if_name);
    prog.bf_len = sizeof(snwnmp_filter) / sizeof(snwnmp_filter[0]);
    prog.bf_insns = snwnmp_filter;

    if ((fd = open(bpfdev, O_RDWR)) < 0)
	err(1, "open: %s", bpfdev);
    if (ioctl(fd, BIOCSETIF, &nic) < 0)
	err(1, "ioctl(BIOCSETIF)");
    if (ioctl(fd, BIOCSHDRCMPLT, &one) < 0)
	err(1, "ioctl(BIOCSHDRCMPLT)");
    if (ioctl(fd, BIOCIMMEDIATE, &one) < 0)
	err(1, "ioctl(BIOCIMMEDIATE)");
    if (ioctl(fd, BIOCSETF, &prog) < 0)
	err(1, "ioctl(BIOCSETF)");

    if (show)
	status(fd, mac);
    else
	configure(fd, mac, ssid, wepkey);

    (void)close(fd);
    exit(0);
    return (0);
}
