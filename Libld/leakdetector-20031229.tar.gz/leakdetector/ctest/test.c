/*
	$Id: test.c,v 1.2 2003/12/29 03:10:16 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <sys/types.h>
#include <sys/wait.h>
#include <err.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "ld.h"

static void *
run(void *arg __unused)
{
    char *s;

    if ((s = strdup("abc")) == NULL)
	err(1, "strdup");
    if ((s = strdup("def")) == NULL)
	err(1, "strdup");
    free(s);
    return NULL;
}

static void
child(void)
{
    char *s;

    if ((s = (char *)malloc(10)) == NULL)
	err(1, "malloc");
    free(s);
    if ((s = (char *)malloc(20)) == NULL)
	err(1, "malloc");
    exit(0);
}

static void
bar(void)
{
    char *s;

    if ((s = (char *)malloc(30)) == NULL)
	err(1, "malloc");
}

static void
foo(void)
{
    pthread_t thread;
    pid_t pid;

    if ((pid = fork()) < 0) {
	err(1, "fork");
    }
    if (pid == 0) {
	child();
	/* NOTREACHED */
    }
    if (pthread_create(&thread, NULL, run, NULL)) {
	err(1, "pthread_create");
    }
    bar();
    if (pthread_join(thread, NULL)) {
	err(1, "pthread_join");
    }
    if (wait(NULL) < 0) {
	err(1, "wait");
    }
}

int
main(void)
{
    if (ld_open("all.log") < 0) {
	err(1, "ld_open() failed.");
    }
    foo();
    if (ld_close() < 0) {
	err(1, "ld_close() failed.");
    }
    abort();
    return 0;
}
