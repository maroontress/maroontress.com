/*
	$Id: ld.c,v 1.2 2003/12/29 03:15:53 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <sys/stat.h>
#include <sys/types.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef RTLD_NEXT
#define RTLD_NEXT ((void *) -1l)
#endif

#include "chunk.h"

#include "ld.h"

typedef int *Frame;
#define FP_CURRENT ((Frame)__builtin_frame_address(0))
#define FP_NEXT(x) ((Frame)((x)[0]))
#define IP_RETURN(x) ((Frame)((x)[1]))
#define FP_IS_ROOT(x) (FP_NEXT(x) == 0 || IP_RETURN(x) == 0)

typedef struct {
    size_t size;
    int recursive;
    size_t pad[2];
} Pad;

static void *(*realMalloc)(size_t) = NULL;
static void (*realFree)(void *) = NULL;
static int fd = -1;

int
ld_open(const char *path)
{
    if (fd >= 0)
	return (-1);
    return (fd = open(path, O_CREAT | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR));
}

int
ld_close(void)
{
    int s;

    if ((s = fd) < 0)
	return (-1);
    fd = -1;
    return (close(s));
}

static void *
ldmalloc(unsigned int n)
{
    void *p;
    Frame fp, ip;
    int k;
    Chunk *c;

    if (realMalloc == NULL)
	realMalloc = dlsym(RTLD_NEXT, "malloc");
    if ((p = realMalloc(sizeof(Pad) + n)) == NULL)
	return (NULL);
    ((Pad *)p)->size = n;
    ((Pad *)p)->recursive = 0;

    fp = FP_CURRENT;
    ip = IP_RETURN(fp);
    for (k = 1, fp = FP_NEXT(fp); !FP_IS_ROOT(fp) && IP_RETURN(fp) != ip;
	 ++k, fp = FP_NEXT(fp)) {
	continue;
    }
    if (!FP_IS_ROOT(fp)) {
	/* a recursive call is detected. */
	((Pad *)p)->recursive = 1;
	++((Pad *)p);
	return (p);
    }

    if ((c = alloca(CHUNK_SIZE(k + 1))) == NULL) {
	realFree(p);
	return (NULL);
    }
    ++((Pad *)p);
    c->h.seq = CHUNK_ALLOCATED;
    c->h.ppid = (unsigned int)getppid();
    c->h.ptr = (unsigned int)p;
    c->len = n;
    c->count = k + 1;
    for (k = 0, fp = FP_CURRENT; !FP_IS_ROOT(fp); ++k, fp = FP_NEXT(fp))
        c->vma[k] = (unsigned int)IP_RETURN(fp);
    c->vma[k] = 0;
    if (fd > 0)
	write(fd, c, CHUNK_SIZE(k + 1));
    return (p);
}

static void
ldfree(void *p)
{
    ChunkHeader c;

    if (realFree == NULL)
	realFree = dlsym(RTLD_NEXT, "free");
    if (p == NULL)
	return;
    c.seq = CHUNK_RELEASED;
    c.ppid = (unsigned int)getppid();
    c.ptr = (unsigned int)p;

    --((Pad *)p);
    if (!((Pad *)p)->recursive && fd > 0)
	write(fd, &c, sizeof(c));

    realFree(p);
}

void *
malloc(size_t n)
{
    return (ldmalloc(n));
}

void
free(void *p)
{
    ldfree(p);
}

void *
calloc(size_t n, size_t s)
{
    void *p;
    
    if ((p = ldmalloc(n * s)) == NULL)
	return (NULL);
    memset(p, 0, n * s);
    return (p);
}
    
void *
realloc(void *p, size_t n)
{
    void *q;

    if ((q = ldmalloc(n)) == NULL)
	return (NULL);
    if (p == NULL)
	return (q);
    memcpy(q, p, (((Pad *)p)[-1]).size);
    ldfree(p);
    return (q);
}
