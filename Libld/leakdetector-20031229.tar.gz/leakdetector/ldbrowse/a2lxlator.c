/*
	$Id: a2lxlator.c,v 1.1 2003/09/22 19:43:29 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>

#include "bfd.h"

#include "a2lxlator.h"

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

static int
initialize(A2LTranslator *x, const char *a_out)
{
    char **matching;
    long n;
    unsigned int s;

    if ((x->fp = bfd_openr(a_out, NULL)) == NULL) {
	warnx("%s: bfd_openr() failed", a_out);
	return 1;
    }
    if (bfd_check_format(x->fp, bfd_archive)) {
	warnx("%s: cannot get addresses from archive", a_out);
	return 1;
    }
    if (!bfd_check_format_matches(x->fp, bfd_object, &matching)) {
	warnx("%s: bfd_check_format_matches() failed", a_out);
	return 1;
    }
    if ((bfd_get_file_flags(x->fp) & HAS_SYMS) == 0) {
	warnx("%s: symbol not found", a_out);
	return 1;
    }
    if ((n = bfd_read_minisymbols(x->fp, FALSE, (PTR)&x->symbols, &s)) == 0)
	n = bfd_read_minisymbols(x->fp, TRUE, (PTR)&x->symbols, &s);
    if (n < 0) {
	warnx("%s: bfd_read_minisymbols() failed", a_out);
	return 1;
    }
    return 0;
}

void
FreeA2LTranslator(A2LTranslator *x)
{
    if (x->fp != NULL)
	bfd_close(x->fp);
    free(x);
}

A2LTranslator *
CreateA2LTranslator(const char *a_out)
{
    A2LTranslator *x;

    bfd_init();
#if 0
#define TARGET "i386-unknown-freebsd4.7"
    if (!bfd_set_default_target(TARGET)) {
	warnx("cannot set BFD default target to %s", TARGET);
	return NULL;
    }
#endif
    if ((x = (A2LTranslator *)malloc(sizeof(A2LTranslator))) == NULL) {
	warnx("malloc() failed");
	return NULL;
    }
    x->fp = NULL;

    if (initialize(x, a_out)) {
	FreeA2LTranslator(x);
	return NULL;
    }
    return x;
}

static void
finder(bfd *fp, asection *section, PTR data)
{
    A2LTranslator *x = (A2LTranslator *)data;
    bfd_size_type size;
    bfd_vma vma;

    if ((vma = x->vma) == 0)
	return;
    x->srcfile = NULL;
    x->function = NULL;
    x->line = 0;

    if ((bfd_get_section_flags(fp, section) & SEC_ALLOC) == 0
	|| (int)(vma -= bfd_get_section_vma(fp, section)) < 0
	|| (size = bfd_get_section_size_before_reloc(section)) <= vma) {
	return;
    }
    if (bfd_find_nearest_line(fp, section, x->symbols, vma,
			      &x->srcfile, &x->function, &x->line)) {
	x->vma = 0;
    }
}

int
QueryA2LTranslator(A2LTranslator *x, unsigned int vma,
		   const char **srcfile_return, const char **function_return,
		   int *line_return)
{
    if ((x->vma = vma) == 0)
	return 1;
    bfd_map_over_sections(x->fp, finder, x);
    *srcfile_return = x->srcfile;
    *function_return = x->function;
    *line_return = x->line;
    return 0;
}
