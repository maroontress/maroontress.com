/*
	$Id: ld.c,v 1.4 2004/01/17 16:20:27 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <sys/stat.h>
#include <sys/types.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#ifndef RTLD_NEXT
#define RTLD_NEXT ((void *)-1l)
#endif

#include "chunk.h"

#include "ld.h"

typedef int *Frame;
#define FP_CURRENT ((Frame)__builtin_frame_address(0))
#define FP_NEXT(x) ((Frame)((x)[0]))
#define IP_RETURN(x) ((Frame)((x)[1]))
#define FP_IS_ROOT(x) (FP_NEXT(x) == 0 || IP_RETURN(x) == 0)

typedef struct {
    size_t size;
    int recursive;
    size_t pad[2];
} Pad;

static void *(*realMalloc)(size_t) = NULL;
static void (*realFree)(void *) = NULL;
static pid_t (*realFork)(void) = NULL;
static int fd = -1;

int
ld_open(const char *path)
{
    if (fd >= 0)
	return (-1);
    return (fd = open(path, O_CREAT | O_TRUNC | O_WRONLY | O_APPEND,
		      S_IRUSR | S_IWUSR));
}

int
ld_close(void)
{
    int s;

    if ((s = fd) < 0)
	return (-1);
    fd = -1;
    return (close(s));
}

static void *ldmalloc0(unsigned int);
static void *(*ldmalloc)(unsigned int) = ldmalloc0;
#ifdef linux
static char top_dlsym[4096], *ptr_dlsym = top_dlsym;
#endif

static void *
ldmalloc1(unsigned int n)
{
    void *p;
    Frame fp, ip;
    int k;
    Chunk *c;

    if ((p = realMalloc(sizeof(Pad) + n)) == NULL)
	return (NULL);
    ((Pad *)p)->size = n;
    ((Pad *)p)->recursive = 0;

    fp = FP_CURRENT;
    ip = IP_RETURN(fp);
    for (k = 1, fp = FP_NEXT(fp); !FP_IS_ROOT(fp) && IP_RETURN(fp) != ip;
	 ++k, fp = FP_NEXT(fp)) {
	continue;
    }
    if (!FP_IS_ROOT(fp)) {
	/*
	  A recursive call has been detected.  Maybe, write(2) is
	  not a system call, using malloc(3).
	*/
	((Pad *)p)->recursive = 1;
	++((Pad *)p);
	return (p);
    }

    if ((c = alloca(CHUNK_SIZE(k + 1))) == NULL) {
	realFree(p);
	return (NULL);
    }
    ++((Pad *)p);
    c->h.seq = CHUNK_ALLOCATED;
    c->h.pid = (unsigned int)getpid();
    c->h.ptr = (unsigned int)p;
    c->len = n;
    c->count = k + 1;
    for (k = 0, fp = FP_CURRENT; !FP_IS_ROOT(fp); ++k, fp = FP_NEXT(fp))
        c->vma[k] = (unsigned int)IP_RETURN(fp);
    c->vma[k] = 0;
    if (fd > 0)
	write(fd, c, CHUNK_SIZE(k + 1));
    return (p);
}

static void *
ldmalloc0(unsigned int n)
{
    Frame fp, ip;
    int k;

    fp = FP_CURRENT;
    ip = IP_RETURN(fp);
    for (k = 1, fp = FP_NEXT(fp); !FP_IS_ROOT(fp) && IP_RETURN(fp) != ip;
	 ++k, fp = FP_NEXT(fp)) {
	continue;
    }
#ifdef linux
    if (!FP_IS_ROOT(fp)) {
	/*
	  A recursive call has been detected.  Maybe, dlsym(3) is
	  using malloc(3).
	*/
	char *p = ptr_dlsym;
	ptr_dlsym += (n + 0x0f) & ~0x0f;
	if (ptr_dlsym >= top_dlsym + sizeof(top_dlsym))
	    abort();
	return (p);
    }
#endif
    if ((realMalloc = dlsym(RTLD_NEXT, "malloc")) == NULL)
	abort();
    ldmalloc = ldmalloc1;
    return (ldmalloc(n));
}

static void ldfree0(void *);
static void (*ldfree)(void *) = ldfree0;

static void
ldfree1(void *p)
{
    ChunkHeader c;

    if (p == NULL)
	return;
#ifdef linux
    if ((char *)p >= top_dlsym && (char *)p < top_dlsym + sizeof(top_dlsym))
	return;
#endif
    c.seq = CHUNK_RELEASED;
    c.pid = (unsigned int)getpid();
    c.ptr = (unsigned int)p;

    --((Pad *)p);
    if (!((Pad *)p)->recursive && fd > 0)
	write(fd, &c, sizeof(c));

    realFree(p);
}

static void
ldfree0(void *p)
{
    if ((realFree = dlsym(RTLD_NEXT, "free")) == NULL)
	abort();
    ldfree = ldfree1;
    ldfree(p);
}

static pid_t ldfork0(void);
static pid_t (*ldfork)(void) = ldfork0;

static pid_t
ldfork1(void)
{
    ChunkHeader c;
    pid_t pid;
    int fildes[2];

    if (pipe(fildes) < 0)
	abort();
    if ((pid = realFork()) > 0) {
	c.seq = CHUNK_BRANCHED;
	c.pid = (unsigned int)pid;
	c.ptr = (unsigned int)getpid();
	if (fd > 0)
	    write(fd, &c, sizeof(c));
	write(fildes[1], &c, sizeof(c));
    }
    else if (pid == 0) {
	(void)read(fildes[0], &c, sizeof(c));
    }
    (void)close(fildes[0]);
    (void)close(fildes[1]);
    return (pid);
}

static pid_t
ldfork0(void)
{
    if ((realFork = dlsym(RTLD_NEXT, "fork")) == NULL)
	abort();
    ldfork = ldfork1;
    return (ldfork());
}

void *
malloc(size_t n)
{
    return (ldmalloc(n));
}

void
free(void *p)
{
    ldfree(p);
}

void *
calloc(size_t n, size_t s)
{
    void *p;
    
    if ((p = ldmalloc(n * s)) == NULL)
	return (NULL);
    memset(p, 0, n * s);
    return (p);
}
    
void *
realloc(void *p, size_t n)
{
    void *q;

    if ((q = ldmalloc(n)) == NULL)
	return (NULL);
    if (p == NULL)
	return (q);
    memcpy(q, p, (((Pad *)p)[-1]).size);
    ldfree(p);
    return (q);
}

pid_t
fork(void)
{
    return (ldfork());
}
