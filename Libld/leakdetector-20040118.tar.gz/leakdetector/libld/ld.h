/*
	$Id: ld.h,v 1.1 2003/09/22 19:43:30 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#ifndef _LD_H_
#define _LD_H_

#include <X11/Xlib.h>

_XFUNCPROTOBEGIN
int ld_open(const char *path);
int ld_close(void);
_XFUNCPROTOEND

#endif /* _LD_H_ */
