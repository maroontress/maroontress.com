/*
	$Id: chunk.h,v 1.3 2004/01/17 16:25:09 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

typedef struct {
    unsigned int seq;
    unsigned int pid;
    unsigned int ptr;
} ChunkHeader;

typedef struct {
    ChunkHeader h;
    unsigned int len;
    unsigned int count;
    unsigned int vma[1];
} Chunk;

#define CHUNK_SIZE(x) (sizeof(Chunk) + ((x) - 1) * sizeof(int))
#define CHUNK_ALLOCATED 'a'
#define CHUNK_RELEASED 'f'
#define CHUNK_BRANCHED 'b'
