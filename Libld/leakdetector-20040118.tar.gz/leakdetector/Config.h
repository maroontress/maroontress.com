/*
	$Id: Config.h,v 1.1 2003/09/22 19:43:29 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

/*
	InstallBinDir: the directory where you wish to install a binary file.
	If this is undefined, the file may be installed in "/usr/X11R?/bin".
*/
XCOMM	#define	InstallBinDir	/usr/X11R6/bin
#define	InstallBinDir	$(HOME)/bin

/*
	BerkeleyDBType: if you use Linux, should define this as one of the
	following values.

	DB1:	you have /usr/include/db1/db.h and /usr/lib/libdb1.so.
	DB185:	you have /usr/include/db_185.h and /usr/lib/libdb.so.
*/
XCOMM	#define	BerkeleyDBType DB1
XCOMM	#define	BerkeleyDBType DB185	/* Red Hat Linux 9, Vine */

/*
	BinutilsDir: if you use FreeBSD, should define this as the directory
	where binutils has been built.
*/
XCOMM	#define	BinutilsDir	$(HOME)/binutils-2.14
#define	BinutilsDir	$(HOME)/tmp/binutils-2.14
