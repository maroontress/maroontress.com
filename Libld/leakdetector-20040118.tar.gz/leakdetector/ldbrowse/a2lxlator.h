/*
	$Id: a2lxlator.h,v 1.1 2003/09/22 19:43:29 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

typedef struct {
    bfd *fp;
    asymbol **symbols;
    bfd_vma vma;
    const char *srcfile;
    const char *function;
    unsigned int line;
} A2LTranslator;

A2LTranslator * CreateA2LTranslator(const char *a_out);
void FreeA2LTranslator(A2LTranslator *xlator);
int QueryA2LTranslator(A2LTranslator *xlator, unsigned int vma,
		       const char **srcfile_return,
		       const char **function_return,
		       int *line_return);
