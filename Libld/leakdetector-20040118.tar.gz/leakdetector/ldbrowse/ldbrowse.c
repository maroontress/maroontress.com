/*
	$Id: ldbrowse.c,v 1.3 2004/01/17 16:29:39 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <stdio.h>
#include <err.h>

#include "bfd.h"
#include "a2lxlator.h"

#include "chunk.h"

static int
printAllocation(FILE *fp, A2LTranslator *x)
{
    unsigned int pid, ptr, len, count;
    int s, line;
    const char *srcfile;
    const char *function;

    if (fread(&pid, sizeof(int), 1, fp) < 1
	|| fread(&ptr, sizeof(int), 1, fp) < 1
	|| fread(&len, sizeof(int), 1, fp) < 1
	|| fread(&count, sizeof(int), 1, fp) < 1) {
	return 1;
    }
    printf("\nallocate: [pid=%u] 0x%x (%d bytes)\n", pid, ptr, len);

    while ((s = fread(&ptr, sizeof(int), 1, fp)) == 1 && ptr) {
	if (QueryA2LTranslator(x, ptr, &srcfile, &function, &line)) {
	    printf("unknown (0x%x)\n", ptr);
	    continue;
	}
	if (function != NULL)
	    printf("%s:%d: in function '%s'\n", srcfile, line, function);
	else
	    printf("%s:%d: in function 0x%x\n", srcfile, line, ptr);
    }
    return (s < 1);
}

static int
printFree(FILE *fp)
{
    unsigned int pid, ptr;

    if (fread(&pid, sizeof(int), 1, fp) < 1
	|| fread(&ptr, sizeof(int), 1, fp) < 1) {
	return 1;
    }
    printf("\nfree: [pid=%u] 0x%x\n", pid, ptr);
    return 0;
}
    
static int
printFork(FILE *fp)
{
    unsigned int pid, ppid;

    if (fread(&pid, sizeof(int), 1, fp) < 1
	|| fread(&ppid, sizeof(int), 1, fp) < 1) {
	return 1;
    }
    printf("\nfork: [pid=%u, ppid=%u]\n", pid, ppid);
    return 0;
}

int
main(int ac, char **av)
{
    A2LTranslator *x;
    FILE *fp;
    char *file;
    int n;

    if (ac < 2 || ac > 3) {
	errx(1, "usage: %s program [file]", av[0]);
    }
    if (ac == 2) {
	fp = stdin;
	file = "<stdin>";
    }
    else {
	if ((fp = fopen(av[2], "r")) == NULL)
	    err(1, "%s", av[2]);
	file = av[2];
    }
    if ((x = CreateA2LTranslator(av[1])) == NULL)
	errx(1, "CreateA2LTranslator() failed");
    while (fread(&n, sizeof(int), 1, fp) == 1) {
	switch (n) {
	case CHUNK_ALLOCATED:
	    if (printAllocation(fp, x))
		errx(1, "%s: unexpected EOF", file);
	    break;
	case CHUNK_RELEASED:
	    if (printFree(fp))
		errx(1, "%s: unexpected EOF", file);
	    break;
	case CHUNK_BRANCHED:
	    if (printFork(fp))
		errx(1, "%s: unexpected EOF", file);
	    break;
	default:
	    errx(1, "%s: unexpected chunk type 0x%x", file, n);
	    break;
	}
    }
    fclose(fp);
    FreeA2LTranslator(x);
    return 0;
}
