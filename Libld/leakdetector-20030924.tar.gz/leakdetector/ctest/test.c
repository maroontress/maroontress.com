/*
	$Id: test.c,v 1.1 2003/09/22 19:43:29 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>
#include <string.h>
#include <err.h>

#include "ld.h"

static void
foo_c(int d, int e, int f)
{
    (void)malloc(10);
    (void)strdup("abc");
}

static void
foo_b(int s)
{
    void *p = malloc(4);
    foo_c(1, 2, 3);
    free(p);
}

static void
foo_a(int s)
{
    (void)malloc(8);
    foo_b(s);
}

int
main(void)
{
    if (ld_open("all.log") < 0) {
	err(1, "ld_open() failed.");
    }
    foo_a(0);
    if (ld_close() < 0) {
	err(1, "ld_close() failed.");
    }
    return 0;
}
