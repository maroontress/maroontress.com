/*
	$Id: ldcollect.c,v 1.1 2003/09/22 19:43:30 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <sys/types.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <err.h>
#ifdef linux
#include "db.h"
#else
#include <db.h>
#endif

#include "chunk.h"
#include "heap.h"

typedef enum {
    SUCCESS,
    UNEXPECTED_EOF,
    UNEXPECTED_CHUNK_TYPE,
    MALLOC_FAILED,
    ALLOCA_FAILED,
    DB_PUT_FAILED,
    DB_DEL_FAILED,
    DB_SEQ_FAILED,
    OVERLAP_CHUNK,
    JUNK_POINTER,
    CREATE_HEAP_CELL_FAILED,
    INSERT_HEAP_FAILED,
    CREATE_HEAP_FAILED
} Status;

static Status
putPointer(FILE *fp, DB *db, unsigned int seq)
{
    unsigned int ptr, len, count;
    int s;
    DBT key, val;
    Chunk *c;

    if (fread(&ptr, sizeof(int), 1, fp) < 1
	|| fread(&len, sizeof(int), 1, fp) < 1
	|| fread(&count, sizeof(int), 1, fp) < 1) {
	return UNEXPECTED_EOF;
    }
    if ((c = (Chunk *)alloca(CHUNK_SIZE(count))) == NULL) {
	return ALLOCA_FAILED;
    }
    c->seq = seq;
    c->ptr = ptr;
    c->len = len;
    c->count = count;
    if (fread(c->vma, sizeof(int), count, fp) != count)
	return UNEXPECTED_EOF;

    key.size = sizeof(ptr);
    key.data = &ptr;
    val.size = CHUNK_SIZE(count);
    val.data = c;
    if ((s = db->put(db, &key, &val, R_NOOVERWRITE)) < 0)
	return DB_PUT_FAILED;
    return (s == 1) ? OVERLAP_CHUNK : SUCCESS;
}

static Status
delPointer(FILE *fp, DB *db)
{
    int ptr, s;
    DBT key;

    if (fread(&ptr, sizeof(int), 1, fp) < 1)
	return UNEXPECTED_EOF;
    key.size = sizeof(ptr);
    key.data = &ptr;
    if ((s = db->del(db, &key, 0)) < 0)
	return DB_DEL_FAILED;
    return (s == 1) ? JUNK_POINTER : SUCCESS;
}

struct HeapCell {
    size_t size;
    char data[0];
};

static int
chunkComparator(HeapCell c1, HeapCell c2)
{
    unsigned int seq1 = ((Chunk *)c1->data)->seq;
    unsigned int seq2 = ((Chunk *)c2->data)->seq;

    return (int)(seq1 - seq2);
}

static HeapCell
createHeapCell(DBT *val)
{
    HeapCell c;

    if ((c = (HeapCell)malloc(sizeof(struct HeapCell) + val->size)) == NULL)
	return NULL;
    bcopy(val->data, c->data, val->size);
    c->size = val->size;
    return c;
}

static void
freeHeapCell(HeapCell c)
{
    free(c);
}
    
static Status
buildHeap(Heap *h, DB *db)
{
    DBT key, val;
    int s;
    HeapCell c;

    for (s = db->seq(db, &key, &val, R_FIRST); s == 0;
	 s = db->seq(db, &key, &val, R_NEXT)) {
	if ((c = createHeapCell(&val)) == NULL)
	    return CREATE_HEAP_CELL_FAILED;
	if (InsertIntoHeap(h, c)) {
	    freeHeapCell(c);
	    return INSERT_HEAP_FAILED;
	}
    }
    if (s < 0)
	return DB_SEQ_FAILED;
    while ((c = TakeMinOfHeap(h)) != NULL) {
	*(int *)(c->data) = CHUNK_ALLOCATED;
	fwrite(c->data, c->size, 1, stdout);
	freeHeapCell(c);
    }
    return SUCCESS;
}

static Status
dumpGarbages(DB *db)
{
    Heap *h;
    Status s;

    if ((h = CreateHeap(chunkComparator)) == NULL)
	return CREATE_HEAP_FAILED;
    s = buildHeap(h, db);
    ForEachOfHeap(h, freeHeapCell);
    FreeHeap(h);
    return (s);
}

static void
printError(Status s, char *target)
{
    switch (s) {
    case UNEXPECTED_EOF:
	errx(1, "%s: unexpected EOF", target);
	/* NOTREACHED */
    case UNEXPECTED_CHUNK_TYPE:
	errx(1, "%s: unexpected chunk type", target);
	/* NOTREACHED */
    case MALLOC_FAILED:
	errx(1, "malloc() failed (too short heap)");
	/* NOTREACHED */
    case ALLOCA_FAILED:
	errx(1, "alloca() failed (too short stack)");
	/* NOTREACHED */
    case DB_PUT_FAILED:
	errx(1, "put() of DB failed");
	/* NOTREACHED */
    case DB_DEL_FAILED:
	errx(1, "del() of DB failed");
	/* NOTREACHED */
    case DB_SEQ_FAILED:
	errx(1, "seq() of DB failed");
	/* NOTREACHED */
    case OVERLAP_CHUNK:
	errx(1, "%s: overlapped chunk detected", target);
	/* NOTREACHED */
    case JUNK_POINTER:
	errx(1, "%s: junk pointer made be free", target);
	/* NOTREACHED */
    case CREATE_HEAP_CELL_FAILED:
	errx(1, "CreateHeapCell() failed");
	/* NOTREACHED */
    case INSERT_HEAP_FAILED:
	errx(1, "InsertIntoHeap() failed");
	/* NOTREACHED */
    case CREATE_HEAP_FAILED:
	errx(1, "CreateHeap() failed");
	/* NOTREACHED */
    default:
	errx(1, "internal error (undefined status)");
	/* NOTREACHED */
    }
}

int
main(int ac, char **av)
{
    FILE *fp;
    DB *db;
    unsigned int seq, n;
    Status s;
    char *file;

    if (ac < 1 || ac > 2) {
	errx(1, "usage: %s [file]", av[0]);
    }
    if ((db = dbopen(NULL, O_RDWR, 0, DB_BTREE, NULL)) == NULL)
	errx(1, "dbopen() failed");

    if (ac == 1) {
	fp = stdin;
	file = "<stdin>";
    }
    else {
	if ((fp = fopen(av[1], "r")) == NULL)
	    err(1, "%s", av[1]);
	file = av[1];
    }
    for (seq = 0; fread(&n, sizeof(int), 1, fp) == 1; ++seq) {
	switch (n) {
	case CHUNK_ALLOCATED:
	    s = putPointer(fp, db, seq);
	    break;
	case CHUNK_RELEASED:
	    s = delPointer(fp, db);
	    break;
	default:
	    s = UNEXPECTED_CHUNK_TYPE;
	    break;
	}
	if (s != SUCCESS) {
	    printError(s, file);
	    /* NOTREACHED */
	}
    }
    fclose(fp);

    if ((s = dumpGarbages(db)) != SUCCESS) {
	printError(s, file);
	/* NOTREACHED */
    }
    db->close(db);
    return 0;
}
