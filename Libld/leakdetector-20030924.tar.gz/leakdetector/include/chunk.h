/*
	$Id: chunk.h,v 1.1 2003/09/22 19:43:29 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

typedef struct {
    unsigned int seq;
    unsigned int ptr;
    unsigned int len;
    unsigned int count;
    unsigned int vma[1];
} Chunk;

#define CHUNK_SIZE(x) (sizeof(Chunk) + ((x) - 1) * sizeof(int))
#define CHUNK_ALLOCATED 'a'
#define CHUNK_RELEASED 'f'
