#define MAX_NODE_NUM 1024

typedef char * Cell;
#define CellCmp(p, q) strcmp((char *)(p), (char *)(q))

typedef struct {
    int n_nodes;
    Cell node[MAX_NODE_NUM];
} Heap;

Heap * CreateHeap(void);
void Insert(Heap *h, Cell c);
Cell TakeMin(Heap *h);
#define Nodes(h) ((h)->n_nodes)
void FreeHeap(Heap *h);
