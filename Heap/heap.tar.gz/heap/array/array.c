#include <stdlib.h>
#include "heap.h"

#define Parent(n) (((n) - 1) / 2)
#define Left(n) (2 * (n) + 1)
#define Right(n) (2 * (n) + 2)

Heap *
CreateHeap(void)
{
    Heap *h;

    if ((h = (Heap *)malloc(sizeof(Heap))) != NULL)
	h->n_nodes = 0;
    return (h);
}

void
FreeHeap(Heap *h)
{
    free(h);
}

static int
MinChild(Heap *h, int n)
{
    if (h->n_nodes <= Left(n))
        return (0);
    else if (h->n_nodes == Right(n))
        return (Left(n));
    else if (CellCmp(h->node[Left(n)], h->node[Right(n)]) < 0)
        return (Left(n));
    return (Right(n));
}

void
Insert(Heap *h, Cell c)
{
    int n, m;

    h->node[h->n_nodes] = c; /* IP$B$X$NA^F~(B */
    for (n = h->n_nodes; (m = Parent(n)) < n
	     && CellCmp(h->node[n], h->node[m]) < 0; n = m) {
        c = h->node[n];
        h->node[n] = h->node[m];
        h->node[m] = c;
    }
    ++(h->n_nodes);
}

Cell
TakeMin(Heap *h)
{
    int n, m;
    Cell r = h->node[0], c;

    h->node[0] = h->node[h->n_nodes - 1]; /* LN$B$r:,$KBeF~(B */
    for (n = 0; (m = MinChild(h, n)) > 0
	     && CellCmp(h->node[n], h->node[m]) > 0; n = m) {
        c = h->node[n];
        h->node[n] = h->node[m];
        h->node[m] = c;
    }
    --(h->n_nodes);
    return (r);
}
