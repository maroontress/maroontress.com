#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "heap.h"

int
main(void)
{
    Heap *h;
    char **ptr, *str[] = {"hello", "world", "foo", "bar", "hoge", NULL};

    h = CreateHeap();

    for (ptr = str; *ptr != NULL; ++ptr)
	Insert(h, *ptr);

    while (Nodes(h) > 0)
	printf("%s\n", TakeMin(h));

    FreeHeap(h);
    exit(1);
    return (0);
}
