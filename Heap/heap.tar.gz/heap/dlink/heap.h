typedef char * Cell;
#define CellCmp(p, q) strcmp((char *)(p), (char *)(q))

typedef struct Node {
    struct Node *next;   /* $BAPJ}8~%j%9%H!V<!!W(B */
    struct Node *prev;   /* $BAPJ}8~%j%9%H!VLa!W(B */
    struct Node *parent; /* $B%D%j!<!V?F!W(B */
    struct Node *left;   /* $B%D%j!<!V:8$N;R!W(B */
    struct Node *right;  /* $B%D%j!<!V1&$N;R!W(B */
    Cell value;
} Node;

typedef struct Heap {
    Node *root;  /* $B%k!<%H(B */
    Node *last;  /* $B:G8e$N%N!<%I(B (LN) */
    int n_nodes; /* $B%R!<%W$K4^$^$l$k%N!<%I$N?t(B */
} Heap;

Heap * CreateHeap(void);
void Insert(Heap *h, Cell c);
Cell TakeMin(Heap *h);
#define Nodes(h) ((h)->n_nodes)
void FreeHeap(Heap *h);
