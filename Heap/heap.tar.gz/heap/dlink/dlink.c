#include <stdlib.h>
#include "heap.h"

static Node *
CreateNode(Cell c)
{
    Node *n;
    
    if ((n = (Node *)malloc(sizeof(Node))) == NULL)
        return (NULL);
    n->next = NULL;
    n->prev = NULL;
    n->parent = NULL;
    n->left = NULL;
    n->right = NULL;
    n->value = c;
    return (n);
}

static void
FreeNode(Node *n)
{
    free(n);
}

Heap *
CreateHeap(void)
{
    Heap *h;

    if ((h = (Heap *)malloc(sizeof(Heap))) == NULL)
	return (NULL);
    h->root = NULL;
    h->last = NULL;
    h->n_nodes = 0;
    return (h);
}

void
FreeHeap(Heap *h)
{
    Node *n, *next;
    
    for (n = h->root; n != NULL; n = next) {
	next = n->next;
	FreeNode(n);
    }
    free(h);
}

static int
Compare(Node *p, Node *q)
{
    return (CellCmp(p->value, q->value));
}

static void
Swap(Node *p, Node *q)
{
    Cell c;

    c = p->value;
    p->value = q->value;
    q->value = c;
}

static void
ReconfigureAtTail(Heap *h)
{
    Node *n, *p;

    for (n = h->last; (p = n->parent) != NULL && Compare(n, p) < 0; n = p)
	Swap(n, p);
}

static void
Add(Heap *h, Node *n)
{
    Node *parent = h->last->parent;

    if (parent == NULL) {
	/* LN$B$N?F$,(BNULL => LN$B$O%k!<%H(B,  IP$B$O%k!<%H$N:8$N;R(B */
	parent = h->root;
	parent->left = n;
    }
    else if (parent->right == NULL) {
	/* LN$B$N?F$N1&$N;R$,(BNULL => IP$B$N?F$O(BLN$B$N?F!J(BIP$B$O(BLN$B$H7;Do!K(B */
	parent->right = n;
    }
    else {
        /* LN$B$N?F$O;R$r(B2$B$D$b$D(B => IP$B$N?F$O(BLN$B$N?F$N!V<!!W$N%N!<%I(B */
	parent = parent->next;
	parent->left = n;
    }
    n->prev = h->last;
    n->parent = parent;
    h->last->next = n;
    h->last = n;
}

void
Insert(Heap *h, Cell c)
{
    Node *n;

    n = CreateNode(c);
    if (h->root == NULL) {
	h->root = n;
	h->last = n;
	h->n_nodes = 1;
	return;
    }
    Add(h, n);
    ReconfigureAtTail(h);
    ++(h->n_nodes);
}

static Node *
MinChild(Node *n)
{
    if (n->left == NULL)
	return (NULL);
    if (n->right == NULL || Compare(n->left, n->right) < 0)
	return (n->left);
    return (n->right);
}

static void
ReconfigureAtRoot(Heap *h)
{
    Node *n, *c;

    for (n = h->root; (c = MinChild(n)) != NULL && Compare(n, c) > 0; n = c)
	Swap(n, c);
}

static void
DeleteLast(Heap *h)
{
    Node *parent, *last;
    
    parent = h->last->parent;
    last = h->last->prev;
    if (parent == NULL) {
	/* LN$B$N?F$,(BNULL => LN$B$O%k!<%H(B */
	h->root = NULL;
	/* $B$3$N$H$-(B last == NULL */
    }
    else if (parent->right == h->last) {
	/* LN$B$N?F$N1&$N;R$,(BLN */
	parent->right = NULL;
	last->next = NULL;
    }
    else {
	/* LN$B$N?F$N:8$N;R$,(BLN */
	parent->left = NULL;
	last->next = NULL;
    }
    FreeNode(h->last);
    h->last = last;
    --(h->n_nodes);
}

Cell
TakeMin(Heap *h)
{
    Cell value;

    if (h->root == NULL)
	return (NULL);
    value = h->root->value;
    h->root->value = h->last->value;
    ReconfigureAtRoot(h);
    DeleteLast(h);
    return (value);
}
