typedef char * Cell;
#define CellCmp(p, q) strcmp((char *)(p), (char *)(q))

typedef struct SameHeightNodes {
    struct SameHeightNodes *next;
    struct SameHeightNodes *prev;
    int height;
    Cell *node; /* (1 << height)$B$NG[Ns$r3d$jEv$F$k(B */
} SameHeightNodes;

typedef struct Heap {
    SameHeightNodes *root;
    SameHeightNodes *last;
    int n_nodes; /* last$B$K4^$^$l$k%N!<%I$N?t(B */
} Heap;

Heap * CreateHeap(void);
void Insert(Heap *h, Cell c);
Cell TakeMin(Heap *h);
#define Nodes(h) ((1 << (h)->last->height) - 1 + (h)->n_nodes)
void FreeHeap(Heap *h);
