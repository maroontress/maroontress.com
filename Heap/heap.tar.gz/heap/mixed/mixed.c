#include <stdlib.h>
#include "heap.h"

#define Parent(n) ((n) / 2)
#define Left(n) (2 * (n))
#define Right(n) (2 * (n) + 1)

static SameHeightNodes *
CreateSameHeightNodes(int height)
{
    int n_nodes = (1 << height);
    SameHeightNodes *s;
    
    if ((s = (SameHeightNodes *)malloc(sizeof(SameHeightNodes))) == NULL)
        goto no_same_height_nodes;
    if ((s->node = (Cell *)malloc(sizeof(Cell) * n_nodes)) == NULL)
        goto no_node;
    s->next = NULL;
    s->prev = NULL;
    s->height = height;
    return (s);

no_node:
    free(s);
no_same_height_nodes:
    return (NULL);
}

static void
FreeSameHeightNodes(SameHeightNodes *s)
{
    free(s->node);
    free(s);
}

Heap *
CreateHeap(void)
{
    Heap *h;

    if ((h = (Heap *)malloc(sizeof(Heap))) == NULL)
	goto no_heap;
    if ((h->root = CreateSameHeightNodes(0)) == NULL)
	goto no_same_height_nodes;
    h->last = h->root;
    h->n_nodes = 0;
    return (h);

no_same_height_nodes:
    free(h);
no_heap:
    return (NULL);
}

void
FreeHeap(Heap *h)
{
    SameHeightNodes *s, *next;
    
    for (s = h->root; s != NULL; s = next) {
	next = s->next;
	FreeSameHeightNodes(s);
    }
    free(h);
}

void
Insert(Heap *h, Cell c)
{
    int n, m;
    SameHeightNodes *d, *e;
    
    if (h->n_nodes >= (1 << h->last->height)) {
        e = CreateSameHeightNodes(h->last->height + 1);
        e->prev = h->last;
        e->next = NULL;
        h->last->next = e;
        h->last = e;
        h->n_nodes = 0;
    }
    h->last->node[h->n_nodes] = c; /* IP$B$X$NA^F~(B */
    for (n = h->n_nodes, d = h->last; (e = d->prev) != NULL
	     && ((m = Parent(n)), CellCmp(d->node[n], e->node[m]) < 0);
             n = m, d = e) {
        c = d->node[n];
        d->node[n] = e->node[m];
        e->node[m] = c;
    }
    ++(h->n_nodes);
}

static int
MinChild(Heap *h, SameHeightNodes *d, int n)
{
    int total = (1 << h->last->height) - 1 + h->n_nodes;

    if ((d = d->next) == NULL || total <= (1 << d->height) - 1 + Left(n))
       return (-1);
    else if (total == (1 << d->height) - 1 + Right(n))
        return (Left(n));
    else if (CellCmp(d->node[Left(n)], d->node[Right(n)]) < 0)
        return (Left(n));
    return (Right(n));
}

Cell
TakeMin(Heap *h)
{
    int n, m;
    Cell r = h->root->node[0], c;
    SameHeightNodes *d, *e;

    h->root->node[0] = h->last->node[h->n_nodes - 1]; /* LN$B$r:,$KBeF~(B */
    for (n = 0, d = h->root; (m = MinChild(h, d, n)) >= 0
             && ((e = d->next), CellCmp(d->node[n], e->node[m]) > 0);
             n = m, d = e) {
        c = d->node[n];
        d->node[n] = e->node[m];
        e->node[m] = c;
    }
    if (--(h->n_nodes) <= 0 && h->last->prev != NULL) {
        e = h->last->prev;
        free(h->last);
        h->last = e;
        h->last->next = NULL;
        h->n_nodes = (1 << h->last->height);
    }
    return (r);
}
