package com.maroontress.uncover;

import com.maroontress.uncover.sqlite.SQLiteDB;

/**
   �ǥե���ȤΥġ��륭�åȤǤ���
*/
public final class DefaultToolkit extends Toolkit {
    /**
       ���󥹥��󥹤��������ޤ���
    */
    public DefaultToolkit() {
    }

    /**
       {@inheritDoc}
    */
    public DB createDB(final String subname) throws DBException {
	return new SQLiteDB(subname);
    }

    /**
       {@inheritDoc}
    */
    public Function createFunction(final FunctionSource source) {
	return new Function(source);
    }

    /**
       {@inheritDoc}
    */
    public Graph createGraph(final GraphSource source) {
	return new Graph(source);
    }

    /**
       {@inheritDoc}
    */
    public Block createBlock(final BlockSource source) {
	return new Block(source);
    }

    /**
       {@inheritDoc}
    */
    public Arc createArc(final ArcSource source) {
	return new Arc(source);
    }

    /**
       {@inheritDoc}
    */
    public Build createBuild(final BuildSource source) {
	return new Build(source);
    }
}
