static inline Vector
NewVector(double x, double y, double z)
{
    Vector r;

    r.x = x;
    r.y = y;
    r.z = z;
    return (r);
}

static inline Vector
AddVector(Vector p, Vector q)
{
    p.x += q.x;
    p.y += q.y;
    p.z += q.z;
    return (p);
}

static inline Vector
SubVector(Vector p, Vector q)
{
    p.x -= q.x;
    p.y -= q.y;
    p.z -= q.z;
    return (p);
}

static inline Vector
ShortVector(Vector p, double b)
{
    p.x /= b;
    p.y /= b;
    p.z /= b;
    return (p);
}

static inline Vector
LongVector(Vector p, double a)
{
    p.x *= a;
    p.y *= a;
    p.z *= a;
    return (p);
}

static inline double
DotProduct(Vector p, Vector q)
{
    return (p.x * q.x + p.y * q.y + p.z * q.z);
}

static inline Vector
CrossProduct(Vector a, Vector b)
{
    Vector r;

    r.x = a.y * b.z - b.y * a.z;
    r.y = a.z * b.x - b.z * a.x;
    r.z = a.x * b.y - b.x * a.y;
    return (r);
}

static inline double
SquareAbsVector(Vector p)
{
    return (p.x * p.x + p.y * p.y + p.z * p.z);
}

static inline double
AbsVector(Vector p)
{
    return (sqrt(p.x * p.x + p.y * p.y + p.z * p.z));
}
