#include <stdlib.h>
#include <stdio.h>

#include "VarWString.h"

static int
wstrlen(wchar_t *str)
{
    int n;
    
    for (n = 0; *str; ++n)
	++str;
    return (n);
}

static wchar_t *
wstrcpy(wchar_t *d, wchar_t *s)
{
    wchar_t *p = d;

    while ((*d = *s) != 0) {
	++d;
	++s;
    }
    return (p);
}

static wchar_t *
wstrncpy(wchar_t *d, wchar_t *s, int n)
{
    wchar_t *p = d;

    while ((*d = *s) != 0 && n > 0) {
	++d;
	++s;
	--n;
    }
    return (p);
}

SylVarWString *
CreateSylVarWStringFromWString(wchar_t *str)
{
    SylVarWString *var;
    
    if ((var = (SylVarWString *)malloc(sizeof(SylVarWString))) == NULL)
	return (NULL);
    var->length = wstrlen(str);
    if ((var->wstring = (wchar_t *)malloc((var->length + 1) * sizeof(wchar_t)))
	== NULL) {
	free(var);
	return (NULL);
    }
    wstrcpy(var->wstring, str);
    return (var);
}

SylVarWString *
CreateSylVarWStringFromString(char *mbs)
{
    SylVarWString *var;
    wchar_t *wcs;
    int mbs_len, wcs_len;

    mbs_len = strlen(mbs);
    if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * (mbs_len + 1))) == NULL
	/*
	   $BCm0U(B: $B4X?t(Bmbstowcs(wc_dst, mb_src, n_bytes)$B$N(B3$BHVL\$N0z?t$K$O!"(B
	   $B%L%kJ8;z$r4^$a$?%5%$%:$rM?$($J$$$H!":G8e$K!V%o%$%I%-%c%i%/%?(B
	   $BJ8;zNs$N%L%kJ8;z!W$rIU2C$7$J$$!#$D$^$j!"(B1$BHVL\$N0z?t$N%P%C%U%!(B
	   $B%5%$%:$rM?$($J$1$l$P$J$i$J$$!#(B
	*/
	|| (wcs_len = mbstowcs(wcs, mbs, mbs_len + 1)) < 0
	|| (var = (SylVarWString *)malloc(sizeof(SylVarWString))) == NULL) {
	return (NULL);
    }
    if ((var->wstring = (wchar_t *)malloc(sizeof(wchar_t) * (wcs_len + 1)))
	== NULL) {
	free(var);
	return (NULL);
    }
    wstrcpy(var->wstring, wcs);
    var->length = wcs_len;
    return (var);
}

void
FreeSylVarWString(SylVarWString *var)
{
    free(var->wstring);
    free(var);
}

wchar_t *
CreateWStringFromSylVarWString(SylVarWString *var, int bgn, int end)
{
    wchar_t *str;

    if ((str = (wchar_t *)malloc((end - bgn + 1) * sizeof(wchar_t))) == NULL)
	return (NULL);
    wstrncpy(str, var->wstring + bgn, end - bgn);
    str[end - bgn] = 0;
    return (str);
}

void
InsertCharIntoSylVarWString(SylVarWString *var, int n, wchar_t c)
{
    wchar_t *sum;
    int len;

    len = var->length + 1;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return;
    wstrncpy(sum, var->wstring, n);
    sum[n] = c;
    wstrcpy(sum + n + 1, var->wstring + n);
    free(var->wstring);
    var->wstring = sum;
    var->length = len;
}

void
InsertWStringIntoSylVarWString(SylVarWString *var, int n, wchar_t *p)
{
    while (*p) {
	InsertCharIntoSylVarWString(var, n, *p);
	++n;
	++p;
    }
}

void
DeleteWCharOfSylVarWString(SylVarWString *var, int n)
{
    wchar_t *sum;
    int len;

    if (var->length <= 0 || var->length <= n)
	return;
    len = var->length - 1;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return;
    wstrncpy(sum, var->wstring, n);
    if (var->wstring[n] != 0)
	wstrcpy(sum + n, var->wstring + n + 1);
    free(var->wstring);
    var->wstring = sum;
    var->length = len;
}

void
DeleteWStringOfSylVarWString(SylVarWString *var, int n, int m)
{
    for (m -= n; m > 0; --m) {
	DeleteWCharOfSylVarWString(var, n);
    }
}
