void open_xeijirou(Display *disp, int ac, char **av, int);
void send_xeijirou(Display *disp, XEvent *ev);
