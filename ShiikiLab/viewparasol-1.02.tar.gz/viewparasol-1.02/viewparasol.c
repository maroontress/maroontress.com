/*
       viewparasol.c 1.0 for X11R6 & GNU C Compiler

       Copyright (C) 1999 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "Menu.h"
#include "VarWString.h"
#include "TextLine.h"
#include "Button.h"
#include "HScrollbar.h"
#include "VScrollbar.h"
#include "property.h"
#include "dataset.h"
#include "filedialog.h"
#include "load.h"
#include "license.h"
#include "xeijirou.h"

char **GlobalAv;
int GlobalAc;

#ifndef min
#define min(a,b) (((a)>(b))?(b):(a))
#endif
#ifndef max
#define max(a,b) (((a)<(b))?(b):(a))
#endif

#define RC_FILE "/.viewparasolrc"

#define DEFAULT_RADIUS (16)
#define DEFAULT_COLOR_WHITE       "gray100"
#define DEFAULT_COLOR_LIGHT_GRAY  "gray85"
#define DEFAULT_COLOR_MEDIUM_GRAY "gray70"
#define DEFAULT_COLOR_DIM_GRAY    "gray50"
#define DEFAULT_COLOR_DARK_GRAY   "gray30"
#define DEFAULT_COLOR_BLACK       "gray0"
#define DEFAULT_COLOR_DARK_BLUE   "#00007f"
#define DEFAULT_COLOR_ILLUMINATED "#ffe0e0"

#define LABEL_WHITE       "White"
#define LABEL_LIGHT_GRAY  "LightGray"
#define LABEL_MEDIUM_GRAY "MediumGray"
#define LABEL_DIM_GRAY    "DimGray"
#define LABEL_DARK_GRAY   "DarkGray"
#define LABEL_BLACK       "Black"
#define LABEL_MARKING     "Marking"
#define LABEL_ILLUMINATED "Illuminated"

#define LABEL_MENU_FONT "MenuFont"
#define LABEL_BUTTON_FONT "ButtonFont"
#define DEFAULT_FONT_MENUBAR "-b&h-lucida-bold-r-normal-*-12-120-*"
#define DEFAULT_FONT_BUTTON "-adobe-helvetica-bold-r-normal-*-12-120-*"

static char *
CreatePathOfUserFile(char *rc)
{
    char *path, *home;

    home = getenv("HOME");
    if ((path = (char *)malloc(strlen(home) + strlen(rc) + 1)) != NULL)
        sprintf(path, "%s%s", home, rc);
    return (path);
}

static void
LoadColorset(Display *disp, ColorSet **cs, unsigned long *pm)
{
    Colormap cmap;
    XColor color;

    cmap = DefaultColormap(disp, DefaultScreen(disp));
    for (; *cs != NULL; ++cs) {
	if (XParseColor(disp, cmap, (*cs)->color, &color) == 0) {
	    fprintf(stderr, "%s: %s \"%s\" is not available.\n",
		    GlobalAv[0], (*cs)->name, (*cs)->color);
	    exit(1);
	}
	else if (XAllocColor(disp, cmap, &color) == 0) {
	    fprintf(stderr, "%s: no available color cell for %s.\n",
		    GlobalAv[0], (*cs)->name);
	    exit(1);
	}
	*pm++ = color.pixel;
    }
}

static void
LoadFontset(Display *disp, FontSet **fs)
{
    XFontStruct *info;

    for (; *fs != NULL; ++fs) {
        if ((info = XLoadQueryFont(disp, (*fs)->font)) != NULL) {
            (*fs)->id = info->fid;
            XFreeFontInfo(NULL, info, 1);
        }
        else{
            fprintf(stderr, "%s: %s \"%s\" is not available.\n",
                    GlobalAv[0], (*fs)->name, (*fs)->font);
            exit(1);
        }
    }
}

static int
AllocColormap(Display *disp, XColor *cells)
{
    Colormap cmap;
    int n, m;

    cmap = DefaultColormap(disp, DefaultScreen(disp));
    for (n = 0; n < 32; ++n) {
	m = n;
	cells[m].red = 0xffff;
	cells[m].green = (short)(((double)n / 32) * 0xffff);
	cells[m].blue = 0x0000;
	if (XAllocColor(disp, cmap, &cells[m]) == 0)
	    return (1);
    }
    for (n = 0; n < 32; ++n) {
	m = n + 32;
	cells[m].red = 0xffff - (short)(((double)n / 32) * 0xffff);
	cells[m].green = 0xffff;
	cells[m].blue = 0x0000;
	if (XAllocColor(disp, cmap, &cells[m]) == 0)
	    return (1);
    }
    for (n = 0; n < 16; ++n) {
	m = n + 64;
	cells[m].red = 0x0000;
	cells[m].green = 0xffff;
	cells[m].blue = (short)(((double)n / 16) * 0xffff);
	if (XAllocColor(disp, cmap, &cells[m]) == 0)
	    return (1);
    }
    for (n = 0; n < 16; ++n) {
	m = n + 80;
	cells[m].red = 0x0000;
	cells[m].green = 0xffff - (short)(((double)n / 16) * 0xffff);
	cells[m].blue = 0xffff;
	if (XAllocColor(disp, cmap, &cells[m]) == 0)
	    return (1);
    }
    for (n = 0; n <= 32; ++n) {
	m = n + 96;
	cells[m].red = (short)(((double)n / 32) * 0x7fff);
	cells[m].green = 0x0000;
	cells[m].blue = 0xffff - (short)(((double)n / 32) * 0x7fff);
	if (XAllocColor(disp, cmap, &cells[m]) == 0)
	    return (1);
    }
    return (0);
}

static Display *Disp;
static unsigned long MenuPixels[8];

static int MainPower = 1;
static FileDialog *PSDialog = NULL;
static FileDialog *EPSDialog = NULL;
static DataSet *Current;
static char *ViewFile;
static int ColorPrinting = 1;

static void
CloseWindow(void)
{
    MainPower = 0;
}

static void
OpenPSDialog(void)
{
#if 1
    char *file, *path;

    if (PSDialog != NULL)
	return;
    file = ((strcmp(ViewFile, "-") == 0) ? "stdin" : ViewFile);
    if ((path = alloca(strlen(file) + 4)) == NULL) {
	fprintf(stderr, "%s: too short stack.\n", GlobalAv[0]);
	return;
    }
    sprintf(path, "%s.ps", file);
    PSDialog = ReserveFileDialog(Disp, MenuPixels, path, "Print PS file");
#else
    char *file, resolvedname[MAXPATHLEN], path[MAXPATHLEN];

    if (PSDialog != NULL)
	return;
    file = ((strcmp(ViewFile, "-") == 0) ? "stdin" : ViewFile);
    if (realpath(file, resolvedname) == NULL)
	return;
    sprintf(path, "%s.ps", resolvedname);
    PSDialog = ReserveFileDialog(Disp, MenuPixels, path, "Print PS file");
#endif
}

static int
IsOpenedPSDialog(void)
{
    return (PSDialog != NULL);
}

static void
ClosePSDialog(void)
{
    FILE *fp;
    char *path;

    if (PSDialog == NULL)
	return;
    if ((path = PSDialog->filename) == NULL) {
	PutbackFileDialog(PSDialog);
	PSDialog = NULL;
	return;
    }
    if ((fp = fopen(path, "w")) == NULL) {
	perror(path);
	PutbackFileDialog(PSDialog);
	PSDialog = NULL;
	return;
    }
    PutbackFileDialog(PSDialog);
    PSDialog = NULL;
    if (ColorPrinting)
	PrintPSColorDataSet(Current, fp);
    else
	PrintPSDataSet(Current, fp);
    fclose(fp);
}

static void
OpenEPSDialog(void)
{
    char *file, *path;

    if (EPSDialog != NULL)
	return;
    file = ((strcmp(ViewFile, "-") == 0) ? "stdin" : ViewFile);
    if ((path = alloca(strlen(file) + 5)) == NULL) {
	fprintf(stderr, "%s: too short stack.\n", GlobalAv[0]);
	return;
    }
    sprintf(path, "%s.eps", file);
    EPSDialog = ReserveFileDialog(Disp, MenuPixels, path, "Print EPS file");
}

static int
IsOpenedEPSDialog(void)
{
    return (EPSDialog != NULL);
}

static void
CloseEPSDialog(void)
{
    FILE *fp;
    char *path;

    if (EPSDialog == NULL)
	return;
    if ((path = EPSDialog->filename) == NULL) {
	PutbackFileDialog(EPSDialog);
	EPSDialog = NULL;
	return;
    }
    if ((fp = fopen(path, "w")) == NULL) {
	perror(path);
	PutbackFileDialog(EPSDialog);
	EPSDialog = NULL;
	return;
    }
    PutbackFileDialog(EPSDialog);
    EPSDialog = NULL;
    if (ColorPrinting)
	PrintEPSColorDataSet(Current, fp);
    else
	PrintEPSDataSet(Current, fp);
    fclose(fp);
}

static void
ToggleColorPrinting(void)
{
    ColorPrinting = 1 - ColorPrinting;
}

static int
IsColorPrinting(void)
{
    return (ColorPrinting);
}

static ExecFunctionList ExecFunc[] = {
    {"PrintPS", OpenPSDialog, IsOpenedPSDialog},
    {"PrintEPS", OpenEPSDialog, IsOpenedEPSDialog},
    {"Quit", CloseWindow, NULL}};
#define EXEC_FUNC_N (sizeof(ExecFunc) / sizeof(ExecFunctionList))

static CheckFunctionList CheckFunc[] = {
    {"Color", ToggleColorPrinting, IsColorPrinting, NULL}};
#define CHECK_FUNC_N (sizeof(CheckFunc) / sizeof(CheckFunctionList))

static int ColorDirection = FromNorthToSouth;
static int ArrowRadius = DEFAULT_RADIUS;
static int UnitRadius = DEFAULT_RADIUS;

static ColorSet White = {LABEL_WHITE, DEFAULT_COLOR_WHITE};
static ColorSet LightGray = {LABEL_LIGHT_GRAY, DEFAULT_COLOR_LIGHT_GRAY};
static ColorSet MediumGray = {LABEL_MEDIUM_GRAY, DEFAULT_COLOR_MEDIUM_GRAY};
static ColorSet DimGray = {LABEL_DIM_GRAY, DEFAULT_COLOR_DIM_GRAY};
static ColorSet DarkGray = {LABEL_DARK_GRAY, DEFAULT_COLOR_DARK_GRAY};
static ColorSet Black = {LABEL_BLACK, DEFAULT_COLOR_BLACK};
static ColorSet Marking = {LABEL_MARKING, DEFAULT_COLOR_DARK_BLUE};
static ColorSet Illuminated = {LABEL_ILLUMINATED, DEFAULT_COLOR_ILLUMINATED};
static ColorSet *AllColors[] = {&White, &LightGray, &MediumGray, &DimGray,
    &DarkGray, &Black, &Marking, &Illuminated, NULL};

static FontSet MenuFont = {LABEL_MENU_FONT, DEFAULT_FONT_MENUBAR};
static FontSet ButtonFont = {LABEL_BUTTON_FONT, DEFAULT_FONT_BUTTON};
static FontSet *AllFonts[] = {&MenuFont, &ButtonFont, NULL}; 

static void
WindowMain(Display *disp, Window base, Window main, int dx, int dy, XEvent *ev)
{
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != base)
            break;
        XResizeWindow(disp, main, ev->xconfigure.width - dx,
            ev->xconfigure.height - dy);
        break;
    }
    if (PSDialog != NULL && SendFileDialog(PSDialog, ev))
	ClosePSDialog();
    if (EPSDialog != NULL && SendFileDialog(EPSDialog, ev))
	CloseEPSDialog();
}

static char **
ParseOption(int ac, char **av)
{
    int mag = 100;
    char **ptr;

    for (ptr = av + 1; ac > 2; ++ptr) {
	if (strcmp(*ptr, "-s") == 0) {
	    if ((UnitRadius = atoi(*++ptr)) <= 0) {
		fprintf(stderr, "%s: invalid size\n", av[0]);
		exit(1);
	    }
	    ac -= 2;
	}
	else if (strcmp(*ptr, "-m") == 0) {
	    if ((mag = atoi(*++ptr)) <= 0) {
		fprintf(stderr, "%s: invalid magnitude\n", av[0]);
		exit(1);
	    }
	    ac -= 2;
	}
	else if (strcmp(*ptr, "-h") == 0) {
	    ColorDirection = FromEastToWest;
	    --ac;
	}
	else {
	    fprintf(stderr, "%s: unknown option %s\n", av[0], *ptr);
	    break;
	}
    }
    if (ac != 2) {
	printf("usage: %s [-s <size>] [-m <magnitude>] [-h] file\n", av[0]);
	exit(1);
    }
    ArrowRadius = (int)((double)mag * UnitRadius / 100);
    return (ptr);
}

static void
LoadError(char *file)
{
    switch (LoadErrorCode) {
    case LOAD_PARSE_ERROR:
        fprintf(stderr, "%s: file %s, parse error `%s' at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_UNTERMINATED_STRING:
        fprintf(stderr, "%s: file %s, unterminated string at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>", LoadErrorLine);
        break;
    case LOAD_TOO_SHORT_MEMORY:
        fprintf(stderr, "%s: file %s, too short memory, while reading"
                "at %d line.\n", GlobalAv[0],
                (file != NULL) ? file : "<stdin>", LoadErrorLine);
            break;
    case LOAD_CANNOT_OPEN:
        fprintf(stderr, "%s: cannot open file %s.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>");
        break;
    case LOAD_UNKNOWN_FUNCTION:
        fprintf(stderr, "%s: file %s, unknown function `%s' at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_EMPTY:
        fprintf(stderr, "%s: no menu defined in file %s.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>");
        break;
    case LOAD_UNEXPECTED_EOF:
        fprintf(stderr, "%s: file %s, unexpected EOF at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>", LoadErrorLine);
        break;
    case LOAD_UNDEFINED_MENU:
        fprintf(stderr, "%s: file %s, undefined menu \"%s\" at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_NO_KEYSYM_ITEM:
        fprintf(stderr, "%s: file %s, undefined KeySym at %d line.\n",
                GlobalAv[0], (file != NULL) ? file : "<stdin>", LoadErrorLine);
        break;
    case LOAD_UNDEFINED_FONT:
        fprintf(stderr, "%s: file %s, undefined font item \"%s\" at "
                "%d line.\n", GlobalAv[0], (file != NULL) ? file : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_UNDEFINED_COLOR:
        fprintf(stderr, "%s: file %s, undefined color item \"%s\" at "
                "%d line.\n", GlobalAv[0], (file != NULL) ? file : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    }
}

void
main(int ac, char **av)
{
    XEvent ev;
    XColor ColorCells[128 + 1];
    DataSet *ds;
    int BaseWindowWidth, BaseWindowHeight;
    int MainWindowWidth, MainWindowHeight, MenubarHSep;
    char *path, *RcFile = RC_FILE, **ptr;
    Window BaseWindow, MainWindow;
    SylMenuList *allmenu, *ml;
    SylMenubar *mb;
    FontSet **fs = AllFonts;
    ColorSet **cs = AllColors;

    GlobalAc = ac;
    GlobalAv = av;
    ViewFile = *(ptr = ParseOption(ac, av));
    if ((Disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    if ((allmenu = CreateSylMenuList()) == NULL
        || (ml = CreateSylMenuList()) == NULL) {
        fprintf(stderr, "%s: too short memory.\n", av[0]);
        exit(1);
    }
    if ((path = CreatePathOfUserFile(RcFile)) == NULL) {
        fprintf(stderr, "%s: can't create path of config file.\n", av[0]);
        exit(1);
    }
    RegisterExecFunctions(ExecFunc, EXEC_FUNC_N);
    RegisterCheckFunctions(CheckFunc, CHECK_FUNC_N);
    if (LoadConfigFile(path, allmenu, ml, fs, cs) != EOF)
        LoadError(path);
    free(path);
    LoadFontset(Disp, fs);
    LoadColorset(Disp, cs, MenuPixels);
    if (AllocColormap(Disp, ColorCells))
        fprintf(stderr, "%s: cannot allocate all colors.\n", av[0]);
    ds = CreateDataSet(Disp, ColorCells, ColorDirection,
		       UnitRadius, ArrowRadius);
    Current = ds;
    LoadDataSet(ds, *ptr);
    open_xeijirou(Disp, ac, av, ShowLicense(ac, av));

    MenubarHSep = QuerySylMenubarHeight(Disp, MenuFont.id) + MENUBAR_SEP;
    BaseWindowWidth = max(min(ds->w, 640), (VSCBARSEP + VSCBARWIDTH) * 2);
    BaseWindowHeight = max(min(ds->h, 640), (HSCBARSEP + HSCBARHEIGHT) * 2)
        + MenubarHSep;
    BaseWindow = XCreateSimpleWindow(Disp, DefaultRootWindow(Disp), 0, 0,
        BaseWindowWidth, BaseWindowHeight, 1, MenuPixels[5], MenuPixels[2]);
    XSelectInput(Disp, BaseWindow, StructureNotifyMask | KeyPressMask);
    SetProperties(Disp, BaseWindow, (strcmp(*ptr, "-") ? *ptr : "stdin"),
	ac, av, 0, 0, (VSCBARSEP + VSCBARWIDTH) * 2,
        (HSCBARSEP + HSCBARHEIGHT) * 2 + MenubarHSep, 1, 1);
    XMapRaised(Disp, BaseWindow);

    MainWindowWidth = min(ds->w, 640);
    MainWindowHeight = min(ds->h, 640);
    MainWindow = XCreateSimpleWindow(Disp, BaseWindow, 0, MenubarHSep,
        MainWindowWidth, MainWindowHeight, 0, MenuPixels[5], MenuPixels[2]);
    XSelectInput(Disp, MainWindow, StructureNotifyMask);
    XMapRaised(Disp, MainWindow);

    ReserveDataSet(ds, MainWindow, MenuPixels);
    DrawDataSet(ds);
    mb = ReserveSylMenubar(Disp, BaseWindow, MenuPixels, None,
        MenuFont.id, ml);
    while (MainPower) {
        while (XEventsQueued(Disp, QueuedAfterReading) == 0
               && ((PSDialog && NiceFileDialog(PSDialog))
		   || (EPSDialog && NiceFileDialog(EPSDialog)))) {
            ;
        }
	XNextEvent(Disp, &ev);
	if (IsWMCloseMessage(&ev) && ev.xclient.window == BaseWindow)
	    break;
	SendDataSet(ds, &ev);
        SendSylMenubar(mb, &ev);
	send_xeijirou(Disp, &ev);
	WindowMain(Disp, BaseWindow, MainWindow, 0, MenubarHSep, &ev);
    }
    XDestroyWindow(Disp, BaseWindow);
    XCloseDisplay(Disp);
    exit(0);
}
