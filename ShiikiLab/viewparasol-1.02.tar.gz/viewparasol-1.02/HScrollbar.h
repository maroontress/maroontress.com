/*
       HScrollbar.h for X11R6 & GNU C Compiler

       Copyright (C) 1997 Syllabub
       Maroontress Fast Software.
*/

#define HSCBARSEP 2     /* window$B$H2#(Bscroll bar$B$N6-3&$N(Bpixel$B?t(B */
#define HSCBARHEIGHT 16 /* $B2#(Bscroll bar$B$N9b$5$N(Bpixel$B?t(B */
#define HSCBARVMIN 12   /* $B2#(Bscroll bar$B$N2#I}$N:G>.(Bpixel$B?t(B (2$B0J>e(B) */

typedef struct {
    Display * disp;
    Window parent;
    Window window;
    Window catch;
    Window bar;
    GC gc;
    Cursor cursor;
    unsigned long * pixels;
    int current;        /* ($BI=<(HO0O$N@hF,7e(B) - 1 */
    int maxcolumn;      /* $BAm7e?t(B */
    int width;          /* $BI=<(HO0O$N(Bpixel$B?t(B, $B2DJQ(B */
    int columns;        /* $BI=<(HO0O$N7e?t(B, $B2DJQ(B */
    int parcolumn;      /* 1$B9T$"$?$j$N(Bpixel$B?t(B, $B8GDj(B */
    int grabbed;        /* $B%9%/%m!<%k%P!<$,%I%i%C%0$5$l$F$$$l$P(BTrue */
    int orgx, orgy;     /* drag$B3+;O;~$N%k!<%H%&%#%s%I%&$KBP$9$k%]%$%s%H(B */
    int orgc;           /* (drag$B3+;O;~$NI=<(HO0O$N@hF,7e(B) - 1 */
    int orgp;           /* drag$B3+;O;~$N(Bcatch$B$N(Bbar$B$KBP$9$k(Bx$B:BI8(B */
    int button;         /* drag$B3+;O;~$K2!$5$l$F$$$?%\%?%s(B */
    void (*scroll)(int, int);
    void (*adjust)(int);
} SylHScrollbar;

/*
    Function:
        ReserveSylHScrollbar - $B2#J}8~$N%9%/%m!<%k%P!<$r3NJ]$9$k!#(B

    Synopsis:
        SylHScrollbar * ReserveSylHScrollbar(display, window, pixels,
            cursor, begin, columns, unit, scroll, adjust);
	Display *display;
        Window window;
	unsigned int * pixels; 
	Cursor cursor;
	int begin;
	int columns;
	int unit;
	void (* scroll)(int, int);
	void (* adjust)(int);
	
    Description:
        ReserveSylHScrollbar$B$O7eC10L$N%9%/%m!<%k=hM}$r=u$1$k!#M-8B$J@~2h(B
	$B:Q$_$N(BPixmap$B$rItJ,I=<($5$;$k$3$H$K$OIT8~$-$G$"$k!#$=$N>l9g$OB>$N(B
	$B5!9=$rMxMQ$7$?J}$,M-Mx$K$J$k!#(B

        display$B$O(BDisplay$B<1JL;R!#(Bwindow$B$O%9%/%m!<%k$NBP>]$H$J$k(BWindow$B<1JL(B
	$B;R!#(Bpixels$B$O%9%/%m!<%k%P!<$N@~2h$G3FIt$K;HMQ$9$k?'$r;XDj$9$kG[Ns!#(B
	cursor$B$O%9%/%m!<%k%P!<$,%I%i%C%0$5$l$F$$$k$H$-$K;HMQ$5$l$k%+!<%=(B
	$B%k$N(BCursor$B<1JL;R!#(Bbegin$B$OI=<(HO0O$N@hF,7e!#$?$@$7Bh(Bn$B7eL\$rI=<(HO(B
	$B0O$N@hF,7e$KI=<($9$k$?$a$K$O!"(Bbegin$B$K(Bn - 1$B$rBeF~$9$k!#(Bcolumns$B$O(B
	$BAm7e?t!#(Bunit$B$O(B1$B7e$"$?$j$N%T%/%;%k?t!#(B

	scroll$B$O%3!<%k%P%C%/4X?t$X$N%]%$%s%?!#(Bscroll(n)$B$G(Bn$B7e%9%/%m!<%k$9(B
	$B$k$h$&$K@_7W$7$F$"$kI,MW$,$"$k!#(Badjust$B$b%3!<%k%P%C%/4X?t$X$N%]%$(B
	$B%s%?!#(Badjust(n - 1)$B$G(Bn$B7eL\$,I=<(HO0O$N@hF,7e$KI=<($5$l$k$h$&$K@_(B
	$B7W$7$F$"$kI,MW$,$"$k!#(Bscroll$B$H(Badjust$B$O8F=PB&$+$iD>@\8F$s$G$O$J$i(B
	$B$J$$!#$=$l$>$l(BScroll$B!A(B, Jump$B!A$r8F$V$3$H!#$?$@$7!"(Bscroll$B$NFbIt$+(B
	$B$i(Badjust$B$r8F$V!"$^$?$O$=$N5U$r$9$k$3$H$O2DG=!#(B

	ReserveSylHScrollbar$B$O<:GT$9$k$H(BNULL$B$rJV$9!#(B

    See also:
        SendSylHScrollbar, PutbackSylHScrollbar, ScrollSylHScrollbar,
	JumpSylHScrollbar
*/
SylHScrollbar * ReserveSylHScrollbar(Display *, Window, unsigned long *,
    Cursor, int, int, int, void (*)(int, int), void (*)(int));
void SendSylHScrollbar(SylHScrollbar *, XEvent *);
void ScrollSylHScrollbar(SylHScrollbar *, int);
void JumpSylHScrollbar(SylHScrollbar *, int);
#define RewriteSylHScrollbar(x) JumpSylHScrollbar((x), (x)->current)
void RangeSylHScrollbar(SylHScrollbar *, int);
void PutbackSylHScrollbar(SylHScrollbar *);
