#define N_SEPARATIONS 16

typedef struct {
    double x, y, z;
} Vector;

typedef struct Data {
    int x, y;
    Vector v;
    double theta, phi;
    double color_theta;
    struct Data *next; /* NULL$B$J$i$P=*C<(B */
} Data;

typedef struct {
    Vector p[3];
    Vector normal;
} Triangle;

typedef struct {
    Vector p[N_SEPARATIONS];
    Vector normal;
} BottomPlate;

typedef struct {
    Vector p[2];
} ArrowTail;

typedef struct {
    Triangle tr[N_SEPARATIONS];
    BottomPlate bp;
    ArrowTail at;
} Parasol;

typedef struct {
    Display *disp;
    XColor *colors;
    Parasol org;
    Data *top;
    Data *last;

    int min_x;
    int min_y;
    int max_x;
    int max_y;

    Window parent;
    Window window;
    int width;
    int height;
    Pixmap pixmap;
    int w, h;
    GC gc;
    int radius;
    int unit;
    unsigned long *pixels;
    SylVScrollbar *vsb;
    SylHScrollbar *hsb;
    int offset_x;
    int offset_y;
    int direction; /* FromNorthToSouth, FromEastToWest (by $B$O$;$P(B) */
} DataSet;

#define FromNorthToSouth 0
#define FromEastToWest 1

DataSet * CreateDataSet(Display *, XColor *, int, int, int);
void LoadDataSet(DataSet *, char *);
void ReserveDataSet(DataSet *, Window, unsigned long *);
void SendDataSet(DataSet *, XEvent *);
void DrawDataSet(DataSet *);

void PrintPSDataSet(DataSet *, FILE *fp);
void PrintPSColorDataSet(DataSet *, FILE *fp);
void PrintEPSDataSet(DataSet *, FILE *fp);
void PrintEPSColorDataSet(DataSet *, FILE *fp);
