/*
        property.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include "property.h"

#define max(a, b) (((a) < (b)) ? (b) : (a))

static Atom WM_PROTOCOLS, WM_REQUEST[2], WM_DELETE_WINDOW, WM_TAKE_FOCUS;
static Window FocusWindow = PointerRoot;

void
SetProperties(Display *disp, Window base, char *title, int ac, char **av,
	      int maxw, int maxh, int minw, int minh, int incw, int inch)
{
    char *whoami = title;
    XWindowAttributes attrs;
    XSizeHints size;
    XClassHint class;
    XWMHints wm;

    XGetWindowAttributes(disp, base, &attrs);
    size.width = attrs.width;
    size.height = attrs.height;
    size.width_inc = incw;
    size.height_inc = inch;
    size.flags = PSize | PResizeInc;
    if (minw > 0 && minh > 0) {
	size.min_width = minw;
	size.min_height = minh; 
	size.flags |=  PMinSize;
    }
    if (maxw > 0 && maxh > 0) {
	size.max_width = max(maxw, minw);
	size.max_height = max(maxh, minh);
	size.flags |=  PMaxSize;
    }
    wm.flags = InputHint /* | XUrgencyHint */;
    wm.input = True;
    class.res_name = whoami;
    class.res_class = whoami;
    XmbSetWMProperties(disp, base, title, title,  av, ac, &size, &wm, &class);

    WM_PROTOCOLS = XInternAtom(disp, "WM_PROTOCOLS", False);
    WM_TAKE_FOCUS = XInternAtom(disp, "WM_TAKE_FOCUS", False);
    WM_DELETE_WINDOW = XInternAtom(disp, "WM_DELETE_WINDOW", False);
    WM_REQUEST[0] = WM_TAKE_FOCUS;
    WM_REQUEST[1] = WM_DELETE_WINDOW;
    XSetWMProtocols(disp, base, WM_REQUEST, 2);
}

int
IsWMCloseMessage(XEvent *ev)
{
    XWindowAttributes attr;

    if (ev->type == FocusIn) {
	if (ev->xfocus.detail != NotifyPointer)
	    FocusWindow = ev->xfocus.window;
        return (0);
    }
    if (ev->type == DestroyNotify) {
	if (ev->xdestroywindow.window == FocusWindow) {
	    FocusWindow = PointerRoot;
	}
        return (0);
    }
    if (ev->type == ClientMessage
	&& ev->xclient.message_type == WM_PROTOCOLS) {
	if (ev->xclient.data.l[0] == (signed)WM_DELETE_WINDOW)
	    return (1);
	if (ev->xclient.data.l[0] == (signed)WM_TAKE_FOCUS
	    && FocusWindow != PointerRoot) {
	    XGetWindowAttributes(ev->xclient.display, FocusWindow, &attr);
	    if (attr.map_state == IsViewable) {
		XSetInputFocus(ev->xclient.display, FocusWindow,
		    RevertToParent, ev->xclient.data.l[1]);
	    }
	}
    }
    return (0);
}
