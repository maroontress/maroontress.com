/*
        load.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997 Syllabub
        Maroontress Fast Software.
*/

#define LOAD_PARSE_ERROR 0
#define LOAD_UNTERMINATED_STRING 1
#define LOAD_TOO_SHORT_MEMORY 2
#define LOAD_CANNOT_OPEN 3
#define LOAD_UNKNOWN_FUNCTION 4
#define LOAD_EMPTY 5
#define LOAD_UNEXPECTED_EOF 6
#define LOAD_UNDEFINED_MENU 7
#define LOAD_NO_KEYSYM_ITEM 8
#define LOAD_UNDEFINED_FONT 9
#define LOAD_UNDEFINED_COLOR 10

extern int LoadErrorCode;
extern int LoadErrorLine;
extern char LoadErrorWord[];

typedef struct {
    char *func_name;
    void (*exec)(void);
    int (*is_grayout)(void);
} ExecFunctionList;

typedef struct {
    char *func_name;
    void (*toggle)(void);
    int (*is_checked)(void);
    int (*is_grayout)(void);
} CheckFunctionList;

typedef struct {
    char *name;
    char *font;
    Font id;
} FontSet;

typedef struct {
    char *name;
    char *color;
} ColorSet;

void RegisterExecFunctions(ExecFunctionList *, int);
void RegisterCheckFunctions(CheckFunctionList *, int);
int LoadConfigFile(char *, SylMenuList *, SylMenuList *,
		   FontSet **, ColorSet **);
