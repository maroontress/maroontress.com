/*
        Menu.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997 Syllabub
        Maroontress Fast Software.
 */

union SylMenuItem;

typedef struct {
    int type;
    char *name;
    char *sep;
    KeySym key;
    int state;
    union SylMenuItem *next;
    int (*is_grayout)(void);
} SylAnyItem;
typedef SylAnyItem SylNopItem;

typedef struct {
    int type;
    char *name;
    char *sep;
    KeySym key;
    int state;
    union SylMenuItem *next;
    int (*is_grayout)(void);

    void (*exec)(void);
} SylExecItem;

typedef struct {
    int type;
    char *name;
    char *sep;
    KeySym key;
    int state;
    union SylMenuItem *next;
    int (*is_grayout)(void);

    int (*is_checked)(void);
    void (*toggle)(void);
} SylCheckItem;

typedef union SylMenuItem {
    int type;
    SylAnyItem any_item;
    SylNopItem nop_item;
    SylExecItem exec_item;
    SylCheckItem check_item;
} SylMenuItem;

typedef struct SylMenu {
    char *name;
    SylMenuItem *top;
    SylMenuItem *last;
    struct SylMenu *next;
} SylMenu;

typedef struct SylMenuList {
    SylMenu *top;
    SylMenu *last;
} SylMenuList;

#define MENU_ITEM_SUCCESS 0
#define MENU_ITEM_NO_KEYSYM 1
#define MENU_ITEM_FAILURE 2

#define MENU_ITEM_NOP 0
#define MENU_ITEM_EXEC 1
#define MENU_ITEM_CHECK 2
#define MENU_ITEM_POPUP 3

#define MENU_ITEM_CHAR_HFILL '|'

SylMenuList * CreateSylMenuList(void);
SylMenu * CreateSylMenu(SylMenuList *, char *);
SylMenu * CopySylMenu(SylMenuList *, SylMenu *);
SylMenu * LookupSylMenu(SylMenuList *, char *);
int CreateSylNopItem(SylMenu *, char *);
int CreateSylExecItem(SylMenu *, char *, void (*)(void), int (*)(void));
int CreateSylCheckItem(SylMenu *, char *, void (*)(void), int (*)(void),
		       int (*)(void));

#define MENUBAR_SEP 2
#define MENUBAR_MENU_SEP 4
#define MENUBAR_MARGIN_W 8
#define MENUBAR_MARGIN_H 4
#define MENUBAR_RULE_H 2

typedef struct {
    Display * disp;
    Window parent;
    Window menubar;
    Window * inputs;
    Pixmap backup;
    XFontStruct * fontinfo;
    GC gc;
    Cursor cursor;
    unsigned long * pixels;
    SylMenuList *menu_list;
    int n_menus;
    int width, height;
    int ascent, descent;
    int baselineskip;
    int focus, pushed, grabbed;

    Window menuface;
    Window * item_inputs;
    Pixmap menuback;
    SylMenuItem *item_list;
    int n_items, item_width, item_height;
    int item_focus;
} SylMenubar;

SylMenubar * ReserveSylMenubar(Display *, Window, unsigned long *,
			       Cursor, Font, SylMenuList *);
void SendSylMenubar(SylMenubar *, XEvent *);
int QuerySylMenubarHeight(Display *, Font);
