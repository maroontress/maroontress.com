#include <sys/param.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "license.h"

#define MAGIC_COOKIE_INET 12345

int
ShowLicense(int ac, char **av)
{
    int s, c, n, ip[4];
    char buf[256], hostname[MAXHOSTNAMELEN], *ptr;
    struct hostent *hp;
    struct sockaddr_in ai;
    FILE *fp;

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
	perror("socket");
	exit(1);
    }
    ai.sin_family = AF_INET;
    ai.sin_port = htons(MAGIC_COOKIE_INET);
#if 0
    if ((hp = gethostbyname(LICENSE_SERVER)) == NULL) {
	fprintf(stderr, "%s: gethostbyname failed\n", av[0]);
	exit(1);
    }
    bcopy(hp->h_addr, &ai.sin_addr, hp->h_length);
#else
    for (c = 0, ptr = LICENSE_SERVER; ptr[c] != 0; ++c)
	buf[c] = (ptr[c] == '.') ? ' ' : ptr[c];
    buf[c] = 0;
    if (sscanf(buf, "%d %d %d %d", &ip[0], &ip[1], &ip[2], &ip[3]) != 4) {
	fprintf(stderr, "%s: invalid IP address\n", av[0]);
	exit(1);
    }
    ((unsigned char *)&ai.sin_addr)[0] = (unsigned char)ip[0];
    ((unsigned char *)&ai.sin_addr)[1] = (unsigned char)ip[1];
    ((unsigned char *)&ai.sin_addr)[2] = (unsigned char)ip[2];
    ((unsigned char *)&ai.sin_addr)[3] = (unsigned char)ip[3];
#endif
    bzero(&ai.sin_zero, 8);
    if (connect(s, (struct sockaddr *)&ai, sizeof(ai)) < 0) {
	perror("connect");
	exit(1);
    }
    if ((fp = fdopen(s, "r")) == NULL) {
	perror("fdopen");
	exit(1);
    }
    if (gethostname(hostname, MAXHOSTNAMELEN) < 0) {
	perror("gethostname");
	exit(1);
    }
    sprintf(buf, "%s %s %s@%s", PRODUCT_NAME, PRODUCT_VERSION,
	    getlogin(), hostname);
    if (send(s, buf, strlen(buf) + 1, 0) < 0) {
	perror("send");
	exit(1);
    }
    for (ptr = buf; (c = fgetc(fp)) != EOF; ++ptr)
	*ptr = (unsigned char)c;
    fclose(fp);
    return (atoi(buf));
}
