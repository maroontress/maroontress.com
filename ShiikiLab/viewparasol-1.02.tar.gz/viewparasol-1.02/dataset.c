/*
       dataset.c 1.0 for X11R6 & GNU C Compiler

       Copyright (C) 1999 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "HScrollbar.h"
#include "VScrollbar.h"
#include "dataset.h"
#include "InlineVector.h"

static Vector
RotatePoint(Vector u, double r, double theta, double phi)
{
    double costheta = cos(theta);
    double sintheta = sin(theta);
    double cosphi = cos(phi);
    double sinphi = sin(phi);
    Vector v, w;

    v.z = (u.z * costheta - u.x * sintheta);
    v.x = (u.z * sintheta + u.x * costheta);
    v.y = (u.y);
    w.x = r * (v.x * cosphi - v.y * sinphi);
    w.y = r * (v.x * sinphi + v.y * cosphi);
    w.z = r * (v.z);
    return (w);
}

static void
RotateParasol(Parasol *src, Parasol *dst,
	      int r, double theta, double phi, XPoint o)
{
    int k, n;
    Vector tmp;

    for (n = 0; n < N_SEPARATIONS; ++n) {
	for (k = 0; k < 3; ++k) {
	    tmp = RotatePoint(src->tr[n].p[k], r, theta, phi);
	    dst->tr[n].p[k].x = o.x + tmp.x;
	    dst->tr[n].p[k].y = o.y - tmp.y;
	    dst->tr[n].p[k].z = tmp.z;
	}	    
	dst->tr[n].normal = RotatePoint(src->tr[n].normal, r, theta, phi);
	tmp = RotatePoint(src->bp.p[n], r, theta, phi);
	dst->bp.p[n].x = o.x + tmp.x;
	dst->bp.p[n].y = o.y - tmp.y;
	dst->bp.p[n].z = tmp.z;
    }
    dst->bp.normal = RotatePoint(src->bp.normal, r, theta, phi);
    for (k = 0; k < 2; ++k) {
	tmp = RotatePoint(src->at.p[k], r, theta, phi);
	dst->at.p[k].x = o.x + tmp.x;
	dst->at.p[k].y = o.y - tmp.y;
	dst->at.p[k].z = tmp.z;
    }
}

static void
DrawTriangles(DataSet *ds, Parasol *cur, Vector s, unsigned int pixel)
{
    int n;
    XPoint xp[4];

    for (n = 0; n < N_SEPARATIONS; ++n) {
	if (DotProduct(cur->tr[n].normal, s) >= 0) {
	    xp[0].x = (short)(cur->tr[n].p[0].x);
	    xp[0].y = (short)(cur->tr[n].p[0].y);
	    xp[1].x = (short)(cur->tr[n].p[1].x);
	    xp[1].y = (short)(cur->tr[n].p[1].y);
	    xp[2].x = (short)(cur->tr[n].p[2].x);
	    xp[2].y = (short)(cur->tr[n].p[2].y);
	    xp[3].x = (short)(cur->tr[n].p[0].x);
	    xp[3].y = (short)(cur->tr[n].p[0].y);
	    XSetForeground(ds->disp, ds->gc, ds->pixels[0]);
	    XFillPolygon(ds->disp, ds->pixmap, ds->gc, xp, 4, Complex,
			 CoordModeOrigin);
	    XSetForeground(ds->disp, ds->gc, ds->colors[pixel].pixel);
	    XDrawLines(ds->disp, ds->pixmap, ds->gc, xp, 4,
		       CoordModeOrigin);
	}
    }
}

static void
DrawBottomPlate(DataSet *ds, Parasol *cur, unsigned int pixel)
{
    int n;
    XPoint xp[N_SEPARATIONS + 1];

    for (n = 0; n < N_SEPARATIONS; ++n) {
	xp[n].x = (short)(cur->bp.p[n].x);
	xp[n].y = (short)(cur->bp.p[n].y);
    }
    xp[n].x = (short)(cur->bp.p[0].x);
    xp[n].y = (short)(cur->bp.p[0].y);

    XSetForeground(ds->disp, ds->gc, ds->pixels[0]);
    XFillPolygon(ds->disp, ds->pixmap, ds->gc, xp, N_SEPARATIONS + 1, Complex,
		 CoordModeOrigin);
    XSetForeground(ds->disp, ds->gc, ds->colors[pixel].pixel);
    XDrawLines(ds->disp, ds->pixmap, ds->gc, xp, N_SEPARATIONS + 1,
	       CoordModeOrigin);
}

static void
DrawArrowTail(DataSet *ds, Parasol *cur, unsigned int pixel)
{
    XPoint xp[2];

    xp[0].x = (short)(cur->at.p[0].x);
    xp[0].y = (short)(cur->at.p[0].y);
    xp[1].x = (short)(cur->at.p[1].x);
    xp[1].y = (short)(cur->at.p[1].y);
    XSetForeground(ds->disp, ds->gc, ds->colors[pixel].pixel);
    XDrawLine(ds->disp, ds->pixmap, ds->gc, xp[0].x, xp[0].y,
	      xp[1].x, xp[1].y);
}

void
DrawDataSet(DataSet *ds)
{
    int pixel;
    Parasol cur;
    Vector sight = {0, 0, 1};
    Data *ptr;
    XPoint org;

    XSetForeground(ds->disp, ds->gc, ds->pixels[0]);
    XFillRectangle(ds->disp, ds->pixmap, ds->gc, 0, 0, ds->w, ds->h);

    for (ptr = ds->top; ptr != NULL; ptr = ptr->next) {
	org.x = (ptr->x - ds->min_x) * ds->unit * 2;
	org.y = ds->h - (ptr->y - ds->min_y) * ds->unit * 2;
	org.x += ds->unit;
	org.y -= ds->unit;
	pixel = (unsigned long)(ptr->color_theta * 128.0 / M_PI);
	RotateParasol(&ds->org, &cur, ds->radius, ptr->theta, ptr->phi, org);
	if (DotProduct(cur.bp.normal, sight) > 0) {
	    DrawTriangles(ds, &cur, sight, pixel);
	    DrawBottomPlate(ds, &cur, pixel);
	    DrawArrowTail(ds, &cur, pixel);
	}
	else {
	    DrawArrowTail(ds, &cur, pixel);
	    DrawTriangles(ds, &cur, sight, pixel);
	}
    }
    XCopyArea(ds->disp, ds->pixmap, ds->window, ds->gc,
        ds->offset_x, ds->offset_y, ds->w, ds->h, 0, 0);
}

static void
SetParasol(Parasol *p)
{
    int n;
    double s, t;
    Vector v0 = {0, 0, 1}, v1 = {0, 0, 0}, v2 = {0, 0, 0};

    for (n = 0; n < N_SEPARATIONS; ++n) {
	s = (double)n / 16 * 2 * M_PI;
	v1.x = cos(s);
	v1.y = sin(s);
	t = (double)(n + 1) / 16 * 2 * M_PI;
	v2.x = cos(t);
	v2.y = sin(t);
	p->tr[n].p[0] = v0;
	p->tr[n].p[1] = v1;
	p->tr[n].p[2] = v2;
	p->tr[n].normal = CrossProduct(SubVector(v2, v1), SubVector(v0, v1));
	p->bp.p[n] = v1;
    }
    p->bp.normal = NewVector(0, 0, -1);
    p->at.p[0] = NewVector(0, 0, 0);
    p->at.p[1] = NewVector(0, 0, -1);
}

DataSet *
CreateDataSet(Display *disp, XColor *colors, int dir, int unit, int radius)
{
    DataSet *ds;
    
    if (dir != FromNorthToSouth && dir != FromEastToWest)
	return (NULL);
    if ((ds = (DataSet *)malloc(sizeof(DataSet))) == NULL)
        return (NULL);
    ds->top = NULL;
    ds->last = NULL;
    ds->disp = disp;
    ds->colors = colors;
    ds->direction = dir;
    ds->unit = unit;
    ds->radius = radius;
    SetParasol(&(ds->org));
    return (ds);
}


static Data *
CopyDataSet(DataSet *ds, int x, int y, double vx, double vy, double vz)
{
    Data *copy;
    Vector xy_proj, z_axis = {0, 0, 1}, x_axis = {1, 0, 0}, y_axis = {0, 1, 0};
    double len;
    /*double theta, phi;*/

    if ((copy = (Data *)malloc(sizeof(Data))) == NULL)
        return (NULL);
    copy->x = x;
    copy->y = y;
    copy->v = NewVector(vx, vy, vz);
    copy->theta = acos(DotProduct(z_axis, copy->v) / AbsVector(copy->v));
    xy_proj = NewVector(vx, vy, 0);
    if ((len = AbsVector(xy_proj)) < DBL_EPSILON * 10)
	copy->phi = 0; /* any */
    else
	copy->phi = acos(DotProduct(x_axis, xy_proj) / len);
    if (vy < 0)
	copy->phi = -copy->phi;

    if (ds->direction == FromNorthToSouth) {
	double st = (len < DBL_EPSILON * 10)
	    ? 0 : DotProduct(y_axis, xy_proj) / len;
	copy->color_theta = fabs(acos(st));
    }
    else if (ds->direction == FromEastToWest)
	copy->color_theta = fabs(copy->phi); /* [0, pi] */

    copy->next = NULL;
    if (ds->top == NULL)
        ds->top = copy;
    else
        ds->last->next = copy;
    ds->last = copy;
    return (copy);
}

static void
LookupSize(Data *p, int *min_x, int *min_y, int *max_x, int *max_y)
{
    *min_x = p->x;
    *min_y = p->y;
    *max_x = p->x;
    *max_y = p->y;
    for (p = p->next; p != NULL; p = p->next) {
	if (p->x > *max_x)
	    *max_x = p->x;
	else if (p->x < *min_x)
	    *min_x = p->x;

	if (p->y > *max_y)
            *max_y = p->y;
	else if (p->y < *min_y)
            *min_y = p->y;
    }
}

void
LoadDataSet(DataSet *ds, char *file)
{
    FILE *fp;
    int n, x, y;
    double vx, vy, vz;

    if (strcmp(file, "-") == 0) {
	fp = stdin;
	file = "stdin";
    }
    else if ((fp = fopen(file, "r")) == NULL) {
	perror(file);
	exit(1);
    }
    while ((n = fscanf(fp, "%d %d %lf %lf %lf", &x, &y, &vx, &vy, &vz)) == 5) {
	if (AbsVector(NewVector(vx, vy, vz)) < DBL_EPSILON) {
	    fprintf(stderr, "%s: warning: zero-length vector "
		    "at (%d %d)\n", file, x, y);
	}
	else if (CopyDataSet(ds, x, y, vx, vy, vz) == NULL) {
	    fprintf(stderr, "%s: too short memory\n", file);
	    exit(1);
	}
    }
    if (n >= 0) {
	printf("%d\n", n);
	fprintf(stderr, "%s: invalid data alignment\n", file);
	exit(1);
    }
    if (ds->top == NULL) {
	fprintf(stderr, "%s: empty data\n", file);
	exit(1);
    }
    LookupSize(ds->top, &ds->min_x, &ds->min_y, &ds->max_x, &ds->max_y);
    ds->w = (ds->max_x - ds->min_x + 1) * ds->unit * 2;
    ds->h = (ds->max_y - ds->min_y + 1) * ds->unit * 2;
}

static Cursor
CreateNullCursor(Display *disp)
{
    static unsigned char bit[] = {
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    Pixmap p;
    XColor exact, white;
    Colormap cmap;
    Cursor c;

    cmap = DefaultColormap(disp, DefaultScreen(disp));
    XAllocNamedColor(disp, cmap, "white", &exact, &white);
    p = XCreateBitmapFromData(disp, DefaultRootWindow(disp), bit, 16, 16);
    c = XCreatePixmapCursor(disp, p, p, &white, &white, 0, 0);
    XFreePixmap(disp, p);
    return (c);
}

static int
WidthOfWindow(int w, int h, int dw, int dh)
{
    if (w >= dw)
        return ((h >= dh) ? (w) : (w - VSCBARSEP - VSCBARWIDTH));
    else
	return ((h >= dh + HSCBARSEP + HSCBARHEIGHT) ?
		(w) : (w - VSCBARSEP - VSCBARWIDTH));
}

static int
HeightOfWindow(int w, int h, int dw, int dh)
{
    if (h >= dh)
        return ((w >= dw) ? (h) : (h - HSCBARSEP - HSCBARHEIGHT));
    else
        return ((w >= dw + VSCBARSEP + VSCBARWIDTH) ?
		(h) : (h - HSCBARSEP - HSCBARHEIGHT));
}

static void
GetWindowLocationAndSize(DataSet *ds, int *x, int *y, int *w, int *h)
{
    int margin, head, tail;
    XWindowAttributes atrs;

    XGetWindowAttributes(ds->disp, ds->parent, &atrs);
    *w = WidthOfWindow(atrs.width, atrs.height, ds->w, ds->h);
    *h = HeightOfWindow(atrs.width, atrs.height, ds->w, ds->h);
    if (*w >= ds->w && *h >= ds->h) {
	*x = (atrs.width - ds->w) / 2;
	*y = (atrs.height - ds->h) / 2;
    }
    else if (*w >= ds->w) {
	margin = (atrs.width - ds->w - VSCBARSEP - VSCBARWIDTH);
	head = margin / 2;
	tail = margin - head;
	*x = head;
	*w -= tail;
	*y = 0;
    }
    else if (*h >= ds->h) {
	margin = (atrs.height - ds->h - HSCBARSEP - HSCBARHEIGHT);
	head = margin / 2;
	tail = margin - head;
	*x = 0;
	*y = head;
	*h -= tail;
    }
    else {
	*x = 0;
	*y = 0;
    }
    ds->width = *w;
    ds->height = *h;
}

static DataSet *callback_ds = NULL;

static void
vadjustcallback(int n)
{
    callback_ds->offset_y = n;
    XCopyArea(callback_ds->disp, callback_ds->pixmap, callback_ds->window,
        callback_ds->gc, callback_ds->offset_x, callback_ds->offset_y,
        callback_ds->width, callback_ds->height, 0, 0);
}

static void
vscrollcallback(int n, int m)
{
    vadjustcallback(n + m);
}

static void
hadjustcallback(int n)
{
    callback_ds->offset_x = n;
    XCopyArea(callback_ds->disp, callback_ds->pixmap, callback_ds->window,
        callback_ds->gc, callback_ds->offset_x, callback_ds->offset_y,
        callback_ds->width, callback_ds->height, 0, 0);
}

static void
hscrollcallback(int n, int m)
{
    hadjustcallback(n + m);
}

void
ReserveDataSet(DataSet *ds, Window parent, unsigned long *pixels)
{
    int x, y, w, h;
    Cursor unvisible;

    ds->parent = parent;
    ds->pixels = pixels;
    ds->gc = XCreateGC(ds->disp, parent, 0, NULL);
    ds->pixmap = XCreatePixmap(ds->disp, DefaultRootWindow(ds->disp),
	ds->w, ds->h, DefaultDepth(ds->disp, DefaultScreen(ds->disp)));
    GetWindowLocationAndSize(ds, &x, &y, &w, &h);
    ds->window = XCreateSimpleWindow(ds->disp, ds->parent, x, y,
	w, h, 0, pixels[5], pixels[2]);
    XSelectInput(ds->disp, ds->window, ExposureMask | StructureNotifyMask);
    XMapRaised(ds->disp, ds->window);
    unvisible = CreateNullCursor(ds->disp);
    ds->offset_x = 0;
    ds->offset_y = 0;
    ds->vsb = ReserveSylVScrollbar(ds->disp, ds->window, pixels, unvisible,
	ds->offset_x, ds->h, 1, vscrollcallback, vadjustcallback);
    ds->hsb = ReserveSylHScrollbar(ds->disp, ds->window, pixels, unvisible,
	ds->offset_y, ds->w, 1, hscrollcallback, hadjustcallback);
}

void
SendDataSet(DataSet *ds, XEvent *ev)
{
    int x, y, w, h;

    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != ds->window)
	    break;
 	XCopyArea(ds->disp, ds->pixmap, ds->window, ds->gc,
	    ds->offset_x + ev->xexpose.x, ds->offset_y + ev->xexpose.y, 
	    ev->xexpose.width, ev->xexpose.height,
            ev->xexpose.x, ev->xexpose.y);
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != ds->parent)
	    break;
	GetWindowLocationAndSize(ds, &x, &y, &w, &h);
	XMoveResizeWindow(ds->disp, ds->window, x, y, w, h);
	break;
    }
    callback_ds = ds;
    SendSylVScrollbar(ds->vsb, ev);
    SendSylHScrollbar(ds->hsb, ev);
}

static void
PrintPSHeader(double tx, double ty, double sw, double sh, FILE *fp)
{
    fprintf(fp,
	    "%%!\n"
	    "%%%%BoundingBox: %f %f %f %f\n"
	    "%%%%EndComments\n",
	    tx, ty, tx + sw, ty + sh);
    fprintf(fp,
	    "\n"
	    "/fillPath {\n"
	    "\t" "gsave\n"
	    "\t\t" "1 setgray fill\n"
	    "\t" "grestore\n"
	    "\t" "stroke\n"
	    "} def\n");
}

static void
PrintPSColorHeader(double tx, double ty, double sw, double sh, FILE *fp)
{
    fprintf(fp,
	    "%%!\n"
	    "%%%%BoundingBox: %f %f %f %f\n"
	    "%%%%EndComments\n",
	    tx, ty, tx + sw, ty + sh);
    fprintf(fp,
	    "\n"
	    "/fillPath {\n"
	    "\t" "gsave\n"
	    "\t\t" "1 1 1 setrgbcolor fill\n"
	    "\t" "grestore\n"
	    "\t" "stroke\n"
	    "} def\n");
}

static void
PrintTrail(FILE *fp)
{
}

static void
PSRotateParasol(Parasol *src, Parasol *dst, int r, double theta, double phi)
{
    int k, n;

    for (n = 0; n < N_SEPARATIONS; ++n) {
	for (k = 0; k < 3; ++k)
	    dst->tr[n].p[k] = RotatePoint(src->tr[n].p[k], r, theta, phi);
	dst->tr[n].normal = RotatePoint(src->tr[n].normal, r, theta, phi);
	dst->bp.p[n] = RotatePoint(src->bp.p[n], r, theta, phi);
    }
    dst->bp.normal = RotatePoint(src->bp.normal, r, theta, phi);
    for (k = 0; k < 2; ++k)
	dst->at.p[k] = RotatePoint(src->at.p[k], r, theta, phi);
}

static void
PSDrawTriangles(FILE *fp, Parasol *cur, Vector s)
{
    int n;

    for (n = 0; n < N_SEPARATIONS; ++n) {
	if (DotProduct(cur->tr[n].normal, s) >= 0) {
	    fprintf(fp,
		    "\tnewpath\n"
		    "\t%f %f moveto\n"
		    "\t%f %f lineto\n"
		    "\t%f %f lineto\n"
		    "\tclosepath\n"
		    "\tfillPath\n",
		    cur->tr[n].p[0].x, cur->tr[n].p[0].y,
		    cur->tr[n].p[1].x, cur->tr[n].p[1].y,
		    cur->tr[n].p[2].x, cur->tr[n].p[2].y);
	}
    }
}

static void
PSDrawBottomPlate(FILE *fp, Parasol *cur)
{
    int n;

    fprintf(fp,
	    "\tnewpath\n"
	    "\t%f %f moveto\n", cur->bp.p[0].x, cur->bp.p[0].y);
    for (n = 1; n < N_SEPARATIONS; ++n) {
	fprintf(fp,
		"\t%f %f lineto\n", cur->bp.p[n].x, cur->bp.p[n].y);
    }
    fprintf(fp,
	    "\tclosepath\n"
	    "\tfillPath\n");
}

static void
PSDrawArrowTail(FILE *fp, Parasol *cur)
{
    fprintf(fp,
	    "\tnewpath\n"
	    "\t%f %f moveto\n"
	    "\t%f %f lineto\n"
	    "\tclosepath\n"
	    "\tfillPath\n",
	    cur->at.p[0].x, cur->at.p[0].y,
	    cur->at.p[1].x, cur->at.p[1].y);
}

void
PrintEPSDataSet(DataSet *ds, FILE *fp)
{
    int x, y;
    double tx, ty, sw, sh, scale;
    Data *ptr;
    Vector sight = {0, 0, 1};
    Parasol cur;
    
    if (ds->w > ds->h) {
	scale = 432.0 / ds->w;
	sw = 432.0;
	sh = scale * ds->h;
    }
    else {
	scale = 432.0 / ds->h;
	sw = scale * ds->w;
	sh = 432.0;
    }
    tx = (598.0 - sw) / 2;
    ty = (842.0 - sh) / 2;
    
    PrintPSHeader(tx, ty, sw, sh, fp);
    fprintf(fp,
	    "\n"
	    "%f %f translate %f %f scale\n"
	    "0 setgray 1 setlinewidth 1 setlinejoin\n",
	    tx, ty, scale, scale);
    PrintTrail(fp);
    for (ptr = ds->top; ptr != NULL; ptr = ptr->next) {
	x = (ptr->x - ds->min_x) * ds->unit * 2 + ds->unit;
	y = (ptr->y - ds->min_y) * ds->unit * 2 + ds->unit;
	fprintf(fp,
		"\n"
		"gsave\n"
		"\t" "%d %d translate\n", x, y);
	PSRotateParasol(&ds->org, &cur, ds->radius, ptr->theta, ptr->phi);
	if (DotProduct(cur.bp.normal, sight) > 0) {
	    PSDrawTriangles(fp, &cur, sight);
	    PSDrawBottomPlate(fp, &cur);
	    PSDrawArrowTail(fp, &cur);
	}
	else {
	    PSDrawArrowTail(fp, &cur);
	    PSDrawTriangles(fp, &cur, sight);
	}
	fprintf(fp,
		"grestore\n");
    }
    PrintTrail(fp);
}

void
PrintEPSColorDataSet(DataSet *ds, FILE *fp)
{
    int x, y;
    double tx, ty, sw, sh, scale;
    Data *ptr;
    Vector sight = {0, 0, 1};
    Parasol cur;
    unsigned long pixel;

    if (ds->w > ds->h) {
	scale = 432.0 / ds->w;
	sw = 432.0;
	sh = scale * ds->h;
    }
    else {
	scale = 432.0 / ds->h;
	sw = scale * ds->w;
	sh = 432.0;
    }
    tx = (598.0 - sw) / 2;
    ty = (842.0 - sh) / 2;

    PrintPSColorHeader(tx, ty, sw, sh, fp);
    fprintf(fp,
	    "\n"
	    "%f %f translate %f %f scale\n"
	    "1 setgray 1 setlinewidth 1 setlinejoin\n",
	    tx, ty, scale, scale);
    PrintTrail(fp);
    for (ptr = ds->top; ptr != NULL; ptr = ptr->next) {
	x = (ptr->x - ds->min_x) * ds->unit * 2 + ds->unit;
	y = (ptr->y - ds->min_y) * ds->unit * 2 + ds->unit;
	pixel = (unsigned long)(ptr->color_theta * 128.0 / M_PI);
	fprintf(fp,
		"\n"
		"gsave\n"
		"\t" "%d %d translate\n", x, y);
	fprintf(fp, "\t%f %f %f setrgbcolor\n",
		(double)ds->colors[pixel].red / 65535,
		(double)ds->colors[pixel].green / 65535,
		(double)ds->colors[pixel].blue / 65535);
	PSRotateParasol(&ds->org, &cur, ds->radius, ptr->theta, ptr->phi);
	if (DotProduct(cur.bp.normal, sight) > 0) {
	    PSDrawTriangles(fp, &cur, sight);
	    PSDrawBottomPlate(fp, &cur);
	    PSDrawArrowTail(fp, &cur);
	}
	else {
	    PSDrawArrowTail(fp, &cur);
	    PSDrawTriangles(fp, &cur, sight);
	}
	fprintf(fp,
		"grestore\n");
    }
    PrintTrail(fp);
}

void
PrintPSDataSet(DataSet *ds, FILE *fp)
{
    PrintEPSDataSet(ds, fp);
    fprintf(fp, "\n"
            "showpage\n"
            "quit\n");
}

void
PrintPSColorDataSet(DataSet *ds, FILE *fp)
{
    PrintEPSColorDataSet(ds, fp);
    fprintf(fp, "\n"
            "showpage\n"
            "quit\n");
}
