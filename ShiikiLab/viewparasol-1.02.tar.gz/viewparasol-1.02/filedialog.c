/*
       filedialog.c 1.0 for X11R6 & GNU C Compiler

       Copyright (C) 1997 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "Button.h"
#include "VarWString.h"
#include "TextLine.h"
#include "VScrollbar.h"
#include "HScrollbar.h"
#include "property.h"
#include "dataset.h"
#include "filedialog.h"

#define DEFAULT_WIDTH 400
#define CONSOLE_HEIGHT 20
#define FONTSET "-*-lucida-medium-r-normal-*-14-*-*-*-*-*-iso8859-1"

static XFontSet
CreateFontset(Display *disp, char *fontlist, int *w, int *h)
{
    XFontSet fs;
    int n_missings, n_fontinfos;
    char **missing, *alternation, **fontname;
    XFontStruct **fontinfo;

    fs = XCreateFontSet(disp, fontlist, &missing, &n_missings, &alternation);
    if (n_missings > 0) {
        XFreeStringList(missing);
        return (None);
    }
    if ((n_fontinfos = XFontsOfFontSet(fs, &fontinfo, &fontname)) < 1) {
        XFreeFontSet(disp, fs);
        return (None);
    }
    *w = abs(XmbTextEscapement(fs, " ", 1));
    *h = fontinfo[0]->ascent + fontinfo[0]->descent;
    return (fs);
}

FileDialog *
ReserveFileDialog(Display *disp, unsigned long *pixels, char *default_file,
		  char *title)
{
    int font_w, font_h;
    char *av[] = {"FileDialog", NULL};
    XFontSet fs;
    FileDialog *pp;

    if ((pp = (FileDialog *)malloc(sizeof(FileDialog))) == NULL)
	return (NULL);
    if ((fs = CreateFontset(disp, FONTSET, &font_w, &font_h)) == None) {
	free(pp);
	return (NULL);
    }
    pp->disp = disp;
    pp->pixels = pixels;
    pp->width = DEFAULT_WIDTH;
    pp->height = font_h * 2 + CONSOLE_HEIGHT;
    pp->base = XCreateSimpleWindow(pp->disp, DefaultRootWindow(pp->disp),
        0, 0, pp->width, pp->height, 1, pp->pixels[5], pp->pixels[2]);
    SetProperties(pp->disp, pp->base, title, 1, av, 0, 0, 154, CONSOLE_HEIGHT,
        1, 1);
    XSelectInput(pp->disp, pp->base, StructureNotifyMask);
    XMapRaised(pp->disp, pp->base);

    pp->main = XCreateSimpleWindow(pp->disp, pp->base,
        0, 0,
        pp->width, pp->height - CONSOLE_HEIGHT,
        0, pp->pixels[5], pp->pixels[2]);
    XSelectInput(pp->disp, pp->main, StructureNotifyMask);
    XMapRaised(pp->disp, pp->main);

    pp->console = XCreateSimpleWindow(pp->disp, pp->base,
        0, pp->height - CONSOLE_HEIGHT,
	pp->width, CONSOLE_HEIGHT,
        0, pp->pixels[5], pp->pixels[2]);
    XMapRaised(pp->disp, pp->console);

    if ((pp->field = CreateSylTextLine(disp, NULL, pp->main, fs, pixels,
	default_file, TEXT_CURSOR_BOTTOM, NULL)) == NULL) {
	free(pp);
	XDestroyWindow(disp, pp->base);
	return (NULL);
    }

    pp->okay.x = 0;
    pp->okay.y = 0;
    pp->okay.format = ButtonLabelLeft;
    pp->okay.str = " Ok ";
    ReserveSylButton(pp->disp, pp->console, XLoadFont(pp->disp, "variable"),
	CopyFromParent, pp->pixels, &pp->okay);

    pp->clear.x = 45;
    pp->clear.y = 0;
    pp->clear.format = ButtonLabelLeft;
    pp->clear.str = "Clear";
    ReserveSylButton(pp->disp, pp->console, XLoadFont(pp->disp, "variable"),
	CopyFromParent, pp->pixels, &pp->clear);

    pp->cancel.x = 95;
    pp->cancel.y = 0;
    pp->cancel.format = ButtonLabelLeft;
    pp->cancel.str = "Cancel";
    ReserveSylButton(pp->disp, pp->console, XLoadFont(pp->disp, "variable"),
	CopyFromParent, pp->pixels, &pp->cancel);

    pp->filename = NULL;
    return (pp);
}

void
PutbackFileDialog(FileDialog *pp)
{
    if (pp->filename != NULL)
	free(pp->filename);
    FreeSylTextLine(pp->field);
    PutbackSylButton(&pp->okay);
    PutbackSylButton(&pp->clear);
    PutbackSylButton(&pp->cancel);
    XDestroyWindow(pp->disp, pp->base);
    free(pp);
}

int
SendFileDialog(FileDialog *pp, XEvent *ev)
{
    if (pp->filename != NULL)
	free(pp->filename);
    if (IsWMCloseMessage(ev) && ev->xclient.window == pp->base)
	return (1);
    if (SendSylButton(&pp->cancel, ev))
	return (1);
    if (SendSylButton(&pp->clear, ev)) {
	ClearSylTextLine(pp->field);
	return (0);
    }
    if (SendSylButton(&pp->okay, ev)) {
	pp->filename = CreateStringFromSylTextLine(pp->field);
	return (1);
    }
    SendSylTextLine(pp->field, ev);
    if (ev->type == ConfigureNotify && ev->xconfigure.window == pp->base) {
        pp->width = ev->xconfigure.width;
        pp->height = ev->xconfigure.height;
        if (pp->height > CONSOLE_HEIGHT) {
            XResizeWindow(pp->disp, pp->main,
			  pp->width, pp->height - CONSOLE_HEIGHT);
        }
	XMoveResizeWindow(pp->disp, pp->console,
			  0, pp->height - CONSOLE_HEIGHT,
			  pp->width, CONSOLE_HEIGHT);
    }
    return (0);
}

int
NiceFileDialog(FileDialog *pp)
{
    return (NiceSylTextLine(pp->field));
}

#if 0
char **GlobalAv;
int GlobalAc;

#define DEFAULT_COLOR_WHITE       "gray100"
#define DEFAULT_COLOR_LIGHT_GRAY  "gray85"
#define DEFAULT_COLOR_MEDIUM_GRAY "gray70"
#define DEFAULT_COLOR_DIM_GRAY    "gray50"
#define DEFAULT_COLOR_DARK_GRAY   "gray30"
#define DEFAULT_COLOR_BLACK       "gray0"
#define DEFAULT_COLOR_DARK_BLUE   "dark blue"
#define DEFAULT_COLOR_ILLUMINATED "#ffe0e0"

#define LABEL_WHITE       "White"
#define LABEL_LIGHT_GRAY  "LightGray"
#define LABEL_MEDIUM_GRAY "MediumGray"
#define LABEL_DIM_GRAY    "DimGray"
#define LABEL_DARK_GRAY   "DarkGray"
#define LABEL_BLACK       "Black"
#define LABEL_MARKING     "Marking"
#define LABEL_ILLUMINATED "Illuminated"

static int MainPower = 1;
static Display *Disp;
static unsigned long MenuPixels[8];

typedef struct {
    char *name;
    char *color;
} ColorSet;

static ColorSet White = {LABEL_WHITE, DEFAULT_COLOR_WHITE};
static ColorSet LightGray = {LABEL_LIGHT_GRAY, DEFAULT_COLOR_LIGHT_GRAY};
static ColorSet MediumGray = {LABEL_MEDIUM_GRAY, DEFAULT_COLOR_MEDIUM_GRAY};
static ColorSet DimGray = {LABEL_DIM_GRAY, DEFAULT_COLOR_DIM_GRAY};
static ColorSet DarkGray = {LABEL_DARK_GRAY, DEFAULT_COLOR_DARK_GRAY};
static ColorSet Black = {LABEL_BLACK, DEFAULT_COLOR_BLACK};
static ColorSet Marking = {LABEL_MARKING, DEFAULT_COLOR_DARK_BLUE};
static ColorSet Illuminated = {LABEL_ILLUMINATED, DEFAULT_COLOR_ILLUMINATED};
static ColorSet *AllColors[] = {&White, &LightGray, &MediumGray, &DimGray,
    &DarkGray, &Black, &Marking, &Illuminated, NULL};

static void
LoadColorset(ColorSet **cs, unsigned long *pm)
{
    Colormap cmap;
    XColor color;

    cmap = DefaultColormap(Disp, DefaultScreen(Disp));
    for (; *cs != NULL; ++cs) {
	if (XParseColor(Disp, cmap, (*cs)->color, &color) == 0) {
	    fprintf(stderr, "%s: %s \"%s\" is not available.\n",
		    GlobalAv[0], (*cs)->name, (*cs)->color);
	    exit(1);
	}
	else if (XAllocColor(Disp, cmap, &color) == 0) {
	    fprintf(stderr, "%s: no available color cell for %s.\n",
		    GlobalAv[0], (*cs)->name);
	    exit(1);
	}
	*pm++ = color.pixel;
    }
}

static void
WindowMain(XEvent *ev)
{
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
    }
}

void
main(int ac, char **av)
{
    XEvent ev;
    ColorSet **cs = AllColors;
    FileDialog *pp;

    GlobalAc = ac;
    GlobalAv = av;
    if ((Disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    LoadColorset(cs, MenuPixels);
    pp = ReserveFileDialog(Disp, MenuPixels, "stdin.ps", "Print PS file");
    while (MainPower) {
        while (XEventsQueued(Disp, QueuedAfterReading) == 0
               && (NiceFileDialog(pp))) {
            ;
	}
	XNextEvent(Disp, &ev);
	WindowMain(&ev);
	if (SendFileDialog(pp, &ev))
	    break;
    }
    if (pp->filename != NULL)
	printf("filename: %s\n", pp->filename);
    PutbackFileDialog(pp);
    XCloseDisplay(Disp);
    exit(0);
}
#endif
