typedef struct {
    double x, y;
} Vector2d;

typedef struct Data {
    int x, y;
    double vx, vy, theta;
    double color_theta;
    struct Data *next; /* NULL$B$J$i$P=*C<(B */
} Data;

typedef struct {
    Display *disp;
    XColor *colors;
    Vector2d *grid;
    int n_grids;
    Data *top;
    Data *last;

    int min_x;
    int min_y;
    int max_x;
    int max_y;

    Window parent;
    Window window;
    int width;
    int height;
    Pixmap pixmap;
    int w, h;
    GC gc;
    int radius;
    int unit;
    unsigned long *pixels;
    SylVScrollbar *vsb;
    SylHScrollbar *hsb;
    int offset_x;
    int offset_y;
    int direction; /* FromNorthToSouth, FromEastToWest (by $B$O$;$P(B) */
} DataSet;

#define FromNorthToSouth 0
#define FromEastToWest 1

DataSet * CreateDataSet(Display *, XColor *, int, int, int, Vector2d *, int);
void LoadDataSet(DataSet *, char *);
void ReserveDataSet(DataSet *, Window, unsigned long *);
void SendDataSet(DataSet *, XEvent *);
void DrawDataSet(DataSet *);
void ChangePropertyDataSet(DataSet *, Vector2d *);
void PrintPSDataSet(DataSet *, FILE *fp);
void PrintPSColorDataSet(DataSet *, FILE *fp);
void PrintEPSDataSet(DataSet *, FILE *fp);
void PrintEPSColorDataSet(DataSet *, FILE *fp);
