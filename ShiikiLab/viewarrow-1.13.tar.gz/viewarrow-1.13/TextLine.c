#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "VarWString.h"
#include "TextLine.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define DRAGGING_SCROLL_DELAY (20 * 1000) /* microseconds */

static int
GetPointedCursor(SylTextLine *txl, int w)
{
    int glue = (txl->cursor_width / 2 + 1), len, len_min, len_max;
    wchar_t *str;

    if (w <= glue)
	return (txl->left);
    if (w > txl->width - glue)
	return (txl->right);
    str = CreateWStringFromSylVarWString(txl->text, txl->left, txl->size);
    len = txl->size - txl->left;
    w -= glue;
    if (abs(XwcTextEscapement(txl->fs, str, len)) >= w) {
        len_max = len;
        len_min = 0;
        len = (len_max + len_min) / 2;
        while (len_max - len_min > 1) {
            if (abs(XwcTextEscapement(txl->fs, str, len)) >= w)
                len_max = len;
            else
                len_min = len;
            len = (len_max + len_min) / 2;
        }
	/*
	   $B%/%j%C%/$7$?J8;z$N:8B&$K(BI$B%S!<%`%]%$%s%?$rG[CV$9$k(B. $B$b$7(BI$B%S!<%`(B
	   $B%]%$%s%?$r1&B&$KG[CV$7$?$$>l9g$O!"<!$N9T$r(Blen = len_max$B$H$9$l$P(B
	   $B$h$$!#(B
	*/
	len = len_min;
    }
    free(str);
    return (txl->left + len);
}

static int
GetOrigin(SylTextLine *txl)
{
    int width, len, n;
    wchar_t *str;

    if ((len = txl->cursor - txl->left) <= 0)
	return (txl->cursor);
    str = CreateWStringFromSylVarWString(txl->text, txl->left, txl->cursor);
    width = txl->width - ((txl->cursor_width & ~1) + 2);
    for (n = 0; abs(XwcTextEscapement(txl->fs, str + n, len)) >= width
	 && txl->left + n < txl->cursor; ++n) {
	--len;
    }
    free(str);
    return (txl->left + n);
}

static int
GetLeftLimit(SylTextLine *txl)
{
    int w, len, len_min, len_max;
    wchar_t *str;

    str = CreateWStringFromSylVarWString(txl->text, 0, txl->cursor);
    len = 0;
    w = txl->width - ((txl->cursor_width & ~1) + 2);
    if (abs(XwcTextEscapement(txl->fs, str + len, txl->cursor - len)) >= w) {
        len_max = txl->cursor;
        len_min = 0;
        len = len_max / 2;
        while (len_max - len_min > 1) {
            if (abs(XwcTextEscapement(txl->fs, str + len, txl->cursor - len))
		>= w)
                len_min = len;
            else
                len_max = len;
            len = (len_max + len_min) / 2;
        }
	len = len_max;
    }
    free(str);
    return (len);
}

static int
GetRightLimit(SylTextLine *txl)
{
    int w, len, len_min, len_max;
    wchar_t *str;

    str = CreateWStringFromSylVarWString(txl->text, txl->left, txl->size);
    len = txl->size - txl->left;
    w = txl->width - ((txl->cursor_width & ~1) + 2);
    if (abs(XwcTextEscapement(txl->fs, str, len)) >= w) {
        len_max = len;
        len_min = txl->cursor - txl->left;
        len = (len_max + len_min) / 2;
        while (len_max - len_min > 1) {
            if (abs(XwcTextEscapement(txl->fs, str, len)) >= w)
                len_max = len;
            else
                len_min = len;
            len = (len_max + len_min) / 2;
        }
	len = len_max;
    }
    free(str);
    return (txl->left + len);
}

static int
MoveCursorLeft(SylTextLine *txl)
{
#if 0
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N1&C<$KE=$j(B
       $B$D$1$k!#(B
    */
    --(txl->cursor);
    return (GetLeftLimit(txl));
#elif 0
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N:8C<$KE=$j(B
       $B$D$1$k!#(BMotif$B$_$?$$$K$9$k!#(B
    */
    if (--(txl->cursor) < txl->left)
	txl->left = txl->cursor;
    return (GetOrigin(txl));
#else
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N:8C<$NJ8;z(B
       $B$N1&B&$KD%$jIU$1$k!#(B
    */
    if (--(txl->cursor) <= txl->left)
	txl->left = (txl->cursor == 0) ? 0 : txl->cursor - 1;
    return (GetOrigin(txl));
#endif
}

static void
SetSelectionOwner(SylTextLine *txl, Time tm)
{
    char *string;
    wchar_t *str;
    int n_bytes, len;

    XSetSelectionOwner(txl->disp, XA_PRIMARY, txl->window, tm);
    if (XGetSelectionOwner(txl->disp, XA_PRIMARY) != txl->window) {
	txl->left_dragged = 0;
	txl->right_dragged = 0;
    }

    if ((str = CreateWStringFromSylVarWString(txl->text,
	txl->left_dragged, txl->right_dragged)) == NULL)
	return;
    len = txl->right_dragged - txl->left_dragged;
    if ((string = (char *)malloc((len + 1) * sizeof(wchar_t))) != NULL) {
	if ((n_bytes = wcstombs(string, str, (len + 1) * sizeof(wchar_t)))
	    >= 0)
	    XStoreBuffer(txl->disp, string, n_bytes, 0);
	free(string);
    }
    free(str);
}

static void
ResetSelectionOwner(SylTextLine *txl)
{
    XSetSelectionOwner(txl->disp, XA_PRIMARY, None, CurrentTime);
    txl->left_dragged = 0;
    txl->right_dragged = 0;
}

static void
DeleteDraggedRegion(SylTextLine *txl)
{
    int len;

    DeleteWStringOfSylVarWString(txl->text,
				 txl->left_dragged, txl->right_dragged);
    if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	txl->size = len;
	txl->cursor = txl->left_dragged;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static void
BackSpace(SylTextLine *txl)
{
    int len;

    if (txl->left_dragged < txl->right_dragged)
	DeleteDraggedRegion(txl);
    else if (txl->cursor > 0) {
	DeleteWCharOfSylVarWString(txl->text, txl->cursor - 1);
	if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->left = MoveCursorLeft(txl);
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
}

static void
Delete(SylTextLine *txl)
{
    int len;

    if (txl->left_dragged < txl->right_dragged)
	DeleteDraggedRegion(txl);
    else if (txl->cursor < txl->size) {
	DeleteWCharOfSylVarWString(txl->text, txl->cursor);
	if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
}

static void
KillLine(SylTextLine *txl)
{
    int len;

    if (txl->cursor < txl->size) {
	DeleteWStringOfSylVarWString(txl->text, txl->cursor, txl->size);
	if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
}

static void
CursorBack(SylTextLine *txl)
{
    if (txl->cursor > 0) {
	txl->left = MoveCursorLeft(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static int
MoveWordLeft(SylTextLine *txl)
{
    wchar_t *str;

    str = CreateWStringFromSylVarWString(txl->text, 0, txl->size);
    while (txl->cursor > 0 && !isalnum(str[txl->cursor - 1]))
	--(txl->cursor);
    while (txl->cursor > 0 && isalnum(str[txl->cursor - 1]))
	--(txl->cursor);
    free(str);
    return (GetOrigin(txl));
}

static void
WordBack(SylTextLine *txl)
{
    if (txl->cursor <= 0)
	return;
    txl->left = MoveWordLeft(txl);
    txl->right = GetRightLimit(txl);
    if (txl->left_dragged < txl->right_dragged)
	ResetSelectionOwner(txl);
    txl->redraw = True;
}

static void
CursorBeginingOfLine(SylTextLine *txl)
{
    if (txl->cursor > 0) {
	txl->cursor = 0;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }    
}

static int
MoveCursorRight(SylTextLine *txl)
{
    ++(txl->cursor);
    return (GetOrigin(txl));
}

static int
MoveWordRight(SylTextLine *txl)
{
    wchar_t *str;

    str = CreateWStringFromSylVarWString(txl->text, 0, txl->size);
    while (txl->cursor < txl->size && !isalnum(str[txl->cursor]))
	++(txl->cursor);
    while (txl->cursor < txl->size && isalnum(str[txl->cursor]))
	++(txl->cursor);
    free(str);
    return (GetOrigin(txl));
}

static void
CursorForward(SylTextLine *txl)
{
    if (txl->cursor < txl->size) {
	txl->left = MoveCursorRight(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static void
WordForward(SylTextLine *txl)
{
    if (txl->cursor >= txl->size)
	return;
    txl->left = MoveWordRight(txl);
    txl->right = GetRightLimit(txl);
    if (txl->left_dragged < txl->right_dragged)
	ResetSelectionOwner(txl);
    txl->redraw = True;
}

static void
CursorEndOfLine(SylTextLine *txl)
{
    if (txl->cursor < txl->size) {
	txl->cursor = txl->size;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }    
}

static void
InsertChar(SylTextLine *txl, wchar_t c)
{
    int len;

    if (txl->left_dragged < txl->right_dragged) {
	DeleteWStringOfSylVarWString(txl->text,
	    txl->left_dragged, txl->right_dragged);
	if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->cursor = txl->left_dragged;
	    txl->left = GetOrigin(txl);
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
    InsertCharIntoSylVarWString(txl->text, txl->cursor, c);
    if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	txl->size = len;
	txl->left = MoveCursorRight(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static void
AdjustDraggedRegion(SylTextLine *txl)
{
    if (txl->dragging < txl->cursor) {
	txl->left_dragged = txl->dragging;
	txl->right_dragged = txl->cursor;
    }
    else {
	txl->left_dragged = txl->cursor;
	txl->right_dragged = txl->dragging;
    }
}

static void
ChangeSelectionOwner(SylTextLine *txl, Time tm)
{
    Window owner;
    XEvent ev;

    if (txl->left_dragged == txl->right_dragged) {
	XSetSelectionOwner(txl->disp, XA_PRIMARY, None, CurrentTime);
	return;
    }
    if ((owner = XGetSelectionOwner(txl->disp, XA_PRIMARY)) == txl->window)
	return;
    if (owner != None) {
	ev.xselectionclear.type = SelectionClear;
	ev.xselectionclear.window = owner;
	ev.xselectionclear.selection = XA_PRIMARY;
	ev.xselectionclear.time = tm;
	XSendEvent(txl->disp, txl->window, False, 0, &ev);
    }
    SetSelectionOwner(txl, tm);
}

static void
CursorBackWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor > 0) {
	txl->left = MoveCursorLeft(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
WordBackWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor > 0) {
	txl->left = MoveWordLeft(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
CursorForwardWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor < txl->size) {
	txl->left = MoveCursorRight(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
WordForwardWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor < txl->size) {
	txl->left = MoveWordRight(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
CursorBeginingOfLineWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor > 0) {
	txl->cursor = 0;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }    
}

static void
CursorEndOfLineWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor < txl->size) {
	txl->cursor = txl->size;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }    
}

static void
ChangeInputFocus(SylTextLine *txl, Time tm)
{
    XSetInputFocus(txl->disp, txl->window, RevertToParent, tm);
}

#define KanaMask 0x2000
static void
LookupKey(SylTextLine *txl, XKeyEvent *key, KeySym ks, wchar_t c)
{
    if (ks == XK_BackSpace || c == 0x08)
	BackSpace(txl);
    else if (ks == XK_Delete || c == 0x7f || c == 0x04)
	Delete(txl);
    else if (c == 0x0b)
	KillLine(txl);
    else if (ks == XK_Left || c == 0x02) {
	if (key->state & ShiftMask) {
	    if (key->state & (Mod1Mask | Mod3Mask))
		WordBackWithShift(txl, key->time);
	    else
		CursorBackWithShift(txl, key->time);
	}
	else if (key->state & (Mod1Mask | Mod3Mask))
	    WordBack(txl);
	else if ((key->state & ~(LockMask | ControlMask | KanaMask)) == 0)
	    CursorBack(txl);
    }
    else if ((c == 'b' || c == 'B') && (key->state & (Mod1Mask | Mod3Mask))) {
	if (key->state & ShiftMask)
	    WordBackWithShift(txl, key->time);
	else
	    WordBack(txl);
    }
    else if (ks == XK_Right || c == 0x06) {
	if (key->state & ShiftMask) {
	    if (key->state & (Mod1Mask | Mod3Mask))
		WordForwardWithShift(txl, key->time);
	    else
		CursorForwardWithShift(txl, key->time);
	}
	else if (key->state & (Mod1Mask | Mod3Mask))
	    WordForward(txl);
	else if ((key->state & ~(LockMask | ControlMask | KanaMask)) == 0)
	    CursorForward(txl);
    }
    else if ((c == 'f' || c == 'F') && (key->state & (Mod1Mask | Mod3Mask))) {
	if (key->state & ShiftMask)
	    WordForwardWithShift(txl, key->time);
	else
	    WordForward(txl);
    }
    else if (c == 0x01) {
	if ((key->state & ShiftMask) == 0)
	    CursorBeginingOfLine(txl);
	else
	    CursorBeginingOfLineWithShift(txl, key->time);
    }
    else if (c == 0x05) {
	if ((key->state & ShiftMask) == 0)
	    CursorEndOfLine(txl);
	else
	    CursorEndOfLineWithShift(txl, key->time);
    }
    else if (ks == XK_Tab || c == 0x09
#ifdef XK_ISO_Left_Tab
	     || ks == XK_ISO_Left_Tab
#endif	     
	     ) {
	if ((key->state & ShiftMask) == 0 && txl->forward_focus != NULL)
	    ChangeInputFocus(txl->forward_focus, key->time);
	else if ((key->state & ShiftMask) && txl->backward_focus != NULL)
	    ChangeInputFocus(txl->backward_focus, key->time);
    }
    else if (c >= ' ') {
	InsertChar(txl, c);
    }
}

static void
LookupPressedKey(SylTextLine *txl, XKeyEvent *key)
{
    KeySym ks;
    unsigned char p[64];
    wchar_t c;

    p[XLookupString(key, p, 64, NULL, NULL)] = 0;
    if ((ks = XLookupKeysym(key, 0)) == NoSymbol)
	return;
    LookupKey(txl, key, ks, (mbtowc(&c, p, 1) > 0) ? c : 0);
}

static void
LookupPressedKeyWithIC(SylTextLine *txl, XKeyEvent *key)
{
    int n, n_lookups;
    KeySym ks;
    Status lookup_status;
#if 0
    /*
       $B;EMM$@$H$3$C$A$G$$$$$O$:$J$N$K(B... $B%9%F!<%?%9$,(BXBufferOverflow$B$N(B
       $B$H$-(BXwcLookupString()$B$NJV$9CM$O!VI,MW$J%P%C%U%!$NBg$-$5!W$N$O$:(B
       $B$@$,!"F~NO%a%=%C%I$K$h$C$F$O>!<j$KF~NO%3%s%F%/%9%H$r@Z$j5M$a$k!#(B
    */
    wchar_t *drain, buf[1], *str = buf;

    n_lookups = XwcLookupString(txl->ic, key, str, 1, &ks, &lookup_status);
    if (lookup_status == XBufferOverflow) {
	if ((str = (wchar_t *)alloca(sizeof(wchar_t) * n_lookups)) == NULL) {
	    if ((drain = XwcResetIC(txl->ic)) != NULL)
		XFree(drain);
	    return;
	}
	n_lookups = XwcLookupString(txl->ic, key, str, n_lookups, &ks,
				    &lookup_status);
    }
#else
    wchar_t *drain, str[256];

    n_lookups = XwcLookupString(txl->ic, key, str, 256, &ks, &lookup_status);
    if (lookup_status == XBufferOverflow) {
	if ((drain = XwcResetIC(txl->ic)) != NULL)
	    XFree(drain);
	return;
    }
#endif
    switch (lookup_status) {
    case XBufferOverflow:
	if ((drain = XwcResetIC(txl->ic)) != NULL)
	    XFree(drain);
	break;
    case XLookupKeySym:
	LookupKey(txl, key, ks, 0);
	break;
    case XLookupChars:
	for (n = 0; n < n_lookups; ++n)
	    LookupKey(txl, key, NoSymbol, str[n]);
	break;
    case XLookupBoth:
	LookupKey(txl, key, ks, str[0]);
	for (n = 1; n < n_lookups; ++n)
	    LookupKey(txl, key, NoSymbol, str[n]);
	break;
    }
}

static void
SetSpotLocation(XIC ic, int x, int y)
{
    XVaNestedList list;
    XPoint spot;
    
    spot.x = x;
    spot.y = y;
    list = XVaCreateNestedList(0, XNSpotLocation, &spot, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}

static void
DrawCursor(SylTextLine *txl, int cx)
{
    int rx, lx, ty, by;

    if (txl->focus == True) {
        lx = cx - ((txl->cursor_width / 3) & ~1);
        rx = cx + ((txl->cursor_width / 3) & ~1);
	ty = txl->descent;
	by = txl->descent + txl->cursor_height - 1;
	XDrawLine(txl->disp, txl->pixmap, txl->gc, cx, ty + 1, cx, by - 1);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, lx, ty, cx - 1, ty);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, lx, by, cx - 1, by);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, cx + 1, ty, rx, ty);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, cx + 1, by, rx, by);
	if (txl->ic != NULL) {
	    SetSpotLocation(txl->ic, cx, ty + txl->ascent);
	}
    }
}

static void
DrawTextLine(SylTextLine *txl)
{
    wchar_t *str;
    int dragged_begin, dragged_len, leftmargin, top;

    if ((top = txl->left) > 0)
	--top;
    str = CreateWStringFromSylVarWString(txl->text, top, txl->right);
    leftmargin = txl->cursor_width / 2 + 1;
    if (txl->left > 0)
	leftmargin -= abs(XwcTextEscapement(txl->fs, str, 1));
    /* draw background */
    XSetForeground(txl->disp, txl->gc,
	(txl->pointed == True) ? txl->pixel[7] : txl->pixel[0]);
    XFillRectangle(txl->disp, txl->pixmap, txl->gc,
	0, 0, txl->width, txl->height);
    /* draw foreground */
    XSetForeground(txl->disp, txl->gc, txl->pixel[5]);
    XwcDrawString(txl->disp, txl->pixmap, txl->fs, txl->gc,
	leftmargin, txl->descent + txl->ascent, str, txl->right - top);
    if (txl->right_dragged - txl->left_dragged > 0) {
	if (top < txl->left_dragged)
	    dragged_begin = txl->left_dragged - top;
	else
	    dragged_begin = 0;
	if (txl->right_dragged < txl->right)
	    dragged_len = txl->right_dragged - top - dragged_begin;
	else
	    dragged_len = txl->right - top - dragged_begin;
	XSetForeground(txl->disp, txl->gc,
	    (txl->pointed == True) ? txl->pixel[7] : txl->pixel[0]);
	XSetBackground(txl->disp, txl->gc, txl->pixel[5]);
	XwcDrawImageString(txl->disp, txl->pixmap, txl->fs, txl->gc,
	    leftmargin + abs(XwcTextEscapement(txl->fs, str, dragged_begin)),
	    txl->descent + txl->ascent, str + dragged_begin, dragged_len);
    }
    if (txl->focus == True) {
	XSetForeground(txl->disp, txl->gc, txl->pixel[5]);
#if 1
	XDrawRectangle(txl->disp, txl->pixmap, txl->gc, 0, 0,
            txl->width - 1, txl->height - 1);
#endif
	DrawCursor(txl, leftmargin
		   + abs(XwcTextEscapement(txl->fs, str, txl->cursor - top)));
    }
    free(str);
}

static int
WindowXpointer(Display *disp, Window w)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, w, &root, &child, &rx, &ry, &wx, &wy, &kb);
    return (wx);
}

int
NiceSylTextLine(SylTextLine *txl)
{
    int x;

    XFlush(txl->disp);
    if (txl->redraw == True) {
	DrawTextLine(txl);
	XCopyArea(txl->disp, txl->pixmap, txl->window, txl->gc,
		  0, 0, txl->width, txl->height, 0, 0);
	txl->redraw = False;
    }
    if (txl->grabbed == True) {
	if ((x = WindowXpointer(txl->disp, txl->window)) < 0) {
	    if (txl->cursor > 0)
		txl->left = MoveCursorLeft(txl);
	}
	else if (x > txl->width) {
	    if (txl->cursor < txl->size)
		txl->left = MoveCursorRight(txl);
	}
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	txl->redraw = True;
	XFlush(txl->disp);
	usleep(DRAGGING_SCROLL_DELAY);
	return (1);
    }
    return (0);
}

static void
SendSelectionReply(SylTextLine *txl, XEvent *ev)
{
    XTextProperty text;
    wchar_t *str;
    XEvent reply;
    XICCEncodingStyle style;
    XSelectionRequestEvent *req = &(ev->xselectionrequest);
    Atom targets;

    reply.xselection.type = SelectionNotify;
    reply.xselection.requestor = req->requestor;
    reply.xselection.selection = req->selection;
    reply.xselection.target = req->target;
    reply.xselection.property = None;
    reply.xselection.time = req->time;
    if (req->target == XInternAtom(txl->disp, "TARGETS", False)) {
	targets = XInternAtom(txl->disp, "COMPOUND_TEXT", False);
	XChangeProperty(req->display, req->requestor, req->property,
			XA_ATOM, 32, PropModeReplace, (char *)&targets, 1);
	reply.xselection.property = req->property;
	XSendEvent(req->display, req->requestor, False, 0, &reply);
	return;
    }
    else if (req->target == XInternAtom(txl->disp, "TEXT", False))
	style = XStdICCTextStyle;
    else if (req->target == XInternAtom(txl->disp, "COMPOUND_TEXT", False))
	style = XCompoundTextStyle;
    else if (req->target == XA_STRING)
	style = XStringStyle;
    else {
	XSendEvent(req->display, req->requestor, False, 0, &reply);
	return;
    }

    if ((str = CreateWStringFromSylVarWString(txl->text,
        txl->left_dragged, txl->right_dragged)) == NULL) {
	XSendEvent(req->display, req->requestor, False, 0, &reply);
	return;
    }
    if (XwcTextListToTextProperty(txl->disp, &str, 1, style, &text) < 0) {
	free(str);
	XSendEvent(req->display, req->requestor, False, 0, &reply);
	return;
    }
    free(str);
    XSetTextProperty(req->display, req->requestor, &text, req->property);
    XFree(text.value);
    reply.xselection.property = req->property;
    XSendEvent(req->display, req->requestor, False, 0, &reply);
}

static void
GetWindowProperty(SylTextLine *txl, XEvent *ev)
{
    XTextProperty text;
    wchar_t **list;
    int n_lists, n, len;
    XSelectionEvent *sel = &(ev->xselection);

    if (sel->property != txl->property) {
	printf("property is different from the requested\n");
	XDeleteProperty(sel->display, sel->requestor, sel->property);
	return;
    }
    if (XGetTextProperty(sel->display, sel->requestor, &text, sel->property)
	== 0) {
	printf("target is %s(%ld), XGetTextProperty failed\n",
	       XGetAtomName(txl->disp, sel->target), sel->target);
	return;
    }
    XDeleteProperty(sel->display, sel->requestor, sel->property);
    if ((n = XwcTextPropertyToTextList(txl->disp, &text, &list, &n_lists))
	< 0) {
	printf("text.value is %s(%ld), XwcTextPropertyToTextList failed\n",
	       text.value, text.nitems);
	XFree(text.value);
	return;
    }
    XFree(text.value);
    /*
       Bug?: text.value$B$K(BJIS$B%3!<%I$GF|K\8l$,3JG<$5$l$F$$$F!"(Btext.value$B$N(B
       $B:G8e$N(B3$B%P%$%H$,(BKanjiOut(0x1b 0x28 0x42)$B$N$H$-!"4X?t(BXwcTextProperty-
       ToTextList()$B$O$J$<$+(B3$B$rJV$9!#$3$3$G$O$H$j$"$($:La$jCM$,@5$N$H$-$O(B
       $B=hM}$rB39T$9$k!#(B
    */
    if (n_lists > 0) {
	for (n = 0; (*list)[n]; ++n) {
	    if ((*list)[n] < ' ')
		(*list)[n] = ' ';
	}
	InsertWStringIntoSylVarWString(txl->text, txl->cursor, *list);
    }
    XwcFreeStringList(list);
    if ((len = LengthOfSylVarWString(txl->text)) != txl->size) {
	txl->cursor += len - txl->size;
	txl->size = len;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

void
SendSylTextLine(SylTextLine *txl, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != txl->window)
	    return;
	XCopyArea(txl->disp, txl->pixmap, txl->window, txl->gc,
	    ev->xexpose.x, ev->xexpose.y,
	    ev->xexpose.width, ev->xexpose.height,
	    ev->xexpose.x, ev->xexpose.y);
	break;
    case EnterNotify:
	if (ev->xcrossing.window != txl->window)
	    return;
	txl->pointed = True;
	txl->redraw = True;
        break;
    case LeaveNotify:
	if (ev->xcrossing.window != txl->window)
	    return;
	txl->pointed = False;
	txl->redraw = True;
        break;
    case ButtonPress:
	if (ev->xbutton.window != txl->window)
	    return;
	XSetInputFocus(txl->disp, txl->window, RevertToParent,
		       ev->xbutton.time);
	if (ev->xbutton.button == 1) {
	    XGrabPointer(txl->disp, txl->window, False, ButtonMotionMask
		| ButtonReleaseMask | PointerMotionHintMask,
		GrabModeAsync, GrabModeSync, DefaultRootWindow(txl->disp),
		None, ev->xbutton.time);
	    txl->grabbed = True; 
	    txl->cursor = GetPointedCursor(txl, ev->xbutton.x);
	    txl->dragging = txl->cursor;
	    txl->left_dragged = txl->cursor;
	    txl->right_dragged = txl->cursor;
	    txl->redraw = True;
	}
        else if (ev->xbutton.button == 2) {
	    txl->cursor = GetPointedCursor(txl, ev->xbutton.x);
	    XConvertSelection(txl->disp, XA_PRIMARY,
		XInternAtom(txl->disp, "TEXT", False),
		txl->property, txl->window, ev->xbutton.time);
	    txl->converting = True;
	    txl->redraw = True;
        }
	break;
    case MotionNotify:
        if (txl->grabbed != True)
            return;
	/*
	   Bug?: $B%;%l%/%7%g%s$r=jM-$9$k%&%#%s%I%&$,%H%C%W%l%Y%k%&%#%s%I%&(B
	   $B$G$J$$$?$a$+!"F10l%"%W%j%1!<%7%g%s4V$G4X?t(BXSetSelectionOwner()
	   $B$r8F$S=P$7$F$b(BSelectionClear$B%$%Y%s%H$,$3$J$$$3$H$,$"$k!#BP:v$H(B
	   $B$7$F!"(BMotionNotify$B$r<u$1<h$C$F$$$k$H$-$K?7$?$JJ8;zNs$,%I%i%C%0(B
	   $B$5$l$?$i!"(Bowner$B$r(BNone$B$H$7$F4X?t(BXSetSelectionOwner()$B$r8F$S=P$7!"(B
	   $B0lEY6/@)E*$K%;%l%/%7%g%s$N%*!<%J$G$J$/$J$k$h$&$K$7$?!#(B
	*/
	if (txl->left_dragged < txl->right_dragged)
	    XSetSelectionOwner(txl->disp, XA_PRIMARY, None, ev->xmotion.time);
	txl->cursor = GetPointedCursor(txl, WindowXpointer(txl->disp,
							   txl->window));
	AdjustDraggedRegion(txl);
        txl->redraw = True;
	break;
    case ButtonRelease:
        if (txl->grabbed != True)
            return;
        XUngrabPointer(txl->disp, ev->xbutton.time);
	if (txl->left_dragged < txl->right_dragged)
	    SetSelectionOwner(txl, ev->xbutton.time);
        txl->grabbed = False;
        txl->redraw = True;
        break;
    case FocusIn:
	if (ev->xfocus.window != txl->window
	    || ev->xfocus.detail == NotifyPointer)
	    return;
	if (txl->ic != NULL)
	    XSetICValues(txl->ic, XNFocusWindow, txl->window, NULL);
	txl->focus = True;
	txl->redraw = True;
        break;
    case FocusOut:
	if (ev->xfocus.window != txl->window
	    || ev->xfocus.detail == NotifyPointer)
	    return;
	txl->focus = False;
	txl->redraw = True;
        break;
    case KeyPress:
	if (ev->xkey.window != txl->window || txl->focus == False)
	    return;
	if (txl->ic == NULL)
	    LookupPressedKey(txl, &(ev->xkey));
	else
	    LookupPressedKeyWithIC(txl, &(ev->xkey));
	break;
    case SelectionNotify:
        if (txl->converting == False || ev->xselection.selection != XA_PRIMARY)
	    break;
	if (ev->xselection.property != None)
	    GetWindowProperty(txl, ev);
	txl->converting = False;
	break;
    case SelectionClear:
        if (ev->xselectionclear.window != txl->window)
	    break;
	txl->left_dragged = 0;
	txl->right_dragged = 0;
	txl->redraw = True;
        break;
    case SelectionRequest:
        if (ev->xselectionrequest.owner == txl->window
	    && txl->left_dragged < txl->right_dragged)
            SendSelectionReply(txl, ev);
        break;
    case ConfigureNotify:
	if (ev->xconfigure.window != txl->parent)
            return;
	txl->width = ev->xconfigure.width;
	txl->height = txl->cursor_height + 2 * txl->descent;
	XMoveResizeWindow(txl->disp, txl->window,
			  0, (ev->xconfigure.height - txl->height) / 2,
			  txl->width, txl->height);
	XFreePixmap(txl->disp, txl->pixmap);
	txl->pixmap = XCreatePixmap(txl->disp, txl->parent,
				    txl->width, txl->height, txl->depth);
	txl->left = GetLeftLimit(txl); /* GetOrigin(txl); */
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
	break;
    }
}

void
SetTabModeSylTextLine(SylTextLine *txl, SylTextLine *next, SylTextLine *back)
{
    txl->forward_focus = next;
    txl->backward_focus = back;
}

char *
CreateStringFromSylTextLine(SylTextLine *txl)
{
    char *string;
    wchar_t *str;
    int n_bytes, len = txl->size;
    
    if ((str = CreateWStringFromSylVarWString(txl->text, 0, txl->size))
	== NULL)
	return (NULL);
    if ((string = (char *)malloc((len + 1) * sizeof(wchar_t))) == NULL) {
	free(str);
	return (NULL);
    }
    if ((n_bytes = wcstombs(string, str, (len + 1) * sizeof(wchar_t))) < 0) {
	free(str);
        return (NULL);
    }
    free(str);
    return (string);
}

void
ClearSylTextLine(SylTextLine *txl)
{
    if (txl->size > 0) {
	txl->left_dragged = 0;
	txl->right_dragged = txl->size;
	DeleteDraggedRegion(txl);
    }
}

SylTextLine *
CreateSylTextLine(Display *disp, XIC ic, Window parent, XFontSet fs,
		  unsigned long *pixel, char *default_string,
		  int default_cursor_location, void (*callback)(int))
{
    int n_fontinfos;
    char **fontname;
    XFontStruct **fontinfo;
    XWindowAttributes attr;
    SylTextLine *txl;
    
    if ((txl = (SylTextLine *)malloc(sizeof(SylTextLine))) == NULL)
	return (NULL);
    if ((txl->text = CreateSylVarWStringFromString(default_string)) == NULL) {
	free(txl);
	return (NULL);
    }
    if ((n_fontinfos = XFontsOfFontSet(fs, &fontinfo, &fontname)) < 1) {
	free(txl->text);
	free(txl);
	return (NULL);
    }
    txl->fs = fs;
    txl->ascent = fontinfo[0]->ascent;
    txl->descent = fontinfo[0]->descent;
    txl->cursor_width = abs(XmbTextEscapement(txl->fs, "x", 1));
    txl->cursor_height = txl->ascent + txl->descent;
    XGetWindowAttributes(disp, parent, &attr);
    txl->width = attr.width;
    txl->height = txl->cursor_height + 2 * txl->descent;
    txl->depth = attr.depth;
    txl->window = XCreateSimpleWindow(disp, parent,
	0, (attr.height - txl->height) / 2, txl->width, txl->height,
        0, pixel[5], pixel[2]);
    XSetWindowBackgroundPixmap(disp, txl->window, None);
    XSelectInput(disp, txl->window, ExposureMask | KeyPressMask
        | ButtonPressMask | OwnerGrabButtonMask | ButtonReleaseMask
        | FocusChangeMask | EnterWindowMask | LeaveWindowMask
        | StructureNotifyMask);
    XMapRaised(disp, txl->window);
    txl->pixmap = XCreatePixmap(disp, parent,
        txl->width, txl->height, txl->depth);
    txl->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, txl->gc, False);
    txl->disp = disp;
    txl->ic = ic;
    txl->parent = parent;
    txl->pixel = pixel;
    txl->size = LengthOfSylVarWString(txl->text);
    txl->cursor = (default_cursor_location == TEXT_CURSOR_TOP) ? 0 : txl->size;
    txl->left = GetLeftLimit(txl);
    txl->right = GetRightLimit(txl);
    txl->dragging = 0;
    txl->left_dragged = 0;
    txl->right_dragged = 0;
    txl->callback = callback;
    txl->forward_focus = NULL;
    txl->backward_focus = NULL;
    txl->grabbed = False;
    txl->pointed = False;
    txl->focus = False;
    txl->redraw = False;
    txl->converting = False;
    txl->property = XInternAtom(disp, "TextLineProperty", False);
    DrawTextLine(txl);
    return (txl);
}

void
FreeSylTextLine(SylTextLine *txl)
{
    XDestroyWindow(txl->disp, txl->window);
    XFreePixmap(txl->disp, txl->pixmap);
    XFreeGC(txl->disp, txl->gc);
    FreeSylVarWString(txl->text);
    free(txl);
}
