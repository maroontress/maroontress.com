/*
        load.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Menu.h"

#include "parse.h"
#include "load.h"

int LoadErrorCode;
int LoadErrorLine;
char LoadErrorWord[40];

static char *Reserved[] = {"menubar", "menu", "nop", "exec", "toggle", NULL};
static ExecFunctionList *TableOfExecFunc;
static int ExecFuncs = 0;
static CheckFunctionList *TableOfCheckFunc;
static int CheckFuncs = 0;

void
RegisterExecFunctions(ExecFunctionList *e, int n)
{
    TableOfExecFunc = e;
    ExecFuncs = n;
}

void
RegisterCheckFunctions(CheckFunctionList *c, int n)
{
    TableOfCheckFunc = c;
    CheckFuncs = n;
}

static void
ErrorUndefinedMenu(Parse *p, char *w)
{
    LoadErrorCode = LOAD_UNDEFINED_MENU;
    LoadErrorLine = ParseLine(p);
    if (strlen(w) >= 32) {
	strncpy(LoadErrorWord, w, 32);
	LoadErrorWord[32] = 0;
	strcat(LoadErrorWord, "...");
    }
    else {
	strcpy(LoadErrorWord, w);
    }
}

static void
ErrorUndefinedFont(Parse *p, char *w)
{
    LoadErrorCode = LOAD_UNDEFINED_FONT;
    LoadErrorLine = ParseLine(p);
    strcpy(LoadErrorWord, w);
}

static void
ErrorUndefinedColor(Parse *p, char *w)
{
    LoadErrorCode = LOAD_UNDEFINED_COLOR;
    LoadErrorLine = ParseLine(p);
    strcpy(LoadErrorWord, w);
}

static void
ErrorNoKeySymItem(Parse *p)
{
    LoadErrorCode = LOAD_NO_KEYSYM_ITEM;
    LoadErrorLine = ParseLine(p);
}

static void
ErrorUnknownFunction(Parse *p, char *w)
{
    LoadErrorCode = LOAD_UNKNOWN_FUNCTION;
    LoadErrorLine = ParseLine(p);
    strcpy(LoadErrorWord, w);
}

static void
ErrorUnterminatedString(Parse *p)
{
    LoadErrorCode = LOAD_UNTERMINATED_STRING;
    LoadErrorLine = ParseLine(p);
}

static void
ErrorUnexpectedEOF(Parse *p)
{
    LoadErrorCode = LOAD_UNEXPECTED_EOF;
    LoadErrorLine = ParseLine(p);
}

static void
ErrorTooShortMemory(Parse *p)
{
    LoadErrorCode = LOAD_TOO_SHORT_MEMORY;
    LoadErrorLine = ParseLine(p);
}

static void
ErrorParseError(Parse *p, char *w)
{
    LoadErrorCode = LOAD_PARSE_ERROR;
    LoadErrorLine = ParseLine(p);
    strcpy(LoadErrorWord, w);
}

#define STRING_MAX 256

static int
IgnoreComment(Parse *p)
{
    int c;

    while ((c = GetChar(p)) != EOF && c != '\n')
	;
    return (c);
}

static int
GetString(Parse *p, char *str, int limit)
{
    int n, c;

    for (n = 0; (c = GetChar(p)) != EOF && n < limit; ++n) {
	if (c == '"')
	    break;
	else if (c == '\\') {
	    if ((c = GetChar(p)) == EOF)
		return (EOF);
	    else if (c != '\n')
		str[n] = c;
	}
	else if (c == '\n')
	    return (c);
	else
	    str[n] = c;
    }
    str[n] = 0;
    return ((c == EOF) ? EOF : 0);
}

static int
NextWord(Parse *p, char *w)
{
    int type;

    while ((type = GetToken(p, w, NULL)) == PARSE_EMPTYLINES
	   || (type == PARSE_CPPCMD && IgnoreComment(p) == '\n'))
	;
    return (type);
}

static ExecFunctionList *
GetExecItem(Parse *p)
{
    int n, type;
    char w[40]; /* it needs (32 + 1) bytes at least. */

    if ((type = NextWord(p, w)) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (type != PARSE_KEYWORD) {
	ErrorParseError(p, w);
	return (NULL);
    }
    for (n = 0; n < ExecFuncs; ++n) {
	if (strcmp(TableOfExecFunc[n].func_name, w) == 0)
	    return (&TableOfExecFunc[n]);
    }
    ErrorUnknownFunction(p, w);
    return (NULL);
}

static CheckFunctionList *
GetCheckItem(Parse *p)
{
    int n, type;
    char w[40]; /* it needs (32 + 1) bytes at least. */

    if ((type = NextWord(p, w)) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (type != PARSE_KEYWORD) {
	ErrorParseError(p, w);
	return (NULL);
    }
    for (n = 0; n < CheckFuncs; ++n) {
	if (strcmp(TableOfCheckFunc[n].func_name, w) == 0)
	    return (&TableOfCheckFunc[n]);
    }
    ErrorUnknownFunction(p, w);
    return (NULL);
}

static SylMenuList *
GetMenu(Parse *p, SylMenuList *ml)
{
    int type;
    char str[STRING_MAX], w[40]; /* it needs (32 + 1) bytes at least. */
    SylMenu *m;
    ExecFunctionList *ei;
    CheckFunctionList *ci;
    
    if ((type = NextWord(p, w)) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (type != PARSE_STRCONST) {
	ErrorParseError(p, w);
	return (NULL);
    }
    else if ((type = GetString(p, str, STRING_MAX - 1)) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (type == '\n') {
	ErrorUnterminatedString(p);
	return (NULL);
    }
    else if ((m = CreateSylMenu(ml, str)) == NULL) {
	ErrorTooShortMemory(p);
	return (NULL);
    }
    else if (NextWord(p, w) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "{") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    while ((type = NextWord(p, w)) == PARSE_STRCONST) {
	if ((type = GetString(p, str, STRING_MAX - 1)) == EOF) {
	    ErrorUnexpectedEOF(p);
	    return (NULL);
	}
	else if (type == '\n') {
	    ErrorUnterminatedString(p);
	    return (NULL);
	}
	else if (NextWord(p, w) == EOF) {
	    ErrorUnexpectedEOF(p);
	    return (NULL);
	}
	else if (strcmp(w, "nop") == 0) {
	    type = CreateSylNopItem(m, str);
	}
	else if (strcmp(w, "exec") == 0) {
	    if ((ei = GetExecItem(p)) == NULL)
		return (NULL);
	    type = CreateSylExecItem(m, str, ei->exec, ei->is_grayout);
	}
	else if (strcmp(w, "toggle") == 0) {
	    if ((ci = GetCheckItem(p)) == NULL)
		return (NULL);
	    type = CreateSylCheckItem(m, str, ci->toggle, ci->is_checked,
				      ci->is_grayout);
	}
	else {
	    ErrorParseError(p, w);
	    return (NULL);
	}
	if (type == MENU_ITEM_FAILURE) {
	    ErrorTooShortMemory(p);
	    return (NULL);
	}
#if 1
	else if (type == MENU_ITEM_NO_KEYSYM) {
	    ErrorNoKeySymItem(p);
	    return (NULL);
	}
#endif
    }
    if (type == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "}") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    return (ml);
}

static SylMenuList *
GetMenubar(Parse *p, SylMenuList *ml, SylMenuList *mb)
{
    int type;
    char str[STRING_MAX], w[40]; /* it needs (32 + 1) bytes at least. */
    SylMenu *m;    

    if (NextWord(p, w) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "{") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    while ((type = NextWord(p, w)) == PARSE_STRCONST) {
	if ((type = GetString(p, str, STRING_MAX - 1)) == EOF) {
	    ErrorUnexpectedEOF(p);
	    return (NULL);
	}
	else if (type == '\n') {
	    ErrorUnterminatedString(p);
	    return (NULL);
	}
	else if ((m = LookupSylMenu(ml, str)) == NULL) {
	    ErrorUndefinedMenu(p, str);
	    return (NULL);
	}
	else if (CopySylMenu(mb, m) == NULL) {
	    ErrorTooShortMemory(p);
	    return (NULL);
	}
    }
    if (type == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "}") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    return (ml);
}

static FontSet **
GetFontset(Parse *p, FontSet **fs)
{
    int type;
    char str[STRING_MAX], w[40]; /* it needs (32 + 1) bytes at least. */
    FontSet **ptr;

    if (NextWord(p, w) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "{") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    while ((type = NextWord(p, w)) == PARSE_KEYWORD) {
	for (ptr = fs; *ptr != NULL && strcmp((*ptr)->name, w) != 0; ++ptr)
	    ;
	if (ptr == NULL) {
	    ErrorUndefinedFont(p, w);
	    return (NULL);
	}
	else if ((type = NextWord(p, w)) != PARSE_STRCONST) {
	    ErrorParseError(p, w);
	    return (NULL);
	}
	else if ((type = GetString(p, str, STRING_MAX - 1)) == EOF) {
	    ErrorUnexpectedEOF(p);
	    return (NULL);
	}
	else if (type == '\n') {
	    ErrorUnterminatedString(p);
	    return (NULL);
	}
	else if (((*ptr)->font = strdup(str)) == NULL) {
	    ErrorTooShortMemory(p);
	    return (NULL);
	}
    }
    if (type == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "}") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    return (fs);
}

static ColorSet **
GetColorset(Parse *p, ColorSet **cs)
{
    int type;
    char str[STRING_MAX], w[40]; /* it needs (32 + 1) bytes at least. */
    ColorSet **ptr;

    if (NextWord(p, w) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "{") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    while ((type = NextWord(p, w)) == PARSE_KEYWORD) {
	for (ptr = cs; *ptr != NULL && strcmp((*ptr)->name, w) != 0; ++ptr)
	    ;
	if (ptr == NULL) {
	    ErrorUndefinedColor(p, w);
	    return (NULL);
	}
	else if ((type = NextWord(p, w)) != PARSE_STRCONST) {
	    ErrorParseError(p, w);
	    return (NULL);
	}
	else if ((type = GetString(p, str, STRING_MAX - 1)) == EOF) {
	    ErrorUnexpectedEOF(p);
	    return (NULL);
	}
	else if (type == '\n') {
	    ErrorUnterminatedString(p);
	    return (NULL);
	}
	else if (((*ptr)->color = strdup(str)) == NULL) {
	    ErrorTooShortMemory(p);
	    return (NULL);
	}
    }
    if (type == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "}") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    return (cs);
}

int
LoadConfigFile(char *file, SylMenuList *ml, SylMenuList *mb,
	       FontSet **fs, ColorSet **cs)
{
    int type;
    char w[40]; /* it needs (32 + 1) bytes at least. */
    Parse *p;

    if ((p = OpenParse(file, Reserved)) == NULL) {
	LoadErrorCode = LOAD_CANNOT_OPEN;
	return (NULL);
    }
    LoadErrorCode = LOAD_EMPTY;
    while ((type = NextWord(p, w)) != EOF) {
	if (strcmp(w, "menu") == 0) {
	    if (GetMenu(p, ml) == NULL)
		break;
	}
	else if (strcmp(w, "menubar") == 0) {
	    if (GetMenubar(p, ml, mb) == NULL)
		break;
	}
	else if (strcmp(w, "fontset") == 0) {
	    if (GetFontset(p, fs) == NULL)
		break;
	}
	else if (strcmp(w, "color") == 0) {
	    if (GetColorset(p, cs) == NULL)
		break;
	}
	else {
	    ErrorParseError(p, w);
	    break;
	}
    }
    CloseParse(p);
    return ((ml->top == NULL) ? 0 : type);
}

/*
   Local Versions
   1997/ 4/ 4 Fri    1.00    Initial Version
*/
