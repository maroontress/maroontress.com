typedef struct {
    Display *disp;
    Window base;
    Window main;
    Window console;
    unsigned long *pixels;
    SylTextLine *field;
    SylButton okay;
    SylButton clear;
    SylButton cancel;

    int height;
    int width;
    char *filename;
} FileDialog;

FileDialog *ReserveFileDialog(Display *, unsigned long *, char *, char *);
int NiceFileDialog(FileDialog *);
void PutbackFileDialog(FileDialog *);
int SendFileDialog(FileDialog *, XEvent *);
