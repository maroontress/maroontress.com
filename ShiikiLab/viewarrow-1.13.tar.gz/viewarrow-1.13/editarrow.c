/*
       editarrow.c 1.0 for X11R6 & GNU C Compiler

       Copyright (C) 1997 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "Button.h"
#include "VScrollbar.h"
#include "HScrollbar.h"
#include "property.h"
#include "dataset.h"
#include "editarrow.h"

#define GRID_RADIUS 4
#define GRID_UNIT ((GRID_RADIUS) * 2 + 1)

#define DEFAULT_WIDTH 300
#define DEFAULT_HEIGHT 300
#define CONSOLE_HEIGHT 20

static void
SaveEditArrow(EditArrow *ea)
{
    int n;
    XPoint org = {DEFAULT_WIDTH / 2, DEFAULT_HEIGHT / 2};

    for (n = 0; n < ea->n_inputs; ++n) {
	ea->input[n].x = ((double)ea->point[n].x - org.x) / ea->radius;
	ea->input[n].y = -((double)ea->point[n].y - org.y) / ea->radius;
    }
}

static void
CreateArrowGrids(EditArrow *ea)
{
    int n;
    XPoint org = {DEFAULT_WIDTH / 2, DEFAULT_HEIGHT / 2};

    for (n = 0; n < ea->n_inputs; ++n) {
	ea->point[n].x = org.x + (short)(ea->input[n].x * ea->radius);
	ea->point[n].y = org.y - (short)(ea->input[n].y * ea->radius);
	ea->grid_window[n] = XCreateSimpleWindow(ea->disp, ea->main,
	    ea->point[n].x - GRID_RADIUS, ea->point[n].y - GRID_RADIUS,
	    GRID_UNIT, GRID_UNIT, 0, ea->pixels[5], ea->pixels[2]);
 	XSelectInput(ea->disp, ea->grid_window[n], ExposureMask
	    | ButtonPressMask | ButtonReleaseMask);
	XMapRaised(ea->disp, ea->grid_window[n]);
    }
}

static void
PutbackArrowGrids(EditArrow *ea)
{
    int n;

    for (n = 0; n < ea->n_inputs; ++n)
	XDestroyWindow(ea->disp, ea->grid_window[n]);
}

static void
DrawColorArrow(EditArrow *ea)
{
    XSetForeground(ea->disp, ea->gc, ea->pixels[2]);
    XFillRectangle(ea->disp, ea->source, ea->gc, 0, 0,
        DEFAULT_WIDTH, DEFAULT_HEIGHT);
    XSetForeground(ea->disp, ea->gc, ea->pixels[3]);
    XDrawArc(ea->disp, ea->source, ea->gc,
        DEFAULT_WIDTH / 2 - ea->radius, DEFAULT_HEIGHT / 2 - ea->radius,
        ea->radius * 2, ea->radius * 2, 0, 360 * 64);
    XSetForeground(ea->disp, ea->gc, ea->pixels[5]);
    XFillPolygon(ea->disp, ea->source, ea->gc, ea->point, ea->n_inputs,
        Complex, CoordModeOrigin);
    XCopyArea(ea->disp, ea->source, ea->main, ea->gc, 0, 0,
	DEFAULT_WIDTH, DEFAULT_HEIGHT, 0, 0);
}

EditArrow *
ReserveEditArrow(Display *disp, unsigned long *pixels, Vector2d *input,
		int n_inputs, int radius, char *title)
{
    char *av[] = {"EditArrow", NULL};
    EditArrow *ea;
    XPoint *point;
    Window *grids;

    if ((ea = (EditArrow *)malloc(sizeof(EditArrow))) == NULL)
	return (NULL);
    if ((point = (XPoint *)malloc(sizeof(XPoint) * n_inputs)) == NULL) {
	free(ea);
	return (NULL);
    }
    if ((grids = (Window *)malloc(sizeof(Window) * n_inputs)) == NULL) {
	free(point);
	free(ea);
	return (NULL);
    }
    ea->disp = disp;
    ea->pixels = pixels;
    ea->input = input;
    ea->n_inputs = n_inputs;
    ea->point = point;
    ea->grid_window = grids;
    ea->radius = radius;

    ea->base = XCreateSimpleWindow(ea->disp, DefaultRootWindow(ea->disp), 0, 0,
	DEFAULT_WIDTH, DEFAULT_HEIGHT + CONSOLE_HEIGHT,
        1, ea->pixels[5], ea->pixels[2]);
    SetProperties(ea->disp, ea->base, title, 1, av,
	DEFAULT_WIDTH, DEFAULT_HEIGHT + CONSOLE_HEIGHT,
        DEFAULT_WIDTH, DEFAULT_HEIGHT + CONSOLE_HEIGHT, 0, 0);
    XSelectInput(ea->disp, ea->base, KeyPressMask);
    XMapRaised(ea->disp, ea->base);

    ea->main = XCreateSimpleWindow(ea->disp, ea->base, 0, 0,
	DEFAULT_WIDTH, DEFAULT_HEIGHT, 0, ea->pixels[5], ea->pixels[2]);
    XSelectInput(ea->disp, ea->main, ButtonPressMask | ButtonReleaseMask
	| ExposureMask);
    XMapRaised(ea->disp, ea->main);

    ea->console = XCreateSimpleWindow(ea->disp, ea->base, 0, DEFAULT_HEIGHT,
	DEFAULT_WIDTH, CONSOLE_HEIGHT, 0, ea->pixels[5], ea->pixels[2]);
    XMapRaised(ea->disp, ea->console);
    ea->okay.x = 0;
    ea->okay.y = 0;
    ea->okay.format = ButtonLabelLeft;
    ea->okay.str = " Ok ";
    ReserveSylButton(ea->disp, ea->console, XLoadFont(ea->disp, "variable"),
	CopyFromParent, ea->pixels, &ea->okay);
    ea->cancel.x = 45;
    ea->cancel.y = 0;
    ea->cancel.format = ButtonLabelLeft;
    ea->cancel.str = "Cancel";
    ReserveSylButton(ea->disp, ea->console, XLoadFont(ea->disp, "variable"),
	CopyFromParent, ea->pixels, &ea->cancel);

    ea->source = XCreatePixmap(ea->disp, DefaultRootWindow(ea->disp),
        DEFAULT_WIDTH, DEFAULT_HEIGHT,
        DefaultDepth(ea->disp, DefaultScreen(ea->disp)));
    ea->gc = XCreateGC(ea->disp, ea->main, 0, NULL);
    ea->is_grabbed_grid = False;
    ea->is_grabbed_main = False;

    CreateArrowGrids(ea);
    DrawColorArrow(ea);
    return (ea);
}

void
PutbackEditArrow(EditArrow *ea)
{
    PutbackSylButton(&ea->okay);
    PutbackSylButton(&ea->cancel);
    PutbackArrowGrids(ea);
    XDestroyWindow(ea->disp, ea->main);
    XDestroyWindow(ea->disp, ea->base);
    XFreePixmap(ea->disp, ea->source);
    XFreeGC(ea->disp, ea->gc);
    free(ea->point);
    free(ea);
}

static void
SendArrowGrid(EditArrow *ea, XEvent *ev, int n)
{
    Window child;
    int x, y, m = GRID_UNIT - 1;

    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != ea->grid_window[n] || ev->xexpose.count)
	    break;
	XSetForeground(ea->disp, ea->gc, ea->pixels[0]);
	XDrawPoint(ea->disp, ea->grid_window[n], ea->gc, 0, 0);
	XSetForeground(ea->disp, ea->gc, ea->pixels[5]);
	XDrawPoint(ea->disp, ea->grid_window[n], ea->gc, m, m);
	XSetForeground(ea->disp, ea->gc, ea->pixels[1]);
	XDrawLine(ea->disp, ea->grid_window[n], ea->gc, 1, 0, m - 1, 0);
	XDrawLine(ea->disp, ea->grid_window[n], ea->gc, 0, 1, 0, m - 1);
	XSetForeground(ea->disp, ea->gc, ea->pixels[4]);
	XDrawLine(ea->disp, ea->grid_window[n], ea->gc, 1, m, m - 1, m);
	XDrawLine(ea->disp, ea->grid_window[n], ea->gc, m, 1, m, m - 1);
	break;
    case ButtonPress:
	if (ev->xbutton.window != ea->grid_window[n])
            break;
	XGrabPointer(ea->disp, ea->grid_window[n], False,
	    ButtonMotionMask | PointerMotionMask | ButtonReleaseMask,
            GrabModeAsync, GrabModeSync, ea->main, None, ev->xbutton.time);
	ea->is_grabbed_grid = True;
	ea->grabbed_grid_window = ea->grid_window[n];
	ea->grabbed_point = &ea->point[n];
	ea->grabbed_offset_x = ev->xbutton.x; 
	ea->grabbed_offset_y = ev->xbutton.y; 
	break;
    case MotionNotify:
        if (ea->is_grabbed_grid == False
	    || ea->grabbed_grid_window != ea->grid_window[n])
            break;
	XTranslateCoordinates(ea->disp, ea->grabbed_grid_window, ea->main,
	    ev->xmotion.x, ev->xmotion.y, &x, &y, &child);
	x -= ea->grabbed_offset_x;
	y -= ea->grabbed_offset_y;
	XMoveWindow(ea->disp, ea->grabbed_grid_window, x, y);
	ea->grabbed_point->x = x + GRID_RADIUS;
	ea->grabbed_point->y = y + GRID_RADIUS;
	DrawColorArrow(ea);
	break;
    case ButtonRelease:
	if (ea->is_grabbed_grid == False
	    || ea->grabbed_grid_window != ea->grid_window[n])
	    break;
	XUngrabPointer(ea->disp, ev->xbutton.time);
	ea->is_grabbed_grid = False;
	break;
    }
}

int
SendEditArrow(EditArrow *ea, XEvent *ev)
{
    int n;

    if (IsWMCloseMessage(ev) && ev->xclient.window == ea->base)
	return (1);
    if (SendSylButton(&ea->cancel, ev))
	return (1);
    if (SendSylButton(&ea->okay, ev)) {
	SaveEditArrow(ea);
	return (1);
    }
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != ea->main)
	    break;
	XCopyArea(ea->disp, ea->source, ea->main, ea->gc,
	    ev->xexpose.x, ev->xexpose.y,
            ev->xexpose.width, ev->xexpose.height,
	    ev->xexpose.x, ev->xexpose.y);
	break;
    case ButtonPress:
	if (ev->xbutton.window != ea->main)
            break;
	XGrabPointer(ea->disp, ea->main, False, ButtonReleaseMask,
            GrabModeAsync, GrabModeSync, ea->main, None, ev->xbutton.time);
	ea->is_grabbed_main = True;
	for (n = 0; n < ea->n_inputs; ++n)
	    XUnmapWindow(ea->disp, ea->grid_window[n]);
	break;
    case ButtonRelease:
	if (ea->is_grabbed_main == False || ev->xbutton.window != ea->main)
	    break;
	XUngrabPointer(ea->disp, ev->xbutton.time);
	ea->is_grabbed_main = False;
	for (n = 0; n < ea->n_inputs; ++n)
	    XMapWindow(ea->disp, ea->grid_window[n]);
	break;
    }
    for (n = 0; n < ea->n_inputs; ++n)
	SendArrowGrid(ea, ev, n);
    return (0);
}

#if 0
char **GlobalAv;
int GlobalAc;

#define DEFAULT_COLOR_WHITE       "gray100"
#define DEFAULT_COLOR_LIGHT_GRAY  "gray85"
#define DEFAULT_COLOR_MEDIUM_GRAY "gray70"
#define DEFAULT_COLOR_DIM_GRAY    "gray50"
#define DEFAULT_COLOR_DARK_GRAY   "gray30"
#define DEFAULT_COLOR_BLACK       "gray0"
#define DEFAULT_COLOR_ILLUMINATED "blue"

#define LABEL_WHITE       "White"
#define LABEL_LIGHT_GRAY  "LightGray"
#define LABEL_MEDIUM_GRAY "MediumGray"
#define LABEL_DIM_GRAY    "DimGray"
#define LABEL_DARK_GRAY   "DarkGray"
#define LABEL_BLACK       "Black"
#define LABEL_ILLUMINATED "Illuminated"

static int MainPower = 1;
static Display *Disp;
static unsigned long MenuPixels[7];

typedef struct {
    char *name;
    char *color;
} ColorSet;

static ColorSet White = {LABEL_WHITE, DEFAULT_COLOR_WHITE};
static ColorSet LightGray = {LABEL_LIGHT_GRAY, DEFAULT_COLOR_LIGHT_GRAY};
static ColorSet MediumGray = {LABEL_MEDIUM_GRAY, DEFAULT_COLOR_MEDIUM_GRAY};
static ColorSet DimGray = {LABEL_DIM_GRAY, DEFAULT_COLOR_DIM_GRAY};
static ColorSet DarkGray = {LABEL_DARK_GRAY, DEFAULT_COLOR_DARK_GRAY};
static ColorSet Black = {LABEL_BLACK, DEFAULT_COLOR_BLACK};
static ColorSet Illuminated = {LABEL_ILLUMINATED, DEFAULT_COLOR_ILLUMINATED};
static ColorSet *AllColors[] = {&White, &LightGray, &MediumGray, &DimGray,
    &DarkGray, &Black, &Illuminated, NULL};

static void
LoadColorset(ColorSet **cs, unsigned long *pm)
{
    Colormap cmap;
    XColor color;

    cmap = DefaultColormap(Disp, DefaultScreen(Disp));
    for (; *cs != NULL; ++cs) {
	if (XParseColor(Disp, cmap, (*cs)->color, &color) == 0) {
	    fprintf(stderr, "%s: %s \"%s\" is not available.\n",
		    GlobalAv[0], (*cs)->name, (*cs)->color);
	    exit(1);
	}
	else if (XAllocColor(Disp, cmap, &color) == 0) {
	    fprintf(stderr, "%s: no available color cell for %s.\n",
		    GlobalAv[0], (*cs)->name);
	    exit(1);
	}
	*pm++ = color.pixel;
    }
}

static void
WindowMain(XEvent *ev)
{
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
    }
}

void
main(int ac, char **av)
{
    int n;
    XEvent ev;
    ColorSet **cs = AllColors;
    EditArrow *ea;
    Vector2d ArrowSource[7] = {{1, 0}, {0, 1}, {-1, 0}, {-0.5, 0},
        {-0.5, -0.8660254}, {0.5, -0.8660254}, {0.5, 0}};

    GlobalAc = ac;
    GlobalAv = av;
    if ((Disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    LoadColorset(cs, MenuPixels);

    ea = ReserveEditArrow(Disp, MenuPixels, ArrowSource, 7, 100,
	"edit arrow pattern");
    while (MainPower) {
	XNextEvent(Disp, &ev);
	WindowMain(&ev);
	if (SendEditArrow(ea, &ev))
	    break;
    }
    PutbackEditArrow(ea);
    for (n = 0; n < 7; ++n)
	printf("%8.7f %8.7f\n", ArrowSource[n].x, ArrowSource[n].y);
    XCloseDisplay(Disp);
    exit(0);
}
#endif
