/*
       colorarrow.c 1.0 for X11R6 & GNU C Compiler

       Copyright (C) 1997 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <math.h>

#include "HScrollbar.h"
#include "property.h"

char **GlobalAv;
int GlobalAc;

#define DEFAULT_WIDTH 300
#define DEFAULT_HEIGHT 300
#define DEFAULT_RANGE ((DEFAULT_WIDTH) * 4)
#define DEFAULT_BEGIN (((DEFAULT_RANGE) - (DEFAULT_WIDTH)) / 2)

#define DEFAULT_COLOR_WHITE       "gray100"
#define DEFAULT_COLOR_LIGHT_GRAY  "gray85"
#define DEFAULT_COLOR_MEDIUM_GRAY "gray70"
#define DEFAULT_COLOR_DIM_GRAY    "gray50"
#define DEFAULT_COLOR_DARK_GRAY   "gray30"
#define DEFAULT_COLOR_BLACK       "gray0"

#define LABEL_WHITE       "White"
#define LABEL_LIGHT_GRAY  "LightGray"
#define LABEL_MEDIUM_GRAY "MediumGray"
#define LABEL_DIM_GRAY    "DimGray"
#define LABEL_DARK_GRAY   "DarkGray"
#define LABEL_BLACK       "Black"

typedef struct {
    char *name;
    char *color;
} ColorSet;

static int MainPower = 1;
static Display *Disp;
static unsigned long MenuPixels[7];
static int BaseWindowWidth = DEFAULT_WIDTH;
static int BaseWindowHeight = DEFAULT_HEIGHT + HSCBARSEP + HSCBARHEIGHT;
static Window BaseWindow;
static Window MainWindow;
static Pixmap MainSource;
static GC gc;
static int ArrowRadius = 100 - 1;

static ColorSet White = {LABEL_WHITE, DEFAULT_COLOR_WHITE};
static ColorSet LightGray = {LABEL_LIGHT_GRAY, DEFAULT_COLOR_LIGHT_GRAY};
static ColorSet MediumGray = {LABEL_MEDIUM_GRAY, DEFAULT_COLOR_MEDIUM_GRAY};
static ColorSet DimGray = {LABEL_DIM_GRAY, DEFAULT_COLOR_DIM_GRAY};
static ColorSet DarkGray = {LABEL_DARK_GRAY, DEFAULT_COLOR_DARK_GRAY};
static ColorSet Black = {LABEL_BLACK, DEFAULT_COLOR_BLACK};
static ColorSet *AllColors[] = {&White, &LightGray, &MediumGray, &DimGray,
    &DarkGray, &Black, NULL};

static void
LoadColorset(ColorSet **cs, unsigned long *pm)
{
    Colormap cmap;
    XColor color;

    cmap = DefaultColormap(Disp, DefaultScreen(Disp));
    for (; *cs != NULL; ++cs) {
	if (XParseColor(Disp, cmap, (*cs)->color, &color) == 0) {
	    fprintf(stderr, "%s: %s \"%s\" is not available.\n",
		    GlobalAv[0], (*cs)->name, (*cs)->color);
	    exit(1);
	}
	else if (XAllocColor(Disp, cmap, &color) == 0) {
	    fprintf(stderr, "%s: no available color cell for %s.\n",
		    GlobalAv[0], (*cs)->name);
	    exit(1);
	}
	*pm++ = color.pixel;
    }
}

static Cursor
CreateNullCursor(Display *disp)
{
    static unsigned char bit[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    Pixmap p;
    XColor exact, white;
    Colormap cmap;
    Cursor c;

    cmap = DefaultColormap(disp, DefaultScreen(disp));
    XAllocNamedColor(disp, cmap, "white", &exact, &white);
    p = XCreateBitmapFromData(disp, DefaultRootWindow(disp), bit, 16, 16);
    c = XCreatePixmapCursor(Disp, p, p, &white, &white, 0, 0);
    XFreePixmap(disp, p);
    return (c);
}

static XColor ColorCells[128 + 1];

static int
AllocColormap(void)
{
    Colormap cmap;
    int n, m;

    cmap = DefaultColormap(Disp, DefaultScreen(Disp));
    for (n = 0; n < 32; ++n) {
	m = n;
	ColorCells[m].red = 0xffff;
	ColorCells[m].green = (short)(((double)n / 32) * 0xffff);
	ColorCells[m].blue = 0x0000;
	if (XAllocColor(Disp, cmap, &ColorCells[m]) == 0)
	    return (1);
    }
    for (n = 0; n < 32; ++n) {
	m = n + 32;
	ColorCells[m].red = 0xffff - (short)(((double)n / 32) * 0xffff);
	ColorCells[m].green = 0xffff;
	ColorCells[m].blue = 0x0000;
	if (XAllocColor(Disp, cmap, &ColorCells[m]) == 0)
	    return (1);
    }
    for (n = 0; n < 16; ++n) {
	m = n + 64;
	ColorCells[m].red = 0x0000;
	ColorCells[m].green = 0xffff;
	ColorCells[m].blue = (short)(((double)n / 16) * 0xffff);
	if (XAllocColor(Disp, cmap, &ColorCells[m]) == 0)
	    return (1);
    }
    for (n = 0; n < 16; ++n) {
	m = n + 80;
	ColorCells[m].red = 0x0000;
	ColorCells[m].green = 0xffff - (short)(((double)n / 16) * 0xffff);
	ColorCells[m].blue = 0xffff;
	if (XAllocColor(Disp, cmap, &ColorCells[m]) == 0)
	    return (1);
    }
    for (n = 0; n <= 32; ++n) {
	m = n + 96;
	ColorCells[m].red = (short)(((double)n / 32) * 0x7fff);
	ColorCells[m].green = 0x0000;
	ColorCells[m].blue = 0xffff - (short)(((double)n / 32) * 0x7fff);
	if (XAllocColor(Disp, cmap, &ColorCells[m]) == 0)
	    return (1);
    }
    return (0);
}

typedef struct {
    double x, y;
} Vector2d;

static void
RotateVector2dIntoXPoint(Vector2d *p, int n, double r, double theta,
			 XPoint o, XPoint *q)
{
    int m;
    double rcostheta = r * cos(theta);
    double rsintheta = r * sin(theta);

    for (m = 0; m < n; ++p, ++q, ++m) {
	q->x = o.x + (short)(p->x * rcostheta - p->y * rsintheta);
	q->y = o.y - (short)(p->x * rsintheta + p->y * rcostheta);
    }
}

static void
DrawColorArrow(int n)
{
    int w;
    unsigned long pixel;
    double theta;
    Vector2d p[7] = {{1, 0}, {0, 1}, {-1, 0}, {-0.5, 0}, {-0.5, -0.8660254},
			 {0.5, -0.8660254}, {0.5, 0}};
    XPoint q[7], org = {DEFAULT_WIDTH / 2, DEFAULT_HEIGHT / 2};

    theta = ((w = DEFAULT_RANGE - DEFAULT_WIDTH) > 0) ? ((double)n / w) : 1.0;
    theta -= 0.5;
    pixel = (unsigned long)(fabs(theta) * 256.0);
    theta *= 2 * M_PI;
    RotateVector2dIntoXPoint(p, 7, ArrowRadius, theta, org, q);
    XSetForeground(Disp, gc, MenuPixels[0]);
    XFillRectangle(Disp, MainSource, gc, 0, 0, DEFAULT_WIDTH, DEFAULT_HEIGHT);
    XSetForeground(Disp, gc, ColorCells[pixel].pixel);
    XFillPolygon(Disp, MainSource, gc, q, 7, Complex, CoordModeOrigin);
    XCopyArea(Disp, MainSource, MainWindow, gc, 0, 0,
	DEFAULT_WIDTH, DEFAULT_HEIGHT, 0, 0);
}

static void
adjustcallback(int n)
{
    DrawColorArrow(n);
}

static void
scrollcallback(int n, int m)
{
    adjustcallback(n + m);
}

static void
WindowMain(XEvent *ev)
{
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
    case Expose:
	if (ev->xexpose.window != MainWindow)
	    break;
	XCopyArea(Disp, MainSource, MainWindow, gc,
            ev->xexpose.x, ev->xexpose.y, 
	    ev->xexpose.width, ev->xexpose.height,
	    ev->xexpose.x, ev->xexpose.y);
	break;
    }
}

void
main(int ac, char **av)
{
    SylHScrollbar *hsb;
    XEvent ev;
    ColorSet **cs = AllColors;
    Cursor unvisible;

    GlobalAc = ac;
    GlobalAv = av;
    if ((Disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    LoadColorset(cs, MenuPixels);
    if (AllocColormap())
        fprintf(stderr, "%s: cannot allocate all colors.\n", av[0]);
    unvisible = CreateNullCursor(Disp);
    BaseWindow = XCreateSimpleWindow(Disp, DefaultRootWindow(Disp), 0, 0,
        BaseWindowWidth, BaseWindowHeight, 1, MenuPixels[5], MenuPixels[2]);
    SetProperties(Disp, BaseWindow, "colorarrow", ac, av, BaseWindowWidth,
        BaseWindowHeight, BaseWindowWidth, BaseWindowHeight, 0, 0);
    XSelectInput(Disp, BaseWindow, StructureNotifyMask | KeyPressMask);
    XMapRaised(Disp, BaseWindow);

    MainWindow = XCreateSimpleWindow(Disp, BaseWindow, 0, 0,
        DEFAULT_WIDTH, DEFAULT_HEIGHT, 0, MenuPixels[5], MenuPixels[0]);
    XSelectInput(Disp, MainWindow, StructureNotifyMask | ExposureMask);
    XMapRaised(Disp, MainWindow);

    MainSource = XCreatePixmap(Disp, DefaultRootWindow(Disp), DEFAULT_WIDTH,
        DEFAULT_HEIGHT, DefaultDepth(Disp, DefaultScreen(Disp)));
    gc = XCreateGC(Disp, MainWindow, 0, NULL);
    DrawColorArrow(DEFAULT_BEGIN);

    hsb = ReserveSylHScrollbar(Disp, MainWindow, MenuPixels, unvisible,
	DEFAULT_BEGIN, DEFAULT_RANGE, 1, scrollcallback, adjustcallback);
    RewriteSylHScrollbar(hsb);

    while (MainPower) {
	XNextEvent(Disp, &ev);
	if (IsWMCloseMessage(&ev))
	    break;
	SendSylHScrollbar(hsb, &ev);
        WindowMain(&ev);
    }
    XDestroyWindow(Disp, BaseWindow);
    XCloseDisplay(Disp);
    exit(0);
}
