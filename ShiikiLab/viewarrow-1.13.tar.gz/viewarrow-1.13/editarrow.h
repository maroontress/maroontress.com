typedef struct {
    Display *disp;
    Window base;
    Window main;
    Window console;
    Pixmap source;
    GC gc;
    Window *grid_window;
    unsigned long *pixels;
    SylButton okay;
    SylButton cancel;

    Vector2d *input;
    int n_inputs;
    XPoint *point;
    int height;
    int width;
    int radius;

    int is_grabbed_grid;
    Window grabbed_grid_window;
    int grabbed_offset_x;
    int grabbed_offset_y;
    XPoint *grabbed_point;

    int is_grabbed_main;
} EditArrow;

EditArrow *ReserveEditArrow(Display *, unsigned long *, Vector2d *, int,
			    int, char *);
void PutbackEditArrow(EditArrow *);
int SendEditArrow(EditArrow *, XEvent *);
