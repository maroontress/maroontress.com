/*
 *      Button.c Version 1.1 for X11R6 & GNU C Compiler
 *
 *      Copyright (C) 1995, 1996 Syllabub
 *      Maroontress Fast Software.
 */

#define ButtonTopLeft 0x00
#define ButtonTopCenter 0x01
#define ButtonBoxCenter 0x02
#define ButtonHFill 0x04
#define ButtonLabelLeft 0x08

typedef struct {
    int x, y, format;
    char *str;
    Display *disp;
    Window win;
    GC gc;
    int	focus, pushed, enabled;
    int len, width, height;
    int textwidth, textheight, decent;
    unsigned long *pixel;
} SylButton;

void ReserveSylButton(Display *, Window, Font, Cursor, unsigned long *,
    SylButton *);
int SendSylButton(SylButton *, XEvent *);
void PutbackSylButton(SylButton *);
void SetSylButton(SylButton *);
void ResetSylButton(SylButton *);
void EnableSylButton(SylButton *);
void DisableSylButton(SylButton *);
