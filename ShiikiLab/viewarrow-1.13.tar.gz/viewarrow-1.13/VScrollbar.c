/*
       VScrollbar.c for X11R6 & GNU C Compiler

       Copyright (C) 1996 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>

#include "VScrollbar.h"

#define min(a, b) (((a) > (b)) ? (b) : (a))
#define max(a, b) (((a) < (b)) ? (b) : (a))

static int
HeightOfCatch(SylVScrollbar *vsb)
{
    return ((vsb->maxline > vsb->lines) ?
	max(vsb->height * vsb->lines / vsb->maxline, VSCBARHMIN)
	: vsb->height);
}

static Window
ParentWindow(Display *disp, Window window)
{
    Window root, parent, *childp;
    unsigned int children;

    if (XQueryTree(disp, window, &root, &parent, &childp, &children))
	XFree(childp);
    return (parent);
}

SylVScrollbar *
ReserveSylVScrollbar(Display *disp, Window window, unsigned long *pixels,
    Cursor cursor, int cur, int end, int parline,
    void (*scroll)(int, int), void (*adjust)(int))
{
    XWindowAttributes atr;
    SylVScrollbar *vsb;

    if ((vsb = (SylVScrollbar *)malloc(sizeof(SylVScrollbar))) == NULL)
	return (NULL);
    XGetWindowAttributes(disp, window, &atr);
    vsb->disp = disp;
    vsb->window = window;
    vsb->parent = ParentWindow(disp, window);
    vsb->current = cur;
    vsb->maxline = end;
    vsb->height = atr.height;
    vsb->lines = atr.height / parline;
    vsb->parline = parline;
    vsb->scroll = scroll;
    vsb->adjust = adjust;
    vsb->grabbed = False;
    vsb->bar = XCreateSimpleWindow(disp, vsb->parent,
        atr.x + atr.width + VSCBARSEP, atr.y,
        VSCBARWIDTH, atr.height, 0, pixels[5], pixels[3]);
    vsb->catch = XCreateSimpleWindow(disp, vsb->bar, 0, 0,
	VSCBARWIDTH, HeightOfCatch(vsb), 0, pixels[5], pixels[2]);
    vsb->cursor = cursor;
    vsb->pixels = pixels;
    vsb->gc = XCreateGC(disp, vsb->bar, 0, 0);
    XSetFunction(disp, vsb->gc, GXcopy);
    XSetLineAttributes(disp, vsb->gc, 0, LineSolid, CapButt, JoinMiter);

    XSelectInput(disp, vsb->bar, ExposureMask);
    XMapRaised(disp, vsb->bar);
    XSelectInput(disp, vsb->catch, ExposureMask
        | ButtonPressMask | ButtonReleaseMask);
    XMapRaised(disp, vsb->catch);
    return (vsb);
}

void 
PutbackSylVScrollbar(SylVScrollbar *vsb)
{
    if (vsb == NULL)
	return;
    XDestroyWindow(vsb->disp, vsb->catch);
    XDestroyWindow(vsb->disp, vsb->bar);
    XFreeGC(vsb->disp, vsb->gc);
    free(vsb);
}

static void
ExposeCatch(SylVScrollbar *vsb)
{
    int last = HeightOfCatch(vsb) - 1;

    XClearWindow(vsb->disp, vsb->catch);
    if (vsb->grabbed == True && vsb->button == 1) {
	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[1]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 2, 1, VSCBARWIDTH - 2, 1);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, 2, 1, last - 1);

	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[4]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 2, last,
		  VSCBARWIDTH - 1, last);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, VSCBARWIDTH - 1, 2,
		  VSCBARWIDTH - 1, last - 1);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, 0, VSCBARWIDTH - 1, 0);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 0, 1, 0, last);

	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[0]);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc, 1, 1);

	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[5]);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc, 0, 0);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc, VSCBARWIDTH - 1, last);
    }
    else {
	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[1]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, 0, VSCBARWIDTH - 3, 0);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 0, 1, 0, last - 2);
	
	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[4]);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 1, last - 1,
		  VSCBARWIDTH - 3, last - 1);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, VSCBARWIDTH - 2, 1,
		  VSCBARWIDTH - 2, last - 2);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, 0, last,
		  VSCBARWIDTH - 1, last);
	XDrawLine(vsb->disp, vsb->catch, vsb->gc, VSCBARWIDTH - 1, 0,
		  VSCBARWIDTH - 1, last - 1);

	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[0]);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc, 0, 0);
	
	XSetForeground(vsb->disp, vsb->gc, vsb->pixels[5]);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc, VSCBARWIDTH - 2, last - 1);
	XDrawPoint(vsb->disp, vsb->catch, vsb->gc, VSCBARWIDTH - 1, last);
    }
}

static int
RootYpointer(Display *disp)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, DefaultRootWindow(disp),
	&root, &child, &rx, &ry, &wx, &wy, &kb);
    return (ry);
}

static void
AdjustPointer(Display *disp, int newx, int newy)
{
    XWarpPointer(disp, None, DefaultRootWindow(disp), 0, 0, 0, 0, newx, newy);
}

static int
AdjustCatch(SylVScrollbar *vsb)
{
    int base, newy;
    XWindowAttributes atr;

    XGetWindowAttributes(vsb->disp, vsb->catch, &atr);
    base = vsb->maxline - vsb->lines;
    newy = ((base <= 0) ? 0 :
        (vsb->height - atr.height) * vsb->current / base);
    if (newy != atr.y)
	XMoveWindow(vsb->disp, vsb->catch, 0, newy);
    return (newy - atr.y);
}

static int
ScrollWindow(SylVScrollbar *vsb, int dif)
{
    int new;

    new = max(min(vsb->current + dif, vsb->maxline - vsb->lines), 0);
    dif = new - vsb->current;
    if (dif) {
	if (abs(dif) < vsb->lines)
	    vsb->scroll(vsb->current, dif);
	else
	    vsb->adjust(new);
	vsb->current = new;
    }
    return (dif);
}

void
ScrollSylVScrollbar(SylVScrollbar *vsb, int dif)
{
    if (vsb == NULL)
	return;
    if (ScrollWindow(vsb, dif)) {
	(void) AdjustCatch(vsb);
    }
}

void
JumpSylVScrollbar(SylVScrollbar *vsb, int new)
{
    if (vsb == NULL)
	return;
    vsb->current = max(min(new, vsb->maxline - vsb->lines), 0);
    vsb->adjust(vsb->current);
    (void) AdjustCatch(vsb);
}

void
RangeSylVScrollbar(SylVScrollbar *vsb, int newmax)
{
    if (vsb == NULL)
	return;
    vsb->maxline = newmax;
    XResizeWindow(vsb->disp, vsb->catch, VSCBARWIDTH, HeightOfCatch(vsb));
    (void) AdjustCatch(vsb);
}

static void
SmoothMotion(SylVScrollbar *vsb)
{
    int cury;

    if ((cury = RootYpointer(vsb->disp)) != vsb->orgy) {
        if (ScrollWindow(vsb, cury - vsb->orgy))
            vsb->orgy += AdjustCatch(vsb);
        AdjustPointer(vsb->disp, vsb->orgx, vsb->orgy);
    }
}

#if 0
static void
JumpMotion(SylVScrollbar *vsb)
{
    int diff, base, newy, cury, half;

    cury = RootYpointer(vsb->disp);
    base = vsb->height - HeightOfCatch(vsb);
    half = ((diff = cury - vsb->orgy) > 0) ? (base / 2) : -(base / 2);
    diff = (diff * (vsb->maxline - vsb->lines) + half) / base;
    (void) ScrollWindow(vsb, (vsb->orgc + diff) - vsb->current);
    newy = max(min(vsb->orgp + cury - vsb->orgy, base), 0);
    XMoveWindow(vsb->disp, vsb->catch, 0, newy);
}
#endif

static int
WindowYpointer(Display *disp, Window d)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, d, &root, &child, &rx, &ry, &wx, &wy, &kb);
    return (wy);
}

static void
JumpMotion(SylVScrollbar *vsb)
{
    int diff, base, cury;

    cury = WindowYpointer(vsb->disp, vsb->bar) - vsb->orgp;
    base = vsb->height - HeightOfCatch(vsb);
    diff = (cury * (vsb->maxline - vsb->lines) + base / 2) / base;
    (void) ScrollWindow(vsb, diff - vsb->current);
    XMoveWindow(vsb->disp, vsb->catch, 0, max(min(cury, base), 0));
}

static void
StepMotion(SylVScrollbar *vsb)
{
    int diff, base, cury;

    cury = RootYpointer(vsb->disp);
    base = (vsb->height - HeightOfCatch(vsb));
    diff = (cury - vsb->orgy) * (vsb->maxline - vsb->lines) / base;
    if (ScrollWindow(vsb, (vsb->orgc + diff) - vsb->current))
	(void) AdjustCatch(vsb);
}

#if 0
static int
CurrentCatch(SylVScrollbar *vsb)
{
    Window root;
    int x, y, w, h, b, d;

    XGetGeometry(vsb->disp, vsb->catch, &root, &x, &y, &w, &h, &b, &d);
    return (y);
}
#endif

void
SendSylVScrollbar(SylVScrollbar *vsb, XEvent *ev)
{
    if (vsb == NULL)
	return;
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.count == 0 && ev->xexpose.window == vsb->catch)
	    ExposeCatch(vsb);
	break;
    case ButtonPress:
	if (ev->xbutton.window != vsb->catch || vsb->maxline <= vsb->lines)
	    break;
	XGrabPointer(vsb->disp, vsb->catch, False,
	     ButtonMotionMask | PointerMotionHintMask | ButtonReleaseMask,
	     GrabModeAsync, GrabModeSync, DefaultRootWindow(vsb->disp),
	     None, ev->xbutton.time);
	vsb->grabbed = True;
	if ((vsb->button = ev->xbutton.button) == 1) {
	    XDefineCursor(vsb->disp, vsb->bar, vsb->cursor);
	    ExposeCatch(vsb);
	}
	vsb->orgc = vsb->current;
	vsb->orgx = ev->xbutton.x_root;
	vsb->orgy = ev->xbutton.y_root;
	vsb->orgp = ev->xbutton.y;
	break;
    case MotionNotify:
	if (vsb->grabbed != True)
	    break;
	if (vsb->button == 1)
	    SmoothMotion(vsb);
	else if (vsb->button == 2)
	    StepMotion(vsb);
	else
	    JumpMotion(vsb);
	break;
    case ButtonRelease:
	if (vsb->grabbed != True)
	    break;
	XUngrabPointer(vsb->disp, ev->xbutton.time);
	vsb->grabbed = False;
	if (vsb->button == 1) {
	    XUndefineCursor(vsb->disp, vsb->bar);
	    ExposeCatch(vsb);
	}
	else if (vsb->button == 3) {
	    AdjustCatch(vsb);
	}
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != vsb->window)
	    break;
	XMoveResizeWindow(vsb->disp, vsb->bar,
	    ev->xconfigure.x + ev->xconfigure.width + VSCBARSEP,
	    ev->xconfigure.y, VSCBARWIDTH, ev->xconfigure.height);
	vsb->height = ev->xconfigure.height;
	vsb->lines = vsb->height / vsb->parline;
	XResizeWindow(vsb->disp, vsb->catch, VSCBARWIDTH, HeightOfCatch(vsb));
	if (vsb->maxline - vsb->current < vsb->lines)
	    vsb->current = max(0, vsb->maxline - vsb->lines);
	vsb->adjust(vsb->current);
	(void) AdjustCatch(vsb);
	break;
    }
}
