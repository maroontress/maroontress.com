#include <stdio.h>

void
main(void)
{
    int n, m;

    for (n = 10; n > 0; --n) {
	for (m = -10; m <= -1; ++m)
	    printf("%d %d %d %d\n", m, n, m - 10 + n, n);
	printf("%d %d %d %d\n", 0, n, 0, 1);
	for (m = 1; m <= 10; ++m)
	    printf("%d %d %d %d\n", m, n, m + 10 - n, n);
    }

    for (n = 10; n > 0; --n) {
	for (m = -10; m <= -1; ++m)
	    printf("%d %d %d %d\n", m, -n, m - 10 + n, -n);
	printf("%d %d %d %d\n", 0, -n, 0, -1);
	for (m = 1; m <= 10; ++m)
	    printf("%d %d %d %d\n", m, -n, m + 10 - n, -n);
    }
}
