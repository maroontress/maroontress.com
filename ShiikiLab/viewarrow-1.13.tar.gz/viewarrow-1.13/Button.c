/*
 *      Button.c Version 1.1 for X11R6 & GNU C Compiler
 *
 *      Copyright (C) 1995, 1996 Syllabub
 *      Maroontress Fast Software.
 */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include "Button.h"

static char GrayOutMask[] = {0x55, 0xaa, 0x55, 0xaa, 0x55, 0xaa, 0x55, 0xaa};

#define WHITE (btn->pixel[0])
#define LGRAY (btn->pixel[1])
#define MGRAY (btn->pixel[2])
#define OGRAY (btn->pixel[3])
#define DGRAY (btn->pixel[4])
#define BLACK (btn->pixel[5])
#define FOCUS (btn->pixel[6])

#define BorderWidth 2
#define LabelHorSep 8
#define LabelVerSep 1
#define LeftMargin (BorderWidth + LabelHorSep)
#define TopMargin (BorderWidth + LabelVerSep)

void
ReserveSylButton(Display *disp, Window parent, Font font, Cursor curs,
    unsigned long *pixel, SylButton *btn)
{
    int dir, ascent, decent, xoffset;
    XCharStruct overall;
    XWindowAttributes winatr;

    btn->focus = 0;
    btn->pushed = 0;
    btn->enabled = 1;
    btn->pixel = pixel;
    btn->len = strlen(btn->str);
    btn->disp = disp;
    XQueryTextExtents(btn->disp, font, btn->str, btn->len,
	&dir, &ascent, &decent, &overall); 
    btn->textwidth = overall.width;
    btn->textheight = ascent + decent;
    btn->decent = decent;
    XGetWindowAttributes(btn->disp, parent, &winatr);
    btn->width = (btn->format & ButtonHFill)
	? winatr.width : btn->textwidth + (LeftMargin * 2);
    btn->height = btn->textheight + (TopMargin * 2);
    if (btn->format & ButtonBoxCenter)
	btn->x = (winatr.width - btn->width) / 2;
    xoffset = (btn->format & ButtonTopCenter) ? (btn->width / 2) : 0;
    btn->win = XCreateSimpleWindow(disp, parent, btn->x - xoffset, btn->y,
	btn->width, btn->height, 0, WHITE, MGRAY);
    btn->gc = XCreateGC(disp, btn->win, 0, 0);
    XSetFont(disp, btn->gc, font);
    XSetLineAttributes(disp, btn->gc, 0, LineSolid, CapButt, JoinMiter);
    XDefineCursor(disp, btn->win, curs);
    XSelectInput(disp, btn->win, ButtonPressMask | ButtonReleaseMask
	| EnterWindowMask | LeaveWindowMask | ExposureMask);
    XMapRaised(disp, btn->win);
}

void
PutbackSylButton(SylButton *btn)
{
    XFreeGC(btn->disp, btn->gc);
    XDestroyWindow(btn->disp, btn->win);
}

static void
DispLabel(SylButton *btn)
{
    Pixmap pattern;

    XSetFunction(btn->disp, btn->gc, GXcopy);
    if (DefaultDepth(btn->disp, DefaultScreen(btn->disp)) == 1) {
	XSetForeground(btn->disp, btn->gc, (btn->focus) ? WHITE : BLACK);
	XSetFillStyle(btn->disp, btn->gc, FillSolid);
	XFillRectangle(btn->disp, btn->win, btn->gc, BorderWidth, BorderWidth,
	    btn->width - (BorderWidth * 2), btn->textheight);
	XSetForeground(btn->disp, btn->gc, (btn->focus) ? BLACK : WHITE);
	XSetBackground(btn->disp, btn->gc, (btn->focus) ? WHITE : BLACK);
    }
    else {
	XSetForeground(btn->disp, btn->gc, (btn->focus) ? FOCUS : BLACK);
	XSetBackground(btn->disp, btn->gc, MGRAY);
    }
    pattern = XCreateBitmapFromData(btn->disp, btn->win, GrayOutMask, 8, 8);
    XSetStipple(btn->disp, btn->gc, pattern);
    XSetFillStyle(btn->disp, btn->gc,
	(btn->enabled) ? FillSolid : FillOpaqueStippled);
    XDrawString(btn->disp, btn->win, btn->gc,
        (btn->width - btn->textwidth) / 2, 
	TopMargin + btn->textheight - btn->decent, btn->str, btn->len);
    XFreePixmap(btn->disp, pattern);
}

static void
DispFrame(SylButton *btn)
{
    int	xtail = btn->width - BorderWidth, ytail = btn->height - BorderWidth;
    Pixmap pattern;

    pattern = XCreateBitmapFromData(btn->disp, btn->win, GrayOutMask, 8, 8);
    XSetStipple(btn->disp, btn->gc, pattern);
    XSetFillStyle(btn->disp, btn->gc,
	(btn->enabled) ? FillSolid : FillOpaqueStippled);
    XSetFunction(btn->disp, btn->gc, GXcopy);
    XSetForeground(btn->disp, btn->gc, (btn->pushed) ? DGRAY : LGRAY);
    XDrawLine(btn->disp, btn->win, btn->gc, 1, 0, xtail, 0);
    XDrawLine(btn->disp, btn->win, btn->gc, 2, 1, xtail - 1, 1);
    XDrawLine(btn->disp, btn->win, btn->gc, 0, 1, 0, ytail);
    XDrawLine(btn->disp, btn->win, btn->gc, 1, 2, 1, ytail - 1);
    XSetForeground(btn->disp, btn->gc, (btn->pushed) ? LGRAY : DGRAY);
    XDrawLine(btn->disp, btn->win, btn->gc, 2, ytail, xtail - 1, ytail);
    XDrawLine(btn->disp, btn->win, btn->gc, 1, ytail + 1, xtail, ytail + 1);
    XDrawLine(btn->disp, btn->win, btn->gc, xtail, 2, xtail, ytail - 1);
    XDrawLine(btn->disp, btn->win, btn->gc, xtail + 1, 1, xtail + 1, ytail);
    XSetForeground(btn->disp, btn->gc, (btn->pushed) ? BLACK : WHITE);
    XDrawPoint(btn->disp, btn->win, btn->gc, 0, 0);
    XDrawPoint(btn->disp, btn->win, btn->gc, 1, 1);
    XSetForeground(btn->disp, btn->gc, (btn->pushed) ? WHITE : BLACK);
    XDrawPoint(btn->disp, btn->win, btn->gc, xtail, ytail);
    XDrawPoint(btn->disp, btn->win, btn->gc, xtail + 1, ytail + 1);
    XFreePixmap(btn->disp, pattern);
}

void
SetSylButton(SylButton *btn)
{
    if (btn->pushed)
	return;
    btn->pushed = 1;
    DispFrame(btn);
}

void
ResetSylButton(SylButton *btn)
{
    if (! btn->pushed)
	return;
    btn->pushed = 0;
    DispFrame(btn);
}

void
EnableSylButton(SylButton *btn)
{
    if (btn->enabled)
	return;
    btn->enabled = 1;
    DispFrame(btn);
    DispLabel(btn);
}

void
DisableSylButton(SylButton *btn)
{
    if (! btn->enabled)
	return;
    btn->enabled = 0;
    DispFrame(btn);
    DispLabel(btn);
}

int
SendSylButton(SylButton *btn, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
        if (ev->xexpose.count != 0 || ev->xexpose.window != btn->win)
	    break;
	DispFrame(btn);
	DispLabel(btn);
        break;
    case EnterNotify:
        if (ev->xcrossing.window != btn->win)
	    break;
	btn->focus = 1;
	DispLabel(btn);
	break;
    case LeaveNotify:
        if (ev->xcrossing.window != btn->win)
	    break;
	btn->focus = 0;
	DispLabel(btn);
	break;
    case ButtonPress:
        if (ev->xbutton.window != btn->win || ! btn->enabled)
	    break;
        XGrabPointer(btn->disp, btn->win, False, ButtonReleaseMask
	     | EnterWindowMask | LeaveWindowMask, GrabModeAsync, GrabModeSync,
	     DefaultRootWindow(btn->disp), None, ev->xbutton.time);
	btn->pushed = 1;
	DispFrame(btn);
	break;
    case ButtonRelease:
	if (btn->pushed == 0)
	    break;
        XUngrabPointer(btn->disp, ev->xbutton.time);
	btn->pushed = 0;
	DispFrame(btn);
	if (btn->focus == 1)
	    return (1);
	break;
    }
    return (0);
}
