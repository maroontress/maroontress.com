/*
       dataset.c 1.2 for X11R6 & GNU C Compiler

       Copyright (C) 1997, 1998 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "HScrollbar.h"
#include "VScrollbar.h"
#include "dataset.h"

static void
RotateVector2dIntoXPoint(Vector2d *p, int n, double r, double theta,
			 XPoint o, XPoint *q)
{
    int m;
    double rcostheta = r * cos(theta);
    double rsintheta = r * sin(theta);

    for (m = 0; m < n; ++p, ++q, ++m) {
	q->x = o.x + (short)(p->x * rcostheta - p->y * rsintheta);
	q->y = o.y - (short)(p->x * rsintheta + p->y * rcostheta);
    }
}

void
DrawDataSet(DataSet *ds)
{
    int pixel;
    double theta;
    XPoint *q, org;
    Data *ptr;

    if ((q = alloca(ds->n_grids * sizeof(XPoint))) == NULL)
	return;
    XSetForeground(ds->disp, ds->gc, ds->pixels[0]);
    XFillRectangle(ds->disp, ds->pixmap, ds->gc, 0, 0, ds->w, ds->h);
    for (ptr = ds->top; ptr != NULL; ptr = ptr->next) {
	org.x = (ptr->x - ds->min_x) * ds->unit * 2;
	org.y = ds->h - (ptr->y - ds->min_y) * ds->unit * 2;
	org.x += ds->unit;
	org.y -= ds->unit;
	theta = ptr->theta;
	pixel = (unsigned long)(ptr->color_theta * 128.0 / M_PI);
	RotateVector2dIntoXPoint(ds->grid, ds->n_grids, ds->radius, theta,
	    org, q);
	XSetForeground(ds->disp, ds->gc, ds->colors[pixel].pixel);
	XFillPolygon(ds->disp, ds->pixmap, ds->gc, q, ds->n_grids, Complex,
	    CoordModeOrigin);
	XDrawLines(ds->disp, ds->pixmap, ds->gc, q, ds->n_grids,
	    CoordModeOrigin);
    }
    XCopyArea(ds->disp, ds->pixmap, ds->window, ds->gc,
        ds->offset_x, ds->offset_y, ds->w, ds->h, 0, 0);
}

DataSet *
CreateDataSet(Display *disp, XColor *colors, int dir, int unit, int radius,
	      Vector2d *grid, int n_grids)
{
    DataSet *ds;
    
    if (dir != FromNorthToSouth && dir != FromEastToWest)
	return (NULL);
    if ((ds = (DataSet *)malloc(sizeof(DataSet))) == NULL)
        return (NULL);
    ds->top = NULL;
    ds->last = NULL;
    ds->disp = disp;
    ds->colors = colors;
    ds->direction = dir;
    ds->unit = unit;
    ds->radius = radius;
    if ((ds->grid = (Vector2d *)malloc(sizeof(Vector2d) * n_grids)) == NULL) {
	free(ds);
	return (NULL);
    }
    memcpy(ds->grid, grid, sizeof(Vector2d) * n_grids);
    ds->n_grids = n_grids;
    return (ds);
}

void
ChangePropertyDataSet(DataSet *ds, Vector2d *grid)
{
    memcpy(ds->grid, grid, sizeof(Vector2d) * ds->n_grids);
}

static Data *
CopyDataSet(DataSet *ds, int x, int y, double vx, double vy)
{
    Data *copy;
    double theta;

    if ((copy = (Data *)malloc(sizeof(Data))) == NULL)
        return (NULL);
    copy->x = x;
    copy->y = y;
    copy->vx = vx;
    copy->vy = vy;
    theta = acos(vy / sqrt(vx * vx + vy * vy)); /* [0, pi] */
    copy->theta = -((copy->vx > 0) ? theta : -theta);
    if (ds->direction == FromNorthToSouth)
	copy->color_theta = fabs(copy->theta);
    else if (ds->direction == FromEastToWest)
	copy->color_theta = acos(vx / sqrt(vx * vx + vy * vy)); /* [0, pi] */
    copy->next = NULL;

    if (ds->top == NULL)
        ds->top = copy;
    else
        ds->last->next = copy;
    ds->last = copy;
    return (copy);
}

static void
LookupSize(Data *p, int *min_x, int *min_y, int *max_x, int *max_y)
{
    *min_x = p->x;
    *min_y = p->y;
    *max_x = p->x;
    *max_y = p->y;
    for (p = p->next; p != NULL; p = p->next) {
	if (p->x > *max_x)
	    *max_x = p->x;
	else if (p->x < *min_x)
	    *min_x = p->x;

	if (p->y > *max_y)
            *max_y = p->y;
	else if (p->y < *min_y)
            *min_y = p->y;
    }
}

void
LoadDataSet(DataSet *ds, char *file)
{
    FILE *fp;
    int n, x, y;
    double vx, vy;

    if (strcmp(file, "-") == 0) {
	fp = stdin;
	file = "stdin";
    }
    else if ((fp = fopen(file, "r")) == NULL) {
	perror(file);
	exit(1);
    }
    while ((n = fscanf(fp, "%d %d %lf %lf", &x, &y, &vx, &vy)) == 4) {
	if (CopyDataSet(ds, x, y, vx, vy) == NULL) {
	    fprintf(stderr, "%s: too short memory\n", file);
	    exit(1);
	}
    }
    if (n >= 0) {
	printf("%d\n", n);
	fprintf(stderr, "%s: invalid data alignment\n", file);
	exit(1);
    }
    if (ds->top == NULL) {
	fprintf(stderr, "%s: empty data\n", file);
	exit(1);
    }
    LookupSize(ds->top, &ds->min_x, &ds->min_y, &ds->max_x, &ds->max_y);
    ds->w = (ds->max_x - ds->min_x + 1) * ds->unit * 2;
    ds->h = (ds->max_y - ds->min_y + 1) * ds->unit * 2;
}

static Cursor
CreateNullCursor(Display *disp)
{
    static unsigned char bit[] = {
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    Pixmap p;
    XColor exact, white;
    Colormap cmap;
    Cursor c;

    cmap = DefaultColormap(disp, DefaultScreen(disp));
    XAllocNamedColor(disp, cmap, "white", &exact, &white);
    p = XCreateBitmapFromData(disp, DefaultRootWindow(disp), bit, 16, 16);
    c = XCreatePixmapCursor(disp, p, p, &white, &white, 0, 0);
    XFreePixmap(disp, p);
    return (c);
}

static int
WidthOfWindow(int w, int h, int dw, int dh)
{
    if (w >= dw)
        return ((h >= dh) ? (w) : (w - VSCBARSEP - VSCBARWIDTH));
    else
	return ((h >= dh + HSCBARSEP + HSCBARHEIGHT) ?
		(w) : (w - VSCBARSEP - VSCBARWIDTH));
}

static int
HeightOfWindow(int w, int h, int dw, int dh)
{
    if (h >= dh)
        return ((w >= dw) ? (h) : (h - HSCBARSEP - HSCBARHEIGHT));
    else
        return ((w >= dw + VSCBARSEP + VSCBARWIDTH) ?
		(h) : (h - HSCBARSEP - HSCBARHEIGHT));
}

static void
GetWindowLocationAndSize(DataSet *ds, int *x, int *y, int *w, int *h)
{
    int margin, head, tail;
    XWindowAttributes atrs;

    XGetWindowAttributes(ds->disp, ds->parent, &atrs);
    *w = WidthOfWindow(atrs.width, atrs.height, ds->w, ds->h);
    *h = HeightOfWindow(atrs.width, atrs.height, ds->w, ds->h);
    if (*w >= ds->w && *h >= ds->h) {
	*x = (atrs.width - ds->w) / 2;
	*y = (atrs.height - ds->h) / 2;
    }
    else if (*w >= ds->w) {
	margin = (atrs.width - ds->w - VSCBARSEP - VSCBARWIDTH);
	head = margin / 2;
	tail = margin - head;
	*x = head;
	*w -= tail;
	*y = 0;
    }
    else if (*h >= ds->h) {
	margin = (atrs.height - ds->h - HSCBARSEP - HSCBARHEIGHT);
	head = margin / 2;
	tail = margin - head;
	*x = 0;
	*y = head;
	*h -= tail;
    }
    else {
	*x = 0;
	*y = 0;
    }
    ds->width = *w;
    ds->height = *h;
}

static DataSet *callback_ds = NULL;

static void
vadjustcallback(int n)
{
    callback_ds->offset_y = n;
    XCopyArea(callback_ds->disp, callback_ds->pixmap, callback_ds->window,
        callback_ds->gc, callback_ds->offset_x, callback_ds->offset_y,
        callback_ds->width, callback_ds->height, 0, 0);
}

static void
vscrollcallback(int n, int m)
{
    vadjustcallback(n + m);
}

static void
hadjustcallback(int n)
{
    callback_ds->offset_x = n;
    XCopyArea(callback_ds->disp, callback_ds->pixmap, callback_ds->window,
        callback_ds->gc, callback_ds->offset_x, callback_ds->offset_y,
        callback_ds->width, callback_ds->height, 0, 0);
}

static void
hscrollcallback(int n, int m)
{
    hadjustcallback(n + m);
}

void
ReserveDataSet(DataSet *ds, Window parent, unsigned long *pixels)
{
    int x, y, w, h;
    Cursor unvisible;

    ds->parent = parent;
    ds->pixels = pixels;
    ds->gc = XCreateGC(ds->disp, parent, 0, NULL);
    ds->pixmap = XCreatePixmap(ds->disp, DefaultRootWindow(ds->disp),
	ds->w, ds->h, DefaultDepth(ds->disp, DefaultScreen(ds->disp)));
    GetWindowLocationAndSize(ds, &x, &y, &w, &h);
    ds->window = XCreateSimpleWindow(ds->disp, ds->parent, x, y,
	w, h, 0, pixels[5], pixels[2]);
    XSelectInput(ds->disp, ds->window, ExposureMask | StructureNotifyMask);
    XMapRaised(ds->disp, ds->window);
    unvisible = CreateNullCursor(ds->disp);
    ds->offset_x = 0;
    ds->offset_y = 0;
    ds->vsb = ReserveSylVScrollbar(ds->disp, ds->window, pixels, unvisible,
	ds->offset_x, ds->h, 1, vscrollcallback, vadjustcallback);
    ds->hsb = ReserveSylHScrollbar(ds->disp, ds->window, pixels, unvisible,
	ds->offset_y, ds->w, 1, hscrollcallback, hadjustcallback);
}

void
SendDataSet(DataSet *ds, XEvent *ev)
{
    int x, y, w, h;

    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != ds->window)
	    break;
 	XCopyArea(ds->disp, ds->pixmap, ds->window, ds->gc,
	    ds->offset_x + ev->xexpose.x, ds->offset_y + ev->xexpose.y, 
	    ev->xexpose.width, ev->xexpose.height,
            ev->xexpose.x, ev->xexpose.y);
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != ds->parent)
	    break;
	GetWindowLocationAndSize(ds, &x, &y, &w, &h);
	XMoveResizeWindow(ds->disp, ds->window, x, y, w, h);
	break;
    }
    callback_ds = ds;
    SendSylVScrollbar(ds->vsb, ev);
    SendSylHScrollbar(ds->hsb, ev);
}

static void
PrintPSHeader(double tx, double ty, double sw, double sh, FILE *fp)
{
    fprintf(fp,
	    "%%!\n"
	    "%%%%BoundingBox: %f %f %f %f\n"
	    "%%%%EndComments\n",
	    tx, ty, tx + sw, ty + sh);
    fprintf(fp,
	    "\n"
	    "/fillGrayPath {\n"
	    "\t" "gsave\n"
	    "\t\t" "fill\n"
	    "\t" "grestore\n"
	    "\t" "stroke\n"
	    "} def\n"
	    "\n"
	    "/fillColorPath {\n"
	    "\t" "setrgbcolor\n"
	    "\t" "gsave\n"
	    "\t\t" "fill\n"
	    "\t" "grestore\n"
	    "\t" "stroke\n"
	    "} def\n");
}

static void
PrintPSArrow(DataSet *ds, FILE *fp)
{
    int n;

    fprintf(fp,
	    "\n"
	    "/makeArrowPath {\n"
	    "\t" "%d %d translate\n"
	    "\t" "%d %d scale\n"
	    "\t" "rotate\n"
	    "\t" "newpath\n"
	    "\t" "%f %f moveto\n",
	    ds->unit, ds->unit,
	    ds->radius, ds->radius,
	    ds->grid[0].x, ds->grid[0].y);
    for (n = 1; n < ds->n_grids; ++n)
	fprintf(fp, "\t" "%f %f lineto\n", ds->grid[n].x, ds->grid[n].y);
    fprintf(fp,
	    "\t" "closepath\n"
	    "} def\n");
}

static void
PrintTrail(FILE *fp)
{
}

void
PrintEPSDataSet(DataSet *ds, FILE *fp)
{
    int x, y;
    double tx, ty, sw, sh, scale, theta;
    Data *ptr;
    
    if (ds->w > ds->h) {
	scale = 432.0 / ds->w;
	sw = 432.0;
	sh = scale * ds->h;
    }
    else {
	scale = 432.0 / ds->h;
	sw = scale * ds->w;
	sh = 432.0;
    }
    tx = (598.0 - sw) / 2;
    ty = (842.0 - sh) / 2;
    
    PrintPSHeader(tx, ty, sw, sh, fp);
    PrintPSArrow(ds, fp);
    fprintf(fp,
	    "\n"
	    "%f %f translate %f %f scale\n"
	    "0 setgray 0 setlinewidth\n",
	    tx, ty, scale, scale);
    PrintTrail(fp);
    for (ptr = ds->top; ptr != NULL; ptr = ptr->next) {
	x = (ptr->x - ds->min_x) * ds->unit * 2;
	y = (ptr->y - ds->min_y) * ds->unit * 2;
	theta = ptr->theta;
	theta *= (180.0 / M_PI); /* [-180, 180] */
	fprintf(fp,
		"\n"
		"gsave\n"
		"\t" "%d %d translate\n"
		"\t" "%f makeArrowPath\n"
		"\t" "fillGrayPath\n"
		"grestore\n",
		x, y, theta);
    }
    PrintTrail(fp);
}

void
PrintEPSColorDataSet(DataSet *ds, FILE *fp)
{
    int x, y;
    unsigned long pixel;
    double tx, ty, sw, sh, scale, theta;
    Data *ptr;

    if (ds->w > ds->h) {
	scale = 432.0 / ds->w;
	sw = 432.0;
	sh = scale * ds->h;
    }
    else {
	scale = 432.0 / ds->h;
	sw = scale * ds->w;
	sh = 432.0;
    }
    tx = (598.0 - sw) / 2;
    ty = (842.0 - sh) / 2;

    PrintPSHeader(tx, ty, sw, sh, fp);
    PrintPSArrow(ds, fp);
    fprintf(fp,
	    "\n"
	    "%f %f translate %f %f scale\n"
	    "0 setlinewidth\n",
	    tx, ty, scale, scale);
    PrintTrail(fp);
    for (ptr = ds->top; ptr != NULL; ptr = ptr->next) {
	x = (ptr->x - ds->min_x) * ds->unit * 2;
	y = (ptr->y - ds->min_y) * ds->unit * 2;
	theta = ptr->theta;
	theta *= (180.0 / M_PI); /* [-180, 180] */
	pixel = (unsigned long)(ptr->color_theta * 128.0 / M_PI);
	fprintf(fp,
		"\n"
		"gsave\n"
		"\t" "%d %d translate\n"
		"\t" "%f makeArrowPath\n"
		"\t" "%f %f %f fillColorPath\n"
		"grestore\n",
		x, y, theta,
		(double)ds->colors[pixel].red / 65535,
		(double)ds->colors[pixel].green / 65535,
		(double)ds->colors[pixel].blue / 65535);
    }
    PrintTrail(fp);
}

void
PrintPSDataSet(DataSet *ds, FILE *fp)
{
    PrintEPSDataSet(ds, fp);
    fprintf(fp, "\n"
            "showpage\n"
            "quit\n");
}

void
PrintPSColorDataSet(DataSet *ds, FILE *fp)
{
    PrintEPSColorDataSet(ds, fp);
    fprintf(fp, "\n"
            "showpage\n"
            "quit\n");
}
