/*
       HScrollbar.c for X11R6 & GNU C Compiler

       Copyright (C) 1997 Syllabub
       Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>

#include "HScrollbar.h"

#define min(a, b) (((a) > (b)) ? (b) : (a))
#define max(a, b) (((a) < (b)) ? (b) : (a))

static int
WidthOfCatch(SylHScrollbar *hsb)
{
    return ((hsb->maxcolumn > hsb->columns) ?
	max(hsb->width * hsb->columns / hsb->maxcolumn, HSCBARVMIN)
	: hsb->width);
}

static Window
ParentWindow(Display *disp, Window window)
{
    Window root, parent, *childp;
    unsigned int children;

    if (XQueryTree(disp, window, &root, &parent, &childp, &children))
	XFree(childp);
    return (parent);
}

SylHScrollbar *
ReserveSylHScrollbar(Display *disp, Window window, unsigned long *pixels,
    Cursor cursor, int cur, int end, int parcolumn,
    void (*scroll)(int, int), void (*adjust)(int))
{
    XWindowAttributes atr;
    SylHScrollbar *hsb;

    if ((hsb = (SylHScrollbar *)malloc(sizeof(SylHScrollbar))) == NULL)
	return (NULL);
    XGetWindowAttributes(disp, window, &atr);
    hsb->disp = disp;
    hsb->window = window;
    hsb->parent = ParentWindow(disp, window);
    hsb->current = cur;
    hsb->maxcolumn = end;
    hsb->width = atr.width;
    hsb->columns = atr.width / parcolumn;
    hsb->parcolumn = parcolumn;
    hsb->scroll = scroll;
    hsb->adjust = adjust;
    hsb->grabbed = False;
    hsb->bar = XCreateSimpleWindow(disp, hsb->parent,
        atr.x, atr.y + atr.height + HSCBARSEP,
        atr.width, HSCBARHEIGHT, 0, pixels[5], pixels[3]);
    hsb->catch = XCreateSimpleWindow(disp, hsb->bar, 0, 0,
	WidthOfCatch(hsb), HSCBARHEIGHT, 0, pixels[5], pixels[2]);
    hsb->cursor = cursor;
    hsb->pixels = pixels;
    hsb->gc = XCreateGC(disp, hsb->bar, 0, 0);
    XSetFunction(disp, hsb->gc, GXcopy);
    XSetLineAttributes(disp, hsb->gc, 0, LineSolid, CapButt, JoinMiter);

    XSelectInput(disp, hsb->bar, ExposureMask);
    XMapRaised(disp, hsb->bar);
    XSelectInput(disp, hsb->catch, ExposureMask
        | ButtonPressMask | ButtonReleaseMask);
    XMapRaised(disp, hsb->catch);
    return (hsb);
}

void 
PutbackSylHScrollbar(SylHScrollbar *hsb)
{
    if (hsb == NULL)
	return;
    XDestroyWindow(hsb->disp, hsb->catch);
    XDestroyWindow(hsb->disp, hsb->bar);
    XFreeGC(hsb->disp, hsb->gc);
    free(hsb);
}

static void
ExposeCatch(SylHScrollbar *hsb)
{
    int last = WidthOfCatch(hsb) - 1;

    XClearWindow(hsb->disp, hsb->catch);
    if (hsb->grabbed == True && hsb->button == 1) {
	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[1]);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 1, 2, 1, HSCBARHEIGHT - 2);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 2, 1, last - 1, 1);

	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[4]);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, last, 2,
		  last, HSCBARHEIGHT - 1);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 2, HSCBARHEIGHT - 1,
		  last - 1, HSCBARHEIGHT - 1);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 0, 1, 0, HSCBARHEIGHT - 1);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 1, 0, last, 0);

	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[0]);
	XDrawPoint(hsb->disp, hsb->catch, hsb->gc, 1, 1);

	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[5]);
	XDrawPoint(hsb->disp, hsb->catch, hsb->gc, 0, 0);
	XDrawPoint(hsb->disp, hsb->catch, hsb->gc, last, HSCBARHEIGHT - 1);
    }
    else {
	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[1]);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 0, 1, 0, HSCBARHEIGHT - 3);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 1, 0, last - 2, 0);
	
	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[4]);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, last - 1, 1,
		  last - 1, HSCBARHEIGHT - 3);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 1, HSCBARHEIGHT - 2,
		  last - 2, HSCBARHEIGHT - 2);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, last, 0,
		  last, HSCBARHEIGHT - 1);
	XDrawLine(hsb->disp, hsb->catch, hsb->gc, 0, HSCBARHEIGHT - 1,
		  last - 1, HSCBARHEIGHT - 1);

	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[0]);
	XDrawPoint(hsb->disp, hsb->catch, hsb->gc, 0, 0);
	
	XSetForeground(hsb->disp, hsb->gc, hsb->pixels[5]);
	XDrawPoint(hsb->disp, hsb->catch, hsb->gc, last - 1, HSCBARHEIGHT - 2);
	XDrawPoint(hsb->disp, hsb->catch, hsb->gc, last, HSCBARHEIGHT - 1);
    }
}

static int
RootXpointer(Display *disp)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, DefaultRootWindow(disp),
	&root, &child, &rx, &ry, &wx, &wy, &kb);
    return (rx);
}

static void
AdjustPointer(Display *disp, int newx, int newy)
{
    XWarpPointer(disp, None, DefaultRootWindow(disp), 0, 0, 0, 0, newx, newy);
}

static int
AdjustCatch(SylHScrollbar *hsb)
{
    int base, newx;
    XWindowAttributes atr;

    XGetWindowAttributes(hsb->disp, hsb->catch, &atr);
    base = hsb->maxcolumn - hsb->columns;
    newx = ((base <= 0) ? 0 :
        (hsb->width - atr.width) * hsb->current / base);
    if (newx != atr.x)
	XMoveWindow(hsb->disp, hsb->catch, newx, 0);
    return (newx - atr.x);
}

static int
ScrollWindow(SylHScrollbar *hsb, int dif)
{
    int new;

    new = max(min(hsb->current + dif, hsb->maxcolumn - hsb->columns), 0);
    dif = new - hsb->current;
    if (dif) {
	if (abs(dif) < hsb->columns)
	    hsb->scroll(hsb->current, dif);
	else
	    hsb->adjust(new);
	hsb->current = new;
    }
    return (dif);
}

void
ScrollSylHScrollbar(SylHScrollbar *hsb, int dif)
{
    if (hsb == NULL)
	return;
    if (ScrollWindow(hsb, dif)) {
	(void) AdjustCatch(hsb);
    }
}

void
JumpSylHScrollbar(SylHScrollbar *hsb, int new)
{
    if (hsb == NULL)
	return;
    hsb->current = max(min(new, hsb->maxcolumn - hsb->columns), 0);
    hsb->adjust(hsb->current);
    (void) AdjustCatch(hsb);
}

void
RangeSylHScrollbar(SylHScrollbar *hsb, int newmax)
{
    if (hsb == NULL)
	return;
    hsb->maxcolumn = newmax;
    XResizeWindow(hsb->disp, hsb->catch, WidthOfCatch(hsb), HSCBARHEIGHT);
    (void) AdjustCatch(hsb);
}

static void
SmoothMotion(SylHScrollbar *hsb)
{
    int curx;

    if ((curx = RootXpointer(hsb->disp)) != hsb->orgx) {
	if (ScrollWindow(hsb, curx - hsb->orgx))
	    hsb->orgx += AdjustCatch(hsb);
	AdjustPointer(hsb->disp, hsb->orgx, hsb->orgy);
    }
}

static int
WindowXpointer(Display *disp, Window d)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, d, &root, &child, &rx, &ry, &wx, &wy, &kb);
    return (wx);
}

static void
JumpMotion(SylHScrollbar *hsb)
{
    int diff, base, curx;

    curx = WindowXpointer(hsb->disp, hsb->bar) - hsb->orgp;
    base = hsb->width - WidthOfCatch(hsb);
    diff = (curx * (hsb->maxcolumn - hsb->columns) + base / 2) / base;
    (void) ScrollWindow(hsb, diff - hsb->current);
    XMoveWindow(hsb->disp, hsb->catch, max(min(curx, base), 0), 0);
}

static void
StepMotion(SylHScrollbar *hsb)
{
    int diff, base, curx;

    curx = RootXpointer(hsb->disp);
    base = (hsb->width - WidthOfCatch(hsb));
    diff = (curx - hsb->orgx) * (hsb->maxcolumn - hsb->columns) / base;
    if (ScrollWindow(hsb, (hsb->orgc + diff) - hsb->current))
	(void) AdjustCatch(hsb);
}

void
SendSylHScrollbar(SylHScrollbar *hsb, XEvent *ev)
{
    if (hsb == NULL)
	return;
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.count == 0 && ev->xexpose.window == hsb->catch)
	    ExposeCatch(hsb);
	break;
    case ButtonPress:
	if (ev->xbutton.window != hsb->catch || hsb->maxcolumn <= hsb->columns)
	    break;
	XGrabPointer(hsb->disp, hsb->catch, False,
	     ButtonMotionMask | PointerMotionHintMask | ButtonReleaseMask,
	     GrabModeAsync, GrabModeSync, DefaultRootWindow(hsb->disp),
	     None, ev->xbutton.time);
	hsb->grabbed = True;
	if ((hsb->button = ev->xbutton.button) == 1) {
	    XDefineCursor(hsb->disp, hsb->bar, hsb->cursor);
	    ExposeCatch(hsb);
	}
	hsb->orgc = hsb->current;
	hsb->orgx = ev->xbutton.x_root;
	hsb->orgy = ev->xbutton.y_root;
	hsb->orgp = ev->xbutton.x;
	break;
    case MotionNotify:
	if (hsb->grabbed != True)
	    break;
	if (hsb->button == 1)
	    SmoothMotion(hsb);
	else if (hsb->button == 2)
	    StepMotion(hsb);
	else
	    JumpMotion(hsb);
	break;
    case ButtonRelease:
	if (hsb->grabbed != True)
	    break;
	XUngrabPointer(hsb->disp, ev->xbutton.time);
	hsb->grabbed = False;
	if (hsb->button == 1) {
	    XUndefineCursor(hsb->disp, hsb->bar);
	    ExposeCatch(hsb);
	}
	else if (hsb->button == 3) {
	    AdjustCatch(hsb);
	}
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != hsb->window)
	    break;
	XMoveResizeWindow(hsb->disp, hsb->bar, ev->xconfigure.x,
	    ev->xconfigure.y + ev->xconfigure.height + HSCBARSEP,
	    ev->xconfigure.width, HSCBARHEIGHT);
	hsb->width = ev->xconfigure.width;
	hsb->columns = hsb->width / hsb->parcolumn;
	XResizeWindow(hsb->disp, hsb->catch, WidthOfCatch(hsb), HSCBARHEIGHT);
	if (hsb->maxcolumn - hsb->current < hsb->columns)
	    hsb->current = max(0, hsb->maxcolumn - hsb->columns);
	hsb->adjust(hsb->current);
	(void) AdjustCatch(hsb);
	break;
    }
}
