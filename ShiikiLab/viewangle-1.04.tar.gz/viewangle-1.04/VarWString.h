typedef struct {
    int length;
    wchar_t *wstring;
} SylVarWString;

SylVarWString * CreateSylVarWStringFromWString(wchar_t *wcs);
SylVarWString * CreateSylVarWStringFromString(char *mbs);
void FreeSylVarWString(SylVarWString *var);
wchar_t * CreateWStringFromSylVarWString(SylVarWString *var, int bgn, int end);
void InsertCharIntoSylVarWString(SylVarWString *var, int n, wchar_t c);
void InsertWStringIntoSylVarWString(SylVarWString *var, int n, wchar_t *p);
void DeleteWCharOfSylVarWString(SylVarWString *var, int n);
void DeleteWStringOfSylVarWString(SylVarWString *var, int n, int m);

#define LengthOfSylVarWString(v) ((v)->length)
