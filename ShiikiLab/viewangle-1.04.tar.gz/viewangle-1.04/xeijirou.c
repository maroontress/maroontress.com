#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/param.h>

#include "xeijirou.h"

#define max(a, b) (((a) < (b)) ? (b) : (a))
typedef unsigned long Pixel;

static Window window;
static Pixmap winbak;
static GC gc;
static Pixel fgcolor, bgcolor;
static Atom WM_PROTOCOLS, WM_DELETE_WINDOW;

#include "xeijirou.h"
#include "xeijirou0.xbm"
#include "xeijirou1.xbm"

static void
SetXEijirouProperties(Display *disp, int ac, char **av)
{
    char *whoami = PRODUCT_NAME " " PRODUCT_VERSION;
    XSizeHints sizes;
    XWindowAttributes atrs;
    XClassHint class;

    XGetWindowAttributes(disp, window, &atrs);
    sizes.width = atrs.width;
    sizes.height = atrs.height;
    sizes.min_width = atrs.width;
    sizes.min_height = atrs.height;
    sizes.max_width = atrs.width;
    sizes.max_height = atrs.height;
    sizes.flags = PSize | PMaxSize | PMinSize;
    class.res_name = PRODUCT_NAME; 
    class.res_class = PRODUCT_NAME;
    XmbSetWMProperties(disp, window, whoami, whoami, av, ac,
		       &sizes, NULL, &class);

    WM_PROTOCOLS = XInternAtom(disp, "WM_PROTOCOLS", False);
    WM_DELETE_WINDOW = XInternAtom(disp, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(disp, window, &WM_DELETE_WINDOW, 1);
}

static int
WindowMain(Display *disp, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window == window) {
	    XCopyArea(disp, winbak, window, gc,
		ev->xexpose.x, ev->xexpose.y,
	        ev->xexpose.width, ev->xexpose.height,
		ev->xexpose.x, ev->xexpose.y);
	}
	break;
    case ButtonPress:
	if (ev->xbutton.window == window)
	    return (1);
	break;
    case ClientMessage:
	if (ev->xclient.message_type == WM_PROTOCOLS
	    && ev->xclient.data.l[0] == (signed)WM_DELETE_WINDOW)
	    return (1);
	break;
    }
    return (0);
}

static MainPower = 1;

void
open_xeijirou(Display *disp, int ac, char **av, int n)
{
    char buf[256], hostname[MAXHOSTNAMELEN];

    bgcolor = WhitePixel(disp, DefaultScreen(disp));
    fgcolor = BlackPixel(disp, DefaultScreen(disp));
    window = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
	0, 0, xeijirou0_width, xeijirou0_height, 1, fgcolor, bgcolor);
    SetXEijirouProperties(disp, ac, av);
    gc = XCreateGC(disp, window, 0, 0);
    XSetForeground(disp, gc, bgcolor);
    XSetBackground(disp, gc, fgcolor);
    XSetFunction(disp, gc, GXcopy);
    XSelectInput(disp, window, ExposureMask | ButtonPressMask);
    if (gethostname(hostname, MAXHOSTNAMELEN) < 0) {
        perror("gethostname");
        exit(1);
    }
    if (n >= 0) {
	winbak = XCreatePixmapFromBitmapData(disp, DefaultRootWindow(disp),
            xeijirou0_bits, xeijirou0_width, xeijirou0_height,
            fgcolor, bgcolor, DefaultDepth(disp, DefaultScreen(disp)));
	sprintf(buf, "%s@%s", getlogin(), hostname);
	XDrawString(disp, winbak, gc, 300, 40, buf, strlen(buf));
	sprintf(buf, "%d", n);
	XDrawString(disp, winbak, gc, 430, 58, buf, strlen(buf));
    }
    else {
	winbak = XCreatePixmapFromBitmapData(disp, DefaultRootWindow(disp),
            xeijirou1_bits, xeijirou1_width, xeijirou1_height,
	    fgcolor, bgcolor, DefaultDepth(disp, DefaultScreen(disp)));
	sprintf(buf, "%s@%s", getlogin(), hostname);
	XDrawString(disp, winbak, gc, 300, 40, buf, strlen(buf));
    }
    XMapRaised(disp, window);
}

void
send_xeijirou(Display *disp, XEvent *ev)
{
    if (MainPower && WindowMain(disp, ev)) {
	XDestroyWindow(disp, window);	
	XFreePixmap(disp, winbak);
	XFreeGC(disp, gc);
	MainPower = 0;
    }
}
