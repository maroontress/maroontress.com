#include <stdio.h>
#include <stdlib.h>

void
main(int ac, char **av)
{
    int e, x, y;
    double m, v, z;

    if (ac != 3) {
	fprintf(stderr, "usage: %s {m} {v}\n", av[0]);
	exit(1);
    }
    m = atof(av[1]);
    v = atof(av[2]) / 100.0;
    while ((e = scanf("%d %d %lf", &x, &y, &z)) == 3) {
	if (z < -m * v)
	    z = 45.0 / (m * (1 - v)) * (z + m);
	else if (z < m * v)
	    z = 45.0 / (m * v) * z + 90.0;
	else 
	    z = 45.0 / (m * (1 - v)) * (z - m) + 180.0;
	printf("%d %d %e\n", x, y, z);
    }
    if (e != EOF) {
	fprintf(stderr, "%s: invalid data format (%d)\n", av[0], e);
	exit(1);
    }
    exit(0);
}
