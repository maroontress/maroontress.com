#define TEXT_CURSOR_TOP 0
#define TEXT_CURSOR_BOTTOM -1

typedef struct SylTextLine {
    Display *disp;
    XIC ic;
    Window parent;
    Window window;
    int ascent;
    int descent;
    int cursor_width;
    int cursor_height;
    Pixmap pixmap;
    GC gc;
    XFontSet fs;
    int width;
    int height;
    int depth;
    unsigned long *pixel;

    SylVarWString *text;
    int size;
    int left;
    int cursor;
    int right;
    int dragging;
    int left_dragged;
    int right_dragged;
    int pointed;
    int focus;
    int grabbed;
    int redraw;
    int converting;
    Atom property;
    struct SylTextLine *forward_focus;
    struct SylTextLine *backward_focus;
    void (*callback)(int);
} SylTextLine;

SylTextLine * CreateSylTextLine(Display *, XIC, Window, XFontSet,
				unsigned long *, char *, int, void (*)(int));
void FreeSylTextLine(SylTextLine *);
void SendSylTextLine(SylTextLine *, XEvent *);
int NiceSylTextLine(SylTextLine *);
void SetTabModeSylTextLine(SylTextLine *, SylTextLine *, SylTextLine *);
void ClearSylTextLine(SylTextLine *);
char * CreateStringFromSylTextLine(SylTextLine *);
