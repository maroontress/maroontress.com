#include <stdio.h>
#include <math.h>

void
main(void)
{
    int n, m, d;

    for (n = 0; n < 100; ++n) {
	for (m = 0; m < 100; ++m) {
	    printf("%d %d %f\n", n, m,
		   180.0 * sin((double)(n * n + m * m) / 1000));
	}
	for (m = 100; m < 200; ++m) {
	    d = m - 100;
	    printf("%d %d %f\n", n, m,
		   180.0 * sin(sqrt(n * n + d * d) / 100));
	}
    }
}
