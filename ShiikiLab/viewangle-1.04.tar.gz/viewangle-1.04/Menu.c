/*
        Menu.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997 Syllabub
        Maroontress Fast Software.
 */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>
#include <string.h>

#include "Menu.h"

SylMenuList *
CreateSylMenuList(void)
{
    SylMenuList *ml;

    if ((ml = (SylMenuList *)malloc(sizeof(SylMenuList))) == NULL)
	return (NULL);
    ml->top = NULL;
    ml->last = NULL;
    return (ml);
}

SylMenu *
CreateSylMenu(SylMenuList *ml, char *name)
{
    SylMenu *m;

    if ((m = (SylMenu *)malloc(sizeof(SylMenu))) == NULL)
	return (NULL);
    if ((m->name = strdup(name)) == NULL) {
	free(m);
	return (NULL);
    }
    m->next = NULL;
    m->top = NULL;
    m->last = NULL;
    if (ml->top == NULL)
	ml->top = m;
    else
	ml->last->next = m;
    ml->last = m;
    return (m);
}

SylMenu *
CopySylMenu(SylMenuList *ml, SylMenu *org)
{
    SylMenu *cpy;

    if ((cpy = (SylMenu *)malloc(sizeof(SylMenu))) == NULL)
	return (NULL);
    cpy->name = org->name;
    cpy->top = org->top;
    cpy->last = org->last;
    cpy->next = NULL;
    if (ml->top == NULL)
	ml->top = cpy;
    else
	ml->last->next = cpy;
    ml->last = cpy;
    return (cpy);
}

SylMenu *
LookupSylMenu(SylMenuList *ml, char *name)
{
    SylMenu *m;

    for (m = ml->top; m != NULL; m = m->next) {
	if (strcmp(name, m->name) == 0)
	    break;
    }
    return (m);
}

static int
SetKeySymAndState(SylMenuItem *i)
{
    int state = 0;
    char *p;

    i->any_item.state = 0;
    i->any_item.key = NoSymbol;
    if (i->any_item.sep == NULL)
	return (MENU_ITEM_SUCCESS);
    p = i->any_item.sep + 1;
    while (*p != 0 && *p != '-' && strchr(p, '-') != NULL) {
	if (strncmp(p, "Shift-", 6) == 0) {
	    if (state & ShiftMask)
		return (MENU_ITEM_NO_KEYSYM);
	    state |= ShiftMask;
	    p += 6;
	}
	else if (strncmp(p, "Control-", 8) == 0) {
	    if (state & ControlMask)
		return (MENU_ITEM_NO_KEYSYM);
	    state |= ControlMask;
	    p += 8;
	}
	else if (strncmp(p, "Meta-", 5) == 0) {
	    if (state & Mod1Mask)
		return (MENU_ITEM_NO_KEYSYM);
	    state |= Mod1Mask;
	    p += 5;
	}
	else {
	    return (MENU_ITEM_NO_KEYSYM);
	}
    }
    if ((i->any_item.key = XStringToKeysym(p)) == NoSymbol)
	return (MENU_ITEM_NO_KEYSYM);
    i->any_item.state = state;
    return (MENU_ITEM_SUCCESS);
}

static int
AddMenuItem(SylMenu *m, SylMenuItem *i, char *name)
{
    int s;

    if ((i->any_item.name = strdup(name)) == NULL) {
	free(i);
	return (MENU_ITEM_FAILURE);
    }
    i->any_item.sep = strchr(i->any_item.name, MENU_ITEM_CHAR_HFILL);
    if ((s = SetKeySymAndState(i)) == MENU_ITEM_FAILURE) {
	free(i->any_item.name);
	free(i);
	return (MENU_ITEM_FAILURE);
    }
    i->any_item.next = NULL;
    if (m->top == NULL)
	m->top = i;
    else
	m->last->any_item.next = i;
    m->last = i;
    return (s);
}

int
CreateSylNopItem(SylMenu *m, char *name)
{
    SylMenuItem *i;

    if ((i = (SylMenuItem *)malloc(sizeof(SylNopItem))) == NULL)
	return (MENU_ITEM_FAILURE);
    i->nop_item.type = MENU_ITEM_NOP;
    i->nop_item.is_grayout = NULL;
    return (AddMenuItem(m, i, name));
}

int
CreateSylExecItem(SylMenu *m, char *name, void (*exec)(void),
		  int (*is_grayout)(void))
{
    SylMenuItem *i;

    if ((i = (SylMenuItem *)malloc(sizeof(SylExecItem))) == NULL)
	return (MENU_ITEM_FAILURE);
    i->exec_item.type = MENU_ITEM_EXEC;
    i->exec_item.exec = exec;
    i->exec_item.is_grayout = is_grayout;
    return (AddMenuItem(m, i, name));
}

int
CreateSylCheckItem(SylMenu *m, char *name, void (*toggle)(void),
		   int (*is_checked)(void), int (*is_grayout)(void))
{
    SylMenuItem *i;

    if ((i = (SylMenuItem *)malloc(sizeof(SylCheckItem))) == NULL)
	return (MENU_ITEM_FAILURE);
    i->check_item.type = MENU_ITEM_CHECK;
    i->check_item.toggle = toggle;
    i->check_item.is_checked = is_checked;
    i->check_item.is_grayout = is_grayout;
    return (AddMenuItem(m, i, name));
}

static int
MenusOfSylMenuList(SylMenuList *ml)
{
    int n;
    SylMenu *m;

    for (n = 0, m = ml->top; m != NULL; m = m->next)
	++n;
    return (n);
}

static void
Draw3dFrame(Display *disp, GC gc, Drawable d, int x, int y, int w, int h,
	    unsigned long *pixels)
{
    w += x;
    h += y;
    XSetForeground(disp, gc, pixels[2]);
    XFillRectangle(disp, d, gc, x, y, w, h);
    XSetForeground(disp, gc, pixels[1]);
    XDrawLine(disp, d, gc, x + 1, y, w - 2, y);
    XDrawLine(disp, d, gc, x, y + 1, x, h - 2);
    XSetForeground(disp, gc, pixels[4]);
    XDrawLine(disp, d, gc, x + 1, h - 1, w - 2, h - 1);
    XDrawLine(disp, d, gc, w - 1, y + 1, w - 1, h - 2);
    XSetForeground(disp, gc, pixels[0]);
    XDrawPoint(disp, d, gc, x, y);
    XSetForeground(disp, gc, pixels[5]);
    XDrawPoint(disp, d, gc, w - 1, h - 1);
}

static void
DrawWindowFrame(Display *disp, GC gc, Drawable d, int w, int h,
	    unsigned long *pixels)
{
    Draw3dFrame(disp, gc, d, 0, 0, w, h, pixels);
}

static int
MenubarTextWidth(XFontStruct *fs, char *str, int len)
{
    return ((2 * MENUBAR_MENU_SEP) + XTextWidth(fs, str, len));
}

static void
DrawMenubarText(Display *disp, GC gc, Drawable d, int x, int y,
		char *str, int len)	
{
    XDrawString(disp, d, gc, x + MENUBAR_MENU_SEP, y, str, len);
}

static void
DrawMenubarTexts(SylMenubar *mb)
{
    int n, x, y, l;
    SylMenu *m;

    x = MENUBAR_MARGIN_W;
    y = MENUBAR_MARGIN_H + mb->descent + mb->ascent;
    XSetForeground(mb->disp, mb->gc, mb->pixels[5]);
    for (n = 0, m = mb->menu_list->top; m != NULL; ++n, m = m->next) {
	l = strlen(m->name);
	DrawMenubarText(mb->disp, mb->gc, mb->backup, x, y, m->name, l);
	x += MenubarTextWidth(mb->fontinfo, m->name, l);
    }
}

static void
DrawFocusMenubarText(SylMenubar *mb, unsigned long fg)
{
    int n, x, y, l, w;
    SylMenu *m;

    x = MENUBAR_MARGIN_W;
    y = MENUBAR_MARGIN_H + mb->descent + mb->ascent;
    for (n = 0, m = mb->menu_list->top; m != NULL; ++n, m = m->next) {
	l = strlen(m->name);
	w = MenubarTextWidth(mb->fontinfo, m->name, l);
	if (n == mb->focus) {
	    XSetForeground(mb->disp, mb->gc, fg);
	    DrawMenubarText(mb->disp, mb->gc, mb->backup, x, y, m->name, l);
	    DrawMenubarText(mb->disp, mb->gc, mb->menubar, x, y, m->name, l);
	}
	x += w;
    }
}

static void
SetFocusMenubarText(SylMenubar *mb, int new)
{
    mb->focus = new;
    DrawFocusMenubarText(mb, mb->pixels[6]);
}

static void
UnsetFocusMenubarText(SylMenubar *mb)
{
    DrawFocusMenubarText(mb, mb->pixels[5]);
    mb->focus = mb->n_menus;
}

static void
CreateMenuPixmap(SylMenubar *mb)
{
    DrawWindowFrame(mb->disp, mb->gc, mb->backup,
		    mb->width, mb->height, mb->pixels);
    DrawMenubarTexts(mb);
}

static void
CreateMenuInputs(SylMenubar *mb)
{
    int x, y, w;
    SylMenu *m;
    Window *win;
    XSetWindowAttributes atr;

    x = MENUBAR_MARGIN_W;
    y = MENUBAR_MARGIN_H;
    win = mb->inputs;
    for (m = mb->menu_list->top; m != NULL; m = m->next) {
	w = (2 * MENUBAR_MENU_SEP)
	    + XTextWidth(mb->fontinfo, m->name, strlen(m->name));
	*win = XCreateWindow(mb->disp, mb->menubar, x, y, w, mb->baselineskip,
            0, 0, InputOnly, CopyFromParent, 0, &atr);
        XSelectInput(mb->disp, *win, EnterWindowMask | LeaveWindowMask
	    | OwnerGrabButtonMask | ButtonPressMask | ButtonReleaseMask);
        XMapRaised(mb->disp, *win);
	x += w;
	++win;
    }
}

SylMenubar *
ReserveSylMenubar(Display *disp, Window parent, unsigned long *pixels,
		  Cursor cursor, Font font, SylMenuList *ml)
{
    XWindowAttributes atr;
    SylMenubar *mb;

    if ((mb = (SylMenubar *)malloc(sizeof(SylMenubar))) == NULL)
        return (NULL);
    mb->menu_list = ml;
    mb->n_menus = MenusOfSylMenuList(ml);
    if ((mb->inputs = (Window *)malloc(sizeof(Window) * mb->n_menus))
	== NULL) {
	free(mb);
	return (NULL);
    }
    XGetWindowAttributes(disp, parent, &atr);
    mb->disp = disp;
    mb->parent = parent;
    mb->cursor = cursor;
    mb->pixels = pixels;
    mb->focus = mb->n_menus;
    mb->pushed = mb->n_menus;
    mb->grabbed = 0;
    mb->width = atr.width;
    mb->fontinfo = XQueryFont(disp, font);
    mb->ascent = mb->fontinfo->ascent;
    mb->descent = mb->fontinfo->descent;
    mb->baselineskip = mb->ascent + mb->descent * 3;
    mb->height = MENUBAR_MARGIN_H + mb->baselineskip + MENUBAR_MARGIN_H;
    mb->menubar = XCreateSimpleWindow(disp, parent, 0, 0,
        mb->width, mb->height, 0, pixels[5], pixels[2]);
    mb->backup = XCreatePixmap(disp, mb->menubar,
        mb->width, mb->height, atr.depth);
    mb->gc = XCreateGC(disp, mb->menubar, 0, 0);
    XSetFunction(disp, mb->gc, GXcopy);
    XSetFont(disp, mb->gc, font);
    XSetBackground(disp, mb->gc, pixels[2]);
    XSetLineAttributes(disp, mb->gc, 0, LineSolid, CapButt, JoinMiter);
    XDefineCursor(disp, mb->menubar, cursor);
    XSelectInput(disp, mb->menubar, ExposureMask);
    XMapRaised(disp, mb->menubar);
    CreateMenuInputs(mb);
    CreateMenuPixmap(mb);
    return (mb);
}

static void
GetPopupWindowSize(SylMenubar *mb)
{
    int w;
    SylMenuItem *mi;

    mb->item_width = 0;
    mb->item_height = 0;
    mb->n_items = 0;
    for (mi = mb->item_list; mi != NULL; mi = mi->any_item.next) {
	w = XTextWidth(mb->fontinfo, mi->any_item.name,
		       strlen(mi->any_item.name));
	if (mi->any_item.sep != NULL)
	    w += mb->baselineskip; /* $B:8B&$H1&B&$N6u$-(B */
	if (mi->any_item.type == MENU_ITEM_CHECK)
	    w += mb->baselineskip; /* CheckMark$B$NI}(B */
	if (mb->item_width < w)
	    mb->item_width = w;
	if (mi->any_item.type == MENU_ITEM_NOP) {
	    if (mi->any_item.name[0] == 0)
		mb->item_height += MENUBAR_RULE_H + 2 * MENUBAR_MARGIN_H;
	    else
		mb->item_height += mb->baselineskip;
	}
	else {
	    mb->item_height += mb->baselineskip;
	    ++(mb->n_items);
	}
    }
    mb->item_width += 2 * MENUBAR_MARGIN_W;
    mb->item_height += 2 * MENUBAR_MARGIN_H;
}

static void
DrawCheckMark(Display *disp, Drawable d, GC gc, int x, int y, int w, int h)
{
    XPoint v[5];

    v[0].x = x + w / 4;
    v[0].y = y - h / 2;
    v[1].x = w / 4;
    v[1].y = h / 2;
    v[2].x = w / 2;
    v[2].y = -h;
    v[3].x = -w / 2;
    v[3].y = h - 1;
    v[4].x = 1 - w / 4;
    v[4].y = - h / 2;
    XDrawLines(disp, d, gc, v, 5, CoordModePrevious);
}

static void
DrawPopupRule(Display *disp, Drawable d, GC gc, unsigned long *pixels,
	      int x, int y, int w)
{
    int h;

    w += x - 1;
    h = y + MENUBAR_RULE_H - 1;
#if 0
    XSetForeground(disp, gc, pixels[2]);
    XDrawPoint(disp, d, gc, x, y);
    XDrawPoint(disp, d, gc, w, h);
    XSetForeground(disp, gc, pixels[5]);
    XDrawPoint(disp, d, gc, w, y);
    XSetForeground(disp, gc, pixels[0]);
    XDrawPoint(disp, d, gc, x, h);
#endif
    XSetForeground(disp, gc, pixels[4]);
    XDrawLine(disp, d, gc, x + 1, y, w - 1, y);
    XSetForeground(disp, gc, pixels[1]);
    XDrawLine(disp, d, gc, x + 1, h, w - 1, h);
}

#define IsGrayOut(x) ((x)->any_item.is_grayout != NULL \
		      && (x)->any_item.is_grayout())

static int
DrawPopupItem(SylMenubar *mb, SylMenuItem *mi, int y, int w)
{
    int x, len;
    char *key;

    if (mi->any_item.type == MENU_ITEM_NOP && mi->any_item.name[0] == 0) {
	DrawPopupRule(mb->disp, mb->menuback, mb->gc, mb->pixels,
		      0, y - (mb->ascent + mb->descent) + MENUBAR_MARGIN_H,
		      mb->item_width);
	return (MENUBAR_RULE_H + 2 * MENUBAR_MARGIN_H);
    }
    x = MENUBAR_MARGIN_W;
    if (mi->any_item.type == MENU_ITEM_CHECK) {
	if (mi->check_item.is_checked != NULL && mi->check_item.is_checked()) {
	    DrawCheckMark(mb->disp, mb->menuback, mb->gc, x, y,
			  mb->ascent + mb->descent, mb->ascent);
	}
	x += mb->baselineskip;
    }
    if (mi->any_item.sep == NULL) {
#if 0
	if (IsGrayOut(mi)) {
	    XSetForeground(mb->disp, mb->gc, mb->pixels[1]);
	    XDrawString(mb->disp, mb->menuback, mb->gc, x+1, y+1,
			mi->any_item.name, strlen(mi->any_item.name));
	    XSetForeground(mb->disp, mb->gc, mb->pixels[3]);
	    XDrawString(mb->disp, mb->menuback, mb->gc, x, y,
			mi->any_item.name, strlen(mi->any_item.name));
	}
	else {
	    XSetForeground(mb->disp, mb->gc, mb->pixels[5]);
	    XDrawString(mb->disp, mb->menuback, mb->gc, x, y,
			mi->any_item.name, strlen(mi->any_item.name));
	}
#else
	XDrawString(mb->disp, mb->menuback, mb->gc, x, y,
		    mi->any_item.name, strlen(mi->any_item.name));
#endif
    }
    else {
#if 0
	if (IsGrayOut(mi)) {
	    XSetForeground(mb->disp, mb->gc, mb->pixels[1]);
	XDrawString(mb->disp, mb->menuback, mb->gc, x+1, y+1, mi->any_item.name,
		    (int)(mi->any_item.sep - mi->any_item.name));
	len = strlen((key = mi->any_item.sep + 1));
	XDrawString(mb->disp, mb->menuback, mb->gc,
		    w - XTextWidth(mb->fontinfo, key, len)+1, y+1, key, len);
	    XSetForeground(mb->disp, mb->gc, mb->pixels[3]);
	XDrawString(mb->disp, mb->menuback, mb->gc, x, y, mi->any_item.name,
		    (int)(mi->any_item.sep - mi->any_item.name));
	len = strlen((key = mi->any_item.sep + 1));
	XDrawString(mb->disp, mb->menuback, mb->gc,
		    w - XTextWidth(mb->fontinfo, key, len), y, key, len);
	}
	else {
	    XSetForeground(mb->disp, mb->gc, mb->pixels[5]);
	XDrawString(mb->disp, mb->menuback, mb->gc, x, y, mi->any_item.name,
		    (int)(mi->any_item.sep - mi->any_item.name));
	len = strlen((key = mi->any_item.sep + 1));
	XDrawString(mb->disp, mb->menuback, mb->gc,
		    w - XTextWidth(mb->fontinfo, key, len), y, key, len);
	}
#else
	XDrawString(mb->disp, mb->menuback, mb->gc, x, y, mi->any_item.name,
		    (int)(mi->any_item.sep - mi->any_item.name));
	len = strlen((key = mi->any_item.sep + 1));
	XDrawString(mb->disp, mb->menuback, mb->gc,
		    w - XTextWidth(mb->fontinfo, key, len), y, key, len);
#endif
    }
    return (mb->baselineskip);
}

static void
DrawPopup(SylMenubar *mb)
{
    int y, w;
    SylMenuItem *mi;

    w = mb->item_width - MENUBAR_MARGIN_W;
    y = MENUBAR_MARGIN_H + mb->descent + mb->ascent;
    for (mi = mb->item_list; mi != NULL; mi = mi->any_item.next) {
#if 1
	XSetForeground(mb->disp, mb->gc, mb->pixels[(IsGrayOut(mi) ? 3 : 5)]);
#endif
	y += DrawPopupItem(mb, mi, y, w);
    }
}

static void
DrawFlatFocus(Display *disp, GC gc, Drawable d, int x, int y, int w, int h,
	      unsigned long *pixels)
{
    XSetForeground(disp, gc, pixels[2]);
    XFillRectangle(disp, d, gc, x, y, w, h);
}

static void
DrawPopupTextFocus(SylMenubar *mb, unsigned long fg,
		   void (*draw_focus)(Display *, GC, Drawable, int, int,
				      int, int, unsigned long *))
{
    int n, x, y, w, h;
    SylMenuItem *mi;

    w = mb->item_width - 2;
    x = 1;
    y = MENUBAR_MARGIN_H;
    h = mb->baselineskip;
    for (n = 0, mi = mb->item_list; mi != NULL; mi = mi->any_item.next) {
	if (mi->any_item.type == MENU_ITEM_NOP) {
	    if (mi->any_item.name[0] == 0)
		y += MENUBAR_RULE_H + 2 * MENUBAR_MARGIN_H;
	    else
		y += mb->baselineskip;
	}
	else {
	    if (n == mb->item_focus && !IsGrayOut(mi)) {
		draw_focus(mb->disp, mb->gc, mb->menuback, x, y,
			   w, h, mb->pixels);
		XSetForeground(mb->disp, mb->gc, fg);
		DrawPopupItem(mb, mi, y + mb->descent + mb->ascent,
			      mb->item_width - MENUBAR_MARGIN_W);
		XCopyArea(mb->disp, mb->menuback, mb->menuface, mb->gc,
			  x, y, w, h, x, y);
	    }
	    y += mb->baselineskip;
	    ++n;
	}
    }
}

static void
SetPopupTextFocus(SylMenubar *mb, int new)
{
    mb->item_focus = new;
    DrawPopupTextFocus(mb, mb->pixels[6], Draw3dFrame);
}

static void
UnsetPopupTextFocus(SylMenubar *mb)
{
    DrawPopupTextFocus(mb, mb->pixels[5], DrawFlatFocus);
    mb->item_focus = mb->n_items;
}

static void
CallMenuItem(SylMenuItem *mi)
{
    switch (mi->any_item.type) {
    case MENU_ITEM_EXEC:
	mi->exec_item.exec();
	break;
    case MENU_ITEM_CHECK:
	mi->check_item.toggle();
	break;
    }
}

static void
CallSelectedItem(SylMenubar *mb)
{
    int n;
    SylMenuItem *mi;

    if (mb->item_focus == mb->n_items)
	return;
    for (n = 0, mi = mb->item_list; mi != NULL; mi = mi->any_item.next) {
	if (mi->any_item.type != MENU_ITEM_NOP) {
	    if (n == mb->item_focus) {
		CallMenuItem(mi);
		break;
	    }
	    ++n;
	}
    }
}

static void
CallItemByKeySym(SylMenubar *mb, XEvent *ev)
{
    SylMenu *m;
    SylMenuItem *mi;
    SylAnyItem *ai;
    int st;
    KeySym ks;
    char p[64];

    /*
       Bug: SunOS 4.1$B$N(BX11R5$B$G$O!":G=i(BXNextEvent$B$G<hF@$7$?(BKeyPress$B%$%Y%s%H$N(B
       state$B%a%s%P$K!"%-!<%\!<%I$N>uBV$HL54X78$K(B0$B$,BeF~$5$l$F$$$k!#$H$3$m$,(B
       XLookupString$B$K$=$N%$%Y%s%H$rEO$7$F$d$k$H!"8F$S=P$7$+$iLa$C$F$-$?$H$-(B
       $B$K$O%a%s%P(Bstate$B$KE,@Z$JCM$,BeF~$5$l$F$$$k!#$3$l$O;EMM$H0[$J$k!#0J2<$N(B
       $B%j%9%H$K$h$C$F!"$3$N8=>]$,3NG'$G$-$k!#(B

       printf("%u\n", ev->xkey.state);
       XLookupString(&(ev->xkey), p, 64, NULL, NULL);
       printf("%s %u\n", p, ev->xkey.state);
     */
    p[XLookupString(&(ev->xkey), p, 64, NULL, NULL)] = 0;
    if ((ks = XLookupKeysym(&(ev->xkey), 0)) == NoSymbol)
	return;
    st = ev->xkey.state;
    for (m = mb->menu_list->top; m != NULL; m = m->next) {
	for (mi = m->top; mi != NULL; mi = mi->any_item.next) {
	    ai = &(mi->any_item);
	    if (ai->type != MENU_ITEM_NOP
		&& ((ai->key == ks && ai->state == st)
		     || (ai->sep != NULL && strcmp(ai->sep + 1, p) == 0))) {
		CallMenuItem(mi);
		return;
	    }
	}
    }
}

static SylMenuItem *
LookupItemList(SylMenuList *ml, int p)
{
    int n;
    SylMenu *m;

    for (n = 0, m = ml->top; n < p; ++n, m = m->next)
	;
    return (m->top);
}

static void
GetPopupGeometry(SylMenubar *mb, int *x, int *y)
{
    Window child;
    XWindowAttributes root, input;

    XTranslateCoordinates(mb->disp, mb->inputs[mb->pushed],
			  DefaultRootWindow(mb->disp), 0, 0, x, y, &child);
    XGetWindowAttributes(mb->disp, mb->inputs[mb->pushed], &input);
    XGetWindowAttributes(mb->disp, DefaultRootWindow(mb->disp), &root);
    if (*x + mb->item_width > root.width)
	*x += input.width - mb->item_width;
    *y += mb->baselineskip + MENUBAR_MARGIN_H;
    if (*y + mb->item_height > root.height)
	*y -= mb->item_height + mb->height;
}

static void
CreatePopupInputs(SylMenubar *mb)
{
    int x, y, w;
    SylMenuItem *mi;
    Window *win;
    XSetWindowAttributes atr;

    x = MENUBAR_MARGIN_W;
    y = MENUBAR_MARGIN_H;
    w = mb->item_width - (2 * MENUBAR_MARGIN_W);
    win = mb->item_inputs;
    for (mi = mb->item_list; mi != NULL; mi = mi->any_item.next) {
	if (mi->any_item.type == MENU_ITEM_NOP) {
	    if (mi->any_item.name[0] == 0)
		y += MENUBAR_RULE_H + 2 * MENUBAR_MARGIN_H;
	    else
		y += mb->baselineskip;
	}
	else {
	    *win = XCreateWindow(mb->disp, mb->menuface, x, y,
	        w, mb->baselineskip, 0, 0, InputOnly, CopyFromParent, 0, &atr);
	    XSelectInput(mb->disp, *win, EnterWindowMask | LeaveWindowMask
		| OwnerGrabButtonMask | ButtonPressMask | ButtonReleaseMask);
	    XMapRaised(mb->disp, *win);
	    y += mb->baselineskip;
	    ++win;
	}
    }
}

static void
CreatePopupWindow(SylMenubar *mb)
{
    int x, y;
    XSetWindowAttributes chg;

    mb->item_list = LookupItemList(mb->menu_list, mb->pushed);
    GetPopupWindowSize(mb);
    mb->item_focus = mb->n_items;
    GetPopupGeometry(mb, &x, &y);
    mb->menuface = XCreateSimpleWindow(mb->disp, DefaultRootWindow(mb->disp),
        x, y,
	mb->item_width, mb->item_height, 1, mb->pixels[5], mb->pixels[2]);
    chg.override_redirect = True;
    XChangeWindowAttributes(mb->disp, mb->menuface, CWOverrideRedirect, &chg);
    XSelectInput(mb->disp, mb->menuface, ExposureMask);
    XMapRaised(mb->disp, mb->menuface);
    mb->menuback = XCreatePixmap(mb->disp, DefaultRootWindow(mb->disp),
	mb->item_width, mb->item_height,
	DefaultDepth(mb->disp, DefaultScreen(mb->disp)));
    DrawWindowFrame(mb->disp, mb->gc, mb->menuback,
        mb->item_width, mb->item_height, mb->pixels);
    DrawPopup(mb);
    if ((mb->item_inputs = (Window *)malloc(sizeof(Window) * mb->n_items))
	!= NULL) {
	CreatePopupInputs(mb);
    }
}

static void
FreePopupWindow(SylMenubar *mb)
{
    int n;

    if (mb->item_inputs != NULL) {
	for (n = 0; n < mb->n_items; ++n) {
	    XDestroyWindow(mb->disp, mb->item_inputs[n]);
	}
	free(mb->item_inputs);
    }	
    XDestroyWindow(mb->disp, mb->menuface);
    XFreePixmap(mb->disp, mb->menuback);
}

void
SendSylMenubar(SylMenubar *mb, XEvent *ev)
{
    int n;
    XWindowAttributes atr;

    switch (ev->type) {
    case ConfigureNotify:
	if (ev->xany.window != mb->parent)
	    break;
	XFreePixmap(mb->disp, mb->backup);
	XGetWindowAttributes(mb->disp, mb->parent, &atr);
	mb->width = atr.width;
	XResizeWindow(mb->disp, mb->menubar, mb->width, mb->height);
	mb->backup = XCreatePixmap(mb->disp, mb->parent,
				   mb->width, mb->height, atr.depth);
	CreateMenuPixmap(mb);
	break;
    case KeyPress:
	if (ev->xany.window != mb->parent)
	    break;
	CallItemByKeySym(mb, ev);
	break;
    case Expose:
        if (ev->xany.window == mb->menubar) {
	    XCopyArea(mb->disp, mb->backup, mb->menubar, mb->gc,
		      ev->xexpose.x, ev->xexpose.y,
		      ev->xexpose.width, ev->xexpose.height,
		      ev->xexpose.x, ev->xexpose.y);
        }
	else if (mb->pushed >= 0 && mb->pushed < mb->n_menus
		 && ev->xany.window == mb->menuface) {
	    XCopyArea(mb->disp, mb->menuback, mb->menuface, mb->gc,
		      ev->xexpose.x, ev->xexpose.y,
		      ev->xexpose.width, ev->xexpose.height,
		      ev->xexpose.x, ev->xexpose.y);
	}
	break;
    case EnterNotify:
	if (mb->pushed != mb->n_menus) {
	    for (n = 0; n < mb->n_items; ++n) {
		if (ev->xany.window == mb->item_inputs[n]) {
		    SetPopupTextFocus(mb, n);
		    break;
		}
	    }
	}
        for (n = 0; n < mb->n_menus; ++n) {
	    if (ev->xany.window == mb->inputs[n]) {
		if ((mb->grabbed && mb->pushed != mb->n_menus) || !mb->grabbed)
		    SetFocusMenubarText(mb, n);
		if (mb->pushed != mb->n_menus && mb->pushed != n) {
		    FreePopupWindow(mb);
		    mb->pushed = mb->focus; 
		    CreatePopupWindow(mb);
		}
		break;
	    }
	}
	break;
    case LeaveNotify:
	if (ev->xcrossing.mode != NotifyNormal) { /* NotifyGrab */
	    mb->grabbed = 1;
	    break;
	}
	if (mb->pushed != mb->n_menus) {
	    for (n = 0; n < mb->n_items; ++n) {
		if (ev->xany.window == mb->item_inputs[n]) {
		    UnsetPopupTextFocus(mb);
		    break;
		}
	    }
	}
	for (n = 0; n < mb->n_menus; ++n) {
	    if (ev->xany.window == mb->inputs[n]) {
		UnsetFocusMenubarText(mb);
		break;
	    }
	}
        break;
    case ButtonPress:
	if (mb->focus == mb->n_menus
	    || XGrabPointer(mb->disp, mb->menubar, True, EnterWindowMask
			    | LeaveWindowMask | ButtonReleaseMask,
			    GrabModeAsync, GrabModeAsync, None,
			    None, ev->xbutton.time) != GrabSuccess)
	    break;
	mb->pushed = mb->focus; 
	CreatePopupWindow(mb);
	break;
    case ButtonRelease:
	mb->grabbed = 0;
	if (mb->pushed == mb->n_menus)
	    break;
	CallSelectedItem(mb);
	mb->pushed = mb->n_menus; 
	FreePopupWindow(mb);
        XUngrabPointer(mb->disp, ev->xbutton.time);
	break;
    }
}

int
QuerySylMenubarHeight(Display *disp, Font fid)
{
    int dir, ac, dc;
    XCharStruct all;

    XQueryTextExtents(disp, fid, " ", 1, &dir, &ac, &dc, &all);
    return (MENUBAR_MARGIN_H * 2 + dc * 3 + ac);
}
