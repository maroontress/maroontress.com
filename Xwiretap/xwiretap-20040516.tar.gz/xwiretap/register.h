/*
	$Id: register.h,v 1.2 2004/05/05 22:08:00 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

void InitializeRegister(const char *);
void FinalizeRegister(void);
void SubmitRegister(const char *, size_t);
