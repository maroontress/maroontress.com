/*
	$Id: register.c,v 1.3 2004/05/10 00:02:11 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

#include <sys/param.h>
#include <err.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include <pthread.h>
#ifdef USE_MECAB
#include <mecab.h>
#endif

#include "WCString.h"
#include "symbolsystem.h"
#include "database.h"
#include "register.h"

#define ENABLE_QUEUE_PROFILE
#define MAX_IDEOGRAPH_LENGTH 32
#define MBS_DELIMITER \
	",;:.!?|+-*/=\\\"'`<>[](){}" \
	"���������������������ʡˡ֡סΡϡȡɡ��ڡ�"

#if defined(NO_WIDEC_H)
#define isspace_w(x) (((unsigned)(x)) < 0177 && isspace((unsigned)(x)))
#elif defined(HAS_ISW_FUNCS)
#define isspace_w iswspace
#else
#define isspace_w isspace
#endif

static mecab_t *theMecab = NULL;
static char dictionary[MAXPATHLEN];

static wchar_t *
wcs_create(const char *mbs)
{
    int bytes, len;
    wchar_t *wcs;

    if (mbs == NULL)
	return (NULL);
    bytes = strlen(mbs) + 1;
    if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * bytes)) == NULL
        || (len = mbstowcs(wcs, mbs, bytes)) < 0) {
        return (NULL);
    }
    return (wstrdup(wcs));
}

static char *
mbs_create(const wchar_t *wcs)
{
    int bytes;
    char *mbs;

    if (wcs == NULL)
	return (NULL);
    bytes = MB_LEN_MAX * wstrlen(wcs) + 1;
    if ((mbs = (char *)alloca(bytes)) == NULL
        || (int)wcstombs(mbs, wcs, bytes) < 0) {
        return (NULL);
    }
    return (strdup(mbs));
}

typedef struct Clause {
    struct Clause *next;
    int sp;
    unsigned char *yomi;
    int yomi_len;
    unsigned char *kanji; /* reference */
    int kanji_len;
    int phonetic_length;
    int ideograph_length;
    int is_suffix;
    int is_unknown;
} Clause;

static Clause *
CreateClause(int sp, char *hinshi, char *yomi, char *kanji)
{
    Clause *c;
    wchar_t *wcs;

    if ((c = (Clause *)malloc(sizeof(Clause))) == NULL)
	return NULL;
    c->next = NULL;
    c->sp = sp;
    if ((wcs = wcs_create((*yomi != 0) ? yomi : kanji)) == NULL
	|| (c->yomi = mbs_create(ReplaceSymbolSystem(wcs))) == NULL) {
	free(c);
	return NULL;
    }
    c->yomi_len = strlen(c->yomi);
    c->kanji = kanji;
    c->kanji_len = strlen(c->kanji);
    c->phonetic_length = 0;
    c->ideograph_length = 0;
    c->is_suffix = (strcmp(hinshi, "��³����x") == 0);
    c->is_unknown = (*yomi == 0);
    return (c);
}

static void
FreeClause(Clause *c)
{
    free(c->yomi);
    free(c);
}

static Clause *
NextClause(Clause *c)
{
    Clause *n, *next;

    if (c->is_unknown || (n = c->next) == NULL)
	return NULL;
    for (; n != NULL && n->is_suffix; n = next) {
	next = n->next;
	c->phonetic_length += n->phonetic_length;
	c->ideograph_length += n->ideograph_length;
	FreeClause(n);
    }
    c->next = n;
    return n;
}

typedef struct {
    unsigned char *phonetic;
    unsigned char *ideograph;
    Clause *clause;
} Phonetic;

static void
FreePhonetic(Phonetic *p)
{
    Clause *c, *next;

    if (p == NULL)
	return;
    free(p->phonetic);
    free(p->ideograph);
    for (c = p->clause; c != NULL; c = next) {
	next = c->next;
	FreeClause(c);
    }
    free(p);
}

static Phonetic *
CreatePhonetic(const wchar_t *wcs)
{
    Phonetic *p;
    Clause *head, *tail, *c;
    char *res, *ln, *startPosition;
    unsigned char *hinshi, *kanji, *yomi, *y;
    int sp, yomiLen, k;

    if ((p = (Phonetic *)malloc(sizeof(Phonetic))) == NULL)
	return NULL;
    p->phonetic = NULL;
    p->ideograph = NULL;
    p->clause = NULL;

    /*
      MeCab�Ƿ����Ǥ�ʬ��
    */
    if ((p->ideograph = mbs_create(wcs)) == NULL) {
	FreePhonetic(p);
	return NULL;
    }
    if ((res = mecab_sparse_tostr(theMecab, p->ideograph)) == NULL) {
	warnx("mecab_sparse_tostr: %s", mecab_strerror(theMecab));
	FreePhonetic(p);
	return NULL;
    }
    head = NULL;
    tail = NULL;
    while ((ln = strsep(&res, "\n")) != NULL) {
	if ((startPosition = strsep(&ln, " ")) == NULL
	    || (sp = atoi(startPosition)) < 0
	    || (hinshi = strsep(&ln, " ")) == NULL
	    || (kanji = strsep(&ln, " ")) == NULL
	    || (yomi = strsep(&ln, " ")) == NULL
	    || (c = CreateClause(sp, hinshi, yomi, kanji)) == NULL)
	    break;
	if (head == NULL)
	    head = c;
	else
	    tail->next = c;
	tail = c;
    }
    p->clause = head;
    if (ln != NULL || head == NULL) {
	FreePhonetic(p);
	return NULL;
    }

    /*
      ������ɤ�ʸ�����ɽ��ʸ�����Ĺ������롣
    */
    yomiLen = 0;
    for (c = p->clause; c != tail; c = c->next) {
	c->ideograph_length = c->next->sp - c->sp;
	c->phonetic_length = c->yomi_len + c->ideograph_length - c->kanji_len;
	yomiLen += c->phonetic_length;
    }
    c->ideograph_length = c->kanji_len;
    c->phonetic_length = c->yomi_len;
    yomiLen += c->phonetic_length;

    /*
      �ɤ�ʸ�����Ϣ�롣
    */
    if ((p->phonetic = (char *)malloc(yomiLen + 1)) == NULL) {
	FreePhonetic(p);
	return NULL;
    }
    for (y = p->phonetic, c = p->clause; c != NULL; c = c->next) {
	bcopy(c->yomi, y, c->yomi_len);
	y += c->yomi_len;
	for (k = c->yomi_len; k < c->phonetic_length; ++k) {
	    *y++ = ' ';
	}
    }
    *y = 0;

    /*
      ��³��������ľ�������Ϣ�뤹�롣��:
      "���Ƥ�����" �� |��|��|����|��| �� |����|������|
    */
    for (c = p->clause; c != NULL; c = NextClause(c))
	;
    return p;
}

static char *
trim(char *str)
{
    char *top;

    while (*str && isspace(*str))
        ++str;
    for (top = str; *str; ++str)
	;
    for (--str; top < str && isspace(*str); *str-- = 0)
	;
    return (top);
}

static void
Register(unsigned char *y, unsigned char *k)
{
    y = trim(y);
    k = trim(k);
#ifdef DEBUG
    warnx("yomi-kanji: |%s|%s|", y, k);
#endif
    PutDatabase(y, k);
    if (strcmp(y, k)) {
	PutDatabase(k, k);
    }
}

static wchar_t *
wtrim(wchar_t *str)
{
    wchar_t *top;

    while (*str && isspace_w(*str))
        ++str;
    for (top = str; *str; ++str)
	;
    for (--str; top < str && isspace_w(*str); *str-- = 0)
	;
    return (top);
}

static void
RegisterToken(wchar_t *ideograph)
{
    Phonetic *p;
    Clause *c;
    unsigned char *y, *k, sk, sy;
    int ideograph_offset, phonetic_offset, ideograph_length;
    
    ideograph = wtrim(ideograph);
#ifdef DEBUG
    {
	char *s = mbs_create(ideograph);
	warnx("token: |%s|", s);
	free(s);
    }
#endif
    if ((ideograph_length = wstrlen(ideograph)) == 0
	|| (p = CreatePhonetic(ideograph)) == NULL) {
	return;
    }
    for (y = p->phonetic; *y != 0 && *y >= ' '; ++y)
	;
    if (*y != 0) {
	warnx("unexpected code: (%d) |%s|%s|", *y, p->phonetic, p->ideograph);
	FreePhonetic(p);
	return;
    }
    ideograph_offset = 0;
    phonetic_offset = 0;
    for (c = p->clause; c != NULL; c = c->next) {
	if (ideograph_length <= MAX_IDEOGRAPH_LENGTH) {
	    k = &(p->ideograph[ideograph_offset]);
	    y = &(p->phonetic[phonetic_offset]);
	    Register(y, k);
	}
	ideograph_offset += c->ideograph_length;
	ideograph_length -= c->ideograph_length;
	phonetic_offset += c->phonetic_length;
    }
    for (ideograph_offset = 0,
	     phonetic_offset = 0,
	     c = p->clause;
	 c->next != NULL;
	 ideograph_offset += c->ideograph_length,
	     phonetic_offset += c->phonetic_length,
	     c = c->next) {
	if (c->ideograph_length > MAX_IDEOGRAPH_LENGTH)
	    continue;
	if (c->is_unknown) {
	    Register(c->yomi, c->kanji);
	    continue;
	}
	k = &(p->ideograph[ideograph_offset]);
	y = &(p->phonetic[phonetic_offset]);
	sk = k[c->ideograph_length];
	sy = y[c->phonetic_length];
	k[c->ideograph_length] = 0;
	y[c->phonetic_length] = 0;
	Register(y, k);
	k[c->ideograph_length] = sk;
	y[c->phonetic_length] = sy;
    }
    FreePhonetic(p);
}

static wchar_t *
GetDefaultDelimiter(void)
{
    static wchar_t *wcs = NULL;

    if (wcs == NULL)
	wcs = wcs_create(MBS_DELIMITER);
    return (wcs);
}

static void
submit(const char *mbs)
{
    wchar_t *wcs, *p, *token, *delim;

    if ((delim = GetDefaultDelimiter()) == NULL)
	return;
    if ((wcs = wcs_create(mbs)) == NULL)
	return;
    if (OpenDatabase(dictionary)) {
	warnx("OpenDatabase() failed.");
	free(wcs);
	return;
    }
    for (p = wcs; (token = wstrsep(&p, delim)) != NULL; RegisterToken(token))
	;
    (void)CloseDatabase();
    free(wcs);
}

typedef struct {
    pthread_mutex_t section;
    pthread_cond_t state_changed;
} Synchronizer;

#define LOCK(x)                                                      \
    if (pthread_mutex_lock(&(x)->section)) {                         \
        warn("%s:%s: pthread_mutex_lock", __FILE__, __FUNCTION__);   \
	abort();                                                     \
    }

#define UNLOCK(x)                                                    \
    if (pthread_mutex_unlock(&(x)->section)) {                       \
        warn("%s:%s: pthread_mutex_unlock", __FILE__, __FUNCTION__); \
	abort();                                                     \
    }

#define NOTIFY(x)                                                    \
    if (pthread_cond_signal(&(x)->state_changed)) {                  \
        warn("%s:%s: pthread_cond_signal", __FILE__, __FUNCTION__);  \
        abort();                                                     \
    }

#define WAIT(x)                                                      \
    if (pthread_cond_wait(&(x)->state_changed, &(x)->section)) {     \
        warn("%s:%s: pthread_cond_wait", __FILE__, __FUNCTION__);    \
        abort();                                                     \
    }

static void
InitializeSynchronizer(Synchronizer *s)
{
    if (pthread_mutex_init(&s->section, NULL)) {
        warn("%s:%s: pthread_mutex_init", __FILE__, __FUNCTION__);
	abort();
    }
    if (pthread_cond_init(&s->state_changed, NULL)) {
        warn("%s:%s: pthread_cond_init", __FILE__, __FUNCTION__);
	abort();
    }
}

static void
FinalizeSynchronizer(Synchronizer *s)
{
    if (pthread_mutex_destroy(&s->section)) {
        warn("%s:%s: pthread_mutex_destroy", __FILE__, __FUNCTION__);
	abort();
    }
    if (pthread_cond_destroy(&s->state_changed)) {
        warn("%s:%s: pthread_cond_destroy", __FILE__, __FUNCTION__);
	abort();
    }
}

typedef struct Request {
    struct Request *next;
    size_t size;
    unsigned char data[0];
} Request;

static Synchronizer queue_gate;
static int queue_count;
static Request *queue_head;
static Request *queue_tail;;
static pthread_t driver;
#ifdef ENABLE_QUEUE_PROFILE
static int queue_max_count;
#endif

static void
InitializeQueue(void)
{
    InitializeSynchronizer(&queue_gate);
    queue_count = 0;
    queue_head = NULL;
    queue_tail = NULL;
#ifdef ENABLE_QUEUE_PROFILE
    queue_max_count = 0;
#endif
}

static void
FinalizeQueue(void)
{
    Request *next;

    FinalizeSynchronizer(&queue_gate);
    for (; queue_head != NULL; queue_head = next) {
	next = queue_head->next;
	free(queue_head);
    }
}

static void *
run(void *arg __unused)
{
    int s;
    Request *req;

    for (;;) {
	LOCK(&queue_gate);
	while ((s = queue_count) == 0) {
	    WAIT(&queue_gate);
	}
	if (s < 0) {
	    UNLOCK(&queue_gate);
	    return NULL;
	}
	if (queue_count > 64) {
	    int k, n;

	    for (k = 0, n = queue_count / 4; k < n; ++k) {
		req = queue_head;
		queue_head = queue_head->next;
		--queue_count;
		free(req);
	    }
	}
	req = queue_head;
	queue_head = queue_head->next;
	--queue_count;
	UNLOCK(&queue_gate);
	submit(req->data);
	free(req);
	usleep(1 * 1000);
    }
    return NULL;
}

void
SubmitRegister(const char *mbs, size_t size)
{
    Request *req;

    if ((req = (Request *)malloc(sizeof(Request) + size)) == NULL)
	return;
    req->next = NULL;
    req->size = size;
    bcopy(mbs, req->data, req->size);
    LOCK(&queue_gate);
    if (queue_head == NULL)
	queue_head = req;
    else
	queue_tail->next = req;
    queue_tail = req;
    ++queue_count;
#ifdef ENABLE_QUEUE_PROFILE
    if (queue_max_count < queue_count)
	queue_max_count = queue_count;
#endif
    NOTIFY(&queue_gate);
    UNLOCK(&queue_gate);
}

void
InitializeRegister(const char *s)
{
    const char *av[] = {"mecab",
			"--node-format=%ps %f[1]x %m %f[7]\n",
			"--eos-format=\\0",
			NULL};

    if ((theMecab = mecab_new(3, (char **)av)) == NULL) {
	errx(1, "mecab_new() failed.");
    }
    snprintf(dictionary, sizeof(dictionary), "%s", s);
    InitializeSylbolSystem();
    InitializeQueue();

    if (pthread_create(&driver, NULL, run, NULL)) {
        warn("%s:%s: pthread_create", __FILE__, __FUNCTION__);
        abort();
    }
}

void
FinalizeRegister(void)
{
    void *status;

    LOCK(&queue_gate);
    queue_count = -1;
    NOTIFY(&queue_gate);
    UNLOCK(&queue_gate);
    if (pthread_join(driver, &status)) {
        warn("%s:%s: pthread_join", __FILE__, __FUNCTION__);
        abort();
    }
#ifdef ENABLE_QUEUE_PROFILE
    warnx("queue_max_count: %d", queue_max_count);
#endif

    mecab_destroy(theMecab);
    FinalizeSylbolSystem();
    FinalizeQueue();
}
