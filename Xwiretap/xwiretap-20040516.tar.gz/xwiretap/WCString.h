/*
	$Id: WCString.h,v 1.1 2004/05/02 22:02:04 syl Exp $

	Copyright (C) 1998, 1999, 2003 Syllabub
	Maroontress Fast Software.
*/

int wstrlen(const wchar_t *str);
wchar_t * wstrcpy(wchar_t *d, const wchar_t *s);
wchar_t * wstrncpy(wchar_t *d, const wchar_t *s, int n);
wchar_t * wstrdup(const wchar_t *s);
int wstrcmp(const wchar_t *s, const wchar_t *t);
wchar_t * wstrchr(const wchar_t *s, wchar_t c);
wchar_t * wstrsep(wchar_t **stringp, const wchar_t *delim);
