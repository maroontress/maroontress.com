/*
	$Id: database.c,v 1.2 2004/05/09 03:19:04 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

#include <sys/stat.h>
#include <sys/types.h>
#ifdef linux
#include "db.h"
#else
#include <db.h>
#endif
#include <err.h>
#include <fcntl.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

#include "database.h"

#if 1
#define HAS_BSD_OPEN (!defined(_POSIX_SOURCE) \
                      && defined(O_SHLOCK) && defined(O_EXLOCK))

#if HAS_BSD_OPEN
#define WRITE_DB_FLAGS (O_CREAT | O_RDWR | O_EXLOCK)
#else
#include <sys/file.h>
#define WRITE_DB_FLAGS (O_CREAT | O_RDWR)
#endif /* HAS_BSD_OPEN */

static DB *db = NULL;
static time_t stamp;

int
OpenDatabase(const char *file)
{
    const int flags = WRITE_DB_FLAGS;
    const int mode = S_IRUSR | S_IWUSR;

    if ((db = dbopen(file, flags, mode, DB_BTREE, NULL)) == NULL) {
        warnx("dbopen() failed.");
	return -1;
    }
#if !HAS_BSD_OPEN
    flock(db->fd(db), LOCK_EX);
#endif
    stamp = time(NULL);
    return 0;
}

int
CloseDatabase(void)
{
    return db->close(db);
}

void
PutDatabase(const char *pre, const char *post)
{
    int prelen = strlen(pre) + 1;
    int postlen = strlen(post) + 1;
    char *data;
    DBT key, val;
    
    if ((data = (char *)alloca(prelen + postlen)) == NULL)
        return;
    memcpy(data, pre, prelen);
    memcpy(data + prelen, post, postlen);
    key.data = (void *)data;
    key.size = prelen + postlen;
    val.data = (void *)&stamp;
    val.size = sizeof(stamp);
    db->put(db, &key, &val, 0);
}
#else
#include <sys/file.h>
#define WRITE_DB_FLAGS (O_CREAT | O_RDWR)

static DB *db = NULL;
static time_t stamp;

int
OpenDatabase(const char *file)
{
    const int flags = WRITE_DB_FLAGS;
    const int mode = S_IRUSR | S_IWUSR;

    if (db == NULL
	&& (db = dbopen(file, flags, mode, DB_BTREE, NULL)) == NULL) {
        warnx("dbopen() failed.");
	return -1;
    }
    flock(db->fd(db), LOCK_EX);
    stamp = time(NULL);
    return 0;
}

int
CloseDatabase(void)
{
    db->sync(db, 0);
    flock(db->fd(db), LOCK_UN);
    return 0;
}

void
PutDatabase(const char *pre, const char *post)
{
    int prelen = strlen(pre) + 1;
    int postlen = strlen(post) + 1;
    char *data;
    DBT key, val;
    
    if ((data = (char *)alloca(prelen + postlen)) == NULL)
        return;
    memcpy(data, pre, prelen);
    memcpy(data + prelen, post, postlen);
    key.data = (void *)data;
    key.size = prelen + postlen;
    val.data = (void *)&stamp;
    val.size = sizeof(stamp);
    db->put(db, &key, &val, 0);
}
#endif
