/*
	$Id: symbolsystem.h,v 1.1 2004/05/02 22:02:05 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

wchar_t * ReplaceSymbolSystem(wchar_t *);
void InitializeSylbolSystem(void);
void FinalizeSylbolSystem(void);
