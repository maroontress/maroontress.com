/*
	$Id: WCString.c,v 1.1 2004/05/02 22:02:04 syl Exp $

	Copyright (C) 1998, 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>

#include "WCString.h"

int
wstrlen(const wchar_t *str)
{
    int n;
    
    for (n = 0; *str; ++n)
	++str;
    return (n);
}

wchar_t *
wstrcpy(wchar_t *d, const wchar_t *s)
{
    wchar_t *p = d;

    while ((*d = *s) != 0) {
	++d;
	++s;
    }
    return (p);
}

wchar_t *
wstrncpy(wchar_t *d, const wchar_t *s, int n)
{
    wchar_t *p = d;

    while (n > 0 && *s != 0) {
	*d = *s;
	++d;
	++s;
	--n;
    }
    while (n > 0) {
	*d = 0;
	++d;
	--n;
    }
    return (p);
}

wchar_t *
wstrdup(const wchar_t *s)
{
    wchar_t *d;

    if ((d = (wchar_t *)malloc((wstrlen(s) + 1) * sizeof(wchar_t))) == NULL)
        return (NULL);
    wstrcpy(d, s);
    return (d);
}

int
wstrcmp(const wchar_t *s, const wchar_t *t)
{
    while (*s != 0 && *s == *t) {
	++s;
	++t;
    }
    return (*s - *t);
}

wchar_t *
wstrchr(const wchar_t *s, wchar_t c)
{
    while (*s != 0 && *s != c)
	++s;
    return ((*s != c) ? NULL : (wchar_t *)s);
}

wchar_t *
wstrsep(wchar_t **stringp, const wchar_t *delim)
{
    wchar_t *top, *p;
    wchar_t *s = NULL;

    top = *stringp;
    if (*top == 0)
        return NULL;
    for (p = top; *p != 0 && (s = wstrchr(delim, *p)) == NULL; ++p)
	;
    *stringp = (*p == 0) ? p : p + 1;
    *p = 0;
    return top;
}
