/*
	$Id: xwiretap.c,v 1.2 2004/05/02 22:02:05 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

#include <sys/param.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <locale.h>
#include <ctype.h>
#include <pthread.h>
#include <netinet/tcp.h>

#include "sentence.h"

#if 0
#define TRACE
#endif

#define N_LISTENING 4

static const char *reference_dictionary = "/tmp/reference.db";

typedef struct {
    pthread_t thread;
    int in;
    int out;
    void *status;
} RelayContext;

static void
set_nodelay(int fd)
{
    int opt;
    socklen_t optlen = sizeof(opt);

    if (getsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &opt, &optlen) < 0) {
	warn("getsockopt");
	return;
    }
    if (opt == 1)
	return;

    opt = 1;
    if (setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt)) < 0)
	warn("setsockopt");
}

static void *
simple_relay(void *arg)
{
    RelayContext *context = (RelayContext *)arg;
    unsigned char buf[1024], *p;
    int s, n;

    for (;;) {
	if ((n = recv(context->in, buf, sizeof(buf), 0)) < 0) {
	    warn("recv");
	    return NULL;
	}
	else if (n == 0) {
	    return NULL;
	}
	for (p = buf; n > 0;) {
	    if ((s = send(context->out, p, n, 0)) < 0) {
		warn("send");
		return NULL;
	    }
	    p += s;
	    n -= s;
	}
    }
    /* NOTREACHED */
    return NULL;
}

#define PAD(x) (((x) + 3) & ~3)

static int
relay_request(FILE *in, FILE *out)
{
    int i, c;
    int opcode;
    int unused;
    unsigned short requestLength;
    int size;

    if ((opcode = fgetc(in)) == EOF
	|| (unused = fgetc(in)) == EOF
	|| fread(&requestLength, 2, 1, in) < 1) {
	return -1;
    }

    fputc(opcode, out);
    fputc(unused, out);
    fwrite(&requestLength, 2, 1, out);

    switch (opcode) {
    case 74:
    {
	unsigned char *request;
	int drawable, gc;
	short x, y;
	int stringLength, delta, font;
	
	size = requestLength - 1;
	size *= 4;
	if ((request = alloca(size)) == NULL)
	    goto relay_req_packet;
	if (fread(request, size, 1, in) < 1)
	    return -1;
	fwrite(request, size, 1, out);
	    
	drawable = *(int *)(request);
	gc = *(int *)(request + 4);
	x = *(short *)(request + 8);
	y = *(short *)(request + 10);
#ifdef TRACE
	printf("PolyText8:\n"
	       "  reqLen=%d, d=0x%x, gc=0x%x, x=%d, y=%d\n",
	       requestLength, drawable, gc, x, y);
#endif
	sentence_set_context(drawable, gc, x, y);
	request += 12;
	size -= 12;
	for (i = 0; size > 1 && (stringLength = request[0]) > 0; ++i) {
	    if (stringLength == 255) {
		font = ((request[1] << 24) | (request[2] << 16)
			| (request[3] << 8) | request[4]);
#ifdef TRACE
		printf("  [%d] font-shift indicator: 0x%x\n", i, font);
#endif
		request += 5;
		size -= 5;
		continue;
	    }
	    delta = request[1];
	    request += 2;
	    size -= 2;
#ifdef TRACE
	    printf("  [%d] textitem: %*.*s(delta=%d)\n", i, stringLength,
		   stringLength, request, delta);
#endif
	    sentence_add_string(0, request, stringLength);
	    request += stringLength;
	    size -= stringLength;
	}
	break;
    }
    case 75:
    {
	unsigned char *request;
	int drawable, gc;
	short x, y;
	int stringLength, k, n, delta, font;

	size = requestLength - 1;
	size *= 4;
	if ((request = alloca(size)) == NULL)
	    goto relay_req_packet;
	if (fread(request, size, 1, in) < 1)
	    return -1;
	fwrite(request, size, 1, out);
	    
	drawable = *(int *)(request);
	gc = *(int *)(request + 4);
	x = *(short *)(request + 8);
	y = *(short *)(request + 10);
#ifdef TRACE
	printf("PolyText16:\n"
	       "  reqLen=%d, d=0x%x, gc=0x%x, x=%d, y=%d\n",
	       requestLength, drawable, gc, x, y);
#endif
	sentence_set_context(drawable, gc, x, y);
	request += 12;
	size -= 12;
	for (i = 0; size > 1 && (stringLength = request[0]) > 0; ++i) {
	    if (stringLength == 255) {
		font = ((request[1] << 24) | (request[2] << 16)
			| (request[3] << 8) | request[4]);
#ifdef TRACE
		printf("  [%d] font-shift indicator: 0x%x\n", i, font);
#endif
		request += 5;
		size -= 5;
		continue;
	    }
	    delta = request[1];
	    request += 2;
	    size -= 2;
	    n = stringLength * 2;
	    for (k = 0; k < n; ++k)
		request[k] |= 0x80;
#ifdef TRACE
	    printf("  [%d] textitem: %*.*s(delta=%d)\n", i, n, n, request,
		   delta);
#endif
	    sentence_add_string(1, request, n);
	    request += n;
	    size -= n;
	}
	break;
    }
    case 76:
    {
	unsigned char *request;
	int length, drawable, gc;
	short x, y;
	unsigned char *string;

	size = requestLength - 1;
	size *= 4;
	if ((request = alloca(size)) == NULL)
	    goto relay_req_packet;
	if (fread(request, size, 1, in) < 1)
	    return -1;
	fwrite(request, size, 1, out);
	    
	length = unused;
	drawable = *(int *)(request);
	gc = *(int *)(request + 4);
	x = *(short *)(request + 8);
	y = *(short *)(request + 10);
	string = request + 12;
#ifdef TRACE
	printf("ImageText8:\n"
	       "  len=%d, reqLen=%d, d=0x%x, gc=0x%x, x=%d, y=%d\n"
	       "  string=%*.*s\n",
	       length, requestLength, drawable, gc, x, y, length, length,
	       string);
#endif
	sentence_set_context(drawable, gc, x, y);
	sentence_add_string(0, string, length);
	break;
    }
    case 77:
    {
	unsigned char *request;
	int length, drawable, gc;
	short x, y;
	unsigned char *string;
	int k, n;

	size = requestLength - 1;
	size *= 4;
	if ((request = alloca(size)) == NULL)
	    goto relay_req_packet;
	if (fread(request, size, 1, in) < 1)
	    return -1;
	fwrite(request, size, 1, out);

	length = unused;
	drawable = *(int *)(request);
	gc = *(int *)(request + 4);
	x = *(short *)(request + 8);
	y = *(short *)(request + 10);
	string = request + 12;
	for (n = length * 2, k = 0; k < n; ++k)
	    string[k] |= 0x80;
#ifdef TRACE
	printf("ImageText16:\n"
	       "  length=%d, reqLen=%d, d=0x%x, gc=0x%x, x=%d, y=%d\n"
	       "  string=%*.*s\n",
	       length, requestLength, drawable, gc, x, y, n, n, string);
#endif
	sentence_set_context(drawable, gc, x, y);
	sentence_add_string(1, string, n);
	break;
    }
    relay_req_packet:
    default:
	/* printf("opcode:%d requestLength=%d\n", opcode, requestLength); */
	size = requestLength - 1;
	size *= 4;
	for (i = 0; i < size; ++i) {
	    if ((c = fgetc(in)) == EOF)
		return -1;
	    fputc(c, out);
	}
	break;
    }
#if 1
    {
	struct timeval timeout = {0L, 0L};
	fd_set fdset;

	FD_ZERO(&fdset);
	FD_SET(fileno(in), &fdset);
	if (select(fileno(in) + 1, &fdset, NULL, NULL, &timeout) == 0) {
	    fflush(out);
	}
    }
#else
    fflush(out);
#endif
    return 0;
}

static void *
wiretap_relay(void *arg)
{
    RelayContext *context = (RelayContext *)arg;
    FILE *in, *out;
    int byte_order;
    unsigned short protocol_major_verion;
    unsigned short protocol_minor_verion;
    unsigned short auth_proto_name_len;
    unsigned short auth_proto_data_len;
    short unused;
    unsigned char *auth_proto_name;
    unsigned char *auth_proto_data;

    if ((in = fdopen(context->in, "r")) == NULL)
	err(1, "fdopen");
    if ((out = fdopen(context->out, "w")) == NULL)
	err(1, "fdopen");

    byte_order = fgetc(in);
    unused = fgetc(in);
    fputc(byte_order, out);
    fputc(unused, out);
#ifdef TRACE
    printf("byte_order: %c\n", byte_order);
    printf("unused: %d\n", unused);
#endif
    
    if (fread(&protocol_major_verion, 2, 1, in) < 1
	|| fread(&protocol_minor_verion, 2, 1, in) < 1
	|| fread(&auth_proto_name_len, 2, 1, in) < 1
	|| fread(&auth_proto_data_len, 2, 1, in) < 1
	|| fread(&unused, 2, 1, in) < 1) {
	return NULL;
    }
    fwrite(&protocol_major_verion, 2, 1, out);
    fwrite(&protocol_minor_verion, 2, 1, out);
    fwrite(&auth_proto_name_len, 2, 1, out);
    fwrite(&auth_proto_data_len, 2, 1, out);
    fwrite(&unused, 2, 1, out);
#ifdef TRACE
    printf("protocol verion: %d.%d\n",
	   protocol_major_verion, protocol_minor_verion);
    printf("auth_proto_name_len: %d\n", auth_proto_name_len);
    printf("auth_proto_data_len: %d\n", auth_proto_data_len);
#endif

    if (auth_proto_name_len > 0) {
	if ((auth_proto_name = alloca(PAD(auth_proto_name_len))) == NULL
	    || fread(auth_proto_name, PAD(auth_proto_name_len), 1, in) < 1) {
	    return NULL;
	}
	fwrite(auth_proto_name, PAD(auth_proto_name_len), 1, out);
#ifdef TRACE
	{
	    int i;
	    
	    printf("auth_proto_name: [");
	    for (i = 0; i < auth_proto_name_len; ++i)
		printf("%c", auth_proto_name[i]);
	    printf("]\n");
	}
#endif
    }
    if (auth_proto_data_len > 0) {
	if ((auth_proto_data = alloca(PAD(auth_proto_data_len))) == NULL
	    || fread(auth_proto_data, PAD(auth_proto_data_len), 1, in) < 1) {
	    return NULL;
	}
	fwrite(auth_proto_data, PAD(auth_proto_data_len), 1, out);
#ifdef TRACE
	{
	    int i;

	    printf("auth_proto_data: [");
	    for (i = 0; i < auth_proto_data_len; ++i)
		printf("%.2X ", auth_proto_data[i]);
	    printf("]\n");
	}
#endif
    }
    fflush(out);
	
    sentence_initialze(reference_dictionary);
    while (relay_request(in, out) == 0)
	;
    sentence_finalize();
    return NULL;
}

static void
serve(int s)
{
    const in_addr_t any = htonl(INADDR_ANY);
    struct sockaddr_in ai;
    int xs;
    RelayContext event, request;

    if ((xs = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	err(1, "socket");
    ai.sin_family = AF_INET;
    ai.sin_port = htons(6000);
    bcopy(&any, &ai.sin_addr, sizeof(any));
    bzero(&ai.sin_zero, 8);
    if (connect(xs, (struct sockaddr *)&ai, sizeof(ai)) < 0)
	err(1, "connect");

    set_nodelay(s);
    set_nodelay(xs);

    event.in = xs;
    event.out = s;
    if (pthread_create(&event.thread, NULL, simple_relay, &event))
        err(1, "%s: pthread_create", __FUNCTION__);

    request.in = s;
    request.out = xs;
    if (pthread_create(&request.thread, NULL, wiretap_relay, &request))
        err(1, "%s: pthread_create", __FUNCTION__);

    if (pthread_join(request.thread, &request.status))
        err(1, "%s: pthread_join", __FUNCTION__);
    if (pthread_cancel(event.thread))
        err(1, "%s: pthread_cancel", __FUNCTION__);
    if (pthread_join(event.thread, &event.status))
        err(1, "%s: pthread_join", __FUNCTION__);

    close(xs);
    close(s);
}

int
main(int ac, char **av)
{
    const in_addr_t any = htonl(INADDR_ANY);
    int n, s, ca_len;
    struct sockaddr_in ai, ca;
    pid_t pid;

    setlocale(LC_ALL, "");

    if (ac > 2) {
	fprintf(stderr, "usage: %s [reference-dictionary-file]\n", av[0]);
	exit(0);
    }
    if (ac == 2) {
	reference_dictionary = av[1];
    }

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        err(1, "socket");
    ai.sin_family = AF_INET;
    ai.sin_port = htons(6001);
    bcopy(&any, &ai.sin_addr, sizeof(any));
    bzero(&ai.sin_zero, 8);
    if (bind(s, (struct sockaddr *)&ai, sizeof(ai)) < 0)
        err(1, "bind");
    if (listen(s, N_LISTENING) < 0)
        err(1, "listen");

#ifdef TRACE
    warnx("start serving");
#endif
    for (;;) {
	ca_len = sizeof(ca);
        if ((n = accept(s, (struct sockaddr *)&ca, &ca_len)) < 0) {
            warnx("accept");
	    continue;
	}
#ifdef TRACE
        warnx("called from %d:%d:%d:%d",
	      ((unsigned char *)&ca.sin_addr)[0],
	      ((unsigned char *)&ca.sin_addr)[1],
	      ((unsigned char *)&ca.sin_addr)[2],
	      ((unsigned char *)&ca.sin_addr)[3]);
#endif
        if ((pid = fork()) < 0)
            err(1, "fork");
        if (pid == 0) {
	    close(s);
#ifdef TRACE
	    warnx("connection opened");
#endif
	    serve(n);
#ifdef TRACE
	    warnx("connection closed");
#endif
	    exit(0);
	}
    }
    /* NOTREACHED */
    exit(0);
    return 0;
}
