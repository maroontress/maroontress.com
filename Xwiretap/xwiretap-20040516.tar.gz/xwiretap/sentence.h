/*
	$Id: sentence.h,v 1.2 2004/05/02 22:02:04 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

void sentence_initialze(const char *);
void sentence_finalize(void);
void sentence_set_context(int drawable, int gc, int x, int y);
void sentence_add_string(int is2b, const char *string, size_t length);
void sentence_flush(void);
