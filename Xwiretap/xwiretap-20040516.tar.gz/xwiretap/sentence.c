/*
	$Id: sentence.c,v 1.3 2004/05/05 22:08:00 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#include "register.h"
#include "sentence.h"

typedef struct {
    int is2b;
    int drawable;
    int gc;
    int baseline;
    int x;
} Context;

static unsigned char buffer[4096];
static size_t offset;
static int overflow;
static Context context;

void
sentence_initialze(const char *s)
{
    InitializeRegister(s);
    offset = 0;
    overflow = 0;
    context.is2b = 1;
    context.drawable = 0;
    context.gc = 0;
    context.baseline = 0;
    context.x = 0;
}

static void
context_changed(int drawable, int gc, int x, int y)
{
    if (overflow) {
#ifdef DEBUG
	warnx("sentence: overflow");
#endif
    }
    else if (offset > 0) {
	buffer[offset] = 0;
#ifdef DEBUG
	warnx("sentence: %s", buffer);
#endif
	SubmitRegister(buffer, offset + 1);
    }
    offset = 0;
    overflow = 0;
    context.is2b = 1;
    context.drawable = drawable;
    context.gc = gc;
    context.baseline = y;
    context.x = x;
}

void
sentence_set_context(int drawable, int gc, int x, int y)
{
    if (context.drawable == drawable
	&& context.baseline == y && context.x == x) {
	context_changed(drawable, gc, x, y);
	return;
    }
    if (context.drawable == drawable
	&& context.baseline <= y
        && (context.gc == gc || (context.baseline == y && context.x < x))) {
        context.gc = gc;
        context.baseline = y;
        context.x = x;
        return;
    }
    context_changed(drawable, gc, x, y);
}

void
sentence_add_string(int is2b, const char *string, size_t length)
{
    if (overflow)
	return;
    if (offset + length + 1 >= sizeof(buffer)) {
	/* too long sentnce? */
	overflow = 1;
	return;
    }
    if (!context.is2b && !is2b && !isspace(*string)) {
	buffer[offset] = ' ';
	++offset;
    }
    bcopy(string, buffer + offset, length);
    offset += length;
    context.is2b = is2b;
}

void
sentence_flush(void)
{
    context_changed(0, 0, 0, 0);
}

void
sentence_finalize(void)
{
    FinalizeRegister();
}
