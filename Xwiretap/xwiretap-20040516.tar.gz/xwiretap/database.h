/*
	$Id: database.h,v 1.1 2004/05/02 22:02:04 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

int OpenDatabase(const char *);
int CloseDatabase(void);
void PutDatabase(const char *, const char *);
