/*
        $Id$

        Copyright (C) 2000 Syllabub
        Maroontress Fast Software.
*/

typedef struct BorderDecorator {
    Display *disp;
    Window root;
    Window window;
    GC gc;
    int root_width;
    int root_height;
    int x;
    int y;
    int width;
    int height;
    int depth;
    int ascent;

    XRectangle child;
    XPoint spot;

    int redraw;
    int resize;
} BorderDecorator;

BorderDecorator * CreateBorderDecorator(Display *disp, Window window);
void FreeBorderDecorator(BorderDecorator *);
void SendBorderDecorator(BorderDecorator *, XEvent *);
int NiceBorderDecorator(BorderDecorator *);

void MoveBorderDecorator(BorderDecorator *, int, int, int *, int *);
void ResizeBorderDecorator(BorderDecorator *, int, int, int);
