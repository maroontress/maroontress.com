/*
        $Id$

        Copyright (C) 2001 Syllabub
        Maroontress Fast Software.
*/

void SetProperties(Display *, Window, char *, char *, char *, int, char **,
		   XSizeHints *, Pixmap, Pixmap, Window);
