/*
        $Id$

        Copyright (C) 2000 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#ifdef HAS_WCHAR_H
#include <wchar.h>
#endif
#ifdef HAS_WCTYPE_H
#include <wctype.h> /* widec.h������˸ƤФ�� */
#endif

#include "Resource.h"
#include "Text.h"
#include "PreeditStringPainter.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define THIS_CLASS "PreeditStringPainter"

#include "PreeditStringPainter.color"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    FontSet0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

static SylSetting
    Geometry = {"geometry", "Geometry", "", NULL};

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return (abs(XwcTextEscapement(fs->id, str, len)));
}

static SylFontSet *
BetterFontSet(PreeditStringPainter *psp)
{
    return ((psp->user_fontset.id != NULL)
	    ? &psp->user_fontset : &psp->fontset);
}

static void
DrawCursor(PreeditStringPainter *psp, int cx)
{
    SylFontSet *fs = BetterFontSet(psp);
    int rx, lx, ty, by;

    lx = cx - ((fs->width / 3) & ~1);
    rx = cx + ((fs->width / 3) & ~1);
    ty = fs->descent;
    by = fs->descent + fs->height - 1;
    XSetLineAttributes(psp->disp, psp->gc, 0,
		       LineSolid, CapButt, JoinRound);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, cx, ty + 1, cx, by - 1);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, lx, ty, cx - 1, ty);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, lx, by, cx - 1, by);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, cx + 1, ty, rx, ty);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, cx + 1, by, rx, by);
}

static void
DrawString(PreeditStringPainter *psp)
{
    int i, x, y, u, w;
    SylFontSet *fs = BetterFontSet(psp);
    wchar_t *wcs = psp->string->wcs;

    if (wcs == NULL)
	return;

    /* draw background */
    XSetForeground(psp->disp, psp->gc, psp->pixel[Background]);
    XFillRectangle(psp->disp, psp->pixmap, psp->gc,
		   0, 0, psp->width, psp->height);
    /* draw foreground */
    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
    x = psp->sidemargin;
    y = fs->height;
    for (i = 0; i < psp->string->len; ++i) {
	w = TextEscapement(fs, wcs + i, 1);
	switch(psp->feedback[i]) {
	case XIMReverse:
	    XSetForeground(psp->disp, psp->gc, psp->pixel[Background]);
	    XSetBackground(psp->disp, psp->gc, psp->pixel[Foreground]);
	    XwcDrawImageString(psp->disp, psp->pixmap, fs->id, psp->gc,
			       x, y, wcs + i, 1);
	    break;
	case XIMUnderline:
	    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
	    XwcDrawString(psp->disp, psp->pixmap, fs->id, psp->gc,
			  x, y, wcs + i, 1);
	    u = fs->descent / 2;
	    XSetLineAttributes(psp->disp, psp->gc, u,
			       LineSolid, CapButt, JoinRound);
	    XDrawLine(psp->disp, psp->pixmap, psp->gc, x, y + u, x + w, y + u);
	    break;
	default:
	    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
	    XwcDrawString(psp->disp, psp->pixmap, fs->id, psp->gc,
			  x, y, wcs + i, 1);
	    break;
	}
	x += w;
    }
    if (!psp->visible_caret)
	return;
    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
    DrawCursor(psp, psp->sidemargin + TextEscapement(fs, wcs, psp->caret));
}

int
NicePreeditStringPainter(PreeditStringPainter *psp)
{
    XFlush(psp->disp);
    if (psp->redraw == True) {
	DrawString(psp);
	XCopyArea(psp->disp, psp->pixmap, psp->window, psp->gc,
		  0, 0, psp->width, psp->height, 0, 0);
	psp->redraw = False;
    }
    return (0);
}

void
SendPreeditStringPainter(PreeditStringPainter *psp, XEvent *ev)
{ 
    SylFontSet *fs = BetterFontSet(psp);

    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != psp->window)
	    return;
	XCopyArea(psp->disp, psp->pixmap, psp->window, psp->gc,
	    ev->xexpose.x, ev->xexpose.y,
	    ev->xexpose.width, ev->xexpose.height,
	    ev->xexpose.x, ev->xexpose.y);
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != psp->window)
            return;
	XFreePixmap(psp->disp, psp->pixmap);
	psp->pixmap = XCreatePixmap(psp->disp, psp->window,
				    psp->width, psp->height, psp->depth);
	DrawString(psp);
	psp->redraw = False;
	psp->cb_func(psp->cb_data, psp->width, psp->height, fs->ascent);
	break;
    }
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  PreeditStringPainter *psp)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    LoadSylColors(disp, fq_name, fq_class, ColorSet, psp->pixel);
    LoadSylFontSets(disp, fq_name, fq_class, FontSet, &psp->fontset);
    GetSylSetting(disp, fq_name, fq_class, &Geometry);
    return (0);
}

static XSizeHints
GetGeometry(Display *disp, char *u_geom, char *d_geom)
{
    XSizeHints xsize;
    int geom_mask, x, y, width, height, gravity;

    xsize.flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    &xsize, &x, &y ,&width, &height, &gravity);
    if (geom_mask & (XValue | YValue)) {
	xsize.x = x;
	xsize.y = y;
	xsize.flags |= USPosition;
    }
    xsize.win_gravity = gravity;
    xsize.flags |= PWinGravity;
    return (xsize);
}

PreeditStringPainter *
CreatePreeditStringPainter(Display *disp, Window parent, char *component,
			   ResizeNotifier callback, void *callback_data)
{
    XWindowAttributes attr;
    PreeditStringPainter *psp;
    
    if ((psp = (PreeditStringPainter *)malloc(sizeof(PreeditStringPainter)))
	== NULL)
	goto no_object;
    if ((psp->string = CreateSylTextFromMBString("", True)) == NULL)
	goto no_text;
    if ((psp->pixel = CreateSylColors(ColorSet)) == NULL)
        goto no_colorset;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, psp))
        goto no_preferences;
    psp->sidemargin = (psp->fontset.width + 2) / 2;
    XGetWindowAttributes(disp, parent, &attr);
    psp->width = attr.width;
    psp->height = psp->fontset.height + 2 * psp->fontset.descent;
    psp->depth = attr.depth;
    psp->window = XCreateSimpleWindow(disp, parent, 0, 0,
	psp->width, psp->height, 0,
	psp->pixel[Foreground], psp->pixel[Background]);
#if 1
    {
	XSizeHints geom = GetGeometry(disp, Geometry.spec, Geometry.orig);
	if (geom.flags & USPosition) {
	    XMoveWindow(disp, parent, geom.x, geom.y);
	    XSetWMNormalHints(disp, parent, &geom);
	}
    }
#endif
    XSetWindowBackgroundPixmap(disp, psp->window, None);
    XSelectInput(disp, psp->window, ExposureMask | StructureNotifyMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, psp->window);
    XMapRaised(disp, psp->window);
    psp->pixmap = XCreatePixmap(disp, parent,
        psp->width, psp->height, psp->depth);
    psp->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, psp->gc, False);
    psp->disp = disp;
    psp->user_fontset.id = NULL;
    psp->user_fg = 0;
    psp->user_bg = 0;
    psp->feedback = NULL;
    psp->n_feedbacks = 0;
    psp->caret = 0;
    psp->visible_caret = False;
    psp->cb_func = callback;
    psp->cb_data = callback_data;
    psp->redraw = True;
    return (psp);

no_preferences:
    FreeSylColors(psp->pixel);
no_colorset:
    FreeSylText(psp->string);
no_text:
    free(psp);
no_object:
    return (NULL);
}

void
FreePreeditStringPainter(PreeditStringPainter *psp)
{
    XDestroyWindow(psp->disp, psp->window);
    XFreePixmap(psp->disp, psp->pixmap);
    XFreeGC(psp->disp, psp->gc);
    XFreeFontSet(psp->disp, psp->fontset.id);
    if (psp->user_fontset.id)
	XFreeFontSet(psp->disp, psp->user_fontset.id);
    FreeSylColors(psp->pixel);
    FreeSylText(psp->string);
    if (psp->feedback != NULL)
	free(psp->feedback);
    free(psp);
}

void
MovePreeditStringPainter(PreeditStringPainter *psp, int x, int y)
{
    XMoveWindow(psp->disp, psp->window, x, y);
}

static unsigned long *
CreateDefaultFeedback(int len)
{
    int k;
    unsigned long *fb;
    
    if (len == 0)
	return NULL;
    if ((fb = (unsigned long *)malloc(sizeof(unsigned long) * len)) != NULL) {
	for (k = 0; k < len; ++k) {
	    fb[k] = 0;
	}
    }
    return (fb);
}

static void
SetPreeditStringPainter(PreeditStringPainter *psp, SylText *str)
{
    SylFontSet *fs = BetterFontSet(psp);
    int len;

    FreeSylText(psp->string);
    psp->string = str;
    len = LengthOfSylText(str);
    
    if (psp->caret > len)
	psp->caret = len;

    if (psp->n_feedbacks < len && psp->feedback != NULL) {
	free(psp->feedback);
	psp->feedback = NULL;
    }
    if (psp->feedback == NULL) {
	psp->feedback = CreateDefaultFeedback(len);
	psp->n_feedbacks = (psp->feedback == NULL) ? 0 : len;
    }
    psp->width = psp->sidemargin * 2
	+ TextEscapement(fs, psp->string->wcs, psp->string->len);
    XResizeWindow(psp->disp, psp->window, psp->width, psp->height);
    psp->redraw = True;
}

void
SetWCStringPreeditStringPainter(PreeditStringPainter *psp, wchar_t *src)
{
    SylText *str;

    if ((str = CreateSylTextFromWCString(src, True)) == NULL)
	return;
    SetPreeditStringPainter(psp, str);
}

void
SetMBStringPreeditStringPainter(PreeditStringPainter *psp, char *src)
{
    SylText *str;

    if ((str = CreateSylTextFromMBString(src, True)) == NULL)
	return;
    SetPreeditStringPainter(psp, str);
}

void
SetCaretPositionPreeditStringPainter(PreeditStringPainter *psp, int caret)
{
    psp->caret = max(0, min(psp->string->len, caret));
    psp->redraw = True;
}

void
SetCaretModePreeditStringPainter(PreeditStringPainter *psp, int mode)
{
    psp->visible_caret = mode;
    psp->redraw = True;
}

void
SetFeedbackPreeditStringPainter(PreeditStringPainter *psp,
				unsigned long *feedback, int len)
{
    int k;

    if (psp->feedback != NULL) {
	free(psp->feedback);
    }
    psp->feedback = CreateDefaultFeedback(psp->string->len);
    psp->n_feedbacks = (psp->feedback == NULL) ? 0 : psp->string->len;
    if (psp->feedback != NULL) {
	for (k = 0; k < len; ++k) {
	    psp->feedback[k] = feedback[k];
	}
    }
    psp->redraw = True;
}

static XFontSet
CreateFontset(Display *disp, char *fontlist, SylFontSet *fsp)
{
    XFontSet fs;
    int n_missings, n_fontinfos;
    char **missing, *alternation, **fontname;
    XFontStruct **fontinfo;

    fs = XCreateFontSet(disp, fontlist, &missing, &n_missings, &alternation);
    if (fs == NULL) {
#if 1
        fprintf(stderr, "CreateFontset: no font_struct_list\n");
#endif
        return (NULL);
    }
    if (n_missings > 0) {
#if 1
        int n;

        for (n = 0; n < n_missings; ++n)
            fprintf(stderr, "CreateFontset: missing, %s\n", missing[n]);
        if (alternation != NULL) {
            fprintf(stderr, "CreateFontset: def_string %s(%d)\n",
                    alternation, strlen(alternation));
	}
#endif
        XFreeStringList(missing);
    }
    if ((n_fontinfos = XFontsOfFontSet(fs, &fontinfo, &fontname)) < 1) {
#if 1
        fprintf(stderr, "CreateFontset: no font_struct_list\n");
#endif
        XFreeFontSet(disp, fs);
        return (NULL);
    }
    fsp->id = fs;
    fsp->width = abs(XmbTextEscapement(fs, "x", 1));
    fsp->height = fontinfo[0]->ascent + fontinfo[0]->descent;
    fsp->ascent = fontinfo[0]->ascent;
    fsp->descent = fontinfo[0]->descent;
    fsp->tabsep = fsp->width * 8;
    return (fs);
}

void
SetFontsetPreeditStringPainter(PreeditStringPainter *psp, char *name)
{
    SylFontSet *fs;

    if (psp->user_fontset.id != NULL) {
	XFreeFontSet(psp->disp, psp->user_fontset.id);
	psp->user_fontset.id = NULL;
    }
    if (name != NULL) {
	CreateFontset(psp->disp, name, &psp->user_fontset);
    }

    fs = BetterFontSet(psp);
    psp->sidemargin = (fs->width + 2) / 2;
    psp->width = psp->sidemargin * 2
	+ TextEscapement(fs, psp->string->wcs, psp->string->len);
    psp->height = fs->height + 2 * fs->descent;
    XResizeWindow(psp->disp, psp->window, psp->width, psp->height);
    psp->redraw = True;
}
