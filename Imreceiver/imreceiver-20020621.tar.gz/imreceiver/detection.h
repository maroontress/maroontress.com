/*
	$Id$

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

unsigned int allocated(void);
