/*
        $Id: BorderDecorator.h,v 1.2 2003/11/15 12:30:45 syl Exp $

        Copyright (C) 2000 Syllabub
        Maroontress Fast Software.
*/

typedef struct BorderDecorator {
    Display *disp;
    Window window;
    GC gc;
    int root_width;
    int root_height;
    int x;
    int y;
    int width;
    int height;
    int depth;
    int ascent;

    XRectangle child;
    XPoint spot;

    int redraw;
    int resize;
} BorderDecorator;

int InitializeBorderDecorator(Display *disp);
void FinalizeBorderDecorator(void);

BorderDecorator * CreateBorderDecorator(Display *disp, Window window);
void FreeBorderDecorator(BorderDecorator *);
void SendBorderDecorator(BorderDecorator *, XEvent *);
int NiceBorderDecorator(BorderDecorator *);

void MoveBorderDecorator(BorderDecorator *, int, int, int *, int *);
void ResizeBorderDecorator(BorderDecorator *, int, int, int);
