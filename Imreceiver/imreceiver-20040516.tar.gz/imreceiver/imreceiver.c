/*
	$Id: imreceiver.c,v 1.6 2004/05/15 18:40:00 syl Exp $

	Copyright (C) 2000, 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#include <X11/extensions/shape.h>
#include <X11/xpm.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>
#ifdef USE_LD
#include <ld.h>
#endif

#include "Resource.h"
#include "WCString.h"
#include "Text.h"
#include "PreeditStringPainter.h"
#include "BorderDecorator.h"
#include "property.h"

#define THIS_CLASS "XIMReceiver"
#define THIS_NAME "imreceiver"

#define GET_STRING        0x01
#define GET_FEEDBACK      0x02
#define GET_CARET         0x04
#define GET_SPOT_LOCATION 0x08
#define GET_FONTSET       0x10

typedef struct IMReceiver {
    struct IMReceiver *next;

    Window target;
    Window window;
    PreeditStringPainter *psp;
    BorderDecorator *bd;

    int schedule;
    int mapcontrol;
} IMReceiver;

static Display *disp;
static IMReceiver *top = NULL;
static XContext Context;
static Atom RECEIVER;
static Atom PREEDIT_WINDOW;
static Atom PREEDIT_STRING;
static Atom PREEDIT_FEEDBACK;
static Atom PREEDIT_CARET;
static Atom PREEDIT_SPOT_LOCATION;
static Atom PREEDIT_FONTSET;
static Atom STATUS_STRING;
static Atom PREDICT_STRING;
static IMReceiver TheRootPreedit;
static IMReceiver TheRootStatus;
static IMReceiver TheRootPredict;
static int MainPower = True;
static int MapControl = False;
static int SelfManaged = False;

static SylSetting
    AutoHiddenMode = {"autoHidden", "AutoHidden", "True", NULL},
    SelfManagedMode = {"selfManaged", "SelfManaged", "True", NULL};

static void
WCSMapReceiver(IMReceiver *x, wchar_t *wcs)
{
    SetWCStringPreeditStringPainter(x->psp, wcs);
    XMapRaised(disp, x->window);
}

static void
UnmapReceiver(IMReceiver *x)
{
    wchar_t null = 0;

    SetWCStringPreeditStringPainter(x->psp, &null);
    if (x->mapcontrol) {
	XUnmapWindow(disp, x->window);
    }
}

static void
GetString(IMReceiver *x, Atom atom)
{
    XTextProperty text;
    wchar_t **list;
    int n_lists, n;

    if (XGetTextProperty(disp, x->target, &text, atom) == 0) {
	UnmapReceiver(x);
	return;
    } 
    if ((n = XwcTextPropertyToTextList(disp, &text, &list, &n_lists)) < 0) {
	XFree(text.value);
	return;
    }
    XFree(text.value);

    if (n_lists > 0) {		
	WCSMapReceiver(x, *list);
    }
    else {
	UnmapReceiver(x);
    }
    XwcFreeStringList(list);
}

static void
GetPreeditString(IMReceiver *x)
{
    GetString(x, PREEDIT_STRING);
}

static void
GetPreeditFeedback(IMReceiver *x)
{
    Atom atom = PREEDIT_FEEDBACK;
    Atom property_type;
    int format;
    long n_items, remain;
    unsigned long *feedback;

    if (XGetWindowProperty(disp, x->target, atom, 0, 8192,
                           False, AnyPropertyType, &property_type, &format,
                           &n_items, &remain, (void *)&feedback) != Success) {
        return;
    }
    if (property_type == XA_INTEGER && format == 32
	&& SetFeedbackPreeditStringPainter(x->psp, feedback, n_items)) {
	warnx("SetFeedbackPreeditStringPainter() failed.");
    }
    XFree(feedback);
}

static void
GetPreeditCaret(IMReceiver *x)
{
    Atom atom = PREEDIT_CARET;
    Atom property_type;
    int format;
    long n_items, remain;
    unsigned long *caret;

    if (XGetWindowProperty(disp, x->target, atom, 0, 8192,
                           False, AnyPropertyType, &property_type, &format,
                           &n_items, &remain, (void *)&caret) != Success) {
        return;
    }
    if (property_type == XA_INTEGER && format == 32 && n_items > 0) {
	SetCaretPositionPreeditStringPainter(x->psp, *caret);
    }
    XFree(caret);
}

static void
GetPreeditSpotLocation(IMReceiver *x)
{
    Atom atom = PREEDIT_SPOT_LOCATION;
    Atom property_type;
    int format;
    long n_items, remain;
    XPoint *spot;

    if (XGetWindowProperty(disp, x->target, atom, 0, 8192,
                           False, AnyPropertyType, &property_type, &format,
                           &n_items, &remain, (void *)&spot) != Success) {
        return;
    }
    if (property_type == XA_POINT && format == 16 && n_items > 0) {
	int sx, sy;
	MoveBorderDecorator(x->bd, spot->x, spot->y, &sx, &sy);	
	MovePreeditStringPainter(x->psp, sx, sy);
    }
    XFree(spot);
}

static void
GetPreeditFontset(IMReceiver *x)
{
    XTextProperty text;
    char **list, *name;
    int n_lists, n;
    Atom atom = PREEDIT_FONTSET;

    if (XGetTextProperty(disp, x->target, &text, atom) == 0) {
	SetFontsetPreeditStringPainter(x->psp, NULL);
	return;
    } 
    if ((n = XTextPropertyToStringList(&text, &list, &n_lists)) < 0) {
	XFree(text.value);
	return;
    }
    XFree(text.value);

    name = (n_lists > 0) ? *list : NULL;
    if (SetFontsetPreeditStringPainter(x->psp, name))
	warnx("SetFontsetPreeditStringPainter() failed: %s", name);
    XFreeStringList(list);
}

static void
GetStatusString(IMReceiver *x)
{
    GetString(x, STATUS_STRING);
}

typedef struct {
    wchar_t *wcs;
    unsigned long *fb;
} Adornment;

static void
InitAdornment(Adornment *ad, wchar_t *wcs, unsigned long *fb)
{
    ad->wcs = wcs;
    ad->fb = fb;
}

static void
AddWCStringAdornment(Adornment *ad, wchar_t *wcs, unsigned long fb)
{
    int m;
    
    wstrcpy(ad->wcs, wcs);
    m = wstrlen(wcs);
    ad->wcs += m;
    for (; m > 0; --m)
	*(ad->fb)++ = fb;
}

static void
AddWCharAdornment(Adornment *ad, wchar_t wc, unsigned long fb)
{
    *(ad->wcs)++ = wc;
    *(ad->fb)++ = fb;
}

static int
UpdatePredictString(IMReceiver *x)
{
    XTextProperty t;
    char **mb_list;
    wchar_t **wc_list, *wcs;
    unsigned long *fb;
    int k, n_lists, total_len;
    Atom atom = PREDICT_STRING;
    Adornment ad;
    const unsigned long PREDICTION_ATTR = XIMReverse;

    /*
      2001-05-12: XwcTextPropertyToTextList()��n�Ĥ�ʸ�����ޤ�ƥ���
      �ȥץ��ѥƥ�����ʸ����Υꥹ�Ȥ���������ȡ��Դ����ʥꥹ�Ȥˤʤ롣
      ���Τ��ᡢ���Ψ�����ޥ���Х���ʸ����ǽ������Ƥ��롣
    */
    if (XGetTextProperty(disp, DefaultRootWindow(disp), &t, atom) == 0) {
	return (-1);
    }
    if (XmbTextPropertyToTextList(disp, &t, &mb_list, &n_lists) != Success) {
	XFree(t.value);
	return (-1);
    }
    XFree(t.value);

    if ((wc_list = (wchar_t **)alloca(sizeof(wchar_t *) * n_lists)) == NULL) {
	XFreeStringList(mb_list);
	return (-1);
    }
    total_len = n_lists - 1;
    for (k = 0; k < n_lists; ++k) {
	int len, bytes = strlen(mb_list[k]) + 1;
	if ((wc_list[k] = (wchar_t *)alloca(sizeof(wchar_t) * bytes)) == NULL
	    || (len = mbstowcs(wc_list[k], mb_list[k], bytes)) < 0) {
	    XFreeStringList(mb_list);
	    return (-1);
	}
	total_len += len;
    }
    XFreeStringList(mb_list);

    if ((wcs = (wchar_t *)alloca(sizeof(*wcs) * (total_len + 1))) == NULL
	|| (fb = (unsigned long *)alloca(sizeof(*fb) * total_len)) == NULL) {
	return (-1);
    }

    InitAdornment(&ad, wcs, fb);
    AddWCStringAdornment(&ad, wc_list[0], PREDICTION_ATTR);
    for (k = 1; k < n_lists; ++k) {
	AddWCharAdornment(&ad, ' ', 0);
	AddWCStringAdornment(&ad, wc_list[k], PREDICTION_ATTR);
    }
    wcs[total_len] = 0;

    SetWCStringPreeditStringPainter(x->psp, wcs); 
    SetFeedbackPreeditStringPainter(x->psp, fb, total_len);
    XMapRaised(disp, x->window);
    return (0);
}

static void
GetPredictString(IMReceiver *x)
{
    if (UpdatePredictString(x))
	UnmapReceiver(x);
}

static void
AddSchedule(IMReceiver *x, int n)
{
    x->schedule |= n;
}

static void
RespondPreeditProperty(IMReceiver *x, XPropertyEvent *p)
{
    if (p->atom == PREEDIT_STRING) {
	AddSchedule(x, GET_STRING);
    }
    else if (p->atom == PREEDIT_FEEDBACK) {
	AddSchedule(x, GET_FEEDBACK);
    }
    else if (p->atom == PREEDIT_CARET) {
	AddSchedule(x, GET_CARET);
    }
    else if (p->atom == PREEDIT_SPOT_LOCATION) {
	AddSchedule(x, GET_SPOT_LOCATION);
    }
    else if (p->atom == PREEDIT_FONTSET) {
	AddSchedule(x, GET_FONTSET);
    }
}

static void
RespondStatusProperty(IMReceiver *x, XPropertyEvent *p)
{
    if (p->atom == STATUS_STRING) {
	GetStatusString(x);
    }
}

static void
RespondPredictProperty(IMReceiver *x, XPropertyEvent *p)
{
    if (p->atom == PREDICT_STRING) {
	GetPredictString(x);
    }
}

static void
ResizeTarget(void *cb_data, int x __unused, int y __unused, int w, int h,
	     int ascent)
{
    ResizeBorderDecorator((BorderDecorator *)cb_data, w, h, ascent);
}

static IMReceiver *
AddTarget(Window w)
{
    XClassHint fq;
    XSetWindowAttributes s;
    IMReceiver *x;

    if (!XFindContext(disp, w, Context, (XPointer *)&x)) {
	return NULL;
    }
    if ((x = (IMReceiver *)malloc(sizeof(IMReceiver))) == NULL) { 
	return NULL;
    }
    x->target = w;
    XSelectInput(disp, x->target, PropertyChangeMask | StructureNotifyMask);
    x->window = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
				    0, 0, 1, 1, 0, 0, 0);
    s.background_pixmap = None;
    s.override_redirect = True;
    s.event_mask = ExposureMask | StructureNotifyMask;
    XChangeWindowAttributes(disp, x->window, CWBackPixmap | CWOverrideRedirect
			    | CWEventMask, &s);
    fq.res_name = (char *)THIS_NAME;
    fq.res_class = (char *)THIS_CLASS;
    XSetClassHint(disp, x->window, &fq);

    x->bd = CreateBorderDecorator(disp, x->window);
    x->psp = CreatePreeditStringPainter(disp, x->window, "balloon",
					ResizeTarget, (void *)x->bd);
    SetCaretModePreeditStringPainter(x->psp, True);
    x->schedule = ~0;
    x->mapcontrol = True;
    x->next = top;
    XSaveContext(disp, x->target, Context, (XPointer)x);
    top = x;
    return (x);
}

static void
RemoveTarget(IMReceiver *x)
{
    IMReceiver *p;

    XDeleteContext(disp, x->target, Context);
    FreePreeditStringPainter(x->psp);
    FreeBorderDecorator(x->bd);
    XDestroyWindow(disp, x->window);

    if (top == x) {
	top = x->next;
    }
    else {
	for (p = top; p->next != x; p = p->next)
	    ;
	p->next = x->next;
    }
    free(x);
}

static void
RemoveAllReceivers(void)
{
    IMReceiver *x, *next;

    for (x = top; x != NULL; x = next) {
	next = x->next;
	if (x->target != DefaultRootWindow(disp)) {
	    XDeleteContext(disp, x->target, Context);
	    FreePreeditStringPainter(x->psp);
	    FreeBorderDecorator(x->bd);
	    XDestroyWindow(disp, x->window);
	    free(x);
	}
	else {
	    FreePreeditStringPainter(x->psp);
	}
    }
}

static void
SendToplevel(XEvent *ev)
{
    IMReceiver *x;

    switch (ev->type) {
    case SelectionRequest:
	if (ev->xselectionrequest.selection == RECEIVER
	    && ev->xselectionrequest.target == PREEDIT_WINDOW) {
	    (void)AddTarget(ev->xselectionrequest.requestor);
	}	
	break;
    case PropertyNotify:
	if (ev->xany.window == DefaultRootWindow(disp)) {
	    RespondPreeditProperty(&TheRootPreedit, &ev->xproperty);
	    RespondStatusProperty(&TheRootStatus, &ev->xproperty);
	    RespondPredictProperty(&TheRootPredict, &ev->xproperty);
	    return;
	}
	if (XFindContext(disp, ev->xany.window, Context, (XPointer *)&x))
	    return;
	RespondPreeditProperty(x, &ev->xproperty);
	break;
    case SelectionClear:
	if (ev->xselectionclear.selection == RECEIVER) {
	    warnx("Another XIM reciever acquired an ownership.");
	    MainPower = False;
	}
	break;
    case DestroyNotify:
	if (XFindContext(disp, ev->xany.window, Context, (XPointer *)&x))
	    return;
	RemoveTarget(x);
	break;
    }
}

static void
UpdatePreeditString(IMReceiver *x)
{
    if (x->schedule & GET_STRING)
	GetPreeditString(x);
    if (x->schedule & GET_FEEDBACK)
        GetPreeditFeedback(x);
    if (x->schedule & GET_CARET)
        GetPreeditCaret(x);
    if (x->schedule & GET_SPOT_LOCATION)
        GetPreeditSpotLocation(x);
    if (x->schedule & GET_FONTSET)
        GetPreeditFontset(x);
    x->schedule = 0;
}

static int
NiceTarget(IMReceiver *x)
{
    UpdatePreeditString(x);
    return (NicePreeditStringPainter(x->psp)
	    || (x->bd != NULL && NiceBorderDecorator(x->bd)));
}

static int
Nice(void)
{
    IMReceiver *x;

    XFlush(disp);
    UpdatePreeditString(&TheRootPreedit);
    for (x = top; x != NULL && !NiceTarget(x); x = x->next)
	;
    return (x != NULL);
}

static void
Send(XEvent *ev)
{
    IMReceiver *x;

    for (x = top; x != NULL; x = x->next) {
	SendPreeditStringPainter(x->psp, ev);
	if (x->bd == NULL)
	    continue;
	SendBorderDecorator(x->bd, ev);
    }
}

static void
ResizeTheRoot(void *cb_data, int x, int y, int w, int h, int ascent __unused)
{
    IMReceiver *r = (IMReceiver *)cb_data;

    XMoveResizeWindow(disp, r->window, x, y, w, h);
}

static void
AddRootReceiver(int ac, char const *const *av,
		const char *title, const char *name, IMReceiver *x,
		int caretMode)
{
    XSetWindowAttributes s;
    XSizeHints h;

    x->target = DefaultRootWindow(disp);
    XSelectInput(disp, x->target, PropertyChangeMask);

    x->window = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
				    0, 0, 1, 1, 0, 0, 0);
    s.background_pixmap = None;
    s.event_mask = ExposureMask | StructureNotifyMask;
    XChangeWindowAttributes(disp, x->window, CWBackPixmap | CWEventMask, &s);
    h.flags = 0;
    SetProperties(disp, x->window, title, THIS_NAME, THIS_CLASS,
		  ac, av, &h, None, None, None);
    if (SelfManaged) {
	s.override_redirect = True;
	XChangeWindowAttributes(disp, x->window, CWOverrideRedirect, &s);
    }

    if ((x->psp = CreatePreeditStringPainter(disp, x->window, name,
					     ResizeTheRoot, x)) == NULL) {
	errx(1, "CreatePreeditStringPainter() failed.");
    }
    SetCaretModePreeditStringPainter(x->psp, caretMode);
    
    if (!(x->mapcontrol = MapControl)) {
	XMapRaised(disp, x->window);
    }
    x->bd = NULL;
    x->next = top;
    top = x;
}

static void
AddTheRootPreedit(int ac, char const *const *av)
{
    IMReceiver *x = &TheRootPreedit;
    
    AddRootReceiver(ac, av, "Preedit", "preedit", x, True);
    GetPreeditString(x);
    GetPreeditFeedback(x);
    GetPreeditCaret(x);
}

static void
AddTheRootStatus(int ac, char const *const *av)
{
    IMReceiver *x = &TheRootStatus;

    AddRootReceiver(ac, av, "Status", "status", x, False);
    GetStatusString(x);
}

static void
AddTheRootPredict(int ac, char const *const *av)
{
    IMReceiver *x = &TheRootPredict;

    AddRootReceiver(ac, av, "Predict", "predict", x, False);
    GetPredictString(x);
}

static void
GetToplevelPreferences(Display *dpy)
{
    GetSylSetting(dpy, "imreceiver", THIS_CLASS, &AutoHiddenMode);
    MapControl = (strcasecmp(AutoHiddenMode.spec, "True") == 0);
    GetSylSetting(dpy, "imreceiver", THIS_CLASS, &SelfManagedMode);
    SelfManaged = (strcasecmp(SelfManagedMode.spec, "True") == 0);
}

int
main(int ac, char const *const *av)
{
    XrmDatabase xrdb;
    XEvent ev;
    Window toplevel;
#if defined(__FreeBSD__) && defined(DEBUG)
    extern char *malloc_options;
    malloc_options = "JA";
#endif

#ifdef USE_LD
    if (ld_open("imreceiver.log") < 0) {
	errx(1, "ld_open failed.");
    }
#endif
    if ((disp = XOpenDisplay("")) == NULL) {
        errx(1, "cannot open display.");
    }
    if (setlocale(LC_ALL, "") == NULL) {
        errx(1, "cannot set locale.");
    }
    if (XSupportsLocale() == False) {
        errx(1, "locale not supported.");
    }
    XrmInitialize();
    xrdb = SylMergedResourceDatabase(disp);
    GetToplevelPreferences(disp);
    if (InitializeBorderDecorator(disp)) {
        errx(1, "InitializeBorderDecorator() failed.");
    }

    Context = XUniqueContext();

    RECEIVER = XInternAtom(disp, "XIM_RECEIVER", False);
    PREEDIT_WINDOW = XInternAtom(disp, "XIM_PREEDIT_WINDOW", False);
    PREEDIT_STRING = XInternAtom(disp, "XIM_PREEDIT_STRING", False);
    PREEDIT_FEEDBACK = XInternAtom(disp, "XIM_PREEDIT_FEEDBACK", False);
    PREEDIT_CARET = XInternAtom(disp, "XIM_PREEDIT_CARET", False);
    PREEDIT_SPOT_LOCATION = XInternAtom(disp, "XIM_PREEDIT_SPOT_LOCATION",
					False);
    PREEDIT_FONTSET = XInternAtom(disp, "XIM_PREEDIT_FONTSET", False);
    STATUS_STRING = XInternAtom(disp, "XIM_STATUS_STRING", False);
    PREDICT_STRING = XInternAtom(disp, "XIM_PREDICT_STRING", False);

    toplevel = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
				   0, 0, 1, 1, 0, 0, 0);
    XSetSelectionOwner(disp, RECEIVER, toplevel, CurrentTime);

    AddTheRootPreedit(ac, av);
    AddTheRootStatus(ac, av);
    AddTheRootPredict(ac, av);
    while (MainPower) {
        while (XEventsQueued(disp, QueuedAfterReading) == 0 && Nice())
            continue;
	XNextEvent(disp, &ev);
	Send(&ev);
	SendToplevel(&ev);
    }
    RemoveAllReceivers();
    FinalizeBorderDecorator();
    CleanupSylFontSet();
    XrmDestroyDatabase(xrdb);  
    XCloseDisplay(disp);
#ifdef USE_LD
    if (ld_close() < 0) {
	errx(1, "ld_close failed.");
    }
#endif
    exit(0);
    return 0;
}
