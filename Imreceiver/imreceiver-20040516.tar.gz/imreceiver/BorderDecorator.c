/*
        $Id: BorderDecorator.c,v 1.3 2004/04/10 20:56:30 syl Exp $

        Copyright (C) 2000 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
#include <X11/xpm.h>
#include <stdlib.h>

#include "BorderDecorator.h"

#include "up_arrow.xpm"
#include "down_arrow.xpm"
#include "top_left.xpm"
#include "top_right.xpm"
#include "bottom_left.xpm"
#include "bottom_right.xpm"
#include "top_side.xpm"
#include "bottom_side.xpm"
#include "left_side.xpm"
#include "right_side.xpm"

#define BORDER_WIDTH 16
#define BORDER_HEIGHT 16

typedef struct {
    Display *disp;
    Pixmap face;
    Pixmap mask;
    unsigned int width;
    unsigned int height;
} Icon;

static Icon *up_arrow = NULL;
static Icon *down_arrow = NULL;
static Icon *top_left = NULL;
static Icon *top_right = NULL;
static Icon *bottom_left = NULL;
static Icon *bottom_right = NULL;
static Icon *top_side = NULL;
static Icon *bottom_side = NULL;
static Icon *left_side = NULL;
static Icon *right_side = NULL;

static void
DrawIconMask(Display *disp, Drawable d, GC gc, Icon *icon, int x, int y)
{
    XCopyArea(disp, icon->mask, d, gc, 0, 0, icon->width, icon->height, x, y);
}

static void
DrawIconFace(Display *disp, Drawable d, GC gc, Icon *icon, int x, int y)
{
    XCopyArea(disp, icon->face, d, gc, 0, 0, icon->width, icon->height, x, y);
}

static Icon *
CreateIcon(Display *disp, Window window, const char *xpm[])
{
    int x, y, bw, dp;
    Window r;
    Icon *p;

    if ((p = (Icon *)malloc(sizeof(Icon))) == NULL)
	return NULL;
    p->disp = disp;
    XpmCreatePixmapFromData(disp, window, (char **)xpm, &p->face, &p->mask,
			    NULL);
    XGetGeometry(disp, p->face, &r, &x, &y, &p->width, &p->height, &bw, &dp);
    return (p);
}

static void
FreeIcon(Icon *p)
{
    if (p == NULL)
	return;
    XFreePixmap(p->disp, p->face);
    XFreePixmap(p->disp, p->mask);
    free(p);
}

#define FREE_ICON(x) \
	FreeIcon(x); \
	x = NULL;

void
FinalizeBorderDecorator(void)
{
    FREE_ICON(up_arrow);
    FREE_ICON(down_arrow);
    FREE_ICON(top_left);
    FREE_ICON(top_right);
    FREE_ICON(bottom_left);
    FREE_ICON(bottom_right);
    FREE_ICON(top_side);
    FREE_ICON(bottom_side);
    FREE_ICON(left_side);
    FREE_ICON(right_side);
}

int
InitializeBorderDecorator(Display *dpy)
{
    Window root = DefaultRootWindow(dpy);

    if ((up_arrow = CreateIcon(dpy, root, up_arrow_xpm)) == NULL
	|| (down_arrow = CreateIcon(dpy, root, down_arrow_xpm)) == NULL
	|| (top_left = CreateIcon(dpy, root, top_left_xpm)) == NULL
	|| (top_right = CreateIcon(dpy, root, top_right_xpm)) == NULL
	|| (bottom_left = CreateIcon(dpy, root, bottom_left_xpm)) == NULL
	|| (bottom_right = CreateIcon(dpy, root, bottom_right_xpm)) == NULL
	|| (top_side = CreateIcon(dpy, root, top_side_xpm)) == NULL
	|| (bottom_side = CreateIcon(dpy, root, bottom_side_xpm)) == NULL
	|| (left_side = CreateIcon(dpy, root, left_side_xpm)) == NULL
	|| (right_side = CreateIcon(dpy, root, right_side_xpm)) == NULL) {
	FinalizeBorderDecorator();
	return (1);
    }
    return (0);
}

BorderDecorator *
CreateBorderDecorator(Display *disp, Window window)
{
    XWindowAttributes attr;
    BorderDecorator *bd;

    if ((bd = (BorderDecorator *)malloc(sizeof(BorderDecorator))) == NULL)
	return NULL;
    XGetWindowAttributes(disp, DefaultRootWindow(disp), &attr);
    bd->root_width = attr.width;
    bd->root_height = attr.height;

    XGetWindowAttributes(disp, window, &attr);
    bd->x = attr.x;
    bd->y = attr.y;
    bd->width = attr.width;
    bd->height = attr.height;
    bd->depth = attr.depth;
    bd->ascent = attr.height;

    bd->gc = XCreateGC(disp, window, 0, 0);
    XSetGraphicsExposures(disp, bd->gc, False);
    
    bd->disp = disp;
    bd->window = window;
    bd->spot.x = 0;
    bd->spot.y = 0;
    bd->redraw = False;
    bd->resize = False;
    return bd;
}

void
FreeBorderDecorator(BorderDecorator *bd)
{
    XFreeGC(bd->disp, bd->gc);
    free(bd);
}

void
SendBorderDecorator(BorderDecorator *bd, XEvent *ev)
{
    switch (ev->type) {
    case MapNotify:
    case ConfigureNotify:
	if (ev->xany.window != bd->window)
	    return;
	bd->resize = True;
	break;
    case Expose:
	if (ev->xany.window != bd->window)
	    return;
	bd->redraw = True;
	break;
    }
}

static void
TileIconFace(Display *disp, Drawable d, GC gc, Icon *icon, int x, int y,
	     int width, int height)
{
    int dx, dy, w, h;

    for (dy = 0; dy < height; dy += h) {
	if ((unsigned)(h = height - dy) > icon->height) {
	    h = icon->height;
	}
	for (dx = 0; dx < width; dx += w) {
	    if ((unsigned)(w = width - dx) > icon->width) {
		w = icon->width;
	    }
	    XCopyArea(disp, icon->face, d, gc, 0, 0, w, h, x + dx, y + dy);
	}
    }
}

static void
TileIconMask(Display *disp, Drawable d, GC gc, Icon *icon, int x, int y,
	     int width, int height)
{
    int dx, dy, w, h;

    for (dy = 0; dy < height; dy += h) {
	if ((unsigned)(h = height - dy) > icon->height) {
	    h = icon->height;
	}
	for (dx = 0; dx < width; dx += w) {
	    if ((unsigned)(w = width - dx) > icon->width) {
		w = icon->width;
	    }
	    XCopyArea(disp, icon->mask, d, gc, 0, 0, w, h, x + dx, y + dy);
	}
    }
}

static void
DrawMaskOfFrame(Display *disp, Pixmap shape_mask, GC shape_gc,
		int lx, int ty, int width, int height)
{
    int rx, by, fw, fh;

    rx = lx + width;
    by = ty + height;
    fw = width - 2 * BORDER_WIDTH;
    fh = height - 2 * BORDER_HEIGHT;

    TileIconMask(disp, shape_mask, shape_gc, top_side,
		 lx + BORDER_WIDTH, ty, fw, BORDER_HEIGHT);
    TileIconMask(disp, shape_mask, shape_gc, bottom_side,
		 lx + BORDER_WIDTH, by - BORDER_WIDTH, fw, BORDER_HEIGHT);
    TileIconMask(disp, shape_mask, shape_gc, left_side,
		 lx, ty + BORDER_HEIGHT, BORDER_WIDTH, fh);
    TileIconMask(disp, shape_mask, shape_gc, right_side,
		 rx - BORDER_WIDTH, ty + BORDER_HEIGHT, BORDER_WIDTH, fh);

    DrawIconMask(disp, shape_mask, shape_gc, top_left,
		 lx, ty);
    DrawIconMask(disp, shape_mask, shape_gc, top_right,
		 rx - top_right->width, ty);
    DrawIconMask(disp, shape_mask, shape_gc, bottom_left,
		 lx, by - bottom_left->height);
    DrawIconMask(disp, shape_mask, shape_gc, bottom_right,
		 rx - bottom_right->width, by - bottom_right->height);

    XFillRectangle(disp, shape_mask, shape_gc,
		   lx + BORDER_WIDTH, ty + BORDER_HEIGHT,
 		   width - 2 * BORDER_WIDTH, height - 2 * BORDER_HEIGHT);
}

static void
DrawFaceOfFrame(Display *disp, Window window, GC gc,
		int lx, int ty, int width, int height)
{
    int rx, by, fw, fh;

    rx = lx + width;
    by = ty + height;
    fw = width - 2 * BORDER_WIDTH;
    fh = height - 2 * BORDER_HEIGHT;

    TileIconFace(disp, window, gc, top_side,
		 lx + BORDER_WIDTH, ty, fw, BORDER_HEIGHT);
    TileIconFace(disp, window, gc, bottom_side,
		 lx + BORDER_WIDTH, by - BORDER_WIDTH, fw, BORDER_HEIGHT);
    TileIconFace(disp, window, gc, left_side,
		 lx, ty + BORDER_HEIGHT, BORDER_WIDTH, fh);
    TileIconFace(disp, window, gc, right_side,
		 rx - BORDER_WIDTH, ty + BORDER_HEIGHT, BORDER_WIDTH, fh);


    DrawIconFace(disp, window, gc, top_left,
		 lx, ty);
    DrawIconFace(disp, window, gc, top_right,
		 rx - top_right->width, ty);
    DrawIconFace(disp, window, gc, bottom_left,
		 lx, by - bottom_left->height);
    DrawIconFace(disp, window, gc, bottom_right,
		 rx - bottom_right->width, by - bottom_right->height);
}

static void
DrawMask(BorderDecorator *bd)
{
    int x, y, upperRoom, lowerRoom;
    Pixmap mask;
    GC gc;

    mask = XCreatePixmap(bd->disp, bd->window, bd->width, bd->height, 1);
    gc = XCreateGC(bd->disp, mask, 0, 0);
    XSetGraphicsExposures(bd->disp, gc, False);

    XSetForeground(bd->disp, gc, 0);
    XFillRectangle(bd->disp, mask, gc, 0, 0, bd->width, bd->height);

    XSetForeground(bd->disp, gc, 1);
    XSetFunction(bd->disp, gc, GXor);

    upperRoom = bd->spot.y - bd->ascent;
    lowerRoom = bd->root_height - bd->spot.y;
    if (upperRoom > lowerRoom) {
	x = bd->spot.x - down_arrow->width / 2 - bd->x;
	y = bd->height - down_arrow->height;
	DrawIconMask(bd->disp, mask, gc, down_arrow, x, y);
	DrawMaskOfFrame(bd->disp, mask, gc, 0, 0,
			bd->width, bd->height - down_arrow->height);
    }
    else {
	x = bd->spot.x - up_arrow->width / 2 - bd->x;
	y = 0;
	DrawIconMask(bd->disp, mask, gc, up_arrow, x, y);
	DrawMaskOfFrame(bd->disp, mask, gc, 0, up_arrow->height,
			bd->width, bd->height - up_arrow->height);
    }
    XShapeCombineMask(bd->disp, bd->window, ShapeBounding, 0, 0,
		      mask, ShapeSet);

    XFreePixmap(bd->disp, mask);
    XFreeGC(bd->disp, gc);
}

static void
DrawFace(BorderDecorator *bd)
{
    int x, y, upperRoom, lowerRoom;

    upperRoom = bd->spot.y - bd->ascent;
    lowerRoom = bd->root_height - bd->spot.y;
    if (upperRoom > lowerRoom) {
	x = bd->spot.x - down_arrow->width / 2 - bd->x;
	y = bd->height - down_arrow->height;
	DrawIconFace(bd->disp, bd->window, bd->gc, down_arrow, x, y);
	DrawFaceOfFrame(bd->disp, bd->window, bd->gc, 0, 0,
			bd->width, bd->height - down_arrow->height);
    }
    else {
	x = bd->spot.x - up_arrow->width / 2 - bd->x;
	y = 0;
	DrawIconFace(bd->disp, bd->window, bd->gc, up_arrow, x, y);
	DrawFaceOfFrame(bd->disp, bd->window, bd->gc, 0, up_arrow->height,
			bd->width, bd->height - up_arrow->height);
    }
}

int
NiceBorderDecorator(BorderDecorator *bd)
{
    XFlush(bd->disp);
    if (bd->resize) {
	bd->resize = False;
	DrawMask(bd);
	return (1);
    }
    if (bd->redraw) {
	bd->redraw = False;
	DrawFace(bd);
    }
    return (0);
}

static void
SetSpot(BorderDecorator *bd, int x, int y)
{
    int upperRoom, lowerRoom;

    bd->spot.x = x;
    bd->spot.y = y;
    upperRoom = bd->spot.y - bd->ascent;
    lowerRoom = bd->root_height - bd->spot.y;
    bd->child.x = BORDER_WIDTH;
    bd->child.y = BORDER_HEIGHT;
    if (upperRoom > lowerRoom) {
	y = bd->spot.y - bd->ascent;
	y -= bd->height;
    }
    else {
	bd->child.y += up_arrow->height;
	y = bd->spot.y;
    }
    if ((x = bd->spot.x - bd->width / 2)< 0)
	x = 0;
    else if (x + bd->width > bd->root_width)
	x = bd->root_width - bd->width;
    XMoveWindow(bd->disp, bd->window, x, y);
    bd->x = x;
    bd->y = y;
}

void
MoveBorderDecorator(BorderDecorator *bd, int x, int y,
		    int *child_x, int *child_y)
{
    SetSpot(bd, x, y);
    *child_x = bd->child.x;
    *child_y = bd->child.y;
}

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif

void
ResizeBorderDecorator(BorderDecorator *bd, int width, int height, int ascent)
{
    bd->child.width = width;
    bd->child.height = height;
    bd->ascent = ascent;
    bd->width = BORDER_WIDTH * 2 + width;
    bd->height = BORDER_HEIGHT * 2 + height
	+ max(up_arrow->height, down_arrow->height);
    XResizeWindow(bd->disp, bd->window, bd->width, bd->height);
    SetSpot(bd, bd->spot.x, bd->spot.y);
}
