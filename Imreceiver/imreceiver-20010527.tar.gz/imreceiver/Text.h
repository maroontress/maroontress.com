/*
	$Id: Text.h,v 1.2 2001/05/23 14:12:07 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

typedef struct {
    wchar_t *wcs; /* �磻�ɥ���饯��ʸ���� */
    int len;      /* ʸ���� */
    int eol;      /* End Of Line (True or False) */
} SylText;

#define LengthOfSylText(t) ((t)->len)
#define EndOfLineSylText(t) ((t)->eol)

SylText * CreateSylTextFromMBString(char *mbs, int eol);
SylText * CreateSylTextFromWCString(wchar_t *wcs, int eol);
void FreeSylText(SylText *txt);
SylText * DuplicateSylText(SylText *txt);
wchar_t * CreateWCStringFromSylText(SylText *txt, int bgn, int end);
wchar_t * CreateWCStringFromSylText0(SylText *txt);
char * CreateMBStringFromSylText(SylText *txt, int bgn, int end);
char * CreateMBStringFromSylText0(SylText *txt);
void InsertWCharIntoSylText(SylText *txt, int n, wchar_t c);
void InsertWCStringIntoSylText(SylText *txt, int n, wchar_t *p);
void InsertSylTextIntoSylText(SylText *txt, int n, SylText *s);
void DeleteWCharOfSylText(SylText *txt, int n);
void DeleteWCStringOfSylText(SylText *txt, int bgn, int end);
void ChangeEndOfLineSylText(SylText *txt, int eol);
int CompareSylText(SylText *, SylText *);

SylText * ConcatAndCreateSylText(SylText *head, SylText *tail);
void SplitAndCreateSylTexts(SylText *txt, int n, int eol,
			    SylText **head, SylText **tail);

int SylTextEscapement(XFontSet fs, SylText *txt, int bgn, int end);
int SylTextEscapement0(XFontSet fs, SylText *txt);
void DrawSylText0(Display *disp, Drawable d, XFontSet fs, GC gc, int x, int y,
		  SylText *txt);
