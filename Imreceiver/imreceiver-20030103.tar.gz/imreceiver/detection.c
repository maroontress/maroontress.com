/*
	$Id$

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include "detection.h"

static void *(*realMalloc)(size_t) = NULL;
static void (*realFree)(void *) = NULL;

static int core = 0;

static void *
ldmalloc(unsigned int n)
{
    void *p;

    if (realMalloc == NULL)
	realMalloc = dlsym(RTLD_NEXT, "malloc");
    if ((p = realMalloc(sizeof(int) + n)) == NULL)
	return (NULL);
    core += n;
    *((unsigned int *)p)++ = n;
    return (p);
}

static void
ldfree(void *p)
{
    if (realFree == NULL)
	realFree = dlsym(RTLD_NEXT, "free");
    if (p == NULL)
	return;
    core -= *--((unsigned int *)p);
    realFree(p);
}

unsigned int
allocated(void)
{
    return (core);
}

void *
malloc(size_t n)
{
    return ldmalloc(n);
}

void
free(void *p)
{
    ldfree(p);
}

void *
calloc(size_t n, size_t s)
{
    void *p;
    
    if ((p = malloc(n * s)) == NULL)
	return NULL;
    memset(p, 0, n * s);
    return p;
}
    
void *
realloc(void *p, size_t n)
{
    void *q;

    if ((q = malloc(n)) == NULL)
	return NULL;
    if (p == NULL)
	return q;
    memcpy(q, p, ((unsigned int *)p)[-1]);
    free(p);
    return q;
}
