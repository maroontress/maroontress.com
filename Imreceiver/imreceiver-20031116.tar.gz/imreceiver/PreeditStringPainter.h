/*
        $Id: PreeditStringPainter.h,v 1.2 2003/11/15 12:56:47 syl Exp $

        Copyright (C) 2000 Syllabub
        Maroontress Fast Software.
*/

typedef void (*ResizeNotifier)(void *, int, int, int, int, int);

typedef struct PreeditStringPainter {
    Display *disp;
    Window window;
    Window parent;
    GC gc;
    Pixmap pixmap;
    SylFontSet fontset;
    int x_parent;
    int y_parent;
    int width;
    int height;
    int root_width;
    int root_height;
    int depth;
    int sidemargin;
    unsigned long *pixel;

    SylFontSet user_fontset;
    unsigned long user_fg;
    unsigned long user_bg;

    SylText *string;
    unsigned long *feedback;
    int n_feedbacks;
    int caret;
    int redraw;
    int visible_caret;
    int grabbed;
    int x_offset;
    int y_offset;

    ResizeNotifier cb_func;
    void *cb_data;
} PreeditStringPainter;

PreeditStringPainter * CreatePreeditStringPainter(Display *disp, Window parent,
						  char *component,
						  ResizeNotifier callback,
						  void *callback_data);
void FreePreeditStringPainter(PreeditStringPainter *);
void SendPreeditStringPainter(PreeditStringPainter *, XEvent *);
int NicePreeditStringPainter(PreeditStringPainter *);

void MovePreeditStringPainter(PreeditStringPainter *, int, int);
int SetWCStringPreeditStringPainter(PreeditStringPainter *, wchar_t *);
int SetMBStringPreeditStringPainter(PreeditStringPainter *, char *);
int SetFeedbackPreeditStringPainter(PreeditStringPainter *,
				    unsigned long *, int);
void SetCaretPositionPreeditStringPainter(PreeditStringPainter *, int);
void SetCaretModePreeditStringPainter(PreeditStringPainter *, int);
int SetFontsetPreeditStringPainter(PreeditStringPainter *, char *);

#if 0
void SetForegroundPreeditStringPainter(PreeditStringPainter *, unsigned long);
void SetBackgroundPreeditStringPainter(PreeditStringPainter *, unsigned long);
#endif
