/*
        $Id: property.h,v 1.1 2003/01/03 14:33:31 syl Exp $

        Copyright (C) 2001 Syllabub
        Maroontress Fast Software.
*/

void SetProperties(Display *, Window, char *, char *, char *, int, char **,
		   XSizeHints *, Pixmap, Pixmap, Window);
