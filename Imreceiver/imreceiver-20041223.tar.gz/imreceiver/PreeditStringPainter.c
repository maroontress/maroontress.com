/*
        $Id: PreeditStringPainter.c,v 1.6 2004/05/15 18:21:55 syl Exp $

        Copyright (C) 2000 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#ifdef HAS_WCHAR_H
#include <wchar.h>
#endif
#ifdef HAS_WCTYPE_H
#include <wctype.h>
#endif

#include "Resource.h"
#include "Text.h"
#include "PreeditStringPainter.h"

#define THIS_CLASS "PreeditStringPainter"

#include "PreeditStringPainter.color"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    FontSet0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

static SylSetting
    Geometry = {"geometry", "Geometry", "", NULL};

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return ((len > 0) ? abs(XwcTextEscapement(fs->id, str, len)) : 0);
}

static SylFontSet *
BetterFontSet(PreeditStringPainter *psp)
{
    return ((psp->user_fontset.id != NULL)
	    ? &psp->user_fontset : &psp->fontset);
}

static void
DrawCursor(PreeditStringPainter *psp, int cx)
{
    SylFontSet *fs = BetterFontSet(psp);
    int rx, lx, ty, by;

    lx = cx - ((fs->width / 3) & ~1);
    rx = cx + ((fs->width / 3) & ~1);
    ty = fs->descent;
    by = fs->descent + fs->height - 1;
    XSetLineAttributes(psp->disp, psp->gc, 0,
		       LineSolid, CapButt, JoinRound);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, cx, ty + 1, cx, by - 1);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, lx, ty, cx - 1, ty);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, lx, by, cx - 1, by);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, cx + 1, ty, rx, ty);
    XDrawLine(psp->disp, psp->pixmap, psp->gc, cx + 1, by, rx, by);
}

static void
DrawString(PreeditStringPainter *psp)
{
    int i, x, y, u, w;
    SylFontSet *fs = BetterFontSet(psp);
    wchar_t *wcs = psp->string->wcs;
    unsigned long fb;

    if (wcs == NULL)
	return;

    /* draw background */
    XSetForeground(psp->disp, psp->gc, psp->pixel[Background]);
    XFillRectangle(psp->disp, psp->pixmap, psp->gc,
		   0, 0, psp->width, psp->height);
    /* draw foreground */
    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
    x = psp->sidemargin;
    y = fs->height;
    for (i = 0; i < psp->string->len; ++i) {
	w = TextEscapement(fs, wcs + i, 1);
	fb = ((psp->feedback != NULL && i < psp->n_feedbacks)
	      ? psp->feedback[i] : 0);
	if (fb & XIMReverse) {
	    XSetForeground(psp->disp, psp->gc, psp->pixel[Background]);
	    XSetBackground(psp->disp, psp->gc, psp->pixel[Foreground]);
	    XwcDrawImageString(psp->disp, psp->pixmap, fs->id, psp->gc,
			       x, y, wcs + i, 1);
	}
	else {
	    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
	    XwcDrawString(psp->disp, psp->pixmap, fs->id, psp->gc,
			  x, y, wcs + i, 1);
	}
	if (fb & XIMUnderline) {
	    u = fs->descent / 2;
	    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
	    XSetLineAttributes(psp->disp, psp->gc, u,
			       LineSolid, CapButt, JoinRound);
	    XDrawLine(psp->disp, psp->pixmap, psp->gc, x, y + u, x + w, y + u);
	}
	x += w;
    }
    if (!psp->visible_caret)
	return;
    XSetForeground(psp->disp, psp->gc, psp->pixel[Foreground]);
    DrawCursor(psp, psp->sidemargin + TextEscapement(fs, wcs, psp->caret));
}

int
NicePreeditStringPainter(PreeditStringPainter *psp)
{
    XFlush(psp->disp);
    if (!psp->redraw)
	return (0);
    DrawString(psp);
    XCopyArea(psp->disp, psp->pixmap, psp->window, psp->gc, 0, 0,
	      psp->width, psp->height, 0, 0);
    psp->redraw = False;
    return (1);
}

static void
GetWindowPointer(Display *disp, Window w, int *x, int *y)
{
    Window root, child;
    int rx, ry, kb;

    XQueryPointer(disp, w, &root, &child, &rx, &ry, x, y, &kb);
}

static int
round(int min, int max, int val)
{
    if (val < min)
	val = min;
    else if (val > max)
	val = max;
    return (val);
}

void
SendPreeditStringPainter(PreeditStringPainter *psp, XEvent *ev)
{ 
    int x, y;
    Cursor cursor;
    SylFontSet *fs = BetterFontSet(psp);

    switch (ev->type) {
    case ButtonPress:
	if (ev->xbutton.window != psp->window)
	    return;
        XRaiseWindow(psp->disp, psp->parent);
	cursor = XCreateFontCursor(psp->disp, XC_fleur);
        XGrabPointer(psp->disp, psp->window, False, ButtonMotionMask
                     | ButtonReleaseMask | PointerMotionHintMask,
                     GrabModeAsync, GrabModeSync, DefaultRootWindow(psp->disp),
                     cursor, ev->xbutton.time);
	XFreeCursor(psp->disp, cursor);
        psp->grabbed = True;
        psp->x_offset = ev->xbutton.x_root - psp->x_parent;
        psp->y_offset = ev->xbutton.y_root - psp->y_parent;
        break;
    case MotionNotify:
        if (!psp->grabbed)
            return;
        GetWindowPointer(psp->disp, DefaultRootWindow(psp->disp), &x, &y);
        psp->x_parent = round(0, psp->root_width - psp->width,
			      x - psp->x_offset);
        psp->y_parent = round(0, psp->root_height - psp->height,
			      y - psp->y_offset);
	psp->cb_func(psp->cb_data, psp->x_parent, psp->y_parent,
		     psp->width, psp->height, fs->ascent);
        break;
    case ButtonRelease:
        if (!psp->grabbed)
            return;
        XUngrabPointer(psp->disp, ev->xbutton.time);
        psp->grabbed = False;
        break;
    case Expose:
	if (ev->xexpose.window != psp->window)
	    return;
	XCopyArea(psp->disp, psp->pixmap, psp->window, psp->gc,
	    ev->xexpose.x, ev->xexpose.y,
	    ev->xexpose.width, ev->xexpose.height,
	    ev->xexpose.x, ev->xexpose.y);
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window == psp->parent) {
	    Window child;
	    XTranslateCoordinates(psp->disp, psp->parent,
				  DefaultRootWindow(psp->disp),
				  0, 0, &x, &y, &child);
	    psp->x_parent = x;
	    psp->y_parent = y;
            return;
	}
	if (ev->xconfigure.window != psp->window)
            return;
	XFreePixmap(psp->disp, psp->pixmap);
	psp->pixmap = XCreatePixmap(psp->disp, psp->window,
				    psp->width, psp->height, psp->depth);
	DrawString(psp);
	psp->redraw = False;
	psp->cb_func(psp->cb_data, psp->x_parent, psp->y_parent,
		     psp->width, psp->height, fs->ascent);
	break;
    }
}

static int
GetAllPreferences(Display *disp, Window win, const char *name,
		  const char *class, PreeditStringPainter *psp)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    LoadSylColors(disp, fq_name, fq_class, ColorSet, psp->pixel);
    LoadSylFontSets(disp, fq_name, fq_class, FontSet, &psp->fontset);
    GetSylSetting(disp, fq_name, fq_class, &Geometry);
    return (0);
}

static void
GetGeometry(Display *disp, const char *u_geom, const char *d_geom,
	    XSizeHints *xsize)
{
    int geom_mask, x, y, width, height, gravity;

    xsize->flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    xsize, &x, &y ,&width, &height, &gravity);
    if (geom_mask & (XValue | YValue)) {
	xsize->x = x;
	xsize->y = y;
	xsize->flags |= USPosition;
    }
    xsize->win_gravity = gravity;
    xsize->flags |= PWinGravity;
}

void
FreePreeditStringPainter(PreeditStringPainter *psp)
{
    if (psp->window != None)
	XDestroyWindow(psp->disp, psp->window);
    if (psp->pixmap != None)
	XFreePixmap(psp->disp, psp->pixmap);
    if (psp->gc != None)
	XFreeGC(psp->disp, psp->gc);
    if (psp->fontset.id)
	FreeSylFontSet(psp->disp, &psp->fontset);
    if (psp->user_fontset.id)
	FreeSylFontSet(psp->disp, &psp->user_fontset);
    if (psp->pixel != NULL)
	FreeSylColors(psp->pixel);
    if (psp->string != NULL)
	FreeSylText(psp->string);
    free(psp->feedback);
    free(psp);
}

PreeditStringPainter *
CreatePreeditStringPainter(Display *disp, Window parent, const char *component,
			   ResizeNotifier callback, void *callback_data)
{
    XWindowAttributes attr;
    XSizeHints geom;
    PreeditStringPainter *psp;
    
    if ((psp = (PreeditStringPainter *)malloc(sizeof(PreeditStringPainter)))
	== NULL) {
	return (NULL);
    }
    psp->window = None;
    psp->pixmap = None;
    psp->gc = None;
    psp->fontset.id = NULL;
    psp->user_fontset.id = NULL;
    psp->pixel = NULL;
    psp->string = NULL;
    psp->feedback = NULL;
    if ((psp->string = CreateSylTextFromMBString("", True)) == NULL
	|| (psp->pixel = CreateSylColors(ColorSet)) == NULL
	|| GetAllPreferences(disp, parent, component, THIS_CLASS, psp)) {
	FreePreeditStringPainter(psp);
	return (NULL);
    }
    psp->sidemargin = (psp->fontset.width + 2) / 2;
    XGetWindowAttributes(disp, DefaultRootWindow(disp), &attr);
    psp->root_width = attr.width;
    psp->root_height = attr.height;
    XGetWindowAttributes(disp, parent, &attr);
    psp->parent = parent;
    psp->x_parent = attr.x;
    psp->y_parent = attr.y;
    psp->width = attr.width;
    psp->height = psp->fontset.height + 2 * psp->fontset.descent;
    psp->depth = attr.depth;
    psp->window = XCreateSimpleWindow(disp, parent, 0, 0,
				      psp->width, psp->height, 0,
				      psp->pixel[Foreground],
				      psp->pixel[Background]);
    GetGeometry(disp, Geometry.spec, Geometry.orig, &geom);
    if (geom.flags & USPosition) {
	psp->x_parent = geom.x;
	psp->y_parent = geom.y;
	XMoveWindow(disp, parent, geom.x, geom.y);
	XSetWMNormalHints(disp, parent, &geom);
    }
    XSetWindowBackgroundPixmap(disp, psp->window, None);
    XSelectInput(disp, psp->window, ExposureMask | StructureNotifyMask
		 | ButtonPressMask | OwnerGrabButtonMask | ButtonReleaseMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, psp->window);
    XMapRaised(disp, psp->window);
    psp->pixmap = XCreatePixmap(disp, parent, psp->width, psp->height,
				psp->depth);
    psp->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, psp->gc, False);
    psp->disp = disp;
    psp->user_fg = 0;
    psp->user_bg = 0;
    psp->n_feedbacks = 0;
    psp->caret = 0;
    psp->visible_caret = False;
    psp->grabbed = False;
    psp->cb_func = callback;
    psp->cb_data = callback_data;
    psp->redraw = True;
    return (psp);
}

void
MovePreeditStringPainter(PreeditStringPainter *psp, int x, int y)
{
    XMoveWindow(psp->disp, psp->window, x, y);
}

static unsigned long *
CreateDefaultFeedback(int n)
{
    int k;
    unsigned long *fb;
    
    if (n == 0 || (fb = (unsigned long *)malloc(sizeof(*fb) * n)) == NULL)
	return NULL;
    for (k = 0; k < n; ++k)
	fb[k] = 0;
    return (fb);
}

static void
SetPreeditStringPainter(PreeditStringPainter *psp, SylText *str)
{
    SylFontSet *fs = BetterFontSet(psp);
    int len;

    if (psp->string != NULL)
	FreeSylText(psp->string);
    psp->string = str;

    len = LengthOfSylText(str);
    if (psp->caret > len)
	psp->caret = len;
    psp->width = psp->sidemargin * 2
	+ TextEscapement(fs, psp->string->wcs, psp->string->len);
    XResizeWindow(psp->disp, psp->window, psp->width, psp->height);
    psp->redraw = True;
}

int
SetWCStringPreeditStringPainter(PreeditStringPainter *psp, wchar_t *src)
{
    SylText *str;

    if ((str = CreateSylTextFromWCString(src, True)) == NULL)
	return (1);
    SetPreeditStringPainter(psp, str);
    return (0);
}

void
SetCaretPositionPreeditStringPainter(PreeditStringPainter *psp, int caret)
{
    psp->caret = round(0, psp->string->len, caret);
    psp->redraw = True;
}

void
SetCaretModePreeditStringPainter(PreeditStringPainter *psp, int mode)
{
    psp->visible_caret = mode;
    psp->redraw = True;
}

int
SetFeedbackPreeditStringPainter(PreeditStringPainter *psp,
				unsigned long *feedback, int len)
{
    free(psp->feedback);
    if ((psp->feedback = CreateDefaultFeedback(len)) == NULL) {
	psp->n_feedbacks = 0;
	return (len);
    }
    psp->n_feedbacks = len;
    bcopy(feedback, psp->feedback, sizeof(*feedback) * len);
    psp->redraw = True;
    return (0);
}

int
SetFontsetPreeditStringPainter(PreeditStringPainter *psp, char *name)
{
    SylFontSet *fs;
    int s;

    if (psp->user_fontset.id != NULL) {
	FreeSylFontSet(psp->disp, &psp->user_fontset);
	psp->user_fontset.id = NULL;
    }
    s = (name != NULL
	 && CreateSylFontSet(psp->disp, name, &psp->user_fontset) == NULL);
    fs = BetterFontSet(psp);
    psp->sidemargin = (fs->width + 2) / 2;
    psp->width = psp->sidemargin * 2
	+ TextEscapement(fs, psp->string->wcs, psp->string->len);
    psp->height = fs->height + 2 * fs->descent;
    XResizeWindow(psp->disp, psp->window, psp->width, psp->height);
    psp->redraw = True;
    return (s);
}
