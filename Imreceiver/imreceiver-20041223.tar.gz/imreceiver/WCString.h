/*
	$Id: WCString.h,v 1.1 2003/01/03 14:33:30 syl Exp $

	Copyright (C) 1998, 1999 Syllabub
	Maroontress Fast Software.
*/

int wstrlen(const wchar_t *str);
wchar_t * wstrcpy(wchar_t *d, const wchar_t *s);
wchar_t * wstrncpy(wchar_t *d, const wchar_t *s, int n);
int wstrcmp(const wchar_t *s, const wchar_t *t);
