#!/bin/sh

#	$Id: colordef2h.sh,v 1.1 2003/01/03 14:33:30 syl Exp $
#
#	Copyright (C) 2000, 2001 Syllabub
#	Maroontress Fast Software.

echo 'static SylSetting'

e=""
n=0
while read func name class args
do
  echo '  ColorSet'$n' = {"'$name'"', '"'$class'"', '"'$args'"', 'NULL},'
  e="$e $func,"
  n=`expr $n + 1`
done

echo '  *ColorSet[] = {'

m=0
while [ $m -lt $n ]
do
  echo '    &ColorSet'$m','
  m=`expr $m + 1`
done

echo '    NULL};'
echo 'enum {'$e'};'
