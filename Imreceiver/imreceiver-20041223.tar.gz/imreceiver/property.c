/*
        $Id: property.c,v 1.3 2004/04/10 20:56:31 syl Exp $

        Copyright (C) 2001 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
#include <err.h>

#include "property.h"

#define max(a, b) (((a) < (b)) ? (b) : (a))

static int
IsMatchIconSize(XIconSize *s, int req_w, int req_h)
{
    if (s->max_width < req_w || s->min_width > req_w
	|| (req_w - s->min_width) % s->width_inc
	|| s->max_height < req_h || s->min_height > req_h
	|| (req_h - s->min_height) % s->height_inc)
	return (0);
    return (1);
}

static int
IconCheck(Display *disp, Drawable d)
{
    int x, y, width, height, border, depth, n, n_icons_sizes;
    Window root;
    XIconSize *icon_size;

    XGetGeometry(disp, d, &root, &x, &y, &width, &height, &border, &depth);
    if (XGetIconSizes(disp, root, &icon_size, &n_icons_sizes) == 0)
	return (0); /* XXX */
    for (n = 0; n < n_icons_sizes; ++n) {
#if 0
	printf("%dx%d, %dx%d, %d:%d\n",
	       icon_size[n].min_width, icon_size[n].min_height,
	       icon_size[n].max_width, icon_size[n].max_height,
	       icon_size[n].width_inc, icon_size[n].height_inc);
#endif
	if (IsMatchIconSize(&icon_size[n], width, height)) {
	    break;
	}
    }
    XFree(icon_size);
    return ((n >= n_icons_sizes) ? 1 : 0);
}

void
SetProperties(Display *disp, Window w, const char *title, const char *name,
	      const char *class, int ac, char const *const *av,
	      XSizeHints *xsize, Pixmap face, Pixmap mask, Window icon)
{
    XClassHint xclass;
    XWMHints xwm;

    xwm.flags = InputHint /* | XUrgencyHint */;
    xwm.input = False;
    xwm.flags |= WindowGroupHint;
    xwm.window_group = w;
    if (face != None) {
	if (IconCheck(disp, face))
	    warnx("icon pixmap size is not matched.");
	xwm.icon_pixmap = face;	/* ICCCM�Ǥ�icon_pixmap�Υǥץ���1�� */
	xwm.flags |= IconPixmapHint;
    }
    if (mask != None) {
	if (IconCheck(disp, mask))
	    warnx("icon mask size is not matched.");
	xwm.icon_mask = mask; /* ICCCM�Ǥ�icon_msak�Υǥץ���1�� */
	xwm.flags |= IconMaskHint;
    }
    if (icon != None) {
	if (IconCheck(disp, icon))
	    warnx("icon window size is not matched.");
	xwm.icon_window = icon;
	xwm.flags |= IconWindowHint;
    }
    xclass.res_name = (char *)name;
    xclass.res_class = (char *)class;
    XmbSetWMProperties(disp, w, title, title, (char **)av, ac,
		       xsize, &xwm, &xclass);
}
