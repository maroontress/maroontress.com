/*
        $Id: property.h,v 1.2 2004/04/10 20:56:31 syl Exp $

        Copyright (C) 2001 Syllabub
        Maroontress Fast Software.
*/

void SetProperties(Display *, Window, const char *, const char *, const char *,
		   int, char const * const *, XSizeHints *,
		   Pixmap, Pixmap, Window);
