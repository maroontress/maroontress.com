#!/bin/sh
echo 'static SylSetting'

e=""
n=0
while read func name class args
do
  echo '  ColorSet'$n' = {"'$name'"', '"'$class'"', '"'$args'"', 'NULL},'
  e="$e $func,"
  n=`expr $n + 1`
done

echo '  *ColorSet[] = {'

m=0
while [ $m -lt $n ]
do
  echo '    &ColorSet'$m','
  m=`expr $m + 1`
done

echo '    NULL};'
echo 'enum {'$e'};'
