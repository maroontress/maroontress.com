/*
        xsel.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Layout.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Button.h"
#include "TextLine.h"
#include "TextArea.h"
#include "PixmapQueue.h"
#include "ListBox.h"
#include "Tape.h"
#include "Null.h"
#include "Control.h"
#include "property.h"
#include "xsel_face.xbm"
#include "xsel_mask.xbm"

#ifdef SHAPE_ICON
#include <X11/extensions/shape.h>
#include <X11/xpm.h>
#include "xsel_icon.xpm"
#endif

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define THIS_CLASS "XSel"
#define TOPLEVEL_DEFAULT_GEOMETRY "480x360"

char **GlobalAv;
int GlobalAc;

static int MainPower = True;
static Atom TARGETS, COMPOUND_TEXT, TEXT, DELETE, NET_ADDRESS, SPAN;

static SylSetting
    Foreground  = {"foreground", "Foreground", "black",  NULL},
    MediumGray  = {"mediumGray", "MediumGray", "gray70", NULL},
    *ColorSet[] = {&Foreground, &MediumGray, NULL};

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset",  "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

#define DEFAULT_XIMSTYLE "PreeditNothing,StatusNothing"
static SylSetting
    IMStyle = {"ximStyle", "XIMStyle", DEFAULT_XIMSTYLE, NULL},
    *IMStyleSet[] = {&IMStyle, NULL};

#define DEFAULT_WM_NAME "Internationalized editor"
static SylSetting
    Modifier = {"localeModifier", "LocaleModifier", "", NULL},
    Geometry = {"geometry", "Geometry", "", NULL},
    Headline = {"headline", "Headline", DEFAULT_WM_NAME, NULL};

static SylSetting
    MSG_UnknownPropertyType = {"messageUnknownPropertyType",
			       "MessageUnknownPropertyType",
			       "Unknown property type", NULL},
    MSG_RetrievingSelection = {"messageRetrievingSelection",
			       "MessageRetrievingSelection",
			       "Retrieving selection...", NULL},
    MSG_TargetsNotFound = {"messageTargetsNotFound", "MessageTargetsNotFound", 
			   "Targets not found", NULL};


static XIMStyle
FindBestStyle(XIM im, XIMStyle request)
{
    int n;
    XIMStyle best_style, style;
    XIMStyles *supported;

    XGetIMValues(im, XNQueryInputStyle, &supported, NULL);
    best_style = 0;
    for (n = 0; n < supported->count_styles; ++n) {
        style = supported->supported_styles[n];
        if (style == request) {
            best_style = style;
            break;
        }
    }
    XFree(supported);
    return (best_style);
}

static XIC
CreateIC(XIM im, XIMStyle request, Window win, XFontSet fs,
	 unsigned long fore, unsigned long back)
{
    XIC ic;
    XVaNestedList preedit, status;
    XPoint Origin = {0, 0};

    preedit = XVaCreateNestedList(0, XNFontSet, fs,
				  XNForeground, fore,
				  XNBackground, back,
				  XNSpotLocation, &Origin, NULL);
    status = XVaCreateNestedList(0, XNFontSet, fs,
				 XNForeground, fore,
				 XNBackground, back,
				 NULL);
    ic = XCreateIC(im, XNInputStyle, request, XNClientWindow, win,
                   XNPreeditAttributes, preedit, XNStatusAttributes, status,
                   NULL);
    XFree(preedit);
    XFree(status);
    return (ic);
}

static void
SetGeometry(XIC ic, char *name, XRectangle *area)
{
    XVaNestedList list;

    list = XVaCreateNestedList(0, XNArea, area, NULL);
    XSetICValues(ic, name, list, NULL);
    XFree(list);
}

static XSizeHints
GetToplevelWindowGeometry(Display *disp, char *u_geom, char *d_geom,
		      int *x, int *y, int *w, int *h)
{
    XSizeHints xsize;
    int geom_mask, width, height, gravity;

    /*
      ICCCM$B$h$j(BXSizeHints$B9=B$BN$N%a%s%P(Bx, y, width, height$B$rL5;k$7$F$$$k!#(B
      xprop$B$G0[>o$JCM$,I=<($5$l$k$N$O(Bxprop$B$NJ}$,(BICCCM$B$rL5;k$7$F$$$k$?$a!#(B
    */
    xsize.flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    &xsize, x, y ,&width, &height, &gravity);
    if (geom_mask & (XValue | YValue))
	xsize.flags |= USPosition;
    xsize.flags |= (geom_mask & (WidthValue | HeightValue)) ? USSize : PSize;
    if (width && height) {
	*w = width;
	*h = height;
    }
    xsize.win_gravity = gravity;
    xsize.flags |= PWinGravity;
    return (xsize);
}

typedef struct SelProp {
    Atom name;
    Atom type;
    int format;
    long n_items;
    long remain;
    void *contents;
    struct SelProp *next;
} SelProp;

typedef struct {
    Display *disp;
    int x;
    int y;
    int width;
    int height;
    Window window;
    Pixmap icon_face;
    Pixmap icon_mask;
#ifdef SHAPE_ICON
    Window icon_window;
    Pixmap icon_pixmap;
    Pixmap icon_shape;
#endif
    XSizeHints size_hint;
    XIC ic;
    XIMStyle style;
    unsigned long pixel[2];
    SylFontSet fs;
    SylButton *retrieve;
    SylListBox *sel;
    SylListBox *targets;
    SylTextLine *name;
    SylTextLine *type;
    SylTextLine *format;
    SylTextLine *items;
    SylTextArea *contents;
    SylNull *status;
    SylTape *s_tape;
    SylTape *n_tape;
    SylTape *t_tape;
    SylTape *y_tape;
    SylTape *f_tape;
    SylTape *i_tape;
    SylTape *c_tape;
    SelProp *top;
} XSel;

static void
GetToplevelPreferences(Display *disp, char *name, char *class, XSel *p)
{
    LoadSylColorset(disp, name, class, ColorSet, p->pixel);
    LoadSylFontset(disp, name, class, FontSet, &p->fs);
    LoadSylIMStyleset(disp, name, class, IMStyleSet, &p->style);
    GetSylSetting(disp, name, class, &Modifier);
    GetSylSetting(disp, name, class, &Geometry);
    GetSylSetting(disp, name, class, &Headline);
    GetSylSetting(disp, name, class, &MSG_UnknownPropertyType);
    GetSylSetting(disp, name, class, &MSG_RetrievingSelection);
    GetSylSetting(disp, name, class, &MSG_TargetsNotFound);
}

static void
print_targets(XSel *x, Atom *contents, int n_items)
{
    int n;
    char *atom;
    SelProp *p, *next;

    ClearSylListBox(x->targets);
    for (p = x->top; p != NULL; p = next) {
	next = p->next;
	XFree(p->contents);
	free(p);
    }
    x->top = NULL;

    for (n = 0; n < n_items; ++n) {
        atom = XGetAtomName(x->disp, contents[n]);
	AddToSylListBox(x->targets, atom);
        XFree(atom);
        if (contents[n] != TARGETS && contents[n] != DELETE) {
            XConvertSelection(x->disp,
                              XA_PRIMARY,
                              contents[n],
                              contents[n],
                              x->window,
                              CurrentTime);
        }
    }
}

static void
UpdateSelName(XSel *x, Atom selection)
{
    char *str;

    str = XGetAtomName(x->disp, selection);
    ClearSylListBox(x->sel);
    AddToSylListBox(x->sel, str);
    XFree(str);
}

static void
UpdateSelPropTypes(XSel *x, SelProp *p)
{
    char buf[256], *s;
    
    s = XGetAtomName(x->disp, p->name);
    SetMBStringSylTextLine(x->name, s);
    XFree(s);

    s = XGetAtomName(x->disp, p->type);
    SetMBStringSylTextLine(x->type, s);
    XFree(s);

    sprintf(buf, "%d", p->format);
    SetMBStringSylTextLine(x->format, buf);

    sprintf(buf, "%ld (%ld)", p->n_items, p->remain);
    SetMBStringSylTextLine(x->items, buf);

    ResetSylTextArea(x->contents);
    if (p->type == XA_STRING || p->type == COMPOUND_TEXT) {
	XTextProperty text;
	char **list;
	int n_lists;

	text.value = (unsigned char *)p->contents;
	text.encoding = p->type;
	text.format = p->format;
	text.nitems = p->n_items;
	if (XmbTextPropertyToTextList(x->disp, &text, &list, &n_lists) >= 0) {
	    if (n_lists > 0) {
		SetMBStringSylTextArea(x->contents, list[0]);
	    }
	    XFreeStringList(list);
	}
    }
    else if (p->type == XA_ATOM && p->name != TARGETS) {
	int n;
	char *atom;
	
	for (n = 0; n < p->n_items; ++n) {
	    atom = XGetAtomName(x->disp, ((Atom *)p->contents)[n]);
	    sprintf(buf, "Atom[%d]: %s\n", n, atom);
	    XFree(atom);
	    SetMBStringSylTextArea(x->contents, buf);
	}
    }
    else if (p->type == XA_INTEGER || p->type == SPAN) {
	int n;

	for (n = 0; n < p->n_items; ++n) {
	    sprintf(buf, "int[%d]: %d\n", n, ((int *)p->contents)[n]);
	    SetMBStringSylTextArea(x->contents, buf);
	}
    }
    else if (p->type == XA_WINDOW || p->type == XA_PIXMAP) {
	int n;

	for (n = 0; n < p->n_items; ++n) {
	    sprintf(buf, "XID[%d]: 0x%lx\n", n, ((XID *)p->contents)[n]);
	    SetMBStringSylTextArea(x->contents, buf);
	}
    }
    else if (p->type == NET_ADDRESS && p->format == 8) {
	int n;

	for (n = 0; n < p->n_items; ++n) {
	    sprintf(buf, "char[%d]: %d (0x%x)\n", n,
		    ((unsigned char *)p->contents)[n],
		    ((unsigned char *)p->contents)[n]);
	    SetMBStringSylTextArea(x->contents, buf);
	}
    }
    else if (p->type != XA_ATOM) {
	SetMBStringSylTextArea(x->contents, MSG_UnknownPropertyType.spec);
    }
}

static void
ClearSelPropTypes(XSel *x)
{
    SetMBStringSylTextLine(x->name, "None");
    SetMBStringSylTextLine(x->type, "");
    SetMBStringSylTextLine(x->format, "");
    SetMBStringSylTextLine(x->items, "");
    ResetSylTextArea(x->contents);
}

static void
ClearSelProp(XSel *x)
{
    ClearSylListBox(x->targets);
    ClearSelPropTypes(x);
}

static SelProp *    
CreateSelProp(XSel *x, Atom prop)
{
    Atom property_type;
    int format;
    long n_items, remain;
    void *contents;
    SelProp *p;

    if ((p = (SelProp *)malloc(sizeof(SelProp))) == NULL) {
	return (NULL);
    }
    if (XGetWindowProperty(x->disp, x->window, prop,
			   0, 8192, True, AnyPropertyType,
			   &property_type, &format, &n_items,
			   &remain, (void *)&contents) != Success) {
	free(p);
	return (NULL);
    }
    p->name = prop;
    p->type = property_type;
    p->format = format;
    p->n_items = n_items;
    p->remain = remain;
    p->contents = contents;
    p->next = NULL;
    return (p);
}

static void
GetWindowProperty(XSel *x, XEvent *ev)
{
    Atom prop = ev->xselection.property;
    SelProp *p;

    if (ev->xselection.target == TARGETS) {
	if (prop == None) {
	    ClearSelProp(x);
	    SetMBStringSylTextArea(x->contents, MSG_TargetsNotFound.spec);
	    return;
	}
	if ((p = CreateSelProp(x, prop)) == NULL) {
	    ClearSelProp(x);
	    printf("XGetWindowProperty() failed.\n");
	    return;
	}
	if (p->type == XA_ATOM) {
	    UpdateSelPropTypes(x, p);
	    print_targets(x, (Atom *)p->contents, p->n_items);
	}
	else {
	    ClearSelProp(x);
	    UpdateSelPropTypes(x, p);
	}
	XFree(p->contents);
	free(p);
    }
    else {
	if (prop == None) {
	    return;
	}
	if ((p = CreateSelProp(x, prop)) == NULL) {
	    printf("XGetWindowProperty() failed.\n");
	    return;
	}
	p->next = x->top;
	x->top = p;
    }
}


static void
SendToplevel(XSel *x, XEvent *ev)
{
    XWindowAttributes attr;
    XRectangle region;
    
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
#ifdef SHAPE_ICON
    case Expose:
        if (ev->xexpose.window != x->icon_window)
            return;
	{
	    GC gc = XCreateGC(x->disp, x->icon_window, 0, 0);
	    XShapeCombineMask(x->disp, x->icon_window, ShapeBounding, 0, 0,
			      x->icon_shape, ShapeSet);
	    XCopyArea(x->disp, x->icon_pixmap, x->icon_window, gc,
		      ev->xexpose.x, ev->xexpose.y,
		      ev->xexpose.width, ev->xexpose.height,
		      ev->xexpose.x, ev->xexpose.y);
	    XFreeGC(x->disp, gc);
 	}
	break;
#endif
    case SelectionNotify:
	if (ev->xselection.requestor != x->window)
            break;
	UpdateSelName(x, ev->xselection.selection);
	GetWindowProperty(x, ev);
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != x->window)
            break;
	x->width = ev->xconfigure.width;
	x->height = ev->xconfigure.height;
	XGetWindowAttributes(x->disp, x->status->parent, &attr);
	if (x->style & XIMPreeditArea) {
	    region.width = max(ev->xconfigure.width - x->fs.height * 6, 1);
	    region.height = attr.height;
	    region.x = ev->xconfigure.width - region.width;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(x->ic, XNPreeditAttributes, &region);
	}
	if (x->style & XIMStatusArea) {
	    region.width = min(ev->xconfigure.width, x->fs.height * 6);
	    region.height = attr.height;
	    region.x = 0;
	    region.y = ev->xconfigure.height - region.height;
	    SetGeometry(x->ic, XNStatusAttributes, &region);
	}
	break;
    }
}

static void
RetrieveCB(void *callback_data)
{
    XSel *x = (XSel *)callback_data;

    XConvertSelection(x->disp,
                      XA_PRIMARY, /* $B%;%l%/%7%g%sL>(B */
                      TARGETS, /* $B%?!<%2%C%H%"%H%`(B */
                      TARGETS, /* $B%W%m%Q%F%#L>!J%?!<%2%C%H$HF1L>$K$7$?!K(B */
                      x->window,
                      CurrentTime);
    ClearSelProp(x);
    SetMBStringSylTextArea(x->contents, MSG_RetrievingSelection.spec);
}

static void
TargetCB(void *callback_data, char *str)
{
    XSel *x = (XSel *)callback_data;
    SelProp *p;

    for (p = x->top; p != NULL; p = p->next) { 
	if (XInternAtom(x->disp, str, False) == p->name) {
	    UpdateSelPropTypes(x, p);
	    break;
	}
    }
    if (p == NULL) {
	ClearSelPropTypes(x);
    }
}

int
main(int ac, char **av)
{
    XIM im;
    XrmDatabase xrdb;
    long toplevel_mask, ic_mask = 0;
    XEvent ev;
    XSel x;
    SylControlManager *mgr;

    GlobalAc = ac;
    GlobalAv = av;
    if (ac != 1) {
	printf("usage: %s\n", av[0]);
	exit(1);
    }
    if ((x.disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    XrmInitialize();
    xrdb = SylMergedResourceDatabase(x.disp);
    GetToplevelPreferences(x.disp, "xsel", THIS_CLASS, &x);
    if (x.fs.id == None) {
        fprintf(stderr, "%s: cannot create fontset.\n", av[0]);
        exit(1);
    }
    if (XSetLocaleModifiers(Modifier.spec) == NULL) {
        fprintf(stderr, "%s: cannot set locale modifiers.\n", av[0]);
        exit(1);
    }
    if ((im = XOpenIM(x.disp, xrdb, "xsel", THIS_CLASS)) == NULL) {
        fprintf(stderr, "%s: cannot open input method.\n", av[0]);
        exit(1);
    }
    if ((x.style = FindBestStyle(im, x.style)) == 0) {
        fprintf(stderr, "%s: no available style of input method.\n", av[0]);
        exit(1);
    }

    x.size_hint = GetToplevelWindowGeometry(x.disp, Geometry.spec,
	TOPLEVEL_DEFAULT_GEOMETRY, &x.x, &x.y, &x.width, &x.height);
    x.window = XCreateSimpleWindow(x.disp, DefaultRootWindow(x.disp),
	x.x, x.y, x.width, x.height, 1, x.pixel[0], x.pixel[1]);
    x.icon_face = XCreateBitmapFromData(x.disp, x.window, xsel_face_bits,
	xsel_face_width, xsel_face_height); 
    x.icon_mask = XCreateBitmapFromData(x.disp, x.window, xsel_mask_bits,
	xsel_mask_width, xsel_mask_height);
#ifdef SHAPE_ICON
    x.icon_window = XCreateSimpleWindow(x.disp, DefaultRootWindow(x.disp),
	0, 0, xsel_mask_width, xsel_mask_height, 0,
        x.pixel[0], x.pixel[1]);
    XSelectInput(x.disp, x.icon_window, ExposureMask);
    XpmCreatePixmapFromData(x.disp, x.icon_window, xsel_icon_xpm,
	&x.icon_pixmap, &x.icon_shape, NULL);
    SetProperties(x.disp, x.window, Headline.spec, "xsel", THIS_CLASS,
	ac, av, &x.size_hint, x.icon_face, x.icon_mask, x.icon_window);
#else
    SetProperties(x.disp, x.window, Headline.spec, "xsel", THIS_CLASS,
	ac, av, &x.size_hint, x.icon_face, x.icon_mask, None);
#endif
    if ((x.ic = CreateIC(im, x.style, x.window, x.fs.id, x.pixel[0],
			 x.pixel[1])) == NULL) {
        fprintf(stderr, "%s: cannot create input context.\n", av[0]);
        exit(1);
    }
    toplevel_mask = StructureNotifyMask;
    if (XGetICValues(x.ic, XNFilterEvents, &ic_mask, NULL) == NULL)
	toplevel_mask |= ic_mask;
    else
	fprintf(stderr, "%s: warning: the current IM has no specification"
		" of the `XNFilterEvents' value.\n", av[0]);
    XSelectInput(x.disp, x.window, toplevel_mask);
    XSetICFocus(x.ic);
    XMapRaised(x.disp, x.window);

    if ((mgr = CreateSylControlManager(x.disp, x.window)) == NULL) {
        fprintf(stderr, "%s: cannot create SylControlManager.\n", av[0]);
	exit(1);
    }
    x.retrieve = CreateSylControlOfSylButton(mgr, "retrieve",
					     RetrieveCB, &x);
    x.sel = CreateSylControlOfSylListBox(mgr, "selection", NULL, NULL);
    x.targets = CreateSylControlOfSylListBox(mgr, "targets", TargetCB, &x);
    x.name = CreateSylControlOfSylTextLine(mgr, "name", NULL);
    x.type = CreateSylControlOfSylTextLine(mgr, "type", NULL);
    x.format = CreateSylControlOfSylTextLine(mgr, "format", NULL);
    x.items = CreateSylControlOfSylTextLine(mgr, "items", NULL);
    x.contents = CreateSylControlOfSylTextArea(mgr, "contents");
    x.status = CreateSylControlOfSylNull(mgr, "status",
					 0, x.fs.height, 0, x.fs.height);
    x.s_tape = CreateSylControlOfSylTape(mgr, "selection", 0);
    x.t_tape = CreateSylControlOfSylTape(mgr, "targets", 1);
    x.n_tape = CreateSylControlOfSylTape(mgr, "name", 1);
    x.y_tape = CreateSylControlOfSylTape(mgr, "type", 1);
    x.f_tape = CreateSylControlOfSylTape(mgr, "format", 1);
    x.i_tape = CreateSylControlOfSylTape(mgr, "items", 1);
    x.c_tape = CreateSylControlOfSylTape(mgr, "contents", 1);
    if (x.retrieve == NULL || x.sel == NULL || x.targets == NULL
	|| x.name == NULL || x.type == NULL || x.format == NULL
	|| x.items == NULL || x.contents == NULL || x.status == NULL
	|| x.s_tape == NULL || x.n_tape == NULL || x.t_tape == NULL
	|| x.y_tape == NULL || x.f_tape == NULL || x.i_tape == NULL) {
        fprintf(stderr, "%s: cannot create SylControl.\n", av[0]);
	exit(1);
    }

    SetOrderSylLayoutManager(mgr->layout,
        SylVLayout(
	    SylHLayout(
		SylPaneOfSylControlManager(mgr, x.retrieve->window),
		SylPaneOfSylControlManager(mgr, x.s_tape->window),
		SylPaneOfSylControlManager(mgr, x.sel->target),
		NULL),
	    SylHRule(),
	    SylHLayout(
		SylVLayout(
		    SylPaneOfSylControlManager(mgr, x.t_tape->window),
		    SylPaneOfSylControlManager(mgr, x.targets->target),
		    NULL),
		SylVLayout(
		    SylPaneOfSylControlManager(mgr, x.n_tape->window),
		    SylPaneOfSylControlManager(mgr, x.name->window),
		    SylHRule(),
		    SylPaneOfSylControlManager(mgr, x.y_tape->window),
		    SylPaneOfSylControlManager(mgr, x.type->window),
		    SylHRule(),
		    SylPaneOfSylControlManager(mgr, x.f_tape->window),
		    SylPaneOfSylControlManager(mgr, x.format->window),
		    SylHRule(),
		    SylPaneOfSylControlManager(mgr, x.i_tape->window),
		    SylPaneOfSylControlManager(mgr, x.items->window),
		    SylHRule(),
		    SylPaneOfSylControlManager(mgr, x.c_tape->window),
		    SylPaneOfSylControlManager(mgr, x.contents->window),
		    NULL),
		NULL),
	    SylPaneOfSylControlManager(mgr, x.status->parent),
	    NULL));
    
    /* begin: $B%"%W%j%1!<%7%g%sFCM-$N=i4|2=(B */
    TARGETS = XInternAtom(x.disp, "TARGETS", False);
    COMPOUND_TEXT = XInternAtom(x.disp, "COMPOUND_TEXT", False);
    TEXT = XInternAtom(x.disp, "TEXT", False);
    DELETE = XInternAtom(x.disp, "DELETE", False);
    NET_ADDRESS = XInternAtom(x.disp, "NET_ADDRESS", False);
    SPAN = XInternAtom(x.disp, "SPAN", False);

    SetICSylTextLine(x.name, x.ic, x.style);
    SetICSylTextLine(x.type, x.ic, x.style);
    SetICSylTextLine(x.format, x.ic, x.style);
    SetICSylTextLine(x.items, x.ic, x.style);
    SetICSylTextArea(x.contents, x.ic, x.style);

    x.top = NULL;
    /* end: $B%"%W%j%1!<%7%g%sFCM-$N=i4|2=(B */

    while (MainPower) {
        while (XEventsQueued(x.disp, QueuedAfterReading) == 0
               && NiceSylControlManager(mgr)) {
            ;
	}
	XNextEvent(x.disp, &ev);
	if (XFilterEvent(&ev, None))
            continue;
	if (IsWMCloseMessage(&ev))
	    break;
	SendSylControlManager(mgr, &ev);
        SendToplevel(&x, &ev);
    }
    FreeSylControlManager(mgr);
    XrmDestroyDatabase(xrdb);  
    XDestroyWindow(x.disp, x.window);
    XCloseDisplay(x.disp);
    exit(0);
}
