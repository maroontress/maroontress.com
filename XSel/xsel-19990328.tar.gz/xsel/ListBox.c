#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/Xatom.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>

#include "Resource.h"
#include "FontStack.h"
#include "VScrollbar.h"
#include "PixmapQueue.h"
#include "ListBox.h"

#define THIS_CLASS "ListBox"
#define FOCUS_FRAME_WIDTH 1

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

static SylSetting
    Foreground  = {"foreground",  "Foreground",  "black",   NULL},
    Background  = {"background",  "Background",  "white",   NULL},
    MediumGray  = {"mediumGray",  "MediumGray",  "gray70",  NULL},
    DimGray     = {"dimGray",     "DimGray",     "gray50",  NULL},
    Illuminated = {"illuminated", "Illuminated", "#ffe0e0", NULL},
    Highlighted = {"highlighted", "Highlighted", "#3f00ff", NULL},
    *ColorSet[] = {&Foreground, &Background, &MediumGray,
                   &DimGray, &Illuminated, &Highlighted, NULL};

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

static SylFontStack CheckMarkStack[] = {
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 4},     /* S0:x0 */
    {SYL_FS_ASCENT}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},    /* S1:y0 */
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 4},     /* S2:x1 */
    {SYL_FS_ASCENT}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},    /* S3:y1 */
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, 2},     /* S4:x2 */
    {SYL_FS_CONST, 0}, {SYL_FS_SUB}, {SYL_FS_ASCENT},    /* S5:y2 */
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, -2},    /* S6:x3 */
    {SYL_FS_ASCENT}, {SYL_FS_SUB}, {SYL_FS_CONST, 1},    /* S7:y3 */
    {SYL_FS_WIDTH}, {SYL_FS_DIV}, {SYL_FS_CONST, -4},
        {SYL_FS_ADD}, {SYL_FS_CONST, 1},                 /* S8:x4 */
    {SYL_FS_ASCENT}, {SYL_FS_DIV}, {SYL_FS_CONST, -2},   /* S9:y4 */
    {SYL_FS_DRAW_LINES}, {SYL_FS_CONST, 5}, {SYL_FS_EOF}};

static Pixmap
CreateMark(Display *disp, Window win, XFontSet fs, int w, int h,
           SylFontStack *s)
{
    GC gc;
    Pixmap d;

    d = XCreatePixmap(disp, win, w, h, 1);
    gc = XCreateGC(disp, d, 0, 0);
    XSetForeground(disp, gc, 0);
    XFillRectangle(disp, d, gc, 0, 0, w, h);
    XSetForeground(disp, gc, 1);
    DrawSylFontStack(disp, d, gc, fs, 0, 0, s);
    XFreeGC(disp, gc);
    return (d);
}

static int
num(SylListBoxItem *p)
{
    return (p->num);
}

static SylListBoxItem *
Item(SylListBox *box, int n)
{
    int k;
    SylListBoxItem *item;

    if (box->item != NULL)
	return (box->item[n]);

    for (k = 0, item = box->top; item != NULL && k < n; ++k, item = item->next)
	;
    return (item);
}

static void
UpdateItem(SylListBoxItem *p)
{
    if (p != NULL && p->pixmap != None && p->exposable == True)
	p->exposable = False;
}

static void
adjustcallback(void *cb_data, int n)
{
    SylListBox *box = cb_data;
    int m;

    if (box->vsb->grabbed == True && box->cursor != NULL) {
	m = n + max(1, box->parent_height / box->baseline_skip) - 1;
	if (num(box->cursor) < n) {
	    UpdateItem(box->cursor);
	    box->cursor = Item(box, n);
	    UpdateItem(box->cursor);
	}
	else if (num(box->cursor) > m) {
	    UpdateItem(box->cursor);
	    box->cursor = Item(box, m);
	    UpdateItem(box->cursor);
	}
    }
    box->window_offset_y = n * box->baseline_skip;
    XMoveWindow(box->disp, box->window,
		-box->window_offset_x, -box->window_offset_y);
}

static void
scrollcallback(void *cb_data, int n, int m)
{
    SylListBox *box = cb_data;

    adjustcallback(box, n + m);
}

static void
PressButton(SylListBox *box, Time tm)
{
    if (box->cursor == NULL)
	return;
    if (box->callback_func != NULL)
	box->callback_func(box->callback_data, box->cursor->mbs);
    UpdateItem(box->selected);
    box->selected = box->cursor;
    UpdateItem(box->selected);
    if (box->to_be_marked == box->marked)
	box->marked = NULL;
}

static void
CursorDown(SylListBox *box, Time tm)
{
    SylListBoxItem *item;
    int n, m;

    if (box->cursor == NULL)
	return;
    n = box->window_offset_y / box->baseline_skip;
    m = n + max(1, box->parent_height / box->baseline_skip) - 1;
    item = Item(box, min(num(box->cursor) + 1, box->n_items - 1));
    if (num(box->cursor) >= m)
	ScrollSylVScrollbar(box->vsb, 1);
    UpdateItem(box->cursor);
    box->cursor = item;
    UpdateItem(box->cursor);
    UpdateItem(box->marked);
    box->marked = NULL;
}

static void
CursorUp(SylListBox *box, Time tm)
{
    SylListBoxItem *item;
    int n, m;

    if (box->cursor == NULL)
	return;
    n = box->window_offset_y / box->baseline_skip;
    m = n + max(1, box->parent_height / box->baseline_skip) - 1;
    item = Item(box, max(num(box->cursor) - 1, 0));
    if (num(box->cursor) <= n)
	ScrollSylVScrollbar(box->vsb, -1);
    UpdateItem(box->cursor);
    box->cursor = item;
    UpdateItem(box->cursor);
    UpdateItem(box->marked);
    box->marked = NULL;
}

static void
SetFocusToNextField(SylListBox *box, Time tm)
{
    if (box->next_field != None)
        XSetInputFocus(box->disp, box->next_field, RevertToParent, tm);
}

static void
SetFocusToPrevField(SylListBox *box, Time tm)
{
    if (box->prev_field != None)
        XSetInputFocus(box->disp, box->prev_field, RevertToParent, tm);
}

#include "ListBoxKeyBinding.h"

static void (*Branch[])(SylListBox *, Time) = {
#include "ListBoxBranch.h"
};

static void
LookupKey(SylListBox *box, XKeyEvent *key, wchar_t c)
{
    SylKeymap *ptr;

    if (key->state & Mod3Mask) {
        /* NEC PC-98xx: GRPH$B%-!<(B (Mod3Mask) $B$r(BAlt$B%-!<$H$7$F2r<a$5$;$k!#(B*/
        key->state &= ~Mod3Mask;
        key->state |= Mod1Mask;
    }
    if (key->keycode == 0 && c == '\n') {
        /*
          kinput2: $B%P!<%8%g%s(B2.0.1$B$G$O!"(BReturn/Tab$B$N%-!<%7%`!"%-!<%3!<%I!"(B
          $B=$>~%-!<$N>uBV$,<N$F$i$l$F$7$^$&!#(Bvje$B$J$i$A$c$s$HF0$/$N$K!#(B
          Control-m$B$J$iDL$k$N$G!"$"$k0UL#LdBj$O$J$$$s$@$1$I(B...$B!#(B
        */
        fprintf(stderr, "warning: the current IM does not pass the keycode"
                " of `Return' key.\n");
        return;
    }
    key->state &= (ShiftMask | ControlMask | Mod1Mask);
    for (ptr = box->keymap[key->keycode]; ptr != NULL; ptr = ptr->next) {
        if (key->state == ptr->mod) {
            (Branch[ptr->func])(box, key->time);
        }
    }
}

static void
LookupPressedKey(SylListBox *box, XKeyEvent *key)
{
    KeySym ks;
    unsigned char p[64];
    wchar_t c;

    p[XLookupString(key, p, 64, NULL, NULL)] = 0;
    if ((ks = XLookupKeysym(key, 0)) == NoSymbol)
        return;
    LookupKey(box, key, (mbtowc(&c, p, 1) > 0) ? c : 0);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  SylListBox *box)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    LoadSylColorset(disp, fq_name, fq_class, ColorSet, box->pixel);
    LoadSylFontset(disp, fq_name, fq_class, FontSet, &box->fontset);
    LoadSylKeybinding(disp, fq_name, fq_class, KeyBinding, box->keymap);
    return (0);
}

SylListBox *
CreateSylListBox(Display *disp, Window parent, char *component,
		 void (*callback_func)(void *, char *), void *callback_data)
{
    XWindowAttributes attr;
    SylListBox *box;
    Pixmap background;
    static char tile_bits[] = {0x0f, 0x0f, 0x0f, 0x0f, 0xf0, 0xf0, 0xf0, 0xf0};

    if ((box = (SylListBox *)malloc(sizeof(SylListBox))) == NULL)
	goto no_list_box;
    if ((box->keymap = CreateSylKeymap()) == NULL)
        goto no_keymap;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, box))
        goto no_preferences;
    box->sidemargin = (box->fontset.width + 2) / 2 + FOCUS_FRAME_WIDTH;
    box->baseline_skip = (2 * box->fontset.descent) + box->fontset.height;
    XGetWindowAttributes(disp, parent, &attr);
    box->parent_width = attr.width;
    box->parent_height = attr.height;
    box->width = attr.width;
    box->height = box->baseline_skip;
    box->depth = attr.depth;
    box->target = XCreateSimpleWindow(disp, parent, 0, 0,
	attr.width, attr.height, 0, box->pixel[0], box->pixel[1]);
    background = XCreatePixmapFromBitmapData(disp, box->target,
	tile_bits, 8, 8, box->pixel[2], box->pixel[3], attr.depth);
    XSetWindowBackgroundPixmap(disp, box->target, background);
    XFreePixmap(disp, background);
    XSelectInput(disp, box->target, ExposureMask | StructureNotifyMask
	| FocusChangeMask | KeyPressMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, box->target);
    XMapRaised(disp, box->target);
    box->window = XCreateSimpleWindow(disp, box->target, 0, 0,
	attr.width, box->baseline_skip, 0, box->pixel[0], box->pixel[1]);
    XSetWindowBackgroundPixmap(disp, box->window, ParentRelative);
    XMapRaised(disp, box->window);
    box->next_field = None;
    box->prev_field = None;
    if ((box->vsb = ReserveSylVScrollbar(disp, box->target,
        "verticalScrollbar", 0, 1, box->baseline_skip,
	scrollcallback, adjustcallback, (void *)box)) == NULL)
        goto no_vscrollbar;
    box->mark_check = CreateMark(disp, box->target, box->fontset.id,
        box->fontset.width, box->fontset.height, CheckMarkStack);
    box->gc = XCreateGC(disp, box->window, 0, 0);
    XSetGraphicsExposures(disp, box->gc, False);
    box->pixmap_queue = CreateSylPixmapQueueSet(disp, parent,
	attr.width, box->baseline_skip); /* pixmap queuing */
    box->context_id = XUniqueContext(); /* using ContextManager */
    box->disp = disp;
    box->parent = parent;
    box->window_offset_x = 0;
    box->window_offset_y = 0;
    box->item = NULL;
    box->top = NULL;
    box->last = NULL;
    box->n_items = 0;
    box->marked = NULL;
    box->to_be_marked = NULL;
    box->selected = NULL;
    box->cursor = NULL;
    box->item_added = False;
    box->focus = False;
    box->callback_func = callback_func;
    box->callback_data = callback_data;
    return (box);

no_vscrollbar :
    XDestroyWindow(disp, box->window);
    XDestroyWindow(disp, box->target);
no_preferences:
    FreeSylKeymap(box->keymap);
no_keymap:
    free(box);
no_list_box:
    return (NULL);
}

static SylListBoxItem *
CreateSylListBoxItem(SylListBox *box, char *mbs)
{
    SylListBoxItem *item;

    if ((item = (SylListBoxItem *)malloc(sizeof(SylListBoxItem))) == NULL)
	goto no_item;
    if ((item->mbs = strdup(mbs)) == NULL)
	goto no_mbs;
    item->len = strlen(mbs);
    item->window = XCreateSimpleWindow(box->disp, box->window,
       0, box->baseline_skip * box->n_items, box->width, box->baseline_skip,
	0, box->pixel[0], box->pixel[1]);
    XSelectInput(box->disp, item->window, ExposureMask | VisibilityChangeMask
        | ButtonPressMask | OwnerGrabButtonMask | ButtonReleaseMask
	| EnterWindowMask | LeaveWindowMask);
    XSetWindowBackgroundPixmap(box->disp, box->window, None);
    XMapRaised(box->disp, item->window);
    item->pixmap = None;
    item->width = 0;
    item->height = 0;
    item->exposable = False; /* NiceExpose */
    item->num = box->n_items;
    item->next = NULL;
    if (XSaveContext(box->disp, item->window, box->context_id, (XPointer)item))
	goto no_context; /* using ContextManager */
    return (item);

no_context:
    XDestroyWindow(box->disp, item->window);
    free(item->mbs);
no_mbs:
    free(item);
no_item:
    return (NULL);
}

static void
FreeSylListBoxItem(SylListBox *box, SylListBoxItem *item)
{
    (void)XDeleteContext(box->disp, item->window,
	 box->context_id); /* using ContextManager */
    XDestroyWindow(box->disp, item->window);
    if (item->pixmap != None) {
	PutSylPixmapQueueSet(box->pixmap_queue, item->pixmap,
			     item->width, item->height); /* pixmap queuing */
    }
    free(item->mbs);
    free(item);
}

void
FreeSylListBox(SylListBox *box)
{
    SylListBoxItem *item, *next;

    if (box->item != NULL)
	free(box->item);
    for (item = box->top; item != NULL; item = next) {
	next = item->next;
	FreeSylListBoxItem(box, item);
    }
    PutbackSylVScrollbar(box->vsb);
    FreeSylPixmapQueueSet(box->pixmap_queue); /* pixmap queuing */
    XFreeGC(box->disp, box->gc);
    XFreePixmap(box->disp, box->mark_check);
    XDestroyWindow(box->disp, box->window);
    XDestroyWindow(box->disp, box->target);
    FreeSylKeymap(box->keymap);
    free(box);
}

int
AddToSylListBox(SylListBox *box, char *str)
{
    SylListBoxItem *item;

    if ((item = CreateSylListBoxItem(box, str)) == NULL)
	return (1);
    if (box->top == NULL)
	box->top = item;
    else
	box->last->next = item;
    box->last = item;

    ++(box->n_items);
    box->item_added = True;
    return (0);
}

static void
FreeBuffer(SylListBox *box, SylListBoxItem *item)
{
    if (item->pixmap == None)
	return;
    (void)PutSylPixmapQueueSet(box->pixmap_queue, item->pixmap,
			       item->width, item->height); /* pixmap queuing */
    item->pixmap = None;
}

static void
CreateBuffer(SylListBox *box, SylListBoxItem *item)
{
    if (box->width != item->width) {
	XResizeWindow(box->disp, item->window,
		      box->width, box->baseline_skip); 
	FreeBuffer(box, item);
    }
    if (item->pixmap != None)
	return;
    /* begin: pixmap queuing */
    item->pixmap = GetSylPixmapQueueSet(box->pixmap_queue);
    item->width = box->pixmap_queue->width;
    item->height = box->pixmap_queue->height;
    /* end: pixmap queuing */

    item->exposable = False; /* NiceExpose */
}

static void
UpdateBuffer(SylListBox *box, SylListBoxItem *p)
{
    UpdateItem(p);
    if (box->to_be_marked == box->marked)
	box->marked = NULL;
}

static void
AdjustSize(SylListBox *box)
{
    SylListBoxItem *item;
    int n, m, y, h;

    h = (box->parent_height <= box->baseline_skip) ? box->parent_height
	: box->parent_height / box->baseline_skip * box->baseline_skip;
    y = (box->parent_height - h) / 2;
    if (h >= box->height || box->n_items <= 1) {
	XUnmapWindow(box->disp, box->vsb->bar);
	box->width = box->parent_width;
    }
    else {
	XMapRaised(box->disp, box->vsb->bar);
	box->width = box->parent_width - SYL_VSB_SEP - SYL_VSB_WIDTH;
    }
    XMoveResizeWindow(box->disp, box->target, 0, y, box->width, h);
    XResizeWindow(box->disp, box->window, box->width, box->height); 
    ReconfigureSylPixmapQueueSet(box->pixmap_queue, box->width,
				 box->baseline_skip); /* pixmap queuing */
    if (box->n_items == 0)
	XUnmapWindow(box->disp, box->window);
    else
	XMapWindow(box->disp, box->window);
    if (box->cursor != NULL) {
	n = box->window_offset_y / box->baseline_skip;
	m = n + max(1, box->parent_height / box->baseline_skip) - 1;
	if (num(box->cursor) < n)
	    box->cursor = Item(box, n);
	else if (num(box->cursor) > m)
	    box->cursor = Item(box, m);
    }
    for (item = box->top; item != NULL; item = item->next) {
	FreeBuffer(box, item);
	CreateBuffer(box, item);
    }
}
	
static void
DrawDummyFocusBox(SylListBox *box)
{
    XWindowAttributes attr;

    if (box->focus == False || box->n_items > 0)
	return;
    XGetWindowAttributes(box->disp, box->target, &attr);
    XDrawRectangle(box->disp, box->target, box->gc, 0, 0,
		   attr.width - 1, attr.height - 1);
}
    
static void
DrawItem(SylListBox *box, SylListBoxItem *item, unsigned int bg_pixel)
{
    XSetForeground(box->disp, box->gc, bg_pixel);
    XFillRectangle(box->disp, item->pixmap, box->gc, 0, 0,
	box->width, box->baseline_skip);
    if (item == box->selected) {
	XSetForeground(box->disp, box->gc, box->pixel[5]);
	XSetBackground(box->disp, box->gc, bg_pixel);
	XCopyPlane(box->disp, box->mark_check, item->pixmap, box->gc,
	    0, 0, box->fontset.width, box->fontset.height,
	    box->sidemargin, box->fontset.descent, 1);
    }
    XSetForeground(box->disp, box->gc, box->pixel[0]);
    XmbDrawString(box->disp, item->pixmap, box->fontset.id, box->gc,
	box->sidemargin + box->fontset.width * 2, box->fontset.height,
        item->mbs, item->len);
    if (item == box->cursor && box->focus == True) {
	XSetForeground(box->disp, box->gc, box->pixel[0]);
	XDrawRectangle(box->disp, item->pixmap, box->gc, 0, 0,
		       box->width - 1, box->baseline_skip - 1);
    }
}

static int
MarkSylListBox(SylListBox *box)
{
    SylListBoxItem *item;

    if (box->to_be_marked == box->marked)
	return (0);
    if (box->marked != NULL && box->marked->pixmap != None) {
	item = box->marked;
	DrawItem(box, item, box->pixel[1]);
	XCopyArea(box->disp, item->pixmap, item->window, box->gc, 0, 0,
		  box->width, box->baseline_skip, 0, 0);
    }
    box->marked = box->to_be_marked;
    if (box->marked != NULL && box->marked->pixmap != None) {
	item = box->marked;
	DrawItem(box, item, box->pixel[4]);
	XCopyArea(box->disp, item->pixmap, item->window, box->gc, 0, 0,
		  box->width, box->baseline_skip, 0, 0);
    }
    return (1);
}

static int
ExposeSylListBox(SylListBox *box) /* NiceExpose */
{
    int n, m;
    SylListBoxItem *item;

    n = box->window_offset_y / box->baseline_skip;
    m = n + box->parent_height / box->baseline_skip;
    for (item = Item(box, n); item != NULL && n <= m; ++n, item = item->next) {
	if (item->pixmap != None && item->exposable == False) {
	    DrawItem(box, item, box->pixel[1]);
	    XCopyArea(box->disp, item->pixmap, item->window, box->gc,
		      0, 0, box->width, box->baseline_skip, 0, 0);
	    item->exposable = True;
	    return (1);
	}
    }
    return (0);
}

void
SetFieldOrderSylListBox(SylListBox *box, Window prev, Window next)
{
    box->prev_field = prev;
    box->next_field = next;
}

int
NiceSylListBox(SylListBox *box)
{
    XFlush(box->disp);

    if (box->item_added == True) {
	if (box->item != NULL)
	    free(box->item);
	if ((box->item = (SylListBoxItem **)malloc(sizeof(SylListBoxItem *)
						   * box->n_items)) != NULL) {
	    int k;
	    SylListBoxItem *item;

	    for (k = 0, item = box->top; item != NULL; ++k, item = item->next)
		box->item[k] = item;
	}
	box->height = box->baseline_skip * box->n_items;
	AdjustSize(box);
	RangeSylVScrollbar(box->vsb, box->n_items);
	box->item_added = False;
    }
    return (ExposeSylListBox(box) /* NiceExpose */
	    || MarkSylListBox(box));
}

static SylListBoxItem *
QueryWhichChild(SylListBox *box, Window w) /* using ContextManager */
{
    SylListBoxItem *item;

    if (XFindContext(box->disp, w, box->context_id, (XPointer *)&item))
	return (NULL);
    return (item);
}

void
SendSylListBox(SylListBox *box, XEvent *ev)
{
    SylListBoxItem *p;

    if (SendSylVScrollbar(box->vsb, ev) == 0)
	return;
    switch (ev->type) {
    case VisibilityNotify:
	if ((p = QueryWhichChild(box, ev->xvisibility.window)) == NULL)
	    break;
	if (ev->xvisibility.state == VisibilityFullyObscured)
	    FreeBuffer(box, p);
        else
	    CreateBuffer(box, p);
	break;
    case Expose:
	if (ev->xexpose.window == box->target) {
	    if (ev->xexpose.count == 0)
		DrawDummyFocusBox(box);
	    break;
	}
	if ((p = QueryWhichChild(box, ev->xexpose.window)) == NULL)
	    break;
	if (p->exposable == False)
	    break; /* NiceExpose */
	XCopyArea(box->disp, p->pixmap, p->window, box->gc,
		  ev->xexpose.x, ev->xexpose.y,
		  ev->xexpose.width, ev->xexpose.height,
		  ev->xexpose.x, ev->xexpose.y);
	break;
    case EnterNotify:
	if ((p = QueryWhichChild(box, ev->xcrossing.window)) != NULL)
	    box->to_be_marked = p;
	break;
    case LeaveNotify:
	if ((p = QueryWhichChild(box, ev->xcrossing.window)) != NULL)
	    box->to_be_marked = NULL;
	break;
    case ButtonPress:
	if ((p = QueryWhichChild(box, ev->xbutton.window)) == NULL)
	    break;
        if (box->focus == True)
	    UpdateBuffer(box, box->cursor);
	else
	    XSetInputFocus(box->disp, box->target, RevertToParent,
			   ev->xbutton.time);
	box->cursor = p;
        if (ev->xbutton.button == 1) {
            XGrabPointer(box->disp, p->window, False,
                ButtonReleaseMask | EnterWindowMask | LeaveWindowMask,
                GrabModeAsync, GrabModeSync, DefaultRootWindow(box->disp),
                None, ev->xbutton.time);
	    box->grabbed = True;
	}
	break;
    case ButtonRelease:
	if ((p = QueryWhichChild(box, ev->xbutton.window)) == NULL
	    || box->grabbed != True)
            break;
        XUngrabPointer(box->disp, ev->xbutton.time);
        box->grabbed = False;
	if (ev->xbutton.button == 1 && box->marked == p) {
	    if (box->callback_func != NULL)
		box->callback_func(box->callback_data, p->mbs);
	    UpdateItem(box->selected);
	    box->selected = p;
	    UpdateBuffer(box, box->selected);
	}
        break;
    case FocusIn:
	if (ev->xfocus.window != box->target
	    || ev->xfocus.detail == NotifyPointer)
            break;
        box->focus = True;
	if (box->cursor == NULL)
	    box->cursor = Item(box, box->window_offset_y / box->baseline_skip);
	UpdateBuffer(box, box->cursor);
	if (box->n_items == 0)
	    DrawDummyFocusBox(box);
        break;
    case FocusOut:
	if (ev->xfocus.window != box->target
	    || ev->xfocus.detail == NotifyPointer)
            break;
        box->focus = False;
	UpdateBuffer(box, box->cursor);
	if (box->n_items == 0)
	    XClearWindow(box->disp, box->target);
        break;
    case KeyPress:
        if (ev->xkey.window != box->target || box->focus == False)
            break;
	LookupPressedKey(box, &(ev->xkey));
        break;
   case ConfigureNotify:
        if (ev->xconfigure.window != box->parent)
            break;
	box->parent_width = ev->xconfigure.width;
	box->parent_height = ev->xconfigure.height;
	AdjustSize(box);
        break;
    }
}

void
ClearSylListBox(SylListBox *box)
{
    SylListBoxItem *item, *next;

    if (box->item != NULL) {
	free(box->item);
	box->item = NULL;
    }
    for (item = box->top; item != NULL; item = next) {
	next = item->next;
	FreeSylListBoxItem(box, item);
    }
    box->window_offset_x = 0;
    box->window_offset_y = 0;
    box->top = NULL;
    box->last = NULL;
    box->n_items = 0;
    box->marked = NULL;
    box->to_be_marked = NULL;
    box->selected = NULL;
    box->cursor = NULL;
    box->item_added = False;
    AdjustSize(box);
    JumpSylVScrollbar(box->vsb, 0);
}
