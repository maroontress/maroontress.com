/*
        Selection.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>

static void
SetTextPropertyAndSendReply(XSelectionRequestEvent *req, wchar_t *wcs,
			    XICCEncodingStyle style, XEvent *reply)
{
    XTextProperty t;

    if (wcs == NULL
	|| XwcTextListToTextProperty(req->display, &wcs, 1, style, &t) < 0) {
	reply->xselection.property = None;
	XSendEvent(req->display, req->requestor, False, 0, reply);
	return;
    }
    XSetTextProperty(req->display, req->requestor, &t, req->property);
    XFree(t.value);
    reply->xselection.property = req->property;
    XSendEvent(req->display, req->requestor, False, 0, reply);
}

void
SylRespondSelectionRequestWithWCString(XSelectionRequestEvent *req,
				       wchar_t *wcs, Time stamp,
				       Atom targets_atom,
				       Atom timestamp_atom,
				       Atom string_atom,
				       Atom text_atom,
				       Atom compound_text_atom)
{
    XEvent reply;
    Atom targets[5];

    reply.xselection.type = SelectionNotify;
    reply.xselection.requestor = req->requestor;
    reply.xselection.selection = req->selection;
    reply.xselection.target = req->target;
    reply.xselection.time = req->time;
    if (req->target == targets_atom) {
	targets[0] = targets_atom;
	targets[1] = timestamp_atom;
	targets[2] = string_atom;
	targets[3] = text_atom;
	targets[4] = compound_text_atom;
	XChangeProperty(req->display, req->requestor, req->property,
	    XA_ATOM, 32, PropModeReplace, (void *)targets, 5);
	reply.xselection.property = req->property;
	XSendEvent(req->display, req->requestor, False, 0, &reply);
    }
    else if (req->target == timestamp_atom) {
	XChangeProperty(req->display, req->requestor, req->property,
	    XA_INTEGER, 32, PropModeReplace, (void *)&stamp, 1);
	reply.xselection.property = req->property;
	XSendEvent(req->display, req->requestor, False, 0, &reply);
    }
    else if (req->target == text_atom)
	SetTextPropertyAndSendReply(req, wcs, XStdICCTextStyle, &reply);
    else if (req->target == compound_text_atom)
	SetTextPropertyAndSendReply(req, wcs, XCompoundTextStyle, &reply);
    else if (req->target == string_atom)
	SetTextPropertyAndSendReply(req, wcs, XStringStyle, &reply);
    else {
	reply.xselection.property = None;
	XSendEvent(req->display, req->requestor, False, 0, &reply);
    }
}
