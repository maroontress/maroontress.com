#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdlib.h>

#include "PixmapQueue.h"

SylPixmapQueueSet *
CreateSylPixmapQueueSet(Display *disp, Window window, int width, int height)
{
    SylPixmapQueueSet *pqs;
    XWindowAttributes attr;

    if ((pqs = (SylPixmapQueueSet *)malloc(sizeof(SylPixmapQueueSet))) == NULL)
	return (NULL);
    XGetWindowAttributes(disp, window, &attr);
    pqs->disp = disp;
    pqs->window = window;
    pqs->width = width;
    pqs->height = height;
    pqs->depth = attr.depth;
    pqs->using_top = NULL;
    pqs->empty_top = NULL;
    return (pqs);
}

/*
  $B3NJ]:Q%-%e!<$N%T%/%9%^%C%W$r$9$Y$F%j%j!<%9!#(B
  $B%-%e!<$O$9$Y$FL$;HMQ%-%e!<$K0\$k!#(B
*/
static void
ReleaseAllPixmap(SylPixmapQueueSet *pqs)
{
    SylPixmapQueue *ptr, *next;

    for (ptr = pqs->using_top; ptr != NULL; ptr = next) {
	next = ptr->next;

	XFreePixmap(pqs->disp, ptr->pixmap);
	ptr->pixmap = None;

	ptr->next = pqs->empty_top;
	pqs->empty_top = ptr;
    }
    pqs->using_top = NULL;
}

void
ReconfigureSylPixmapQueueSet(SylPixmapQueueSet *pqs, int width, int height)
{
    if (width == pqs->width && height == pqs->height)
	return;
    ReleaseAllPixmap(pqs);
    pqs->width = width;
    pqs->height = height;
}

/*
  $B3NJ]:Q%-%e!<$N%T%/%9%^%C%W$r$9$Y$F%j%j!<%9!"%-%e!<$b$9$Y$F%j%j!<%9!#(B
*/
void
FreeSylPixmapQueueSet(SylPixmapQueueSet *pqs)
{
    SylPixmapQueue *ptr, *next;

    ReleaseAllPixmap(pqs);
    for (ptr = pqs->empty_top; ptr != NULL; ptr = next) {
	next = ptr->next;
	free(ptr);
    }
    free(pqs);
}

static SylPixmapQueue *
CreatePixmapQueue()
{
    SylPixmapQueue *pq;
    
    if ((pq = (SylPixmapQueue *)malloc(sizeof(SylPixmapQueue))) == NULL)
	return (NULL);
    pq->pixmap = None;
    pq->next = NULL;
    return (pq);
}

int
PutSylPixmapQueueSet(SylPixmapQueueSet *pqs, Pixmap p, int width, int height)
{
    SylPixmapQueue *pq;

    if (pqs->width != width || pqs->height != height) {
	XFreePixmap(pqs->disp, p);
	return (1);
    }
    else if ((pq = pqs->empty_top) != NULL) {
	pqs->empty_top = pq->next;
    }
    else if ((pq = CreatePixmapQueue()) == NULL) {
	XFreePixmap(pqs->disp, p);
	return (-1);
    }
    pq->pixmap = p;
    pq->next = pqs->using_top;
    pqs->using_top = pq;
    return (0);
}

Pixmap
GetSylPixmapQueueSet(SylPixmapQueueSet *pqs)
{
    Pixmap p;
    SylPixmapQueue *pq;

    if (pqs->using_top == NULL) {
	return (XCreatePixmap(pqs->disp, pqs->window, pqs->width,
			      pqs->height, pqs->depth));
    }
    pq = pqs->using_top;
    pqs->using_top = pq->next;

    p = pq->pixmap;
    pq->pixmap = None;
    pq->next = pqs->empty_top;
    pqs->empty_top = pq;

    return (p);
}
