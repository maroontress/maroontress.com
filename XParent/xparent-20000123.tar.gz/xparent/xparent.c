#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/Xlocale.h>
#ifdef USE_SHAPE
#include <X11/extensions/shape.h>
#endif
#include <fcntl.h>
#include <sys/ioctl.h>
#include <machine/apm_bios.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Resource.h"
#include "Layout.h"
#include "VScrollbar.h"
#include "WCString.h"
#include "Text.h"
#include "Button.h"
#include "TextLine.h"
#include "TextArea.h"
#include "PixmapQueue.h"
#include "ListBox.h"
#include "Plate.h"
#include "Null.h"
#include "Control.h"
#include "property.h"

static int MainPower = True;

#define THIS_CLASS "XParent"
#define TOPLEVEL_DEFAULT_GEOMETRY "640x24"

#include "xparent.color"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"graph.fontset", "Graph.Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

#define DEFAULT_WM_NAME "Transparent"
static SylSetting
    Geometry = {"geometry", "Geometry", "", NULL},
    LayoutMode = {"layoutMode", "LayoutMode", "thin", NULL},
    Headline = {"headline", "Headline", DEFAULT_WM_NAME, NULL};

static SylSetting
    MSG_Charging = {"messageCharging", "MessageCharging", "CHARGING", NULL},
    MSG_Unknown = {"messageUnknown", "MessageUnknown", "UNKNOWN", NULL},
    MSG_Disabled = {"messageDisabled", "MessageDisabled", "DISABLED", NULL},
    MSG_Empty = {"messageEmpty", "MessageEmpty", "EMPTY", NULL},
    MSG_NotFound = {"messageNotFound", "MessageNotFound", "NOT FOUND", NULL};

typedef struct sockaddr SockAddr;
typedef struct apm_info APMInfo;

enum {
    ACLINE_OFF_LINE,
    ACLINE_ON_LINE,
    ACLINE_UNKNOWN
} ACLineStatus;

enum {
    BATTERY_HIGH,
    BATTERY_LOW,
    BATTERY_CRITICAL,
    BATTERY_CHARGING,
    BATTERY_UNKNOWN
} BatteryStatus;

#define CAPACITY_UNKNOWN 101

static void
GetAPMInfo(int fd, APMInfo *info)
{
    if (ioctl(fd, APMIO_GETINFO, info) < 0) {
	info->ai_acline = ACLINE_UNKNOWN;
	info->ai_batt_stat = BATTERY_UNKNOWN;
	info->ai_batt_life = CAPACITY_UNKNOWN;
#ifdef PAO
	info->ai_batt_time = -1;
#endif
	return;
    }
    if (info->ai_acline >= ACLINE_UNKNOWN)
	info->ai_acline = ACLINE_UNKNOWN;
    if (info->ai_batt_stat >= BATTERY_UNKNOWN)
	info->ai_batt_stat = BATTERY_UNKNOWN;
    if (info->ai_batt_life >= CAPACITY_UNKNOWN)
	info->ai_batt_life = CAPACITY_UNKNOWN;
#ifdef PAO
    if (info->ai_batt_time < 0)
	info->ai_batt_time = -1;
#endif
}

static XSizeHints
GetToplevelWindowGeometry(Display *disp, char *u_geom, char *d_geom,
		      int *x, int *y, int *w, int *h)
{
    XSizeHints xsize;
    int geom_mask, width, height, gravity;

#if 0
    if (incw > 0 || inch > 0) {
	xsize.width_inc = incw;
	xsize.height_inc = inch;
	xsize.flags |= PResizeInc;
    }
    if (minw > 0 && minh > 0) {
	xsize.min_width = minw;
	xsize.min_height = minh; 
	xsize.flags |= PMinSize;
    }
    if (maxw > 0 && maxh > 0) {
	xsize.max_width = max(maxw, minw);
	xsize.max_height = max(maxh, minh);
	xsize.flags |= PMaxSize;
    }
#endif
    /*
      ICCCM$B$h$j(BXSizeHints$B9=B$BN$N%a%s%P(Bx, y, width, height$B$rL5;k$7$F$$$k!#(B
      xprop$B$G0[>o$JCM$,I=<($5$l$k$N$O(Bxprop$B$NJ}$,(BICCCM$B$rL5;k$7$F$$$k$?$a!#(B
    */
    xsize.flags = 0;
    geom_mask = XWMGeometry(disp, DefaultScreen(disp), u_geom, d_geom, 1,
			    &xsize, x, y ,&width, &height, &gravity);
    if (geom_mask & (XValue | YValue))
	xsize.flags |= USPosition;
    xsize.flags |= (geom_mask & (WidthValue | HeightValue)) ? USSize : PSize;
    if (width && height) {
	*w = width;
	*h = height;
    }
    xsize.win_gravity = gravity;
    xsize.flags |= PWinGravity;
    return (xsize);
}

typedef struct {
    Display *disp;
    Window window;
    unsigned long *pixel;
    SylFontSet fs;
    XSizeHints size_hint;
    int x;
    int y;
    int width;
    int height;
    int graph_width;
    int graph_height;

    APMInfo info;
    SylPlate *acline;
    SylPlate *batt_time;
    SylNull *batt_graph;
    SylPlate *batt_life;

    SylPlate *slot;
    SylTextLine *cardinfo;
    SylButton *attach;
    SylButton *detach;
} XParent;

static void
GetToplevelPreferences(Display *disp, char *name, char *class, XParent *x)
{
    LoadSylColorset(disp, name, class, ColorSet, x->pixel);
    LoadSylFontset(disp, name, class, FontSet, &x->fs);
    GetSylSetting(disp, name, class, &Geometry);
    GetSylSetting(disp, name, class, &LayoutMode);
    GetSylSetting(disp, name, class, &Headline);
    GetSylSetting(disp, name, class, &MSG_Unknown);
    GetSylSetting(disp, name, class, &MSG_Charging);
    GetSylSetting(disp, name, class, &MSG_Disabled);
    GetSylSetting(disp, name, class, &MSG_Empty);
    GetSylSetting(disp, name, class, &MSG_NotFound);
}

static void
GetCardInfo(int crd, XParent *x)
{
    struct sockaddr_un where;
    char buf[256], *all[6], **str, *ptr, dup[256];
    int n = sizeof(where), len = sizeof(buf) - 1, m;

    if ((len = recvfrom(crd, buf, len, 0, (SockAddr *)&where, &n)) < 0)
	perror("recvfrom");
    if (len <= 0)
	return;
    ((char *)&where)[where.sun_len] = 0;
    buf[len] = 0;

    for (m = 0, str = all, ptr = buf; (*str = strsep(&ptr, "~")) != NULL; ++m)
	++str;
    if (*all[4] == '1') {
	DisableSylButton(x->attach);
	EnableSylButton(x->detach);
	sprintf(dup, "%s %s (%s)", all[1], all[2], all[3]);
	SetMBStringSylTextLine(x->cardinfo, dup);
    }
    else if (*all[4] == '2') {
	EnableSylButton(x->attach);
	DisableSylButton(x->detach);
	SetMBStringSylTextLine(x->cardinfo, MSG_Disabled.spec);
    }
    else if (*all[4] == '0') {
	DisableSylButton(x->attach);	
	DisableSylButton(x->detach);
	SetMBStringSylTextLine(x->cardinfo, MSG_Empty.spec);
    }
    else {
	SetMBStringSylTextLine(x->cardinfo, "");
    }
}

static void
DrawBattGraph(XParent *x)
{
    int total, sp, w, m, n, h;
    Drawable d = x->batt_graph->parent;
    GC gc;
    APMInfo *info = &x->info;
    
    sp = XmbTextEscapement(x->fs.id, " ", 1);
    if ((total = x->graph_width / (sp + 1)) <= 0)
	total = 1;
    h = ((x->graph_height - x->fs.height) / 2) + x->fs.ascent;
    
    gc  = XCreateGC(x->disp, d, 0, 0);
    if (info->ai_batt_life != CAPACITY_UNKNOWN) {
	w = 0;
	m = info->ai_batt_life * total / 100;
	XSetForeground(x->disp, gc, x->pixel[MediumGray]);
	XSetBackground(x->disp, gc, x->pixel[Illuminated]);
	for (n = 0; n <= m; ++n) {
	    XmbDrawImageString(x->disp, d, x->fs.id, gc, w, h, " ", 1);
	    w += sp + 1;
	}
	XSetForeground(x->disp, gc, x->pixel[MediumGray]);
	XSetBackground(x->disp, gc, x->pixel[Darkened]);	
	for (n = m + 1; n < total; ++n) {
	    XmbDrawImageString(x->disp, d, x->fs.id, gc, w, h, " ", 1);
	    w += sp + 1;
	}
    }
    XFreeGC(x->disp, gc);
}

static void
DrawAPMInfo(XParent *x)
{
    static char *acline[] = {"=D-x-", "=D---", "=D-?-"};
    char *ptr, buf[32];
    int hour, min, sec;
    APMInfo *info = &x->info;

    ptr = acline[info->ai_acline];
    UpdateSylPlateFromMBString(x->acline, ptr);

    if (info->ai_batt_stat == BATTERY_CHARGING) {
	ptr = MSG_Charging.spec;
    }
#ifdef PAO
    else if (info->ai_batt_time < 0) {
	ptr = MSG_Unknown.spec;
    }
    else {
	hour = info->ai_batt_time / 3600;
	min = (info->ai_batt_time % 3600) / 60;
	sec = info->ai_batt_time % 60;
	sprintf(buf, "%4d:%02d:%02d", hour, min, sec);
	ptr = buf;
    } 
#else
    else {
	ptr = MSG_Unknown.spec;	
    }
#endif
    UpdateSylPlateFromMBString(x->batt_time, ptr);
 
    if (info->ai_batt_life != CAPACITY_UNKNOWN) {
	sprintf(buf, "%3d%%", info->ai_batt_life);
	ptr = buf;
    }
    else {
	ptr = "???%";
    }
    UpdateSylPlateFromMBString(x->batt_life, ptr);
    DrawBattGraph(x);
}

static void
UpdateAPMInfo(XParent *x)
{
    DrawAPMInfo(x);
}

#ifdef USE_SHAPE
static void
UpdateShapeMask(XParent *x)
{
    Pixmap mask;
    GC gc;
    Window FindSylToplevelWindow(Display *, Window, int *, int *);
    int total, sp, w, n, h;
    APMInfo *info = &x->info;
    SylNull *g = x->batt_graph;
    XWindowAttributes attr;
    
    XGetWindowAttributes(g->disp, g->parent, &attr);
    mask = XCreatePixmap(g->disp, g->parent, attr.width, attr.height, 1);
    gc = XCreateGC(g->disp, mask, 0, 0);

    sp = XmbTextEscapement(x->fs.id, " ", 1);
    if ((total = x->graph_width / (sp + 1)) <= 0)
	total = 1;
    h = ((x->graph_height - x->fs.height) / 2) + x->fs.ascent;

    XSetForeground(x->disp, gc, 1);
    XFillRectangle(x->disp, mask, gc, 0, 0, attr.width, attr.height);
    if (info->ai_batt_life != CAPACITY_UNKNOWN) {
	w = 0;
	XSetForeground(x->disp, gc, 1);
	XSetBackground(x->disp, gc, 0);
	for (n = 0; n < total; ++n) {
	    XmbDrawImageString(x->disp, mask, x->fs.id, gc, w, h, " ", 1);
	    w += sp + 1;
	}
    }
    XShapeCombineMask(x->disp, x->window, ShapeBounding, attr.x, attr.y,
		      mask, ShapeSubtract);

    XFreeGC(x->disp, gc);
    XFreePixmap(x->disp, mask);
}
#endif

static void
SendToplevel(XParent *x, XEvent *ev)
{
    switch (ev->type) {
    case MappingNotify:
        XRefreshKeyboardMapping(&(ev->xmapping));
        break;
    case Expose:
        if (ev->xexpose.window != x->batt_graph->parent
	    || ev->xexpose.count > 0)
            break;;	
#ifdef USE_SHAPE
	UpdateShapeMask(x);
#endif
	DrawBattGraph(x);
	break;
    case ConfigureNotify:
	if (ev->xconfigure.window != x->batt_graph->parent)
            break;
	if (x->graph_width == ev->xconfigure.width
	    && x->graph_height == ev->xconfigure.height)
	    break;
	x->graph_width = ev->xconfigure.width;
	x->graph_height = ev->xconfigure.height;
#ifdef USE_SHAPE
	UpdateShapeMask(x);
#endif
	DrawBattGraph(x);
	break;
    }
}

static void
AttachCB(void *cb_data)
{
    int crd = *(int *)cb_data;
#if 1
    send(crd, "P\n", 2, 0);
#else
    struct sockaddr_un dst = {0, AF_UNIX, "/var/tmp/.pccardd"};
    
    sendto(crd, "P\n", 2, 0, (SockAddr *)&dst, SUN_LEN(&dst));
#endif
}

static void
DetachCB(void *cb_data)
{
    int crd = *(int *)cb_data;
#if 1
    send(crd, "Q\n", 2, 0);
#else
    struct sockaddr_un dst = {0, AF_UNIX, "/var/tmp/.pccardd"};
    
    sendto(crd, "Q\n", 2, 0, (SockAddr *)&dst, SUN_LEN(&dst));
#endif
}

static void
Terminate(int sig)
{
    sig = 0;
    MainPower = False;
}

static char *BoundSocketName = NULL;
static void
FinalizeBoundSocket(void)
{
    if (BoundSocketName != NULL)
	unlink(BoundSocketName);
}

int
main(int ac, char **av)
{
    int n, apm, crd, xds, fds;
    XParent x;
    XEvent ev;
    XWindowAttributes attr;
    XrmDatabase xrdb;
    fd_set readfds;
    struct timeval interval = {10L, 0L};
    SylControlManager *mgr;
    struct sockaddr_un src = {0, AF_UNIX, "/tmp/.xparent"};
    struct sockaddr_un dst = {0, AF_UNIX, "/var/tmp/.pccardd"};
    
    /* initialization for toolkit */
    signal(SIGHUP, Terminate);
    signal(SIGINT, Terminate);
    signal(SIGTERM, Terminate);
    if ((x.disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    XrmInitialize();
    xrdb = SylMergedResourceDatabase(x.disp);
    if ((x.pixel = CreateSylColorset(ColorSet)) == NULL) {
        fprintf(stderr, "%s: cannot create colorset.\n", av[0]);
        exit(1);
    }
    GetToplevelPreferences(x.disp, "xparent", THIS_CLASS, &x);
    x.size_hint = GetToplevelWindowGeometry(x.disp, Geometry.spec,
	TOPLEVEL_DEFAULT_GEOMETRY, &x.x, &x.y, &x.width, &x.height);
    x.window = XCreateSimpleWindow(x.disp, DefaultRootWindow(x.disp), x.x, x.y,
	x.width, x.height, 0, x.pixel[Foreground], x.pixel[MediumGray]);
    SetProperties(x.disp, x.window, Headline.spec, "xparent", THIS_CLASS,
	ac, av, &x.size_hint, None, None, None);
    XSelectInput(x.disp, x.window, StructureNotifyMask);

    if ((mgr = CreateSylControlManager(x.disp, x.window)) == NULL) {
        fprintf(stderr, "%s: cannot create SylControlManager.\n", av[0]);
        exit(1);
    }
    x.acline = CreateSylControlOfSylPlate(mgr, "acline", 0);
    x.batt_time = CreateSylControlOfSylPlate(mgr, "batteryTime", 0);
    x.batt_graph = CreateSylControlOfSylNull(mgr, "batteryGraph",
					     0, x.fs.height, 0, x.fs.height);
    x.batt_life = CreateSylControlOfSylPlate(mgr, "batteryLife", 0);
    x.slot = CreateSylControlOfSylPlate(mgr, "slot", 0);
    x.cardinfo = CreateSylControlOfSylTextLine(mgr, "cardInfo", NULL);
    x.attach = CreateSylControlOfSylButton(mgr, "cardAttach", AttachCB, &crd);
    x.detach = CreateSylControlOfSylButton(mgr, "cardDetach", DetachCB, &crd);
    if (x.acline == NULL || x.batt_time == NULL || x.batt_graph == NULL
	|| x.batt_life == NULL || x.slot == NULL || x.cardinfo == NULL
	|| x.attach == NULL || x.detach == NULL) {
        fprintf(stderr, "%s: cannot create SylControl.\n", av[0]);
        exit(1);
    }

    /* hacking batt_graph */
    XGetWindowAttributes(x.batt_graph->disp, x.batt_graph->parent, &attr);
    x.graph_width = attr.width;
    x.graph_height = attr.height;
    XSelectInput(x.batt_graph->disp, x.batt_graph->parent,
		 StructureNotifyMask | ExposureMask); 
    XMapRaised(x.batt_graph->disp, x.batt_graph->parent);
 
    /* specific initialization */
    if ((apm = open("/dev/apm", O_RDWR)) < 0) {
	perror("/dev/apm");
	exit(1);
    }
    if ((crd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
	perror("socket");
	exit(1);
    }
#if 1
    if (connect(crd, (SockAddr *)&dst, SUN_LEN(&dst)) < 0) {
	perror("connect");
	exit(1);
    }
#endif
    if (bind(crd, (SockAddr *)&src, SUN_LEN(&src)) < 0) {
	perror("bind");
	exit(1);
    }
    BoundSocketName = src.sun_path;
    atexit(FinalizeBoundSocket);
    xds = ConnectionNumber(x.disp);
    fds = ((xds > crd) ? xds : crd) + 1;
#if 1
    send(crd, "N0\n", 3, 0);
#else
    sendto(crd, "N0\n", 3, 0, (SockAddr *)&dst, SUN_LEN(&dst));
#endif
    GetAPMInfo(apm, &x.info); 
    DrawAPMInfo(&x);
    SetMBStringSylTextLine(x.cardinfo, MSG_NotFound.spec);
    DisableSylButton(x.attach);	
    DisableSylButton(x.detach);

    /* layout definition */
    if (strcmp(LayoutMode.spec, "thin") == 0) {
	SetOrderSylLayoutManager(mgr->layout, SylHLayout(
	    SylPaneOfSylControlManager(mgr, x.acline->window),
	    SylPaneOfSylControlManager(mgr, x.batt_time->window),
	    SylPaneOfSylControlManager(mgr, x.batt_graph->parent),
	    SylPaneOfSylControlManager(mgr, x.batt_life->window),
	    SylPaneOfSylControlManager(mgr, x.slot->window),
	    SylPaneOfSylControlManager(mgr, x.cardinfo->window),
	    SylPaneOfSylControlManager(mgr, x.attach->window),
	    SylPaneOfSylControlManager(mgr, x.detach->window),
	    NULL));
    }
    else {
	SetOrderSylLayoutManager(mgr->layout, SylVLayout(
	    SylVFill(),
	    SylHLayout(
		SylPaneOfSylControlManager(mgr, x.acline->window),
		SylPaneOfSylControlManager(mgr, x.batt_time->window),
		SylPaneOfSylControlManager(mgr, x.batt_graph->parent),
		SylPaneOfSylControlManager(mgr, x.batt_life->window),
		NULL),
	    SylVFill(),
	    SylHLayout(
		SylPaneOfSylControlManager(mgr, x.slot->window),
		SylPaneOfSylControlManager(mgr, x.cardinfo->window),
		SylPaneOfSylControlManager(mgr, x.attach->window),
		SylPaneOfSylControlManager(mgr, x.detach->window),
		NULL),
	    SylVFill(),
	    NULL));
    }
    
    /* main loop */
    XMapRaised(x.disp, x.window);
    while (MainPower) {
        while (XEventsQueued(x.disp, QueuedAfterReading) == 0
               && NiceSylControlManager(mgr)) {
            ;
	}
        if (XEventsQueued(x.disp, QueuedAfterReading) == 0) {
	    XFlush(x.disp);	
	    FD_ZERO(&readfds);
	    FD_SET(xds, &readfds);	
	    FD_SET(crd, &readfds);	
	    if ((n = select(fds, &readfds, NULL, NULL, &interval)) < 0) {
		if (errno == EINTR && MainPower == False)
		    goto terminate;
	    } 
	    else if (n == 0) { /* time limit expired */
		GetAPMInfo(apm, &x.info);
		UpdateAPMInfo(&x);	 
#if 1
		send(crd, "N0\n", 3, 0);
#else
		sendto(crd, "N0\n", 3, 0, (SockAddr *)&dst, SUN_LEN(&dst));
#endif
	    }
	    else if (FD_ISSET(crd, &readfds)) {
		GetCardInfo(crd, &x);
	    }
	}
        if (XEventsQueued(x.disp, QueuedAfterReading) == 0)
	    continue;
	XNextEvent(x.disp, &ev); 
	if (IsWMCloseMessage(&ev))
	    break;
        SendSylControlManager(mgr, &ev);
	SendToplevel(&x, &ev);
    }

    /* finalization */
terminate:
    FreeSylControlManager(mgr);
    XrmDestroyDatabase(xrdb);  
    XDestroyWindow(x.disp, x.window);
    XCloseDisplay(x.disp);
    close(crd);
    exit(0);
    return (0);
}
