/*
        Plate.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

typedef struct SylPlate {
    Display *disp;
    Window parent;
    Window window;
    GC gc;
    SylFontSet fontset;
    int width;
    int height;
    int sidemargin;
    unsigned long *pixel;

    SylText *text;
    int gravity;
    int redraw;
} SylPlate;

SylPlate * CreateSylPlate(Display *, Window, char *);
void FreeSylPlate(SylPlate *);
void SendSylPlate(SylPlate *, XEvent *);
int NiceSylPlate(SylPlate *);
void UpdateSylPlateFromMBString(SylPlate *, char *);
