/*
        Plate.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#ifdef USE_SHAPE
#include <X11/extensions/shape.h>
#endif
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "Plate.h"

#define THIS_CLASS "Plate"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

#include "Plate.color"

static SylSetting
    LabelStr = {"label", "Label", "", NULL},
    GravityStr = {"gravity", "Gravity", "Center", NULL};

static int
StringToGravity(char *str)
{
    if (strcmp(str, "NorthWest") == 0)
	return (NorthWestGravity);
    else if (strcmp(str, "North") == 0)
	return (NorthGravity);
    else if (strcmp(str, "NorthEast") == 0)
	return (NorthEastGravity);
    else if (strcmp(str, "West") == 0)
	return (WestGravity);
    else if (strcmp(str, "Center") == 0)
	return (CenterGravity);
    else if (strcmp(str, "East") == 0)
	return (EastGravity);
    else if (strcmp(str, "SouthWest") == 0)
	return (SouthWestGravity);
    else if (strcmp(str, "South") == 0)
	return (SouthGravity);
    else if (strcmp(str, "SouthEast") == 0)
	return (SouthEastGravity);
    else 
	return (CenterGravity);
}

static int
PositionX(int parent_width, int width, int gravity)
{
    switch (gravity) {
    case NorthWestGravity:
    case WestGravity:
    case SouthWestGravity:
	return (0);
    case NorthEastGravity:
    case EastGravity:
    case SouthEastGravity:
	return (parent_width - width);
    }
    return ((parent_width - width) / 2);
}

static int
PositionY(int parent_height, int height, int gravity)
{
    switch (gravity) {
    case NorthWestGravity:
    case NorthGravity:
    case NorthEastGravity:
	return (0);
    case SouthWestGravity:
    case SouthGravity:
    case SouthEastGravity:
	return (parent_height - height);
    }
    return ((parent_height - height) / 2);
}

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return (abs(XwcTextEscapement(fs->id, str, len)));
}

static int
TextEscapementOfSylText(SylFontSet *fs, SylText *txt)
{
    int len, width;
    wchar_t *wcs;
    
    len = LengthOfSylText(txt);
    wcs = CreateWCStringFromSylText(txt, 0, len);
    width = TextEscapement(fs, wcs, len);
    free(wcs);
    return (width);
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  SylPlate *plt)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    GetSylSetting(disp, fq_name, fq_class, &LabelStr);
    if ((plt->text = CreateSylTextFromMBString(LabelStr.spec, True)) == NULL)
        return(1);

    LoadSylColorset(disp, fq_name, fq_class, ColorSet, plt->pixel);
    LoadSylFontset(disp, fq_name, fq_class, FontSet, &plt->fontset);
    GetSylSetting(disp, fq_name, fq_class, &GravityStr);
    plt->gravity = StringToGravity(GravityStr.spec);
    return (0);
}

SylPlate *
CreateSylPlate(Display *disp, Window parent, char *component)
{
    XWindowAttributes attr;
    SylPlate *plt;

    if ((plt = (SylPlate *)malloc(sizeof(SylPlate))) == NULL)
        goto no_plate;
    if ((plt->pixel = CreateSylColorset(ColorSet)) == NULL)
        goto no_colorset;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, plt))
        goto no_preferences;
    plt->sidemargin = 1;
    XGetWindowAttributes(disp, parent, &attr);
    plt->width = TextEscapementOfSylText(&plt->fontset, plt->text)
	+ plt->sidemargin * 2;
    plt->height = plt->fontset.height + plt->sidemargin * 2;
    plt->window = XCreateSimpleWindow(disp, parent,
	PositionX(attr.width, plt->width, plt->gravity),
	PositionY(attr.height, plt->height, plt->gravity),
        plt->width, plt->height,
        0, plt->pixel[Foreground], plt->pixel[MediumGray]);
    XSelectInput(disp, plt->window, ExposureMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, plt->window);
    XMapRaised(disp, plt->window);
    plt->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, plt->gc, False);
    plt->disp = disp;
    plt->parent = parent;
    plt->redraw = False;
    return (plt);

no_preferences:
    FreeSylColorset(plt->pixel);
no_colorset:
    free(plt);
no_plate:
    return (NULL);
}

void
FreeSylPlate(SylPlate *plt)
{
    XDestroyWindow(plt->disp, plt->window);
    XFreeGC(plt->disp, plt->gc);
    XFreeFontSet(plt->disp, plt->fontset.id);
    FreeSylText(plt->text);
    FreeSylColorset(plt->pixel);
    free(plt);
}

#ifdef USE_SHAPE
static void
UpdateShapeMask(SylPlate *plt)
{
    int x = 0, y = 0, dx, dy, len;
    wchar_t *wcs;
    Window w;
    XWindowAttributes attr;
    Pixmap m;
    GC gc;
    Window FindSylToplevelWindow(Display *, Window, int *, int *);

    if ((w = FindSylToplevelWindow(plt->disp, plt->parent, &x, &y)) == None)
	return;
    XGetWindowAttributes(plt->disp, plt->parent, &attr);
    dx = PositionX(attr.width, plt->width, plt->gravity);
    dy = PositionY(attr.height, plt->height, plt->gravity);

    len = LengthOfSylText(plt->text);
    wcs = CreateWCStringFromSylText(plt->text, 0, len);
    m = XCreatePixmap(plt->disp, plt->parent, attr.width, attr.height, 1);
    gc = XCreateGC(plt->disp, m, 0, 0);

    XSetForeground(plt->disp, gc, 1);
    XFillRectangle(plt->disp, m, gc, 0, 0, attr.width, attr.height);
    XSetForeground(plt->disp, gc, 0);
    XwcDrawString(plt->disp, m, plt->fontset.id, gc, dx + plt->sidemargin,
		  dy + plt->fontset.ascent + plt->sidemargin, wcs, len);
    XShapeCombineMask(plt->disp, w, ShapeBounding, x, y, m, ShapeSubtract);

    XSetForeground(plt->disp, gc, 0);
    XFillRectangle(plt->disp, m, gc, 0, 0, attr.width, attr.height);
    XSetForeground(plt->disp, gc, 1);
    XwcDrawString(plt->disp, m, plt->fontset.id, gc, dx + plt->sidemargin,
		  dy + plt->fontset.ascent + plt->sidemargin, wcs, len);
    XShapeCombineMask(plt->disp, w, ShapeBounding, x, y, m, ShapeUnion);

    XFreeGC(plt->disp, gc);
    XFreePixmap(plt->disp, m);
    free(wcs);
}
#endif

void
SendSylPlate(SylPlate *plt, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
        if (ev->xexpose.window != plt->window || ev->xexpose.count > 0)
            break;
	plt->redraw = True;
        break;
    case ConfigureNotify:
        if (ev->xconfigure.window != plt->parent)
            return;
        XMoveWindow(plt->disp, plt->window,
	    PositionX(ev->xconfigure.width, plt->width, plt->gravity),
	    PositionY(ev->xconfigure.height, plt->height, plt->gravity)); 
	plt->redraw = True;
        break;
    }
}

static void
DrawWindow(SylPlate *plt)
{
    int len;
    wchar_t *wcs;

    len = LengthOfSylText(plt->text);
    wcs = CreateWCStringFromSylText(plt->text, 0, len);
    XSetForeground(plt->disp, plt->gc, plt->pixel[Foreground]);
    XSetBackground(plt->disp, plt->gc, plt->pixel[MediumGray]);
    XwcDrawImageString(plt->disp, plt->window, plt->fontset.id, plt->gc,
		       plt->sidemargin, plt->fontset.ascent + plt->sidemargin,
		       wcs, len);
    free(wcs);
}

void
UpdateSylPlateFromMBString(SylPlate *plt, char *mbs)
{
    char *old;

    old = CreateMBStringFromSylText(plt->text, 0, LengthOfSylText(plt->text));
    if (strcmp(old, mbs) != 0) {
	FreeSylText(plt->text);
	plt->text = CreateSylTextFromMBString(mbs, False);
	plt->redraw = True;
    }
    free(old);
}

int
NiceSylPlate(SylPlate *plt)
{
    XFlush(plt->disp);
    if (plt->redraw == True) {
#ifdef USE_SHAPE
	UpdateShapeMask(plt);
#endif
        DrawWindow(plt);
        plt->redraw = False;
    }
    return (0);
}
