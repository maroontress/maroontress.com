#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

typedef struct sockaddr SockAddr;

static void
printData(int s)
{
    struct sockaddr_un where;
    char buf[256], *all[6], **str, *ptr;
    int n = sizeof(where), len = sizeof(buf) - 1, m;

    if ((len = recvfrom(s, buf, len, 0, (SockAddr *)&where, &n)) < 0) {
	perror("recvfrom");
	exit(1);
    }
    ((char *)&where)[where.sun_len] = 0;
    buf[len] = 0;
#if 0
    printf("n: %d\n", n);
    printf("sun_len: %d\n", where.sun_len);
    printf("sun_family: %d\n", where.sun_family);
    printf("sun_path: %s\n", where.sun_path);
    printf("len: %d\n", len);
    printf("%s\n", buf);
#endif

/*
  0~~~~0                      : slot0~~~~empty 
  0~3Com~Megahertz 589E~ep0~1 : slot0~maker~model~dev~enabled
  0~~~~2                      : slot0~~~~disabled
*/
    for (m = 0, str = all, ptr = buf; (*str = strsep(&ptr, "~")) != NULL; ++m)
	++str;
#if 0
    {
	int k;
	for (k = 0; k < m; ++k)
	    printf("%s\n", all[k]);
    }
#endif
    if (*all[4] == '1')
	printf("slot%s: %s %s (%s): on\n", all[0], all[1], all[2], all[3]);
    else if (*all[4] == '2')
	printf("slot%s: off\n", all[0]);
    else if (*all[4] == '0')
	printf("slot%s: empty\n", all[0]);
}

int
main(void)
{
    struct sockaddr_un src = {0, AF_UNIX, "/tmp/.xparent"};
    struct sockaddr_un dst = {0, AF_UNIX, "/var/tmp/.pccardd"};
    char cmd[] = "N0\n";
    int s, len = strlen(cmd);
    
    if ((s = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0) {
	perror("socket");
	exit(1);
    }
    if (bind(s, (SockAddr *)&src, SUN_LEN(&src)) < 0) {
	perror("bind");
	exit(1);
    }
    if (sendto(s, cmd, len, 0, (SockAddr *)&dst, SUN_LEN(&dst)) < 0) {
	perror("sendto");
	exit(1);
    }
    printData(s);
    close(s);
    unlink(src.sun_path);
    exit(0);
    return (0);
}
