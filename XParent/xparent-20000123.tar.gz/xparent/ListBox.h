typedef struct SylListBoxItem {
    char *mbs;
    int len;

    Window window;
    Pixmap pixmap;
    int width;
    int height;
    int exposable; /* NiceExpose */
    int num;
    struct SylListBoxItem *next;
} SylListBoxItem;

typedef struct {
    SylListBoxItem **item;
    SylListBoxItem *top;
    SylListBoxItem *last;
    int n_items;

    Display *disp;
    Window parent;
    Window target;
    Window window;
    Window next_field;
    Window prev_field;
    Pixmap mark_check;
    XContext context_id;
    SylPixmapQueueSet *pixmap_queue;
    GC gc;
    SylFontSet fontset;
    int width;
    int height;
    int depth;
    int parent_width;
    int parent_height;
    int baseline_skip;
    int sidemargin;
    int window_offset_x;
    int window_offset_y;
    unsigned long *pixel;
    SylKeymap **keymap;
    SylVScrollbar *vsb;

    SylListBoxItem *marked;
    SylListBoxItem *to_be_marked;
    SylListBoxItem *selected;
    SylListBoxItem *cursor;
    int item_added;
    int focus;
    int grabbed;
    int sorting;
    void (*callback_func)(void *, char *);
    void *callback_data;
} SylListBox;

SylListBox * CreateSylListBox(Display *, Window, char *,
			      void (*)(void *, char *), void *);
void FreeSylListBox(SylListBox *);
void SendSylListBox(SylListBox *, XEvent *);
int NiceSylListBox(SylListBox *);

void ClearSylListBox(SylListBox *);
int AddToSylListBox(SylListBox *, char *);
void SetFieldOrderSylListBox(SylListBox *, Window, Window);
