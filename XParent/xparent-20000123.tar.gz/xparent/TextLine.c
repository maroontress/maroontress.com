/*
        TextLine.c 1.1 for X11R6 & GNU C Compiler

        Copyright (C) 1998, 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#ifdef USE_SHAPE
#include <X11/extensions/shape.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#ifdef HAS_WCHAR_H
#include <wchar.h>
#endif
#ifdef HAS_WCTYPE_H
#include <wctype.h> /* widec.h$B$,$5$i$K8F$P$l$k(B */
#endif

#include "Selection.h"
#include "Resource.h"
#include "Text.h"
#include "TextLine.h"

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif
#ifndef min
#define min(a, b) (((a) > (b)) ? (b) : (a))
#endif

#define THIS_CLASS "TextLine"
#define DRAGGING_SCROLL_DELAY (20 * 1000) /* microseconds */
#define ON_THE_SPOT

#include "TextLine.color"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
static SylSetting
    Fontset0 = {"fontset", "Fontset", DEFAULT_FONTSET, NULL},
    *FontSet[] = {&Fontset0, NULL};

#define LINE_FOCUS_FRAME_WIDTH 1
/* $B<!$N%^%/%m$OGQ;_$7$?J}$,$$$$$@$m$&$J(B */
#define TextLineTextWidth(t) ((t)->width - ((t)->sidemargin) * 2)

static int
TextEscapement(SylFontSet *fs, wchar_t *str, int len)
{
    return (abs(XwcTextEscapement(fs->id, str, len)));
}

static int
GetPointedCursor(SylTextLine *txl, int w)
{
    int glue = txl->sidemargin, len, len_min, len_max;
    wchar_t *str;

    if (w <= glue)
	return (txl->left);
    if (w > txl->width - glue)
	return (txl->right);
    str = CreateWCStringFromSylText(txl->text, txl->left, txl->size);
    len = txl->size - txl->left;
    w -= glue;
    if (TextEscapement(&txl->fontset, str, len) >= w) {
        len_max = len;
        len_min = 0;
        len = (len_max + len_min) / 2;
        while (len_max - len_min > 1) {
            if (TextEscapement(&txl->fontset, str, len) >= w)
                len_max = len;
            else
                len_min = len;
            len = (len_max + len_min) / 2;
        }
	/*
	   $B%/%j%C%/$7$?J8;z$N:8B&$K(BI$B%S!<%`%]%$%s%?$rG[CV$9$k(B. $B$b$7(BI$B%S!<%`(B
	   $B%]%$%s%?$r1&B&$KG[CV$7$?$$>l9g$O!"<!$N9T$r(Blen = len_max$B$H$9$l$P(B
	   $B$h$$!#(B
	*/
	len = len_min;
    }
    free(str);
    return (txl->left + len);
}

static int
GetOrigin(SylTextLine *txl)
{
    int width, len, n;
    wchar_t *str;

    if ((len = txl->cursor - txl->left) <= 0)
	return (txl->cursor);
    str = CreateWCStringFromSylText(txl->text, txl->left, txl->cursor);
    width = TextLineTextWidth(txl);
    for (n = 0; TextEscapement(&txl->fontset, str + n, len) >= width
	     && txl->left + n < txl->cursor; ++n) {
	--len;
    }
    free(str);
    return (txl->left + n);
}

static int
GetLeftLimit(SylTextLine *txl)
{
    int w, len, len_min, len_max;
    wchar_t *str;

    str = CreateWCStringFromSylText(txl->text, 0, txl->cursor);
    len = 0;
    w = TextLineTextWidth(txl);
    if (TextEscapement(&txl->fontset, str + len, txl->cursor - len) >= w) {
        len_max = txl->cursor;
        len_min = 0;
        len = len_max / 2;
        while (len_max - len_min > 1) {
            if (TextEscapement(&txl->fontset, str + len, txl->cursor - len)
		>= w)
                len_min = len;
            else
                len_max = len;
            len = (len_max + len_min) / 2;
        }
	len = len_max;
    }
    free(str);
    return (len);
}

static int
GetRightLimit(SylTextLine *txl)
{
    int w, len, len_min, len_max;
    wchar_t *str;

    str = CreateWCStringFromSylText(txl->text, txl->left, txl->size);
    len = txl->size - txl->left;
    w = TextLineTextWidth(txl);
    if (TextEscapement(&txl->fontset, str, len) >= w) {
        len_max = len;
        len_min = txl->cursor - txl->left;
        len = (len_max + len_min) / 2;
        while (len_max - len_min > 1) {
            if (TextEscapement(&txl->fontset, str, len) >= w)
                len_max = len;
            else
                len_min = len;
            len = (len_max + len_min) / 2;
        }
	len = len_max;
    }
    free(str);
    return (txl->left + len);
}

static int
MoveCursorLeft(SylTextLine *txl)
{
#if 0
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N1&C<$KE=$j(B
       $B$D$1$k!#(B
    */
    --(txl->cursor);
    return (GetLeftLimit(txl));
#elif 0
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N:8C<$KE=$j(B
       $B$D$1$k!#(BMotif$B$_$?$$$K$9$k!#(B
    */
    if (--(txl->cursor) < txl->left)
	txl->left = txl->cursor;
    return (GetOrigin(txl));
#else
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N:8C<$NJ8;z(B
       $B$N1&B&$KD%$jIU$1$k!#(B
    */
    if (--(txl->cursor) <= txl->left)
	txl->left = (txl->cursor == 0) ? 0 : txl->cursor - 1;
    return (GetOrigin(txl));
#endif
}

static void
SetSelectionOwner(SylTextLine *txl, Time tm)
{
#if 0
    char *string;
    wchar_t *str;
    int n_bytes, len;
#endif

    XSetSelectionOwner(txl->disp, XA_PRIMARY, txl->window, tm);
    if (XGetSelectionOwner(txl->disp, XA_PRIMARY) != txl->window) {
	txl->left_dragged = 0;
	txl->right_dragged = 0;
    }
    txl->stamp = tm;
#if 0
    /*
      XXX $BM%@hEY$N9b$$(BTODO:
      $B0J2<$N%+%C%H%P%C%U%!99?7$K4X$9$k=hM}$O!"4X?t(BNiceSylTextLine()$B$+$i(B
      $B$+$i8F$S=P$5$l$kJ}<0$KJQ99$7$?$[$&$,$h$$$@$m$&!#(Btxl->cutbuffer_ready
      == False$B$G(Btxl->selected == True$B$J$i$P0J2<$N=hM}$r9T$&$h$&$K!#:#$N(B
      $B$H$3$m$O%+%C%H%P%C%U%!$KBP$9$k=hM}$OL5;k$9$k$3$H$K$7$F$*$/!#(B
    */
    if ((str = CreateWCStringFromSylText(txl->text,
					 txl->left_dragged,
					 txl->right_dragged)) == NULL)
	return;
    len = txl->right_dragged - txl->left_dragged;
    /*
      CopySelectedRegionToWCString()$B$O:G8e$K%L%kJ8;z$rIU2C$9$k$N$G!"(B
      1$BJ8;zJ,B?$/3NJ]$7$F$*$/!#(B
    */
    if ((string = (char *)malloc((len + 1) * sizeof(MB_LEN_MAX))) != NULL) {
	if ((n_bytes = wcstombs(string, str, (len + 1) * sizeof(MB_LEN_MAX)))
	    >= 0)
	    XStoreBuffer(txl->disp, string, n_bytes, 0);
	free(string);
    }
    free(str);
#endif
}

static void
ResetSelectionOwner(SylTextLine *txl)
{
    XSetSelectionOwner(txl->disp, XA_PRIMARY, None, txl->stamp);
    txl->left_dragged = 0;
    txl->right_dragged = 0;
}

static void
DeleteDraggedRegion(SylTextLine *txl)
{
    int len;

    DeleteWCStringOfSylText(txl->text, txl->left_dragged, txl->right_dragged);
    if ((len = LengthOfSylText(txl->text)) != txl->size) {
	txl->size = len;
	txl->cursor = txl->left_dragged;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static void
BackSpace(SylTextLine *txl, Time tm)
{
    int len;

    if (txl->left_dragged < txl->right_dragged)
	DeleteDraggedRegion(txl);
    else if (txl->cursor > 0) {
	DeleteWCharOfSylText(txl->text, txl->cursor - 1);
	if ((len = LengthOfSylText(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->left = MoveCursorLeft(txl);
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
}

static void
Delete(SylTextLine *txl, Time tm)
{
    int len;

    if (txl->left_dragged < txl->right_dragged)
	DeleteDraggedRegion(txl);
    else if (txl->cursor < txl->size) {
	DeleteWCharOfSylText(txl->text, txl->cursor);
	if ((len = LengthOfSylText(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
}

static void
KillLine(SylTextLine *txl, Time tm)
{
    int len;

    if (txl->cursor < txl->size) {
	DeleteWCStringOfSylText(txl->text, txl->cursor, txl->size);
	if ((len = LengthOfSylText(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
}

static void
CursorBack(SylTextLine *txl, Time tm)
{
    if (txl->cursor > 0) {
	txl->left = MoveCursorLeft(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static int
IsSeparator(wchar_t c)
{
#ifdef HAS_ISW_FUNCS
    return (iswpunct(c) || iswspace(c));
#else
    return (ispunct(c) || isspace(c));
#endif
}

static int
MoveWordLeft(SylTextLine *txl)
{
    wchar_t *str;

    str = CreateWCStringFromSylText(txl->text, 0, txl->size);
    while (txl->cursor > 0 && !IsSeparator(str[txl->cursor - 1]))
	--(txl->cursor);
    while (txl->cursor > 0 && IsSeparator(str[txl->cursor - 1]))
	--(txl->cursor);
    free(str);
#if 1
    /*
       $B%9%/%m!<%k$9$k$H$-$K!"(BI$B%S!<%`%]%$%s%?$rF~NO%U%#!<%k%I$N:8C<$NJ8;z(B
       $B$N1&B&$KD%$jIU$1$k!#(B
    */
    if (txl->cursor <= txl->left && txl->cursor > 0)
	txl->left = txl->cursor - 1;
#endif
    return (GetOrigin(txl));
}

static void
WordBack(SylTextLine *txl, Time tm)
{
    if (txl->cursor <= 0)
	return;
    txl->left = MoveWordLeft(txl);
    txl->right = GetRightLimit(txl);
    if (txl->left_dragged < txl->right_dragged)
	ResetSelectionOwner(txl);
    txl->redraw = True;
}

static void
CursorBeginingOfLine(SylTextLine *txl, Time tm)
{
    if (txl->cursor > 0) {
	txl->cursor = 0;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }    
}

static int
MoveCursorRight(SylTextLine *txl)
{
    ++(txl->cursor);
    return (GetOrigin(txl));
}

static int
MoveWordRight(SylTextLine *txl)
{
    wchar_t *str;

    str = CreateWCStringFromSylText(txl->text, 0, txl->size);
    while (txl->cursor < txl->size && !IsSeparator(str[txl->cursor]))
	++(txl->cursor);
    while (txl->cursor < txl->size && IsSeparator(str[txl->cursor]))
	++(txl->cursor);
    free(str);
    return (GetOrigin(txl));
}

static void
CursorForward(SylTextLine *txl, Time tm)
{
    if (txl->cursor < txl->size) {
	txl->left = MoveCursorRight(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static void
WordForward(SylTextLine *txl, Time tm)
{
    if (txl->cursor >= txl->size)
	return;
    txl->left = MoveWordRight(txl);
    txl->right = GetRightLimit(txl);
    if (txl->left_dragged < txl->right_dragged)
	ResetSelectionOwner(txl);
    txl->redraw = True;
}

static void
CursorEndOfLine(SylTextLine *txl, Time tm)
{
    if (txl->cursor < txl->size) {
	txl->cursor = txl->size;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }    
}

static void
InsertChar(SylTextLine *txl, wchar_t c)
{
    int len;

    if (txl->left_dragged < txl->right_dragged) {
	DeleteWCStringOfSylText(txl->text,
				txl->left_dragged, txl->right_dragged);
	if ((len = LengthOfSylText(txl->text)) != txl->size) {
	    txl->size = len;
	    txl->cursor = txl->left_dragged;
	    txl->left = GetOrigin(txl);
	    txl->right = GetRightLimit(txl);
	    if (txl->left_dragged < txl->right_dragged)
		ResetSelectionOwner(txl);
	    txl->redraw = True;
	}
    }
    InsertWCharIntoSylText(txl->text, txl->cursor, c);
    if ((len = LengthOfSylText(txl->text)) != txl->size) {
	txl->size = len;
	txl->left = MoveCursorRight(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

static void
AdjustDraggedRegion(SylTextLine *txl)
{
    if (txl->dragging < txl->cursor) {
	txl->left_dragged = txl->dragging;
	txl->right_dragged = txl->cursor;
    }
    else {
	txl->left_dragged = txl->cursor;
	txl->right_dragged = txl->dragging;
    }
}

static void
ChangeSelectionOwner(SylTextLine *txl, Time tm)
{
    Window owner;

    AdjustDraggedRegion(txl);
    if ((owner = XGetSelectionOwner(txl->disp, XA_PRIMARY)) == txl->window) {
	if (txl->left_dragged == txl->right_dragged)
	    XSetSelectionOwner(txl->disp, XA_PRIMARY, None, txl->stamp);
	return;
    }
    if (owner != None) {
        /*
	  Bug?: $B%;%l%/%7%g%s$r=jM-$9$k%&%#%s%I%&$,%H%C%W%l%Y%k%&%#%s%I%&(B
	  $B$G$J$$$?$a$+!"F10l%"%W%j%1!<%7%g%s4V$G4X?t(BXSetSelectionOwner()
	  $B$r8F$S=P$7$F$b(BSelectionClear$B%$%Y%s%H$,$3$J$$$3$H$,$"$k!#BP:v$H(B
	  $B$7$F!"0lEY6/@)E*$K%;%l%/%7%g%s$N%*!<%J$G$J$/$J$k$h$&$K$7$?!#(B

	  $B<+H/E*$KJ|4~$9$k$o$1$G$O$J$$$N$G!"%?%$%`%9%?%s%W$O(Btm$B$G$h$$!#(B
        */
	XSetSelectionOwner(txl->disp, XA_PRIMARY, None, tm);
	/*
	  $B<B$O<!$N$h$&$J%3!<%I$G$b$h$$!#%$%Y%s%H$r(Btxl->window$B$KAw$k$N$O(B
	  $B0l8+$*$+$7$$$h$&$@$1$I!"F10l%"%W%j%1!<%7%g%s$G$O%$%Y%s%H$rEpD0(B
	  $B$7$F$$$k$N$G!"7k2LE*$K$&$^$/$$$/!#(B

	  XEvent ev;
	  
	  ev.xselectionclear.type = SelectionClear;
	  ev.xselectionclear.window = owner;
	  ev.xselectionclear.selection = XA_PRIMARY;
	  ev.xselectionclear.time = tm;
	  XSendEvent(txl->disp, txl->window, False, 0, &ev);
	*/
    }
    SetSelectionOwner(txl, tm);
}

static void
CursorBackWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor > 0) {
	txl->left = MoveCursorLeft(txl);
	txl->right = GetRightLimit(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
WordBackWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor > 0) {
	txl->left = MoveWordLeft(txl);
	txl->right = GetRightLimit(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
CursorForwardWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor < txl->size) {
	txl->left = MoveCursorRight(txl);
	txl->right = GetRightLimit(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
WordForwardWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor < txl->size) {
	txl->left = MoveWordRight(txl);
	txl->right = GetRightLimit(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }
}

static void
CursorBeginingOfLineWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor > 0) {
	txl->cursor = 0;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }    
}

static void
CursorEndOfLineWithShift(SylTextLine *txl, Time tm)
{
    if (txl->left_dragged == txl->right_dragged)
	txl->dragging = txl->cursor;
    if (txl->cursor < txl->size) {
	txl->cursor = txl->size;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	ChangeSelectionOwner(txl, tm);
	txl->redraw = True;
    }    
}

static void
SetFocusToNextField(SylTextLine *txl, Time tm)
{
    if (txl->next_field != None)
        XSetInputFocus(txl->disp, txl->next_field, RevertToParent, tm);
}

static void
SetFocusToPrevField(SylTextLine *txl, Time tm)
{
    if (txl->prev_field != None)
        XSetInputFocus(txl->disp, txl->prev_field, RevertToParent, tm);
}

#include "TextLine.bind"

static void (*Branch[])(SylTextLine *, Time) = {
#include "TextLine.branch"
};

static void
LookupKey(SylTextLine *txl, XKeyEvent *key, wchar_t c)
{
    SylKeymap *ptr;

    if (key->state & Mod3Mask) {
        /* NEC PC-98xx: GRPH$B%-!<(B (Mod3Mask) $B$r(BAlt$B%-!<$H$7$F2r<a$5$;$k!#(B*/
        key->state &= ~Mod3Mask;
        key->state |= Mod1Mask;
    }
    if (key->keycode == 0 && c == '\n') {
        /*
          kinput2: $B%P!<%8%g%s(B2.0.1$B$G$O!"(BReturn/Tab$B$N%-!<%7%`!"%-!<%3!<%I!"(B
          $B=$>~%-!<$N>uBV$,<N$F$i$l$F$7$^$&!#(Bvje$B$J$i$A$c$s$HF0$/$N$K!#(B
          Control-m$B$J$iDL$k$N$G!"$"$k0UL#LdBj$O$J$$$s$@$1$I(B...$B!#(B
        */
        fprintf(stderr, "warning: the current IM does not pass the keycode"
                " of `Return' key.\n");
        return;
    }
    key->state &= (ShiftMask | ControlMask | Mod1Mask);
    for (ptr = txl->keymap[key->keycode]; ptr != NULL; ptr = ptr->next) {
        if (key->state == ptr->mod) {
            (Branch[ptr->func])(txl, key->time);
            return;
        }
    }
    if (isprint(c))
        InsertChar(txl, c);
}

static void
LookupPressedKey(SylTextLine *txl, XKeyEvent *key)
{
    KeySym ks;
    unsigned char p[64];
    wchar_t c;

    p[XLookupString(key, p, 64, NULL, NULL)] = 0;
    if ((ks = XLookupKeysym(key, 0)) == NoSymbol)
	return;
    LookupKey(txl, key, (mbtowc(&c, p, 1) > 0) ? c : 0);
}

static void
LookupPressedKeyWithIC(SylTextLine *txl, XKeyEvent *key)
{
    int n, n_lookups;
    KeySym ks;
    Status lookup_status;
#if 0
    /*
      $B;EMM$@$H$3$C$A$G$$$$$O$:$J$N$K(B... $B%9%F!<%?%9$,(BXBufferOverflow$B$N(B
      $B$H$-(BXwcLookupString()$B$NJV$9CM$O!VI,MW$J%P%C%U%!$NBg$-$5!W$N$O$:(B
      $B$@$,!"F~NO%a%=%C%I$K$h$C$F$O>!<j$KF~NO%3%s%F%/%9%H$r@Z$j5M$a$k!#(B
    */
    wchar_t *drain, buf[1], *str = buf;

    n_lookups = XwcLookupString(txl->ic, key, str, 1, &ks, &lookup_status);
    if (lookup_status == XBufferOverflow) {
	if ((str = (wchar_t *)alloca(sizeof(wchar_t) * n_lookups)) == NULL) {
	    if ((drain = XwcResetIC(txl->ic)) != NULL)
		XFree(drain);
	    return;
	}
	n_lookups = XwcLookupString(txl->ic, key, str, n_lookups, &ks,
				    &lookup_status);
    }
#else
    wchar_t *drain, str[1024];

    n_lookups = XwcLookupString(txl->ic, key, str, 1024, &ks, &lookup_status);
#endif
    switch (lookup_status) {
    case XBufferOverflow:
	if ((drain = XwcResetIC(txl->ic)) != NULL)
	    XFree(drain);
	break;
    case XLookupKeySym:
	LookupKey(txl, key, 0);
	break;
    case XLookupChars:
	for (n = 0; n < n_lookups; ++n)
	    LookupKey(txl, key, str[n]);
	break;
    case XLookupBoth:
	LookupKey(txl, key, str[0]);
	for (n = 1; n < n_lookups; ++n)
	    LookupKey(txl, key, str[n]);
	break;
    }
}

static void
SetICSpotLocation(XIC ic, int x, int y)
{
    XVaNestedList list;
    XPoint spot;
    
    spot.x = x;
    spot.y = y;
    list = XVaCreateNestedList(0, XNSpotLocation, &spot, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}

static void
SetICFontSet(XIC ic, XFontSet fs, int h)
{
    XVaNestedList list;
    
    list = XVaCreateNestedList(0, XNFontSet, fs, XNLineSpace, h, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}

#ifdef ON_THE_SPOT
static int
PreeditStart(XIC ic, SylTextLine *txl, void *call_data)
{
#ifdef DEBUG
    printf("TextLine: Start\n");
#endif
    if (txl->ic != ic || call_data != NULL) {
#ifdef DEBUG
	printf("TextLine: Start: invalid arguments\n");
#endif
	return (0);
    }
    txl->n_preedit_chars = 0;
    txl->preedit_caret = 0;
    txl->preedit_begin = txl->cursor;
    return (-1);
}

static void
PreeditClear(SylTextLine *txl)
{
#if 0
    while (txl->preedit_caret > 0) {
	BackSpace(txl, CurrentTime);
	--(txl->preedit_caret);
	--(txl->n_preedit_chars);
    }
    while (txl->n_preedit_chars > 0) {
	Delete(txl, CurrentTime);
	--(txl->n_preedit_chars);
    }
#else
    DeleteWCStringOfSylText(txl->text, txl->preedit_begin,
			    txl->preedit_begin + txl->n_preedit_chars);
    txl->size = LengthOfSylText(txl->text);
    txl->cursor = txl->preedit_begin;
    txl->left = GetOrigin(txl); /* GetLeftLimit(txl) */
    txl->right = GetRightLimit(txl);
    txl->preedit_caret = 0;
    txl->n_preedit_chars = 0;
#endif
    if (txl->feedback != NULL)
	free(txl->feedback);
    txl->feedback = NULL;
    txl->redraw = True;
}

static void
PreeditDone(XIC ic, SylTextLine *txl, void *call_data)
{
#ifdef DEBUG
    printf("TextLine: Done\n");
#endif
    if (txl->ic != ic || call_data != NULL) {
#ifdef DEBUG
	printf("TextLine: Done: not my ic\n");
#endif
	return;
    }
    if (txl->n_preedit_chars > 0)
	PreeditClear(txl);
}

static void
PreeditDraw(XIC ic, SylTextLine *txl, XIMPreeditDrawCallbackStruct *dcs)
{
    int m, n, len;
    wchar_t *wcs;
    XIMFeedback *fb;

#ifdef DEBUG
    printf("TextLine: Draw: enter\n");
#endif
    if (txl->ic != ic) {
#ifdef DEBUG
	printf("TextLine: Draw: not my ic\n");
#endif
	return;
    } 
    if (txl->n_preedit_chars == 0) {
	txl->preedit_begin = txl->cursor;
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
    }
    /* delete */
#ifdef DEBUG
    printf("TextLine: Draw: caret=%d, chg_first=%d, chg_length=%d\n",
	   dcs->caret, dcs->chg_first, dcs->chg_length);
#endif
    if (dcs->chg_length > 0) {
	if (dcs->chg_first < 0 || dcs->chg_first > txl->n_preedit_chars
	    || dcs->chg_first + dcs->chg_length > txl->n_preedit_chars) {
#ifdef DEBUG
	    printf("TextLine: Draw: invalid chg_first, chg_length\n");
#endif
	}
	else {
	    n = txl->preedit_begin + dcs->chg_first;
	    DeleteWCStringOfSylText(txl->text, n, n + dcs->chg_length);
	    txl->size = LengthOfSylText(txl->text);
	    txl->cursor = txl->preedit_begin + dcs->chg_first;
	    txl->preedit_caret = dcs->chg_first;
	    txl->n_preedit_chars -= dcs->chg_length;
	    
	    if ((len = txl->n_preedit_chars) == 0) {
		if (txl->feedback != NULL)
		    free(txl->feedback);
		txl->feedback = NULL;
	    }
	    else {
		if ((fb = (XIMFeedback *)malloc(sizeof(XIMFeedback) * len))
		    != NULL) {
		    for (n = 0; n < dcs->chg_first; ++n)
			fb[n] = txl->feedback[n];
		    for (; n < len; ++n)
			fb[n] = txl->feedback[n + dcs->chg_length];
		}
		if (txl->feedback != NULL)
		    free(txl->feedback);
		txl->feedback = fb;
	    }
	}
    }
    /* insert */
    if (dcs->text == NULL) {
#ifdef DEBUG
	printf("TextLine: Draw: text=NULL\n");
#endif
    }
    else {
	len = dcs->text->length;
#ifdef DEBUG
	printf("TextLine: Draw: text->length=%d\n", len);
#endif
	if (dcs->text->encoding_is_wchar == False) {
#ifdef DEBUG
	    printf("TextLine: Draw: text->string.multi_byte=%s\n",
		   dcs->text->string.multi_byte);
#endif
	    if (dcs->text->string.multi_byte == NULL) {
		wcs = NULL;
	    }
	    else if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * (len + 1)))
		     != NULL) {
		mbstowcs(wcs, dcs->text->string.multi_byte, len + 1);
	    }
	}
	else {
	    wcs = dcs->text->string.wide_char;
	}
	if (wcs != NULL) {
#ifdef DEBUG
	    printf("TextLine: Draw: insert %d widechar(s)\n", len);
#endif
	    InsertWCStringIntoSylText(txl->text, txl->cursor, wcs);
	    txl->n_preedit_chars += len;
	    txl->preedit_caret += len;
	    if ((len = LengthOfSylText(txl->text)) != txl->size) {
		txl->cursor += len - txl->size;
		txl->size = len;
	    }
	}
	/* feedback */
	if (dcs->text->feedback != NULL) {
#ifdef DEBUG
#if 0
	    printf("TextLine: Draw: feedback(dcs):");
	    for (n = 0; n < dcs->text->length; ++n) {
		printf(" [%d]", n);
		switch (dcs->text->feedback[n]) {
		case XIMReverse: printf("R"); break;
		case XIMUnderline: printf("U"); break;
		case XIMHighlight: printf("H"); break;
		case XIMPrimary: printf("P"); break;
		case XIMSecondary: printf("S"); break;
		case XIMTertiary: printf("T"); break;
		default: printf("%ld", dcs->text->feedback[n]); break;
		}
	    }
	    printf("\n");
#endif
#endif
	    if (wcs == NULL) {
		for (n = dcs->chg_first; n < dcs->text->length; ++n)
		    txl->feedback[n] = dcs->text->feedback[n];
	    }
	    else {
		if ((fb = (XIMFeedback *)malloc(sizeof(XIMFeedback)
						* txl->n_preedit_chars))
		    == NULL) {
		    if (txl->feedback == NULL)
			free(txl->feedback);
		    txl->feedback = NULL;
		}
		else {
		    if (txl->feedback == NULL) {
			for (n = 0; n < dcs->text->length; ++n)
			    fb[n] = dcs->text->feedback[n];
			txl->feedback = fb;
		    }
		    else {
			for (n = 0; n < dcs->chg_first; ++n)
			    fb[n] = txl->feedback[n];
			for (m = 0; m < dcs->text->length; ++m)
			    fb[n + m] = dcs->text->feedback[m];
		    for (; n + m < txl->n_preedit_chars; ++n)
			fb[n + m] = txl->feedback[n];
		    free(txl->feedback);
		    txl->feedback = fb;
		    }
		}
	    }
#ifdef DEBUG
#if 0
	    printf("TextLine: Draw: feedback(all):");
	    for (n = 0; n < txl->n_preedit_chars; ++n) {
		printf(" [%d]", n);
		switch (txl->feedback[n]) {
		case XIMReverse: printf("R"); break;
		case XIMUnderline: printf("U"); break;
		case XIMHighlight: printf("H"); break;
		case XIMPrimary: printf("P"); break;
		case XIMSecondary: printf("S"); break;
		case XIMTertiary: printf("T"); break;
		default: printf("%ld", txl->feedback[n]); break;
		}
	    }
	    printf("\n");
#endif
#endif
	}
    }
    /* caret */
    txl->preedit_caret = dcs->caret;
    txl->cursor = txl->preedit_begin + txl->preedit_caret;
    txl->left = GetOrigin(txl); /* GetLeftLimit(txl); */
    txl->right = GetRightLimit(txl);
#if 0 /* $B%&%#%s%I%&I}$,69$$$H$-$O!"%+!<%=%k0LCV$,9TF,$K$/$k$h$&$K$9$k!#(B */
    if (txl->right < txl->preedit_begin + txl->n_preedit_chars) {
	txl->left = txl->cursor;
	txl->right = GetRightLimit(txl);
    }
#endif
#ifdef DEBUG
    printf("TextLine: Draw: fix: %d\n", txl->cursor);
#endif
    /* fix */
    txl->redraw = True;
#ifdef DEBUG
    printf("TextLine: Draw: leave\n");
#endif
}

static void
PreeditCaret(XIC ic, SylTextLine *txl, XIMPreeditCaretCallbackStruct *ccs)
{
#ifdef DEBUG
    printf("TextLine: Caret\n");
#endif
    if (txl->ic != ic) {
#ifdef DEBUG
	printf("TextLine: Caret: not my ic\n");
#endif
	return;
    }
#ifdef DEBUG
    printf("TextLine: Caret: position=%d, direction=%d, style=%d\n",
	   ccs->position, ccs->direction, ccs->style);
#endif
    switch (ccs->direction) {
    case XIMForwardChar:
	if (txl->preedit_caret >= txl->n_preedit_chars)
	    break;
	CursorForward(txl, CurrentTime);
	++(txl->preedit_caret);
	break;
    case XIMBackwardChar:
	if (txl->preedit_caret <= 0)
	    break;
	CursorBack(txl, CurrentTime);
	--(txl->preedit_caret);
	break;
    case XIMAbsolutePosition:
	if (ccs->position < 0 || ccs->position > txl->n_preedit_chars)
	    break;
	txl->preedit_caret = ccs->position;
	txl->cursor = txl->preedit_begin + txl->preedit_caret;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	txl->redraw = True;
	break;
    case XIMForwardWord:
    case XIMBackwardWord:
    case XIMCaretUp:
    case XIMCaretDown:
    case XIMPreviousLine:
    case XIMNextLine:
    case XIMLineStart:
    case XIMLineEnd:
    case XIMDontChange:
    default:
	break;
    }
    ccs->position = txl->preedit_caret;
}

static void
SetICPreeditCallbacks(XIC ic, SylTextLine *txl)
{
    XVaNestedList list;
    XIMCallback Start, Done, Draw, Caret;

    Start.client_data = (XPointer)txl;
    Start.callback = (XIMProc)PreeditStart;
    Done.client_data = (XPointer)txl;
    Done.callback = (XIMProc)PreeditDone;
    Draw.client_data = (XPointer)txl;
    Draw.callback = (XIMProc)PreeditDraw;
    Caret.client_data = (XPointer)txl;
    Caret.callback = (XIMProc)PreeditCaret;
    list = XVaCreateNestedList(0, XNPreeditStartCallback, &Start,
			       XNPreeditDoneCallback, &Done,
			       XNPreeditDrawCallback, &Draw,
			       XNPreeditCaretCallback, &Caret, NULL);
    XSetICValues(ic, XNPreeditAttributes, list, NULL);
    XFree(list);
}
#endif

static void
ResetIC(SylTextLine *txl)
{
    char *mbs;

#ifdef ON_THE_SPOT
    if (txl->n_preedit_chars > 0)
	PreeditClear(txl);
#endif
    /*
       XwcResetIC()$B$NLa$jCM$r(BXFree()$B$9$k$H<!$N%a%C%;!<%8$,I=<($5$l$k!#(B
       in free(): warning: junk pointer, too high to make sense

       $B$7$+$?$J$$$N$G!"(BXmbResetIC()$B$r;H$&!#(B
    */
    if ((mbs = XmbResetIC(txl->ic)) != NULL) {
	XFree(mbs);
    }
}

static void
DrawCursor(SylTextLine *txl, int cx)
{
    int rx, lx, ty, by;

    if (txl->focus == True) {
        lx = cx - ((txl->fontset.width / 3) & ~1);
        rx = cx + ((txl->fontset.width / 3) & ~1);
	ty = txl->fontset.descent;
	by = txl->fontset.descent + txl->fontset.height - 1;
	XSetLineAttributes(txl->disp, txl->gc, 0,
			   LineSolid, CapButt, JoinRound);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, cx, ty + 1, cx, by - 1);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, lx, ty, cx - 1, ty);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, lx, by, cx - 1, by);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, cx + 1, ty, rx, ty);
	XDrawLine(txl->disp, txl->pixmap, txl->gc, cx + 1, by, rx, by);
        if (txl->ic != NULL && txl->ic_style & XIMPreeditPosition) {
            SetICSpotLocation(txl->ic, cx, ty + txl->fontset.ascent);
        }
    }
}

static void
DrawTextLine(SylTextLine *txl)
{
    wchar_t *str;
    int x, dragged_begin, dragged_len, margin, top;

    if ((top = txl->left) > 0)
	--top;
    str = CreateWCStringFromSylText(txl->text, top, txl->right);
    margin = txl->sidemargin;
    if (txl->left > 0)
	margin -= TextEscapement(&txl->fontset, str, 1);
    /* draw background */
    XSetForeground(txl->disp, txl->gc, (txl->pointed == True)
		   ? txl->pixel[Illuminated] : txl->pixel[Background]);
    XFillRectangle(txl->disp, txl->pixmap, txl->gc,
		   0, 0, txl->width, txl->height);
    /* draw foreground */
    XSetForeground(txl->disp, txl->gc, txl->pixel[Foreground]);
    XwcDrawString(txl->disp, txl->pixmap, txl->fontset.id, txl->gc,
		  margin, txl->fontset.descent + txl->fontset.ascent,
		  str, txl->right - top);
#ifdef ON_THE_SPOT
    if (txl->n_preedit_chars > 0) {
	int i, len = txl->right - top, y, w;
	if (txl->preedit_begin < top) {
	    i = 0;
	    txl->preedit_drawing = top - txl->preedit_begin;
	}
	else {
	    i = txl->preedit_begin - top;
	    txl->preedit_drawing = 0;
	}
	for (; i < len && txl->preedit_drawing < txl->n_preedit_chars; ++i) {
	    x = margin + TextEscapement(&txl->fontset, str, i);
	    w = TextEscapement(&txl->fontset, str + i, 1);
	    y = txl->fontset.height;
	    switch(txl->feedback[txl->preedit_drawing]) {
	    case XIMReverse:
		XSetForeground(txl->disp, txl->gc, (txl->pointed) ?
		    txl->pixel[Illuminated] : txl->pixel[Background]);
		XSetBackground(txl->disp, txl->gc, txl->pixel[Preedited]);
		XwcDrawImageString(txl->disp, txl->pixmap, txl->fontset.id,
				   txl->gc, x, y, str + i, 1);
		break;
	    case XIMUnderline:
		XSetForeground(txl->disp, txl->gc, txl->pixel[Preedited]);
		XwcDrawString(txl->disp, txl->pixmap, txl->fontset.id, txl->gc,
			      x, y, str + i, 1);
		y += txl->fontset.descent / 2;
		XSetLineAttributes(txl->disp, txl->gc,
				   txl->fontset.descent / 2,
				   LineSolid, CapButt, JoinRound);
		XDrawLine(txl->disp, txl->pixmap, txl->gc, x, y, x + w, y);
		break;
	    default:
		XSetForeground(txl->disp, txl->gc, txl->pixel[Preedited]);
		XwcDrawString(txl->disp, txl->pixmap, txl->fontset.id, txl->gc,
			      x, y, str + i, 1);
		break;
	    }
	    ++(txl->preedit_drawing);
	}
    }
#endif
    if (txl->right_dragged - txl->left_dragged > 0) {
	if (top < txl->left_dragged)
	    dragged_begin = txl->left_dragged - top;
	else
	    dragged_begin = 0;
	if (txl->right_dragged < txl->right)
	    dragged_len = txl->right_dragged - top - dragged_begin;
	else
	    dragged_len = txl->right - top - dragged_begin;
	x = margin + TextEscapement(&txl->fontset, str, dragged_begin);
	XSetForeground(txl->disp, txl->gc, (txl->pointed == True)
		       ? txl->pixel[Illuminated] : txl->pixel[Background]);
	XSetBackground(txl->disp, txl->gc, txl->pixel[Foreground]);
	XwcDrawImageString(txl->disp, txl->pixmap, txl->fontset.id, txl->gc,
			   x, txl->fontset.height,
			   str + dragged_begin, dragged_len);
    }
    if (txl->focus == True) {
	x = margin + TextEscapement(&txl->fontset, str, txl->cursor - top);
	XSetForeground(txl->disp, txl->gc, txl->pixel[Foreground]);
	XDrawRectangle(txl->disp, txl->pixmap, txl->gc, 0, 0,
		       txl->width - 1, txl->height - 1);
	DrawCursor(txl, x);
		   
    }
    free(str);
}

static int
WindowXpointer(Display *disp, Window w)
{
    Window root, child;
    int rx, ry, wx, wy, kb;

    XQueryPointer(disp, w, &root, &child, &rx, &ry, &wx, &wy, &kb);
    return (wx);
}

#ifdef USE_SHAPE
static void
UpdateShapeMask(SylTextLine *txl)
{
    int x = 0, y = 0, dx, dy;
    Window w; 
    XWindowAttributes attr;
    Pixmap m;
    GC gc;
    Window FindSylToplevelWindow(Display *, Window, int *, int *);

    if ((w = FindSylToplevelWindow(txl->disp, txl->parent, &x, &y)) == None)
	return;
    XGetWindowAttributes(txl->disp, txl->parent, &attr);
    dx = (attr.width - txl->width) / 2;
    dy = (attr.height - txl->height) / 2;
    m = XCreatePixmap(txl->disp, txl->parent, attr.width, attr.height, 1);
    gc = XCreateGC(txl->disp, m, 0, 0);

    XSetForeground(txl->disp, gc, 1);
    XFillRectangle(txl->disp, m, gc, 0, 0, attr.width, attr.height);
    XSetForeground(txl->disp, gc, 0);
    XFillRectangle(txl->disp, m, gc, dx, dy, txl->width, txl->height);
    XShapeCombineMask(txl->disp, w, ShapeBounding, x, y, m, ShapeSubtract);
    XSetForeground(txl->disp, gc, 0);
    XFillRectangle(txl->disp, m, gc, 0, 0, attr.width, attr.height);
    XSetForeground(txl->disp, gc, 1);
    XFillRectangle(txl->disp, m, gc, dx, dy, txl->width, txl->height);
    XShapeCombineMask(txl->disp, w, ShapeBounding, x, y, m, ShapeUnion);

    XFreeGC(txl->disp, gc);
    XFreePixmap(txl->disp, m);
}
#endif

int
NiceSylTextLine(SylTextLine *txl)
{
    int x;

    XFlush(txl->disp);
    if (txl->redraw == True) {
#ifdef USE_SHAPE
	UpdateShapeMask(txl);
#endif
	DrawTextLine(txl);
	XCopyArea(txl->disp, txl->pixmap, txl->window, txl->gc,
		  0, 0, txl->width, txl->height, 0, 0);
	txl->redraw = False;
    }
    if (txl->grabbed == True) {
	if ((x = WindowXpointer(txl->disp, txl->window)) < 0) {
	    if (txl->cursor > 0)
		txl->left = MoveCursorLeft(txl);
	}
	else if (x > txl->width) {
	    if (txl->cursor < txl->size)
		txl->left = MoveCursorRight(txl);
	}
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	AdjustDraggedRegion(txl);
	txl->redraw = True;
	XFlush(txl->disp);
	usleep(DRAGGING_SCROLL_DELAY);
	return (1); /* XXX */
    }
    return (0);
}

static void
SendSelectionReply(SylTextLine *txl, XEvent *ev)
{
    wchar_t *wcs;
    XSelectionRequestEvent *req = &(ev->xselectionrequest);

    wcs = CreateWCStringFromSylText(txl->text, txl->left_dragged,
	txl->right_dragged);
    SylRespondSelectionRequestWithWCString(req, wcs, txl->stamp,
        txl->targets_atom, txl->timestamp_atom, XA_STRING, txl->text_atom,
	txl->compound_text_atom);
    free(wcs);
}

static void
GetWindowProperty(SylTextLine *txl, XEvent *ev)
{
    XTextProperty text;
    wchar_t **list;
    int n_lists, n, len;
    XSelectionEvent *sel = &(ev->xselection);

    if (sel->property != txl->property) {
#ifdef DEBUG
	printf("property is different from the requested\n");
#endif
	XDeleteProperty(sel->display, sel->requestor, sel->property);
	return;
    }
    if (XGetTextProperty(sel->display, sel->requestor, &text, sel->property)
	== 0) {
#ifdef DEBUG
	char *atom = XGetAtomName(txl->disp, sel->target);
	printf("target is %s(%ld), XGetTextProperty failed\n",
	       atom, sel->target);
	XFree(atom);
#endif
	return;
    }
    XDeleteProperty(sel->display, sel->requestor, sel->property);
    if ((n = XwcTextPropertyToTextList(txl->disp, &text, &list, &n_lists))
	< 0) {
#ifdef DEBUG
	printf("text.value is %s(%ld), XwcTextPropertyToTextList failed\n",
	       text.value, text.nitems);
#endif
	XFree(text.value);
	return;
    }
    XFree(text.value);
    /*
      Bug?: text.value$B$K(BJIS$B%3!<%I$GF|K\8l$,3JG<$5$l$F$$$F!"(Btext.value$B$N(B
      $B:G8e$N(B3$B%P%$%H$,(BKanjiOut(0x1b 0x28 0x42)$B$N$H$-!"4X?t(BXwcTextProperty
      ToTextList()$B$O$J$<$+(B3$B$rJV$9!#$3$3$G$O$H$j$"$($:La$jCM(Bn$B$,(B (0$B$N$H$-$O(B
      $B$b$A$m$s(B) $B@5$N$H$-$b=hM}$rB39T$9$k!#(B
    */
    if (n_lists > 0) {
	for (n = 0; (*list)[n]; ++n) {
	    if (!isprint((*list)[n]))
		(*list)[n] = ' ';
	}
	InsertWCStringIntoSylText(txl->text, txl->cursor, *list);
    }
    XwcFreeStringList(list);
    if ((len = LengthOfSylText(txl->text)) != txl->size) {
	txl->cursor += len - txl->size;
	txl->size = len;
	txl->left = GetOrigin(txl);
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
	txl->redraw = True;
    }
}

void
SendSylTextLine(SylTextLine *txl, XEvent *ev)
{
    switch (ev->type) {
    case Expose:
	if (ev->xexpose.window != txl->window)
	    return;
	XCopyArea(txl->disp, txl->pixmap, txl->window, txl->gc,
	    ev->xexpose.x, ev->xexpose.y,
	    ev->xexpose.width, ev->xexpose.height,
	    ev->xexpose.x, ev->xexpose.y);
	break;
    case EnterNotify:
	if (ev->xcrossing.window != txl->window)
	    return;
	txl->pointed = True;
	txl->redraw = True;
        break;
    case LeaveNotify:
	if (ev->xcrossing.window != txl->window)
	    return;
	txl->pointed = False;
	txl->redraw = True;
        break;
    case ButtonPress:
	if (ev->xbutton.window != txl->window)
	    return;
	if (txl->focus == False) {
	    XSetInputFocus(txl->disp, txl->window, RevertToParent,
			   ev->xbutton.time);
	}
#ifdef ON_THE_SPOT
	/*
	  $BA0JT=8J8;zNs$,$"$k>l9g$O$I$N$h$&$K$9$k$N$,$h$$$N$+(B? $B$H$j$"$($:!"(B
	  $B%^%&%9%$%Y%s%H$rL5;k$9$k$h$&$K$7$?!#(B
	*/
	if (txl->n_preedit_chars > 0)
	    return;
#endif	
	if (ev->xbutton.button == 1) {
	    XGrabPointer(txl->disp, txl->window, False, ButtonMotionMask
		| ButtonReleaseMask | PointerMotionHintMask,
		GrabModeAsync, GrabModeSync, DefaultRootWindow(txl->disp),
		None, ev->xbutton.time);
	    txl->grabbed = True; 
	    txl->cursor = GetPointedCursor(txl, ev->xbutton.x);
	    txl->dragging = txl->cursor;
	    txl->left_dragged = txl->cursor;
	    txl->right_dragged = txl->cursor;
	    txl->redraw = True;
	}
        else if (ev->xbutton.button == 2) {
	    txl->cursor = GetPointedCursor(txl, ev->xbutton.x);
	    XConvertSelection(txl->disp, XA_PRIMARY, txl->text_atom,
			      txl->property, txl->window, ev->xbutton.time);
	    txl->redraw = True;
        }
	break;
    case MotionNotify:
        if (txl->grabbed != True)
            return;
	/*
	  Bug?: $B%;%l%/%7%g%s$r=jM-$9$k%&%#%s%I%&$,%H%C%W%l%Y%k%&%#%s%I%&(B
	  $B$G$J$$$?$a$+!"F10l%"%W%j%1!<%7%g%s4V$G4X?t(BXSetSelectionOwner()
	  $B$r8F$S=P$7$F$b(BSelectionClear$B%$%Y%s%H$,$3$J$$$3$H$,$"$k!#BP:v$H(B
	  $B$7$F!"(BMotionNotify$B$r<u$1<h$C$F$$$k$H$-$K?7$?$JJ8;zNs$,%I%i%C%0(B
	  $B$5$l$?$i!"(Bowner$B$r(BNone$B$H$7$F4X?t(BXSetSelectionOwner()$B$r8F$S=P$7!"(B
	  $B0lEY6/@)E*$K%;%l%/%7%g%s$N%*!<%J$G$J$/$J$k$h$&$K$7$?!#(B
	*/
	if (txl->left_dragged < txl->right_dragged)
	    XSetSelectionOwner(txl->disp, XA_PRIMARY, None, ev->xmotion.time);
	txl->cursor = GetPointedCursor(txl, WindowXpointer(txl->disp,
							   txl->window));
	AdjustDraggedRegion(txl);
        txl->redraw = True;
	break;
    case ButtonRelease:
        if (txl->grabbed != True)
            return;
        XUngrabPointer(txl->disp, ev->xbutton.time);
	if (txl->left_dragged < txl->right_dragged)
	    SetSelectionOwner(txl, ev->xbutton.time);
        txl->grabbed = False;
        txl->redraw = True;
        break;
    case FocusIn:
	if (ev->xfocus.window != txl->window
	    || ev->xfocus.detail == NotifyPointer)
	    return;
	if (txl->ic != NULL) {
	    XSetICFocus(txl->ic);
	    XSetICValues(txl->ic, XNFocusWindow, txl->window, NULL);
	    if (txl->ic_style & XIMPreeditPosition)
		SetICFontSet(txl->ic, txl->fontset.id, txl->fontset.height);
#ifdef ON_THE_SPOT
	    else if (txl->ic_style & XIMPreeditCallbacks)
		SetICPreeditCallbacks(txl->ic, txl);
#endif
	}
	txl->focus = True;
	txl->redraw = True;
        break;
    case FocusOut:
	if (ev->xfocus.window != txl->window
	    || ev->xfocus.detail == NotifyPointer)
	    return;
        if (txl->ic != NULL) {
	    ResetIC(txl);
	    XUnsetICFocus(txl->ic);
	}
	txl->focus = False;
	txl->redraw = True;
        break;
    case KeyPress:
	if (ev->xkey.window != txl->window || txl->focus == False)
	    return;
#ifdef ON_THE_SPOT
	if (txl->n_preedit_chars > 0)
	    return; /* $BA0JT=8J8;zNs$,$"$k>l9g$O%-!<%$%Y%s%H$rL5;k$9$k!#(B */
#endif	
	if (txl->ic == NULL)
	    LookupPressedKey(txl, &(ev->xkey));
	else
	    LookupPressedKeyWithIC(txl, &(ev->xkey));
	break;
    case SelectionNotify:
        if (ev->xselection.selection != XA_PRIMARY
	    || ev->xselection.requestor != txl->window)
	    break;
	if (ev->xselection.property != None)
	    GetWindowProperty(txl, ev);
	break;
    case SelectionClear:
        if (ev->xselectionclear.window != txl->window)
	    break;
	txl->left_dragged = 0;
	txl->right_dragged = 0;
	txl->redraw = True;
        break;
    case SelectionRequest:
        if (ev->xselectionrequest.owner == txl->window
	    && txl->left_dragged < txl->right_dragged)
            SendSelectionReply(txl, ev);
        break;
    case ConfigureNotify:
	if (ev->xconfigure.window != txl->parent)
            return;
	txl->width = ev->xconfigure.width;
	txl->height = txl->fontset.height + 2 * txl->fontset.descent;
	XMoveResizeWindow(txl->disp, txl->window,
			  0, (ev->xconfigure.height - txl->height) / 2,
			  txl->width, txl->height);
	XFreePixmap(txl->disp, txl->pixmap);
	txl->pixmap = XCreatePixmap(txl->disp, txl->parent,
				    txl->width, txl->height, txl->depth);
	txl->left = GetLeftLimit(txl); /* GetOrigin(txl); */
	txl->right = GetRightLimit(txl);
	if (txl->left_dragged < txl->right_dragged)
	    ResetSelectionOwner(txl);
        if (txl->ic != NULL)
	    ResetIC(txl);
	txl->redraw = True;
	break;
    }
}

void
SetFieldOrderSylTextLine(SylTextLine *txl, Window prev, Window next)
{
    txl->prev_field = prev;
    txl->next_field = next;
}

void
SetICSylTextLine(SylTextLine *txl, XIC ic, XIMStyle ic_style)
{
    txl->ic = ic;
    txl->ic_style = ic_style;
}

static int
GetAllPreferences(Display *disp, Window win, char *name, char *class,
                  SylTextLine *txl)
{
    char *fq_name, *fq_class;
    XClassHint ch;

    if (XGetClassHint(disp, win, &ch) == 0)
        return (1);
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) != NULL)
        FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) != NULL)
        FQCompose(ch.res_class, class, fq_class);
    XFree(ch.res_name);
    XFree(ch.res_class);
    if (fq_name == NULL || fq_class == NULL)
        return (1);

    LoadSylColorset(disp, fq_name, fq_class, ColorSet, txl->pixel);
    LoadSylFontset(disp, fq_name, fq_class, FontSet, &txl->fontset);
    LoadSylKeybinding(disp, fq_name, fq_class, KeyBinding, txl->keymap);
    return (0);
}

SylTextLine *
CreateSylTextLine(Display *disp, Window parent, char *component,
		  void (*callback)(int))
{
    XWindowAttributes attr;
    SylTextLine *txl;
    Pixmap background;
    static char tile_bits[] = {0x0f, 0x0f, 0x0f, 0x0f, 0xf0, 0xf0, 0xf0, 0xf0};
    
    if ((txl = (SylTextLine *)malloc(sizeof(SylTextLine))) == NULL)
	goto no_text_line;
    if ((txl->text = CreateSylTextFromMBString("", True)) == NULL)
	goto no_text;
    if ((txl->pixel = CreateSylColorset(ColorSet)) == NULL)
        goto no_colorset;
    if ((txl->keymap = CreateSylKeymap()) == NULL)
	goto no_keymap;
    if (GetAllPreferences(disp, parent, component, THIS_CLASS, txl))
        goto no_preferences;
    txl->sidemargin = (txl->fontset.width + 2) / 2 + LINE_FOCUS_FRAME_WIDTH;
    XGetWindowAttributes(disp, parent, &attr);
    txl->width = attr.width;
    txl->height = txl->fontset.height + 2 * txl->fontset.descent;
    txl->depth = attr.depth;
    txl->window = XCreateSimpleWindow(disp, parent,
	0, (attr.height - txl->height) / 2, txl->width, txl->height,
        0, txl->pixel[Foreground], txl->pixel[MediumGray]);
    background = XCreatePixmapFromBitmapData(disp, txl->window, tile_bits,
	8, 8, txl->pixel[MediumGray], txl->pixel[DimGray], attr.depth);
    XSetWindowBackgroundPixmap(disp, txl->window, background);
    XFreePixmap(disp, background);
    XSelectInput(disp, txl->window, ExposureMask | KeyPressMask
	| ButtonPressMask | OwnerGrabButtonMask | ButtonReleaseMask
	| FocusChangeMask | EnterWindowMask | LeaveWindowMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, txl->window);
    XMapRaised(disp, txl->window);
    txl->next_field = None;
    txl->prev_field = None;
    txl->pixmap = XCreatePixmap(disp, parent,
        txl->width, txl->height, txl->depth);
    txl->gc = XCreateGC(disp, parent, 0, 0);
    XSetGraphicsExposures(disp, txl->gc, False);
    txl->disp = disp;
    txl->ic = NULL;
    txl->ic_style = XIMPreeditNone | XIMStatusNone;
    txl->parent = parent;
    txl->size = LengthOfSylText(txl->text);
    txl->cursor = txl->size; /* 0 */
    txl->left = GetLeftLimit(txl);
    txl->right = GetRightLimit(txl);
    txl->dragging = 0;
    txl->left_dragged = 0;
    txl->right_dragged = 0;
    txl->stamp = CurrentTime;
    txl->callback = callback;
    txl->grabbed = False;
    txl->pointed = False;
    txl->focus = False;
    txl->redraw = False;
#ifdef ON_THE_SPOT
    txl->n_preedit_chars = 0;
    txl->preedit_caret = 0;
    txl->preedit_begin = txl->cursor;
    txl->preedit_drawing = 0;
    txl->feedback = NULL;
#endif
    txl->property = XInternAtom(disp, "TextLineProperty", False);
    txl->text_atom = XInternAtom(disp, "TEXT", False);
    txl->compound_text_atom = XInternAtom(disp, "COMPOUND_TEXT", False);
    txl->targets_atom = XInternAtom(disp, "TARGETS", False);
    txl->timestamp_atom = XInternAtom(disp, "TIMESTAMP", False);
    DrawTextLine(txl);
    return (txl);

no_preferences:
    FreeSylKeymap(txl->keymap);    
no_keymap:
    FreeSylColorset(txl->pixel);
no_colorset:
    FreeSylText(txl->text);
no_text:
    free(txl);
no_text_line:
    return (NULL);
}

void
FreeSylTextLine(SylTextLine *txl)
{
    XDestroyWindow(txl->disp, txl->window);
    XFreePixmap(txl->disp, txl->pixmap);
    XFreeGC(txl->disp, txl->gc);
    XFreeFontSet(txl->disp, txl->fontset.id);
    FreeSylKeymap(txl->keymap);
    FreeSylColorset(txl->pixel);
    FreeSylText(txl->text);
    free(txl);
}

int
GetMBStringSylTextLine(SylTextLine *txl, char *dst)
{
    char *mbs;
    int n_bytes;
    
    if ((mbs = CreateMBStringFromSylText(txl->text, 0, txl->size)) == NULL)
	return (-1);
    n_bytes = strlen(mbs);
    if (dst != NULL)
	strcpy(dst, mbs);
    free(mbs);
    return (n_bytes);
}

void
SetMBStringSylTextLine(SylTextLine *txl, char *src) /* added */
{
    SylText *text;

    if ((text = CreateSylTextFromMBString(src, True)) == NULL)
	return;
    FreeSylText(txl->text);
    txl->text = text;
    txl->size = LengthOfSylText(text);
    txl->cursor = txl->size; /* 0 */
    txl->left = GetLeftLimit(txl);
    txl->right = GetRightLimit(txl);
    txl->dragging = 0;
    txl->left_dragged = 0;
    txl->right_dragged = 0;
    txl->stamp = CurrentTime;
    txl->redraw = True;
}
