#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Null.h"

SylNull *
CreateSylNull(Display *disp, Window parent)
{
    SylNull *nul;
    
    if ((nul = (SylNull *)malloc(sizeof(SylNull))) == NULL)
	return (NULL);
    nul->disp = disp;
    nul->parent = parent;
    return (nul);
}

void
FreeSylNull(SylNull *nul)
{
    free(nul);
}
