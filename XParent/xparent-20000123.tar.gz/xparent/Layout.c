/*
        Layout.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#ifdef USE_SHAPE
#include <X11/extensions/shape.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include "Resource.h"
#include "Layout.h"

#define THIS_CLASS "Pane"

static SylPanedWindow
    HFill = {SYL_PANED_WINDOW, NULL, 0, 0, 0, 1, True, NULL, None, None},
    VFill = {SYL_PANED_WINDOW, NULL, 0, 0, 1, 0, True, NULL, None, None},
    HRule = {SYL_PANED_WINDOW, NULL, 0, SYL_LAYOUT_SEP, 0, SYL_LAYOUT_SEP * 2,
	    True, NULL, None, None},
    VRule = {SYL_PANED_WINDOW, NULL, SYL_LAYOUT_SEP, 0, SYL_LAYOUT_SEP * 2, 0,
	    True, NULL, None, None};

SylPane *
SylHFill(void)
{
    SylPanedWindow *pnw;

    if ((pnw = (SylPanedWindow *)malloc(sizeof(SylPanedWindow))) == NULL)
	return (NULL);
    *pnw = HFill;
    return ((SylPane *)pnw);
}

SylPane *
SylVFill(void)
{
    SylPanedWindow *pnw;

    if ((pnw = (SylPanedWindow *)malloc(sizeof(SylPanedWindow))) == NULL)
	return (NULL);
    *pnw = VFill;
    return ((SylPane *)pnw);
}

SylPane *
SylHRule(void)
{
    SylPanedWindow *pnw;

    if ((pnw = (SylPanedWindow *)malloc(sizeof(SylPanedWindow))) == NULL)
	return (NULL);
    *pnw = HRule;
    return ((SylPane *)pnw);
}

SylPane *
SylVRule(void)
{
    SylPanedWindow *pnw;

    if ((pnw = (SylPanedWindow *)malloc(sizeof(SylPanedWindow))) == NULL)
	return (NULL);
    *pnw = VRule;
    return ((SylPane *)pnw);
}

SylPane *
CreateSylPane(Display *disp, Window parent, char *component, int map)
{
    XWindowAttributes attr;
    SylPanedWindow *pnw;
    int screen;
    unsigned long black, white;

    if ((pnw = (SylPanedWindow *)malloc(sizeof(SylPanedWindow))) == NULL)
	return (NULL);
    screen = DefaultScreen(disp);
    black = BlackPixel(disp, screen);
    white = WhitePixel(disp, screen);
    XGetWindowAttributes(disp, parent, &attr);
    pnw->window = XCreateSimpleWindow(disp, parent, 0, 0,
	attr.width, attr.height, 0, black, white);
    XSetWindowBackgroundPixmap(disp, pnw->window, ParentRelative);
    XSelectInput(disp, pnw->window, StructureNotifyMask);
    SetFQClassHint(disp, parent, component, THIS_CLASS, pnw->window);
    if (map)
	XMapRaised(disp, pnw->window);
    pnw->type = SYL_PANED_WINDOW;
    pnw->disp = disp;
    pnw->parent = parent;
    pnw->min_width = 0;
    pnw->min_height = 0;
    pnw->max_width = 0;
    pnw->max_height = 0;
    pnw->next = NULL;
    return ((SylPane *)pnw);
}

void
SetSizeSylPane(SylPane *p, int min_w, int min_h, int max_w, int max_h)
{
    SylPanedWindow *pnw = &(p->pane);

    pnw->min_width = min_w;
    pnw->min_height = min_h;
    pnw->max_width = max_w;
    pnw->max_height = max_h;
}

static int
MinSize(int a, int b)
{
    return ((a < b) ? b : a);
}

static int
MaxSize(int a, int b)
{
    if (a == 0 && b == 0)
	return (0);
    if (a > 0 && b == 0)
	return (a);
    if (a == 0 && b > 0)
	return (b);
    return ((a < b) ? a : b);
}

static int
AddMinSize(int a, int b)
{
    return (a + b + SYL_LAYOUT_SEP);
}

static int
AddMaxSize(int a, int b)
{
    return ((a == 0 || b == 0) ? 0 : (a + b + SYL_LAYOUT_SEP));
}

static SylPanedList *
NewSylPanedList(SylPane *top)
{
    SylPanedList *pnl;

    if ((pnl = (SylPanedList *)malloc(sizeof(SylPanedList))) == NULL)
	return (NULL);
    pnl->next = NULL;
    pnl->top = top;
    pnl->last = top;
    pnl->min_width = top->any.min_width;
    pnl->min_height = top->any.min_height;
    pnl->max_width = top->any.max_width;
    pnl->max_height = top->any.max_height;
    return (pnl);
}

static int
IsVariableHeight(SylPane *p)
{
    return (p->any.max_height == 0 || p->any.min_height < p->any.max_height);
}

static int
MinimumHeight(SylPane *p)
{
    return (p->any.min_height);
}

static int
MaximumHeight(SylPane *p)
{
    return (p->any.max_height);
}

SylPane *
SylVLayout(SylPane *top, ...)
{
    SylPanedList *pnl;
    SylPane *pane;
    va_list ap;

    if ((pnl = NewSylPanedList(top)) == NULL)
	return (NULL);
    pnl->type = SYL_PANED_VERTICAL;
    pnl->is_variable = IsVariableHeight;
    pnl->minimum = MinimumHeight;
    pnl->maximum = MaximumHeight;

    va_start(ap, top);
    while ((pane = va_arg(ap, SylPane *)) != NULL) {
	pnl->last->any.next = pane;
	pnl->last = pane;
	pnl->min_width = MinSize(pane->any.min_width, pnl->min_width);
	pnl->min_height = AddMinSize(pane->any.min_height, pnl->min_height);
	pnl->max_width = MaxSize(pane->any.max_width, pnl->max_width);
	pnl->max_height = AddMaxSize(pane->any.max_height, pnl->max_height);
    }
    va_end(ap);

    if (pnl->max_width > 0 && pnl->min_width > pnl->max_width)
	pnl->max_width = pnl->min_width;
    return ((SylPane *)pnl);
}

static int
IsVariableWidth(SylPane *p)
{
    return (p->any.max_width == 0 || p->any.min_width < p->any.max_width);
}

static int
MinimumWidth(SylPane *p)
{
    return (p->any.min_width);
}

static int
MaximumWidth(SylPane *p)
{
    return (p->any.max_width);
}

SylPane *
SylHLayout(SylPane *top, ...)
{
    SylPanedList *pnl;
    SylPane *pane;
    va_list ap;

    if ((pnl = NewSylPanedList(top)) == NULL)
	return (NULL);
    pnl->type = SYL_PANED_HORIZONTAL;
    pnl->is_variable = IsVariableWidth;
    pnl->minimum = MinimumWidth;
    pnl->maximum = MaximumWidth;

    va_start(ap, top);
    while ((pane = va_arg(ap, SylPane *)) != NULL) {
	pnl->last->any.next = pane;
	pnl->last = pane;
	pnl->min_width = AddMinSize(pane->any.min_width, pnl->min_width);
	pnl->min_height = MinSize(pane->any.min_height, pnl->min_height);
	pnl->max_width = AddMaxSize(pane->any.max_width, pnl->max_width);
	pnl->max_height = MaxSize(pane->any.max_height, pnl->max_height);
    }
    va_end(ap);

    if (pnl->max_height > 0 && pnl->min_height > pnl->max_height)
	pnl->max_height = pnl->min_height;
    return ((SylPane *)pnl);
}

static void
FreeSylPanedList(SylPane *pane)
{
    SylPane *next;

    while (pane != NULL) {
	next = pane->any.next;
	if (pane->any.type != SYL_PANED_WINDOW) {
	    FreeSylPanedList(pane->list.top);
	    free(pane);
	}
	else if (pane->pane.window != None) {
	    XDestroyWindow(pane->pane.disp, pane->pane.window);
	    free(pane);
	}
	pane = next;
    }
}

void
FreeSylPane(SylPane *pane)
{
    FreeSylPanedList(pane);
}

#ifdef USE_SHAPE
static int
HasProperty(Display *disp, Window w, Atom p)
{
    int n, n_props;
    Atom *prop;

    if ((prop = XListProperties(disp, w, &n_props)) == NULL)
        return (0);
    for (n = 0; n < n_props && prop[n] != p; ++n)
        ;
    XFree(prop);
    return (n < n_props);
}

static Window
ParentWindow(Display *disp, Window window)
{
    Window root, parent, *child;
    unsigned int children;

    if (XQueryTree(disp, window, &root, &parent, &child, &children) == 0)
	return (None);
    if (child != NULL)
	XFree(child);
    return (parent);
}

Window
FindSylToplevelWindow(Display *disp, Window w, int *x, int *y)
{
    Window p, root = DefaultRootWindow(disp);
    Atom WM_STATE = XInternAtom(disp, "WM_STATE", False);
    XWindowAttributes attr;

    while (w != None && HasProperty(disp, w, WM_STATE) == False
           && (p = ParentWindow(disp, w)) != root) {
	XGetWindowAttributes(disp, w, &attr);
	*x += attr.x;
	*y += attr.y;
        w = p;
    }
    return (w);
}
#endif

SylLayoutManager *
CreateSylLayoutManager(Display *disp, Window window)
{
    SylLayoutManager *mgr;

    if ((mgr = (SylLayoutManager *)malloc(sizeof(SylLayoutManager))) == NULL)
	return (NULL);
    mgr->disp = disp;
    mgr->parent = window;
    mgr->pane = NULL;
#ifdef USE_SHAPE
    mgr->width = 0;
    mgr->height = 0;
#endif
    return (mgr);
}

void
FreeSylLayoutManager(SylLayoutManager *mgr)
{
    FreeSylPanedList(mgr->pane);
    free(mgr);
}

static void
setglue(int n_fill_panes, int glue, int *ext, int *rem)
{
    *ext = (n_fill_panes > 0) ? glue / n_fill_panes : 0;
    *rem = (n_fill_panes > 0) ? glue % n_fill_panes : 0;
}

static int
getglue(int ext, int rem, int n)
{
    return (ext + (n < rem));
}

static void ConfigureSylPane(SylPane *, int, int, int, int);

static void
NormalConfigure(SylPane *pane, int glue,
		int *x, int *y, int *width, int *height, int *loc, int *len)
{
    int n, q, r, n_expandings, minimum, maximum;
    SylPane *ptr;

    n_expandings = 0;
    for (ptr = pane->list.top; ptr != NULL; ptr = ptr->any.next) {
	if ((ptr->any.expanding = pane->list.is_variable(ptr)) == True) {
	    ++n_expandings;
	}
    }
    
    do {
	setglue(n_expandings, glue, &q, &r);
	for (n = 0, ptr = pane->list.top; ptr != NULL; ptr = ptr->any.next) {
	    if (ptr->any.expanding) {
		maximum = pane->list.maximum(ptr);
		minimum = pane->list.minimum(ptr);
		if (maximum > 0 && maximum < minimum + getglue(q, r, n++)) {
		    glue -= maximum - minimum;
		    ptr->any.expanding = False;
		    --n_expandings;
		    break;
		}
	    }
	}
    } while (ptr != NULL);

    for (n = 0, ptr = pane->list.top; ptr != NULL; ptr = ptr->any.next) {
	*len = (ptr->any.expanding)
	    ? pane->list.minimum(ptr) + getglue(q, r, n++)
	    : pane->list.maximum(ptr);
	ConfigureSylPane(ptr, *x, *y, *width, *height);
	*loc += SYL_LAYOUT_SEP + *len;
    }
}

static void
CollapseConfigure(SylPane *pane, int *x, int *y, int *width, int *height,
		  int *loc, int *len)
{
    int sum, rem, sep, n, minimum = pane->list.minimum(pane);
    SylPane *ptr;

    sum = 0;
    for (n = 0, ptr = pane->list.top; ptr != NULL; ++n, ptr = ptr->any.next) {
	ptr->any.expanding = *len * pane->list.minimum(ptr) / minimum;
	sum += ptr->any.expanding;
    }
    sep = *len * SYL_LAYOUT_SEP / minimum;
    if (n > 0)
	sum += (n - 1) * sep;
    rem = *len - sum;
    for (ptr = pane->list.top; rem > 0 && ptr != NULL; ptr = ptr->any.next) {
	++ptr->any.expanding;
	--rem;
    }
    for (ptr = pane->list.top; ptr != NULL; ptr = ptr->any.next) {
	*len = ptr->any.expanding;
	ConfigureSylPane(ptr, *x, *y, *width, *height);
	*loc += sep + *len;
	if (rem > 0) {
	    ++(*loc);
	    --rem;
	}
    }
}    

static void
ConfigureSylPane(SylPane *pane, int x, int y, int w, int h)
{
    int glue;

    switch (pane->any.type) {
    case SYL_PANED_WINDOW:
	if (w > 0 && h > 0 && pane->pane.window != None)
	    XMoveResizeWindow(pane->pane.disp, pane->pane.window, x, y, w, h);
	break;
    case SYL_PANED_VERTICAL:
	if ((glue = h - pane->any.min_height) >= 0)
	    NormalConfigure(pane, glue, &x, &y, &w, &h, &y, &h);
	else
	    CollapseConfigure(pane, &x, &y, &w, &h, &y, &h);
	break;
    case SYL_PANED_HORIZONTAL:
	if ((glue = w - pane->any.min_width) >= 0)
	    NormalConfigure(pane, glue, &x, &y, &w, &h, &x, &w);
	else
	    CollapseConfigure(pane, &x, &y, &w, &h, &x, &w);
	break;
    }
}

#ifdef USE_SHAPE	      
static void
SetShapeMask(SylLayoutManager *mgr)
{
    int n, n_children;
    Window r, p, *child;
    XWindowAttributes attr;

    mgr->shape_mask = XCreatePixmap(mgr->disp, mgr->parent,
				    mgr->width, mgr->height, 1);
    mgr->shape_gc = XCreateGC(mgr->disp, mgr->shape_mask, 0, 0);
    XSetForeground(mgr->disp, mgr->shape_gc, 0);
    XFillRectangle(mgr->disp, mgr->shape_mask, mgr->shape_gc,
		   0, 0, mgr->width, mgr->height);
    if (XQueryTree(mgr->disp, mgr->parent, &r, &p, &child, &n_children)) {
	for (n = 0; n < n_children; ++n) {
	    XGetWindowAttributes(mgr->disp, child[n], &attr);
	    XSetForeground(mgr->disp, mgr->shape_gc, 1);
	    XFillRectangle(mgr->disp, mgr->shape_mask, mgr->shape_gc,
			   attr.x, attr.y, attr.width, attr.height);
	}
    }
    XShapeCombineMask(mgr->disp, mgr->parent, ShapeBounding, 0, 0,
		      mgr->shape_mask, ShapeSet);
    if (child != NULL)
	XFree(child);
    XFreeGC(mgr->disp, mgr->shape_gc);
    XFreePixmap(mgr->disp, mgr->shape_mask);
}
#endif

void
SetOrderSylLayoutManager(SylLayoutManager *mgr, SylPane *pane)
{
    XWindowAttributes attr;

    mgr->pane = pane;
    XGetWindowAttributes(mgr->disp, mgr->parent, &attr); 
    ConfigureSylPane(mgr->pane, 0, 0, attr.width, attr.height);
#ifdef USE_SHAPE	      
    mgr->width = attr.width;
    mgr->height = attr.height;
    SetShapeMask(mgr);
#endif
}

void
SendSylLayoutManager(SylLayoutManager *mgr, XEvent *ev)
{
    switch (ev->type) {
    case ConfigureNotify:
        if (ev->xconfigure.window != mgr->parent)
	    break;
	ConfigureSylPane(mgr->pane, 0, 0,
			 ev->xconfigure.width, ev->xconfigure.height);
#ifdef USE_SHAPE	    
	if (mgr->width == ev->xconfigure.width
	    && mgr->height == ev->xconfigure.height)
	    break;
	mgr->width = ev->xconfigure.width;
	mgr->height = ev->xconfigure.height;
	SetShapeMask(mgr);
#endif
	break;
    }
}
