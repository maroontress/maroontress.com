typedef struct SylPixmapQueue {
    Pixmap pixmap;
    struct SylPixmapQueue *next;
} SylPixmapQueue;

typedef struct SylPixmapQueueSet {
    Display *disp;
    Window window;
    int width;
    int height;
    int depth;
    SylPixmapQueue *using_top;
    SylPixmapQueue *empty_top;
} SylPixmapQueueSet;

SylPixmapQueueSet * CreateSylPixmapQueueSet(Display *, Window, int, int);
void FreeSylPixmapQueueSet(SylPixmapQueueSet *);
int PutSylPixmapQueueSet(SylPixmapQueueSet *, Pixmap, int, int);
Pixmap GetSylPixmapQueueSet(SylPixmapQueueSet *);
void ReconfigureSylPixmapQueueSet(SylPixmapQueueSet *, int, int);
