/*
	$Id: WCString.c,v 1.1 2000/10/03 18:45:23 syl Exp $

	Copyright (C) 1998, 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>

#include "WCString.h"

int
wstrlen(wchar_t *str)
{
    int n;
    
    for (n = 0; *str; ++n)
	++str;
    return (n);
}

wchar_t *
wstrcpy(wchar_t *d, wchar_t *s)
{
    wchar_t *p = d;

    while ((*d = *s) != 0) {
	++d;
	++s;
    }
    return (p);
}

wchar_t *
wstrncpy(wchar_t *d, wchar_t *s, int n)
{
    wchar_t *p = d;

    while ((*d = *s) != 0 && n > 0) {
	++d;
	++s;
	--n;
    }
    return (p);
}

int
wstrcmp(wchar_t *s, wchar_t *t)
{
    while (*s != 0) {
	if (*s != *t)
	    return (*s - *t);
	++s;
	++t;
    }
    return (-*t);
}
