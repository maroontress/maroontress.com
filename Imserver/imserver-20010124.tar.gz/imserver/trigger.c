/*
	$Id: trigger.c,v 1.1 2000/10/03 18:45:29 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "xim.h"
#include "strparse.h"
#include "trigger.h"

#define BUF_SIZE 64
static char Keyword[BUF_SIZE];
static char *Reserved[] = {"keysym", "modifier", "mask", NULL};

typedef struct {
    char *name;
    unsigned int code;
} ModifierTable;

static ModifierTable Modifier[] = {
    {"None", 0}, {"Shift", ShiftMask}, {"Control", ControlMask},
    {"Mod1", Mod1Mask}, {"Mod2", Mod2Mask}, {"Mod3", Mod3Mask},
    {"Mod4", Mod4Mask}, {"Mod5", Mod5Mask}};
#define N_MODIFIERS (sizeof(Modifier) / sizeof(ModifierTable))

static int
StringToModifier(char *name, CARD32 *mod)
{
    unsigned int n;

    for (n = 0; n < N_MODIFIERS; ++n) {
        if (strcmp(Modifier[n].name, name) == 0) {
            *mod |= Modifier[n].code;
            return (1);
        }
    }
    return (0);
}

typedef enum {
    SUCCESS, UNEXPECTED_EOS, PARSE_ERROR, UNKNOWN_KEYSYM, UNKNOWN_MODIFIER,
    UNKNOWN_MASK
} Result;

static int
GetNextWord(StrParse *p, char *w)
{
    int type;

    while ((type = GetToken(p, w, NULL)) == STR_PARSE_EMPTYLINES)
        ;
    return (type);
}

static Result
GetTriggerKey(StrParse *p, XIMTRIGGERKEY *t)
{
    int type;
    char *w = Keyword;

    t->modifier = 0;
    t->mask = 0;
    if ((type = GetNextWord(p, w)) == EOF)
	return (UNEXPECTED_EOS);
    else if (type != STR_PARSE_RESERVED || strcmp(w, "keysym") != 0)
	return (PARSE_ERROR);
    else if ((type = GetNextWord(p, w)) == EOF)
	return (UNEXPECTED_EOS);
    else if ((t->keysym = XStringToKeysym(w)) == NoSymbol)
	return (UNKNOWN_KEYSYM);
    else if ((type = GetNextWord(p, w)) != EOF) {
	if (strcmp(w, "modifier") == 0) {
	    do {
		if ((type = GetNextWord(p, w)) == EOF)
		    return (UNEXPECTED_EOS);
		else if (StringToModifier(w, &(t->modifier)) == 0)
		    return (UNKNOWN_MODIFIER);
		else if ((type = GetNextWord(p, w)) == EOF)
		    return (SUCCESS);
	    } while (strcmp(w, "-") == 0);
	}
	if (strcmp(w, "mask") == 0) {
	    do {
		if ((type = GetNextWord(p, w)) == EOF)
		    return (UNEXPECTED_EOS);
		else if (StringToModifier(w, &(t->mask)) == 0)
		    return (UNKNOWN_MASK);
		else if ((type = GetNextWord(p, w)) == EOF)
		    return (SUCCESS);
	    } while (strcmp(w, "-") == 0);
	}
	return (PARSE_ERROR);
    }
    return (SUCCESS);
}

void
LoadTriggerKeys(Display *disp, char *name, char *class,
		SylSetting *key, XIMTRIGGERKEY *tri)
{
    StrParse *p;

    GetSylSetting(disp, name, class, key);
    if ((p = OpenStrParse(key->spec, BUF_SIZE, Reserved)) == NULL) {
	fprintf(stderr, "%s.%s: line %d, too short memory.\n",
		name, key->name, p->line);
	return;
    }
    switch (GetTriggerKey(p, tri)) {
    case SUCCESS:
	break;
    case UNEXPECTED_EOS:
	fprintf(stderr, "%s.%s: line %d, unexpected EOS.\n",
		name, key->name, p->line);
	break;
    case PARSE_ERROR:
	fprintf(stderr, "%s.%s: line %d, parse error `%s'.\n",
		name, key->name, p->line, Keyword);
	break;
    case UNKNOWN_KEYSYM:
	fprintf(stderr, "%s.%s: line %d, unknown keysym `%s'.\n",
		name, key->name, p->line, Keyword);
	break;
    case UNKNOWN_MODIFIER:
	fprintf(stderr, "%s.%s: line %d, unknown modifier `%s'.\n",
		name, key->name, p->line, Keyword);
	break;
    case UNKNOWN_MASK:
	fprintf(stderr, "%s.%s: line %d, unknown mask `%s'.\n",
		name, key->name, p->line, Keyword);
	break;
    }
    CloseStrParse(p);
}
