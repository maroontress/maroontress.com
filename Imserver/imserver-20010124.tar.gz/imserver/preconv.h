/*
	$Id: preconv.h,v 1.1 2000/10/03 18:45:27 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void LoadPreconversionMapping(Display *, char *, char *, SylSetting *);
int Preconvert(SylText *txt, int caret, int *back, int *forward);
