/*
	$Id: status.h,v 1.1 2000/10/03 18:45:28 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void DrawStatusWindow(Display *, InputContext *);
void RaiseStatusWindow(Display *, InputContext *);
