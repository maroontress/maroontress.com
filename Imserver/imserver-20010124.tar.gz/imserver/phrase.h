/*
	$Id: phrase.h,v 1.1 2000/10/03 18:45:27 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

typedef struct Candidate {
    struct Candidate *next;
    SylText *applicant;
} Candidate;

typedef struct Phrase {
    struct Phrase *next;
    struct Phrase *prev;
    int offset;         /* �ɤ�ʸ�������ʸ�ᳫ�ϰ��� */
    int length;         /* �ɤ�ʸ������θ��ߤ�ʸ��ʸ���� */
    int original;       /* �ɤ�ʸ������ν����ʸ��ʸ���� */
    SylText *chosen;    /* ɽ������Ƥ������ʸ���� */
    SylText *applicant; /* ���ߤ�ñʸ�����ʸ���� */
    Candidate *top;     /* ñʸ�����ꥹ�� */
} Phrase;

Candidate *CreateCandidate(SylText *);
void FreeCandidate(Candidate *);

Phrase * CreatePhrase(SylText *, int bgn, int end);
Phrase * CreateSinglePhrase(SylText *, int bgn, int end);
Phrase * CreateKatakanaPhrase(SylText *, int bgn, int end);
Phrase * CreateHiraganaPhrase(SylText *, int bgn, int end);
Phrase * CreateHankakuPhrase(SylText *, int bgn, int end);
Phrase * CreateZenkakuPhrase(SylText *, int bgn, int end);
void FreePhrase(Phrase *);

int BeginningOfPhrase(Phrase *, Phrase *);
int LengthOfPhrase(Phrase *);
int CaretPositionOfPhrase(Phrase *, Phrase *);
wchar_t * CreateWCStringFromPhrase(Phrase *);
CARD32 * CreateFeedbackFromPhrase(Phrase *, Phrase *);
void ChangeNextRankOfPhrase(Phrase *, SylText *);
void ChangePrevRankOfPhrase(Phrase *, SylText *);
void StudyPhrase(Phrase *head, SylText *txt);
Phrase * ShortenPhrase(Phrase *view, SylText *txt);
Phrase * LengthenPhrase(Phrase *view, SylText *txt);
void ChangeKatakanaPhrase(Phrase *p, SylText *txt);
void ChangeHiraganaPhrase(Phrase *p, SylText *txt);
void ChangeHankakuPhrase(Phrase *p, SylText *txt);
void ChangeZenkakuPhrase(Phrase *p, SylText *txt);
