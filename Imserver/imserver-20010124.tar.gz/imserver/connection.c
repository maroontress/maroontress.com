/*
	$Id: connection.c,v 1.3 2001/01/23 14:46:55 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "connection.h"
#include "leakdetect.h"

InputContext *
CreateInputContext(Connection *con)
{
    InputContext *ic;

    if (con->idle == NULL) {
	if (con->next_ic_id > 0xffff)
	    return (NULL);
	if ((ic = (InputContext *)ldmalloc(sizeof(InputContext))) == NULL)
	    return (NULL);
	ic->ic_id = con->next_ic_id;
	++(con->next_ic_id);
    }
    else {
	ic = con->idle;
	con->idle = ic->next;
    }
    ic->next = con->work;
    ic->input_style = 0;
    ic->client_window = None;
    ic->focus_window = None;
    ic->preedit_window = None;
    ic->preedit_fontset.id = NULL;
    ic->preedit_fontset_name = NULL;
    ic->preedit_foreground = BlackPixel(con->disp, DefaultScreen(con->disp));
    ic->preedit_background = WhitePixel(con->disp, DefaultScreen(con->disp));
    ic->preedit_spot_location.x = 0;
    ic->preedit_spot_location.y = 0;
    ic->status_window = None;
    ic->status_gc = None;
    ic->status_fontset.id = NULL;
    ic->status_fontset_name = NULL;
    ic->status_foreground = BlackPixel(con->disp, DefaultScreen(con->disp));
    ic->status_background = WhitePixel(con->disp, DefaultScreen(con->disp));
    ic->status_area.x = 0;
    ic->status_area.y = 0;
    ic->status_area.width = 0;
    ic->status_area.height = 0;
    ic->candidate_window = None;
    ic->candidate_fontset = NULL;
    ic->forward = False;
    ic->focus = False;
    ic->romaji = False;
    ic->max_preedit_chars = 0;
    ic->preedit = CreateSylTextFromMBString("", False);
    ic->fixed = CreateSylTextFromMBString("", False);
    ic->caret = 0;
    ic->head = NULL;
    ic->view = NULL;
    ic->preedit_draw = NULL;
    con->work = ic;
    return (ic);
}

InputContext *
SerachInputContext(Connection *con, int ic_id)
{
    InputContext *p;

    for (p = con->work; p != NULL && p->ic_id != ic_id; p = p->next)
	;
    return (p);
}

static void
DestroyInputContext(Connection *con, InputContext *ic, int destroyed)
{
    ic->preedit_draw->focus_out(con, ic);
    if (ic->preedit_window != None)
	XDeleteContext(con->disp, ic->preedit_window, con->preedit);
    if (ic->status_window != None && !destroyed)
	XDestroyWindow(con->disp, ic->preedit_window);
    if (ic->preedit_fontset.id != NULL)
	XFreeFontSet(con->disp, ic->preedit_fontset.id);
    if (ic->preedit_fontset_name != NULL)
	free(ic->preedit_fontset_name);
    if (ic->status_fontset.id != NULL)
	XFreeFontSet(con->disp, ic->status_fontset.id);
    if (ic->status_fontset_name != NULL)
	free(ic->status_fontset_name);
    if (ic->status_window != None)
	XDeleteContext(con->disp, ic->status_window, con->status);
    if (ic->status_window != None && !destroyed)
	XDestroyWindow(con->disp, ic->status_window);
    if (ic->status_gc != None)
	XFreeGC(con->disp, ic->status_gc);
    if (ic->candidate_window != None)
	XDeleteContext(con->disp, ic->candidate_window, con->candidate);
    if (ic->candidate_window != None && !destroyed)
	XDestroyWindow(con->disp, ic->candidate_window);
    FreeSylText(ic->preedit);
    FreeSylText(ic->fixed);
    FreePhrase(ic->head);
}

void
FreeInputContext(Connection *con, int ic_id)
{
    InputContext *ic, *p;

    if ((ic = SerachInputContext(con, ic_id)) == NULL)
	return;
    if (con->work == ic) {
	con->work = ic->next;
    }
    else {
	for (p = con->work; p->next != ic; p = p->next)
	    ;
	p->next = ic->next;
    }
    DestroyInputContext(con, ic, False);
    ic->next = con->idle;
    con->idle = ic;
}

static int NextID = 1;
static Connection *Work = NULL;
static Connection *Idle = NULL;

Connection *
CreateConnection(XClientMessageEvent *msg)
{
    Connection *con;

    if (Idle == NULL) {
	if (NextID > 0xffff)
	    return (NULL);
	if ((con = (Connection *)ldmalloc(sizeof(Connection))) == NULL)
	    return (NULL);
	con->im_id = NextID;
	++NextID;
    }
    else {
	con = Idle;
	Idle = con->next;
    }
    con->next = Work;
    con->disp = msg->display;
    con->client = (Window)msg->data.l[0];
    con->server = XCreateSimpleWindow(con->disp, con->client,
				      0, 0, 1, 1, 0, 0, 0);
    XSelectInput(con->disp, con->server, StructureNotifyMask);
    con->work = NULL;
    con->idle = NULL;
    con->next_ic_id = 1;
    Work = con;
    return (con);
}

void
FreeConnection(Connection *con)
{
    InputContext *p, *next;
    Connection *q;

    for (p = con->work; p != NULL; p = next) {
	next = p->next;
	DestroyInputContext(con, p, True);
	ldfree(p);
    }
    for (p = con->idle; p != NULL; p = next) {
	next = p->next;
	ldfree(p);
    }
    /* con->server���˲�����롣 */
    if (Work == con) {
	Work = con->next;
    }
    else {
	for (q = Work; q->next != con; q = q->next)
	    ;
	q->next = con->next;
    }
    con->next = Idle;
    Idle = con;
}
