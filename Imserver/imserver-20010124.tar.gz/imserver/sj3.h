/*
	$Id: sj3.h,v 1.1 2000/10/03 18:45:28 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

int OpenConversionServerWithSj3(char *);
void CloseConversionServerWithSj3(void);
void ChangeNextRankOfPhraseWithSJ3(Phrase *, wchar_t *);
void ChangePrevRankOfPhraseWithSJ3(Phrase *, wchar_t *);
Phrase * ConvertSinglePhraseWithSJ3(wchar_t *, int offset, int length);
Phrase * ConvertWithSJ3(wchar_t *, int offset);
void StudyPhraseWithSJ3(Phrase *, wchar_t *);
void StudyPairOfPhraseWithSJ3(Phrase *, wchar_t *, wchar_t *);
