/*
	$Id: status.c,v 1.1 2000/10/03 18:45:28 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdio.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "phrase.h"
#include "connection.h"
#include "status.h"

void
DrawStatusWindow(Display *disp, InputContext *ic)
{
    unsigned char buf[256];

    if (ic->status_window == None)
	return;
    if (ic->forward) {
	sprintf(buf, " %s%s ", 
		(ic->head == NULL ? "����" : "�Ѵ�"),
		(ic->romaji ? "R" : ""));
    }
    else {
	sprintf(buf, " Off ");
    }
    XSetForeground(disp, ic->status_gc, ic->status_background);
    XFillRectangle(disp, ic->status_window, ic->status_gc, 0, 0,
		   ic->status_area.width, ic->status_area.height);
    XSetForeground(disp, ic->status_gc, ic->status_foreground);
    XmbDrawString(disp, ic->status_window, ic->status_fontset.id,
		  ic->status_gc, 0, ic->status_fontset.ascent,
		  buf, strlen(buf));
}

void
RaiseStatusWindow(Display *disp, InputContext *ic)
{
    if (ic->status_window == None)
	return;
    XRaiseWindow(disp, ic->status_window);
}
