/*
	$Id: undofix.h,v 1.1 2000/10/03 18:45:29 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

extern void (*UndofixBranch[])(Connection *, InputContext *,
			       XIM_FORWARD_EVENT *);
