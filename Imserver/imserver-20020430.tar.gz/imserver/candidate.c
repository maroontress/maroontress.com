/*
	$Id: candidate.c,v 1.5 2001/05/23 14:32:07 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "phrase.h"
#include "connection.h"
#include "candidate.h"

static void
GetSize(Display *disp, Window window, int *width, int *height, int *border)
{
    XWindowAttributes parent;
    
    XGetWindowAttributes(disp, window, &parent);
    if ((*width = parent.width - 2) <= 0)
	*width = 2;
    if ((*height = parent.height - 2) <= 0)
	*height = 2;
    *border = 1;
}

Window
CreateCandidateWindow(Display *disp, Window parent)
{
    int screen, width, height, border;
    Window window;
    XSetWindowAttributes attr;

    screen = DefaultScreen(disp);
    GetSize(disp, parent, &width, &height, &border);
    window = XCreateSimpleWindow(disp, parent, 0, 0, width, height, border,
				 BlackPixel(disp, screen),
				 WhitePixel(disp, screen));
    attr.override_redirect = True;
    XChangeWindowAttributes(disp, window, CWOverrideRedirect, &attr);
    XSelectInput(disp, window, ExposureMask | StructureNotifyMask);
    return (window);
}

static Window
ParentWindow(Display *disp, Window window)
{
    Window root, parent, *childp;
    unsigned int children;

    if (XQueryTree(disp, window, &root, &parent, &childp, &children))
        XFree(childp);
    return (parent);
}

static int
MaximumWidth(InputContext *ic)
{
    int w, width, off, len;
    Candidate *c;

    off = ic->view->offset;
    len = ic->view->length;
    width = SylTextEscapement(ic->candidate_fontset->id, ic->preedit,
			      off, off + len);
    for (c = ic->view->top; c != NULL; c = c->next) {
	w = SylTextEscapement0(ic->candidate_fontset->id, c->applicant);
	if (w > width) {
	    width = w;
	}
    }
    return (width);
}

void
ResizeCandidateWindow(Display *disp, InputContext *ic)
{
    int width, height, border;
    int escapement, minimum;

    GetSize(disp, ParentWindow(disp, ic->candidate_window), &width, &height,
	    &border);
    if (ic->view != NULL) {
	escapement = MaximumWidth(ic);
	minimum = XmbTextEscapement(ic->candidate_fontset->id, "000/000", 7);
	if (escapement < minimum)
	    escapement = minimum;
	if (escapement < width)
	    width = escapement;
    }
    XResizeWindow(disp, ic->candidate_window, width, height);
}

static Candidate *
TopOfPage(InputContext *ic, int n_lines, int *page, int *line, int *n_pages)
{
    Phrase *v = ic->view;
    Candidate *p, *top = v->top;
    int n;
    
    n = 0;
    for (p = top; p && CompareSylText(p->applicant, v->chosen); p = p->next) {
	if ((++n % n_lines) == 0) {
	    top = p->next;
	}
    }
    if (p == NULL) {
        /* ���ꤨ�ʤ������ݸ� */
	return (NULL);
    }
    *page = n / n_lines;
    *line = n % n_lines;
    for (; p != NULL; p = p->next) {
	++n;
    }
    *n_pages = (n - 1) / n_lines;
    return (top);
}

static void
DrawPage(Display *disp, Drawable d, SylFontSet *fs, GC gc,
	 int width, int height, Candidate *p, int line, int n_lines)
{
    int n, y, fg, bg;

    fg = BlackPixel(disp, DefaultScreen(disp));
    bg = WhitePixel(disp, DefaultScreen(disp));
    y = fs->ascent;
    for (n = 0; p != NULL && n < n_lines; ++n, p = p->next) {
	XSetForeground(disp, gc, (n == line) ? fg : bg);
	XFillRectangle(disp, d, gc, 0, y - fs->ascent, width, fs->height);
	XSetForeground(disp, gc, (n == line) ? bg : fg);
	DrawSylText0(disp, d, fs->id, gc, 0, y, p->applicant);
	y += fs->height;
    }
    y -= fs->ascent;
    XSetForeground(disp, gc, bg);
    XFillRectangle(disp, d, gc, 0, y, width, height - y);
}

static void
DrawFoot(Display *disp, Drawable d, SylFontSet *fs, GC gc,
	 int width, int height, int page, int n_pages)
{
    int len;
    char buf[32];

    sprintf(buf, "%d/%d", page + 1, n_pages + 1);
    len = strlen(buf);
    width -= XmbTextEscapement(fs->id, buf, len);
    XSetForeground(disp, gc, BlackPixel(disp, DefaultScreen(disp)));
    XmbDrawString(disp, d, fs->id, gc, width, height - fs->descent, buf, len);
}

void
DrawCandidateWindow(Display *disp, InputContext *ic)
{
    Candidate *top;
    int line, page, n_lines, n_pages;
    XWindowAttributes attr;
    GC gc = DefaultGC(disp, DefaultScreen(disp));

    XGetWindowAttributes(disp, ic->candidate_window, &attr);

    if ((n_lines = attr.height / ic->candidate_fontset->height - 1) <= 0)
	n_lines = 1;
    if ((top = TopOfPage(ic, n_lines, &page, &line, &n_pages)) == NULL)
	return;

    DrawPage(disp, ic->candidate_window, ic->candidate_fontset, gc,
	     attr.width, attr.height, top, line, n_lines);
    DrawFoot(disp, ic->candidate_window, ic->candidate_fontset, gc,
	     attr.width, attr.height, page, n_pages);
}
