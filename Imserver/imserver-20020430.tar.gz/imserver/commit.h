/*
	$Id: commit.h,v 1.1 2000/10/03 18:45:24 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void ClearString(Connection *con, InputContext *ic);
void CommitString(Connection *con, InputContext *ic);
void EchoXIMForwardEvent(Connection *con, XIM_FORWARD_EVENT *ev);
