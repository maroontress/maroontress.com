/*
	$Id: engine.h,v 1.1 2001/05/23 14:00:44 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

typedef struct {
    int (*open)(char *);
    void (*close)(void);
    Phrase * (*convert)(wchar_t *, int);
    Phrase * (*convert_single_phrase)(wchar_t *, int, int);
    void (*get_candidate_list)(Phrase *, wchar_t *);
    void (*study)(Phrase *, SylText *);
} Engine;

int OpenEngine(char *);
void CloseEngine(void);
void ChangeNextRankOfPhraseWithEngine(Phrase *, wchar_t *);
void ChangePrevRankOfPhraseWithEngine(Phrase *, wchar_t *);
Phrase * ConvertSinglePhraseWithEngine(wchar_t *, int, int);
Phrase * ConvertWithEngine(wchar_t *, int);
void StudyPhraseWithEngine(Phrase *, SylText *);
