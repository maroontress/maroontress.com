#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h"
#include "message.h"
#include "status.h"
#include "commit.h"
#include "preconv.h"
#include "preedit.h"

static unsigned char *
KanaToMBSrting(unsigned char c)
{
    static unsigned char *table[] = {
	/* */ "��", "��", "��", "��", "��", "��", "��",
        "��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��"};
    c -= 0xa1;
    return (table[c]);
}

static wchar_t
VoicedSound(wchar_t w)
{
    static char *before[] = {
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", NULL};
    static char *after[] = {
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", NULL};
    char **ptr;
    wchar_t c;
    int n;

    for (n = 0, ptr = before; *ptr != NULL; ++n, ++ptr) {
	mbtowc(&c, *ptr, 2);
	if (c == w) {
	    mbtowc(&w, after[n], 2);
	    return (w);
	}
    }
    return (0);
}

static wchar_t
SemivoicedSound(wchar_t w)
{
    static char *before[] = {"��", "��", "��", "��", "��", NULL};
    static char *after[] = {"��", "��", "��", "��", "��", NULL};
    char **ptr;
    wchar_t c;
    int n;

    for (n = 0, ptr = before; *ptr != NULL; ++n, ++ptr) {
	mbtowc(&c, *ptr, 2);
	if (c == w) {
	    mbtowc(&w, after[n], 2);
	    return (w);
	}
    }
    return (0);
}

static void
PreeditDrawWChar(Connection *con, InputContext *ic, wchar_t w,
		 int chg_first, int chg_length)
{
    CARD32 Underline = 2;
    XTextProperty t;
    wchar_t buf[2], *wcs = buf;
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    
    buf[0] = w;
    buf[1] = 0;
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = 1;
    xim_preedit_draw.feedback.val = &Underline;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    XFree(t.value); /* XwcTextListToTextProperty() */
}

static void
PreeditDrawWCString(Connection *con, InputContext *ic,
		    int chg_first, int chg_length)
{
    const CARD32 Underline = 2;
    XTextProperty t;
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int n, len;
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(ic->preedit, chg_first, ic->caret);
    len = ic->caret - chg_first;
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = ldmalloc(sizeof(CARD32) * len);
    for (n = 0; n < len; ++n)
	xim_preedit_draw.feedback.val[n] = Underline;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    ldfree(xim_preedit_draw.feedback.val);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText() */
}

void
PreeditInsertChar(XIM_FORWARD_EVENT *ev, Connection *con, unsigned char *buf)
{ 
    const int TenTen = 0xde; /* "��" */
    const int Maru = 0xdf; /* "��" */
    wchar_t w, snd, *wcs;
    int chg_first, chg_length, back, forward;
    InputContext *ic;

    if ((ic = SerachInputContext(con, ev->ic_id)) == NULL)
	return;
    if (ic->head != NULL) {
	ClearString(con, ic); 
	EchoXIMForwardEvent(con, ev);
	CommitString(con, ic);
	return;
    }
    if (0xa1 <= *buf && *buf <= 0xdf)
	mbtowc(&w, KanaToMBSrting(*buf), 2);
    else
	w = *buf;
    chg_first = ic->caret;
    chg_length = 0;
    if (ic->caret > 0) {
	wcs = CreateWCStringFromSylText(ic->preedit, ic->caret - 1, ic->caret);
	if ((*buf == TenTen && (snd = VoicedSound(*wcs)) != 0)
	    || ((*buf == Maru && (snd = SemivoicedSound(*wcs)) != 0))) {
	    --(ic->caret);
	    DeleteWCharOfSylText(ic->preedit, ic->caret);
	    w = snd;
	    chg_first = ic->caret;
	    chg_length = 1;
	}
	free(wcs); /* CreateWCStringFromSylText() */
    }
    InsertWCharIntoSylText(ic->preedit, ic->caret, w);
    ++(ic->caret);
    if (ic->romaji == True
	&& Preconvert(ic->preedit, ic->caret, &back, &forward)) {
	chg_first -= back - 1;
	chg_length += back - 1;
	ic->caret += (forward - back);
	PreeditDrawWCString(con, ic, chg_first, chg_length);
    }
    else {
	PreeditDrawWChar(con, ic, w, chg_first, chg_length);
    }
}

static void
PreeditSpecifiedConvert(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev,
			Phrase *(*create_phrase)(SylText *, int, int))
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;

    ic->head = create_phrase(ic->preedit, 0, LengthOfSylText(ic->preedit));
    ic->view = ic->head;
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);
    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view);

    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfSylText(ic->preedit);
    /*
      BUG: ����status��NO_STRING (1) �ӥåȤ򥻥åȤ�����硢���饤�����
      ¦��XIMPreeditDrawCallbackStruct�Υ���text��NULL�ˤʤäƤ��ޤ���
      ������xc/lib/X11/imCallbk.c�δؿ�_read_text_from_packet()�ΥХ���
    */
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
    DrawStatusWindow(con->disp, ic);
}

static void
PreeditConvert(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    PreeditSpecifiedConvert(con, ic, ev, CreatePhrase);
}

static void
PreeditConvertSingle(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    PreeditSpecifiedConvert(con, ic, ev, CreateSinglePhrase);
}

static void
PreeditHiragana(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    PreeditSpecifiedConvert(con, ic, ev, CreateHiraganaPhrase);
}

static void
PreeditKatakana(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    PreeditSpecifiedConvert(con, ic, ev, CreateKatakanaPhrase);
}

static void
PreeditZenkaku(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    PreeditSpecifiedConvert(con, ic, ev, CreateZenkakuPhrase);
}

static void
PreeditHankaku(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    PreeditSpecifiedConvert(con, ic, ev, CreateHankakuPhrase);
}

static void
PreeditBackSpace(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;

    if (ic->caret <= 0)
	return;
    --(ic->caret);
    DeleteWCharOfSylText(ic->preedit, ic->caret);
    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 1;
    xim_preedit_draw.status = 1 & 2; /* NO_STRING & NO_FEEDBACK */
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
PreeditDelete(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;

    if (ic->caret == LengthOfSylText(ic->preedit))
	return;
    DeleteWCharOfSylText(ic->preedit, ic->caret);
    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 1;
    xim_preedit_draw.status = 1 & 2; /* NO_STRING & NO_FEEDBACK */
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
PreeditMoveCaret(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;

    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 0;
    xim_preedit_draw.status = 1 & 2; /* NO_STRING & NO_FEEDBACK */
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
PreeditCaretRight(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    if (ic->caret >= LengthOfSylText(ic->preedit))
	return;
    ++(ic->caret);
    PreeditMoveCaret(con, ic, ev);
}

static void
PreeditCaretLeft(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    if (ic->caret <= 0)
	return;
    --(ic->caret);
    PreeditMoveCaret(con, ic, ev);
}

static void
PreeditCaretHead(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    if (ic->caret <= 0)
	return;
    ic->caret = 0;
    PreeditMoveCaret(con, ic, ev);
}

static void
PreeditCaretTail(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    if (ic->caret >= LengthOfSylText(ic->preedit))
	return;
    ic->caret = LengthOfSylText(ic->preedit);
    PreeditMoveCaret(con, ic, ev);
}

static void
PreeditLineFeed(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ClearString(con, ic); 
    EchoXIMForwardEvent(con, ev);
    CommitString(con, ic);
}

static void
PreeditCommit(Connection *con, InputContext *ic,
	      XIM_FORWARD_EVENT *ev __unused)
{
    ClearString(con, ic); 
    CommitString(con, ic);
}

static void
RomajiHenkanMode(Connection *con, InputContext *ic,
		 XIM_FORWARD_EVENT *ev __unused)
{
    ic->romaji = True;
    DrawStatusWindow(con->disp, ic);
}

static void
DirectKanaInputMode(Connection *con, InputContext *ic,
		    XIM_FORWARD_EVENT *ev __unused)
{
    ic->romaji = False;
    DrawStatusWindow(con->disp, ic);
}

void (*PreeditBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverPreedit.branch"
};
