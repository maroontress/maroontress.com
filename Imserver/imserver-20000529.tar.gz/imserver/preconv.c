#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "preconv.h"

typedef struct Preconversion {
    struct Preconversion *next;
    wchar_t *src_wcs;
    int src_len;
    wchar_t *dst_wcs;
    int dst_len;
} Preconversion;

static Preconversion *Mapping = NULL;

static void
AddToPreconversionMapping(char *src, char *dst)
{
    Preconversion *map, *ptr;
    SylText *txt;

    /*printf("%s %s\n", src, dst);*/
    if ((map = (Preconversion *)malloc(sizeof(Preconversion))) == NULL)
	goto no_preconversion;
    map->next = NULL;
    if ((txt = CreateSylTextFromMBString(src, False)) == NULL)
	goto no_src_txt;
    map->src_len = LengthOfSylText(txt);
    map->src_wcs = CreateWCStringFromSylText(txt, 0, map->src_len);
    FreeSylText(txt);
    if ((txt = CreateSylTextFromMBString(dst, False)) == NULL)
	goto no_dst_txt;
    map->dst_len = LengthOfSylText(txt);
    map->dst_wcs = CreateWCStringFromSylText(txt, 0, map->dst_len);
    FreeSylText(txt);

    if (Mapping == NULL || Mapping->src_len <= map->src_len) {
	map->next = Mapping;
	Mapping = map;
    }
    else {
	for (ptr = Mapping; ptr->next != NULL; ptr = ptr->next) {
	    if (ptr->next->src_len <= map->src_len) {
		map->next = ptr->next;
		ptr->next = map;
		break;
	    }
	}
	if (ptr->next == NULL) {
	    ptr->next = map;
	}
    }
    return;

no_dst_txt:
    free(map->src_wcs);
no_src_txt:
    free(map);
no_preconversion:
    return;
}

typedef struct {
    char *ptr;
    int line;
} StringParse;

static int
GetChar(StringParse *p)
{
    int c;

    if ((c = *(p->ptr)) == 0)
	return (EOF);
    ++(p->ptr);
    if (c == '\n')
	++(p->line);
    return (c);
}

#if 0
static void
UngetChar(int c, StringParse *p)
{
    if (c != EOF)
	--(p->ptr);
}
#endif

static int
IsDelimiter(int c)
{
    return (strchr(" \t\n", c) != NULL);
}

#define BEGINNING_OF_STRING 0
#define EQUAL_OPERATOR 1
#define UNKNOWN_OPERATOR 2

static int
GetNextWord(StringParse *p, int *buf)
{
    int c;

    while ((c = GetChar(p)) != EOF && IsDelimiter(c))
	;
    if (c == EOF) {
	*buf = 0;
	return (EOF);
    }
    else if (c == '"') {
	*buf = c;
	return (BEGINNING_OF_STRING);
    }
    else if (c == '=') {
	*buf = c;
	return (EQUAL_OPERATOR);
    }
    *buf = c;
    return (UNKNOWN_OPERATOR);
}

static int
CreateString(StringParse *p, char **str)
{
    int n, len;
    char *ptr;

    for (len = 0, ptr = p->ptr; *ptr != 0; ++ptr) {
	if (*ptr == '"')
	    break;
	if (*ptr == '\\' && *++ptr == 0)
	    return (-1);
	++len;
    }
    if (*ptr != '"')
	return (-1);
    if ((*str = malloc(len + 1)) == NULL)
	return (len);
    for (ptr = p->ptr, n = 0; n < len; ++ptr, ++n) {
	if (*ptr == '\\')
	    ++ptr;
	(*str)[n] = *ptr;
    }
    (*str)[n] = 0;
    p->ptr = ptr + 1;
    return (len);
}

void
LoadPreconversionMapping(Display *disp, char *name, char *class,
			 SylSetting *map)
{
    StringParse p;
    int type, c;
    char *src, *dst;

    GetSylSetting(disp, name, class, map);
    p.ptr = map->spec;
    p.line = 1;
    while ((type = GetNextWord(&p, &c)) != EOF) {
	if (type != BEGINNING_OF_STRING) {
	    fprintf(stderr, "%s.%s: line %d, unexpected character `%c'.\n",
		    name, map->name, p.line, c);
	    break;
	}
	else if ((type = CreateString(&p, &src)) < 0) {
	    fprintf(stderr, "%s.%s: line %d, unterminated string.\n",
		    name, map->name, p.line);
	    break;
	}
	else if (src == NULL) {
	    fprintf(stderr, "%s.%s: line %d, too long string.\n",
		    name, map->name, p.line);
	    break;
	}
	else if (type == 0) {
	    fprintf(stderr, "%s.%s: line %d, zero-length string.\n",
		    name, map->name, p.line);
	    free(src);
	    break;
	}
	else if ((type = GetNextWord(&p, &c)) != EQUAL_OPERATOR) {
	    fprintf(stderr, "%s.%s: line %d, unexpected character `%c', "
		    "expected `='.\n", name, map->name, p.line, c);
	    free(src);
	    break;
	}
	else if ((type = GetNextWord(&p, &c)) != BEGINNING_OF_STRING) {
	    fprintf(stderr, "%s.%s: line %d, unexpected character `%c'.\n",
		    name, map->name, p.line, c);
	    free(src);
	    break;
	}
	else if ((type = CreateString(&p, &dst)) < 0) {
	    fprintf(stderr, "%s.%s: line %d, unterminated string.\n",
		    name, map->name, p.line);
	    free(src);
	    break;
	}
	else if (dst == NULL) {
	    fprintf(stderr, "%s.%s: line %d, too long string.\n",
		    name, map->name, p.line);
	    free(src);
	    break;
	}
	else if (type == 0) {
	    fprintf(stderr, "%s.%s: line %d, zero-length string.\n",
		    name, map->name, p.line);
	    free(src);
	    free(dst);
	    break;
	}
	AddToPreconversionMapping(src, dst);
	free(src);
	free(dst);
    }
}

static wchar_t *
FindMappedString(wchar_t *wcs, int len, int *srclen, int *dstlen)
{
    Preconversion *ptr;
    int m;

    for (ptr = Mapping; ptr != NULL; ptr = ptr->next) {
	if ((m = len - ptr->src_len) < 0)
	    continue;
	if (wstrcmp(wcs + m, ptr->src_wcs) == 0) {
	    *srclen = ptr->src_len;
	    *dstlen = ptr->dst_len;
	    return (ptr->dst_wcs);
	}
    }
    return (NULL);
}

int
Preconvert(SylText *txt, int caret, int *back, int *forward)
{
    wchar_t *wcs, *xch;

    wcs = CreateWCStringFromSylText(txt, 0, caret);
    if ((xch = FindMappedString(wcs, caret, back, forward)) == NULL) {
	free(wcs);
	return (False);
    }
    DeleteWCStringOfSylText(txt, caret - *back, caret);
    InsertWCStringIntoSylText(txt, caret - *back, xch);
    free(wcs);
    return (True);
}

#if 0
int
main(void)
{
    char src[256], dst[256];
    Preconversion *ptr;
    char *map = "\"a\" = \"��\"\n \"tsu\" = \"��\"\n \"i\" = \"��\"";

    LoadPreconversionMapping("imserver", "preconversionMapping", map);
    for (ptr = Mapping; ptr != NULL; ptr = ptr->next) {
	wcstombs(src, ptr->src_wcs, 256);
	wcstombs(dst, ptr->dst_wcs, 256);
	printf("%s %s\n", src, dst);
    }
    return (0);
}
#endif
