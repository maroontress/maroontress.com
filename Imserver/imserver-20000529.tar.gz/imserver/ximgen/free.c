/*
        free.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "free.h"

void
PrintFree(FILE *fp, PacketList *pl)
{
    Packet *ptr;

    fprintf(fp,
            "\n"
	    "void\n"
            "Free_SerializedPacket(SerializedPacket *p)\n"
	    "{\n"
	    "\t" "ldfree(p);\n"
	    "}\n"
	    "\n"
            "void\n"
            "Free_STR(STR *p)\n"
            "{\n"
	    "\t" "Release_STR(p);\n"
            "\t" "ldfree(p);\n"
            "}\n"
            "\n"
            "void\n"
            "Free_STRING(STRING *p)\n"
            "{\n"
	    "\t" "Release_STRING(p);\n"
            "\t" "ldfree(p);\n"
            "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
        if (ptr->head == NULL)
            continue;
        fprintf(fp,
                "\n"
                "void\n"
                "Free_%s(%s *p)\n"
                "{\n",
		ptr->type, ptr->type);
	if (!IsCardinalOnly(pl, ptr->type))
	    fprintf(fp,	"\t" "Release_%s(p);\n", ptr->type);
        fprintf(fp,
		"\t" "ldfree(p);\n"
                "}\n");
    }
}
