void LoadTriggerKeys(Display *, char *, char *, SylSetting *, XIMTRIGGERKEY *);
