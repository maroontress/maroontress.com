#include <stdlib.h>
#include "leakdetect.h"

static int core = 0;

void *
ldmalloc(unsigned int n)
{
    void *p;

    if ((p = malloc(sizeof(int) + n)) == NULL)
	return (NULL);
    core += n;
    *((unsigned int *)p)++ = n;
    return (p);
}

void
ldfree(void *p)
{
    if (p == NULL)
	return;
    core -= *--((unsigned int *)p);
    free(p);
}

unsigned int
ldusing(void)
{
    return (core);
}
