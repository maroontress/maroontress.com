/*
	This file is generated automatically by ximpc.
	Don't edit this file.
*/

#include <X11/Xproto.h>
#include <string.h>
#include <stdlib.h>
#include "leakdetect.h"
#include "xim.h"

CARD8 *
Read_STR(STR *p, CARD8 *d)
{
	p->len = *((CARD8 *)d)++;
	if ((p->val = (STRING8)ldmalloc(sizeof(CARD8) * (p->len + 1))) != NULL) {
		memcpy(p->val, d, p->len);
		p->val[p->len] = 0;
	}
	d += p->len;
	return (d);
}

CARD8 *
Read_STRING(STRING *p, CARD8 *q)
{
	CARD8 *d = q;

	p->len = *((CARD16 *)d)++;
	if ((p->val = (STRING8)ldmalloc(sizeof(CARD8) * (p->len + 1))) != NULL) {
		memcpy(p->val, d, p->len);
		p->val[p->len] = 0;
	}
	d += p->len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

CARD8 *
Read_XIMATTR(XIMATTR *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->id = *((CARD16 *)d)++;
	p->type = *((CARD16 *)d)++;
	p->name.len = *((CARD16 *)d)++;
	if ((p->name.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->name.len + 1))) != NULL) {
		memcpy(p->name.val, d, p->name.len);
		p->name.val[p->name.len] = 0;
	}
	d += p->name.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

CARD8 *
Read_XICATTR(XICATTR *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->id = *((CARD16 *)d)++;
	p->type = *((CARD16 *)d)++;
	p->name.len = *((CARD16 *)d)++;
	if ((p->name.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->name.len + 1))) != NULL) {
		memcpy(p->name.val, d, p->name.len);
		p->name.val[p->name.len] = 0;
	}
	d += p->name.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

CARD8 *
Read_XIMTRIGGERKEY(XIMTRIGGERKEY *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->keysym = *((CARD32 *)d)++;
	p->modifier = *((CARD32 *)d)++;
	p->mask = *((CARD32 *)d)++;
	return (d);
}

CARD8 *
Read_EXT(EXT *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->major_opcode = *((CARD8 *)d)++;
	p->minor_opcode = *((CARD8 *)d)++;
	p->name.len = *((CARD16 *)d)++;
	if ((p->name.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->name.len + 1))) != NULL) {
		memcpy(p->name.val, d, p->name.len);
		p->name.val[p->name.len] = 0;
	}
	d += p->name.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

CARD8 *
Read_XIMSTYLES(XIMSTYLES *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;

	p->style.num = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->style.val = (CARD32 **)ldmalloc(sizeof(CARD32 *) * (p->style.num + 1));
	for (k = 0; k < p->style.num; ++k) {
		p->style.val[k] = (CARD32 *)ldmalloc(sizeof(CARD32));
		*(p->style.val[k]) = *((CARD32 *)d)++;
	}
	return (d);
}

CARD8 *
Read_XIMATTRIBUTE(XIMATTRIBUTE *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->id = *((CARD16 *)d)++;
	p->data.len = *((CARD16 *)d)++;
	if ((p->data.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->data.len + 1))) != NULL) {
		memcpy(p->data.val, d, p->data.len);
		p->data.val[p->data.len] = 0;
	}
	d += p->data.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

CARD8 *
Read_XICATTRIBUTE(XICATTRIBUTE *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->id = *((CARD16 *)d)++;
	p->data.len = *((CARD16 *)d)++;
	if ((p->data.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->data.len + 1))) != NULL) {
		memcpy(p->data.val, d, p->data.len);
		p->data.val[p->data.len] = 0;
	}
	d += p->data.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

static CARD8 *
Read_XIM_ERROR(XIM_ERROR *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	p->flag = *((CARD16 *)d)++;
	p->code = *((CARD16 *)d)++;
	p->detail.len = *((CARD16 *)d)++;
	if ((p->detail.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->detail.len + 1))) != NULL) {
		memcpy(p->detail.val, d, p->detail.len);
		p->detail.val[p->detail.len] = 0;
	}
	d += p->detail.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

static CARD8 *
Read_XIM_CONNECT(XIM_CONNECT *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;

	p->byte_order = *((CARD8 *)d)++;
	p->unused = *((CARD8 *)d)++;
	p->major_version = *((CARD16 *)d)++;
	p->minor_version = *((CARD16 *)d)++;
	p->auth.num = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->auth.val = (STRING **)ldmalloc(sizeof(STRING *) * (p->auth.num + 1));
	for (k = 0; k < p->auth.num; ++k) {
		p->auth.val[k] = (STRING *)ldmalloc(sizeof(STRING));
		d = Read_STRING(p->auth.val[k], d);
	}
	return (d);
}

static CARD8 *
Read_XIM_OPEN(XIM_OPEN *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->locale.len = *((CARD8 *)d)++;
	if ((p->locale.val = (STRING8)ldmalloc(sizeof(CARD8) * (p->locale.len + 1))) != NULL) {
		memcpy(p->locale.val, d, p->locale.len);
		p->locale.val[p->locale.len] = 0;
	}
	d += p->locale.len;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

static CARD8 *
Read_XIM_CLOSE(XIM_CLOSE *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->unused = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_TRIGGER_NOTIFY(XIM_TRIGGER_NOTIFY *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	p->flag = *((CARD32 *)d)++;
	p->index = *((CARD32 *)d)++;
	p->mask = *((CARD32 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_ENCODING_NEGOTIATION(XIM_ENCODING_NEGOTIATION *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;
	LIST **c;
	CARD8 *b;

	p->im_id = *((CARD16 *)d)++;
	k = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->encoding = NULL;
	for (c = &(p->encoding), b = d; d - b < k; c = &((*c)->next)) {
		(*c) = (LIST *)ldmalloc(sizeof(LIST));
		(*c)->data = (STR *)ldmalloc(sizeof(STR));
		(*c)->next = NULL;
		d = Read_STR((*c)->data, d);
	}
	d += (4 - ((d - q) % 4)) % 4;
	k = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->detail = NULL;
	for (c = &(p->detail), b = d; d - b < k; c = &((*c)->next)) {
		(*c) = (LIST *)ldmalloc(sizeof(LIST));
		(*c)->data = (STRING *)ldmalloc(sizeof(STRING));
		(*c)->next = NULL;
		d = Read_STRING((*c)->data, d);
	}
	return (d);
}

static CARD8 *
Read_XIM_QUERY_EXTENSION(XIM_QUERY_EXTENSION *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;
	LIST **c;
	CARD8 *b;

	p->im_id = *((CARD16 *)d)++;
	k = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->extension = NULL;
	for (c = &(p->extension), b = d; d - b < k; c = &((*c)->next)) {
		(*c) = (LIST *)ldmalloc(sizeof(LIST));
		(*c)->data = (STR *)ldmalloc(sizeof(STR));
		(*c)->next = NULL;
		d = Read_STR((*c)->data, d);
	}
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

static CARD8 *
Read_XIM_SET_IM_VALUES(XIM_SET_IM_VALUES *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;
	LIST **c;
	CARD8 *b;

	p->im_id = *((CARD16 *)d)++;
	k = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->im_attribute = NULL;
	for (c = &(p->im_attribute), b = d; d - b < k; c = &((*c)->next)) {
		(*c) = (LIST *)ldmalloc(sizeof(LIST));
		(*c)->data = (XIMATTRIBUTE *)ldmalloc(sizeof(XIMATTRIBUTE));
		(*c)->next = NULL;
		d = Read_XIMATTRIBUTE((*c)->data, d);
	}
	return (d);
}

static CARD8 *
Read_XIM_GET_IM_VALUES(XIM_GET_IM_VALUES *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;

	p->im_id = *((CARD16 *)d)++;
	p->im_attribute_id.num = *((CARD16 *)d)++;
	p->im_attribute_id.num /= sizeof(CARD16);
	p->im_attribute_id.val = (CARD16 *)ldmalloc(sizeof(CARD16) * (p->im_attribute_id.num + 1));
	for (k = 0; k < p->im_attribute_id.num; ++k)
		p->im_attribute_id.val[k] = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

static CARD8 *
Read_XIM_CREATE_IC(XIM_CREATE_IC *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;
	LIST **c;
	CARD8 *b;

	p->im_id = *((CARD16 *)d)++;
	k = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->ic_attribute = NULL;
	for (c = &(p->ic_attribute), b = d; d - b < k; c = &((*c)->next)) {
		(*c) = (LIST *)ldmalloc(sizeof(LIST));
		(*c)->data = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE));
		(*c)->next = NULL;
		d = Read_XICATTRIBUTE((*c)->data, d);
	}
	return (d);
}

static CARD8 *
Read_XIM_DESTROY_IC(XIM_DESTROY_IC *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_SET_IC_VALUES(XIM_SET_IC_VALUES *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;
	LIST **c;
	CARD8 *b;

	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	k = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	p->ic_attribute = NULL;
	for (c = &(p->ic_attribute), b = d; d - b < k; c = &((*c)->next)) {
		(*c) = (LIST *)ldmalloc(sizeof(LIST));
		(*c)->data = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE));
		(*c)->next = NULL;
		d = Read_XICATTRIBUTE((*c)->data, d);
	}
	return (d);
}

static CARD8 *
Read_XIM_GET_IC_VALUES(XIM_GET_IC_VALUES *p, CARD8 *q)
{
	CARD8 *d = q;
 	int k;

	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	p->ic_attribute_id.num = *((CARD16 *)d)++;
	p->ic_attribute_id.num /= sizeof(CARD16);
	p->ic_attribute_id.val = (CARD16 *)ldmalloc(sizeof(CARD16) * (p->ic_attribute_id.num + 1));
	for (k = 0; k < p->ic_attribute_id.num; ++k)
		p->ic_attribute_id.val[k] = *((CARD16 *)d)++;
	d += (4 - ((d - q) % 4)) % 4;
	return (d);
}

static CARD8 *
Read_XIM_SET_IC_FOCUS(XIM_SET_IC_FOCUS *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_UNSET_IC_FOCUS(XIM_UNSET_IC_FOCUS *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_FORWARD_EVENT(XIM_FORWARD_EVENT *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	p->flag = *((CARD16 *)d)++;
	p->serial = *((CARD16 *)d)++;
	memcpy(&(p->event), (XEVENT *)d, sizeof(XEVENT));
	d += sizeof(XEVENT);
	return (d);
}

static CARD8 *
Read_XIM_SYNC(XIM_SYNC *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_SYNC_REPLY(XIM_SYNC_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_RESET_IC(XIM_RESET_IC *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	return (d);
}

static CARD8 *
Read_XIM_PREEDIT_START_REPLY(XIM_PREEDIT_START_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;
 
	p->im_id = *((CARD16 *)d)++;
	p->ic_id = *((CARD16 *)d)++;
	p->value = *((CARD32 *)d)++;
	return (d);
}

static void
Release_STR(STR *p)
{
	ldfree(p->val);
}

static void
Release_STRING(STRING *p)
{
	ldfree(p->val);
}

static void
Release_XIMATTR(XIMATTR *p)
{
	Release_STRING(&(p->name));
}

static void
Release_XICATTR(XICATTR *p)
{
	Release_STRING(&(p->name));
}

static void
Release_EXT(EXT *p)
{
	Release_STRING(&(p->name));
}

static void
Release_XIMSTYLES(XIMSTYLES *p)
{
	int k;

	for (k = 0; k < p->style.num; ++k) {
		ldfree(p->style.val[k]);
	}
	ldfree(p->style.val);
}

static void
Release_XIMATTRIBUTE(XIMATTRIBUTE *p)
{
	Release_STRING(&(p->data));
}

static void
Release_XICATTRIBUTE(XICATTRIBUTE *p)
{
	Release_STRING(&(p->data));
}

static void
Release_XIM_ERROR(XIM_ERROR *p)
{
	Release_STRING(&(p->detail));
}

static void
Release_XIM_CONNECT(XIM_CONNECT *p)
{
	int k;

	for (k = 0; k < p->auth.num; ++k) {
		Release_STRING(p->auth.val[k]);
	}
	ldfree(p->auth.val);
}

static void
Release_XIM_OPEN(XIM_OPEN *p)
{
	Release_STR(&(p->locale));
}

static void
Release_XIM_OPEN_REPLY(XIM_OPEN_REPLY *p)
{
	LIST *c, *next;

	for (c = p->im_attr; c != NULL; c = next) {
		Release_XIMATTR(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
	for (c = p->ic_attr; c != NULL; c = next) {
		Release_XICATTR(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_ENCODING_NEGOTIATION(XIM_ENCODING_NEGOTIATION *p)
{
	LIST *c, *next;

	for (c = p->encoding; c != NULL; c = next) {
		Release_STR(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
	for (c = p->detail; c != NULL; c = next) {
		Release_STRING(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_QUERY_EXTENSION(XIM_QUERY_EXTENSION *p)
{
	LIST *c, *next;

	for (c = p->extension; c != NULL; c = next) {
		Release_STR(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_QUERY_EXTENSION_REPLY(XIM_QUERY_EXTENSION_REPLY *p)
{
	LIST *c, *next;

	for (c = p->extension; c != NULL; c = next) {
		Release_EXT(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_SET_IM_VALUES(XIM_SET_IM_VALUES *p)
{
	LIST *c, *next;

	for (c = p->im_attribute; c != NULL; c = next) {
		Release_XIMATTRIBUTE(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_GET_IM_VALUES(XIM_GET_IM_VALUES *p)
{
	ldfree(p->im_attribute_id.val);
}

static void
Release_XIM_GET_IM_VALUES_REPLY(XIM_GET_IM_VALUES_REPLY *p)
{
	LIST *c, *next;

	for (c = p->im_attribute; c != NULL; c = next) {
		Release_XIMATTRIBUTE(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_CREATE_IC(XIM_CREATE_IC *p)
{
	LIST *c, *next;

	for (c = p->ic_attribute; c != NULL; c = next) {
		Release_XICATTRIBUTE(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_SET_IC_VALUES(XIM_SET_IC_VALUES *p)
{
	LIST *c, *next;

	for (c = p->ic_attribute; c != NULL; c = next) {
		Release_XICATTRIBUTE(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_GET_IC_VALUES(XIM_GET_IC_VALUES *p)
{
	ldfree(p->ic_attribute_id.val);
}

static void
Release_XIM_GET_IC_VALUES_REPLY(XIM_GET_IC_VALUES_REPLY *p)
{
	LIST *c, *next;

	for (c = p->ic_attribute; c != NULL; c = next) {
		Release_XICATTRIBUTE(c->data);
		ldfree(c->data);
		next = c->next;
		ldfree(c);
	}
}

static void
Release_XIM_COMMIT_CHARS(XIM_COMMIT_CHARS *p)
{
	Release_STRING(&(p->string));
}

static void
Release_XIM_RESET_IC_REPLY(XIM_RESET_IC_REPLY *p)
{
	Release_STRING(&(p->preedit));
}

static void
Release_XIM_PREEDIT_DRAW(XIM_PREEDIT_DRAW *p)
{
	Release_STRING(&(p->string));
	ldfree(p->feedback.val);
}

CARD8 *
Write_STRING(STRING *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->len;
	memcpy(d, p->val, p->len);
	d += p->len;
	while ((d - q) % 4)
		*d++ = 0;
	return (d);
}

CARD8 *
Write_XIMATTR(XIMATTR *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->id;
	*((CARD16 *)d)++ = p->type;
	*((CARD16 *)d)++ = p->name.len;
	memcpy(d, p->name.val, p->name.len);
	d += p->name.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

CARD8 *
Write_XICATTR(XICATTR *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->id;
	*((CARD16 *)d)++ = p->type;
	*((CARD16 *)d)++ = p->name.len;
	memcpy(d, p->name.val, p->name.len);
	d += p->name.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

CARD8 *
Write_XIMTRIGGERKEY(XIMTRIGGERKEY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD32 *)d)++ = p->keysym;
	*((CARD32 *)d)++ = p->modifier;
	*((CARD32 *)d)++ = p->mask;
	return (d);
}

CARD8 *
Write_EXT(EXT *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD8 *)d)++ = p->major_opcode;
	*((CARD8 *)d)++ = p->minor_opcode;
	*((CARD16 *)d)++ = p->name.len;
	memcpy(d, p->name.val, p->name.len);
	d += p->name.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

CARD8 *
Write_XIMSTYLES(XIMSTYLES *p, CARD8 *q)
{
	CARD8 *d = q;
	int k;

	*((CARD16 *)d)++ = p->style.num;
	while ((d - q) % 4)
		*(d)++ = 0;
	for (k = 0; k < p->style.num; ++k)
		*((CARD32 *)d)++ = *(p->style.val[k]);
	return (d);
}

CARD8 *
Write_XIMATTRIBUTE(XIMATTRIBUTE *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->id;
	*((CARD16 *)d)++ = p->data.len;
	memcpy(d, p->data.val, p->data.len);
	d += p->data.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

CARD8 *
Write_XICATTRIBUTE(XICATTRIBUTE *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->id;
	*((CARD16 *)d)++ = p->data.len;
	memcpy(d, p->data.val, p->data.len);
	d += p->data.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

static CARD8 *
Write_XIM_ERROR(XIM_ERROR *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD16 *)d)++ = p->flag;
	*((CARD16 *)d)++ = p->code;
	*((CARD16 *)d)++ = p->detail.len;
	memcpy(d, p->detail.val, p->detail.len);
	d += p->detail.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

static CARD8 *
Write_XIM_CONNECT_REPLY(XIM_CONNECT_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->major_version;
	*((CARD16 *)d)++ = p->minor_version;
	return (d);
}

static CARD8 *
Write_XIM_OPEN_REPLY(XIM_OPEN_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;
	LIST *c;
	CARD8 *b, *len;

	*((CARD16 *)d)++ = p->im_id;
	len = d;
	*((CARD16 *)d)++ = 0; /* dummy */
	while ((d - q) % 4)
		*(d)++ = 0;
	b = d;
	for (c = p->im_attr; c != NULL; c = c->next) {
		d = Write_XIMATTR(c->data, d);
	}
	*((CARD16 *)len) = d - b;
	len = d;
	*((CARD16 *)d)++ = 0; /* dummy */
	while ((d - q) % 4)
		*(d)++ = 0;
	b = d;
	for (c = p->ic_attr; c != NULL; c = c->next) {
		d = Write_XICATTR(c->data, d);
	}
	*((CARD16 *)len) = d - b;
	return (d);
}

static CARD8 *
Write_XIM_CLOSE_REPLY(XIM_CLOSE_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->unused;
	return (d);
}

static CARD8 *
Write_XIM_SET_EVENT_MASK(XIM_SET_EVENT_MASK *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD32 *)d)++ = p->forward_mask;
	*((CARD32 *)d)++ = p->sync_mask;
	return (d);
}

static CARD8 *
Write_XIM_REGISTER_TRIGGERKEYS(XIM_REGISTER_TRIGGERKEYS *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->unused;
	*((CARD32 *)d)++ = p->on_keys_length;
	d = Write_XIMTRIGGERKEY(&(p->on_keys), d);
	*((CARD32 *)d)++ = p->off_keys_length;
	d = Write_XIMTRIGGERKEY(&(p->off_keys), d);
	return (d);
}

static CARD8 *
Write_XIM_TRIGGER_NOTIFY_REPLY(XIM_TRIGGER_NOTIFY_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_ENCODING_NEGOTIATION_REPLY(XIM_ENCODING_NEGOTIATION_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->category;
	*((CARD16 *)d)++ = p->index;
	*((CARD16 *)d)++ = p->unused;
	return (d);
}

static CARD8 *
Write_XIM_QUERY_EXTENSION_REPLY(XIM_QUERY_EXTENSION_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;
	LIST *c;
	CARD8 *b, *len;

	*((CARD16 *)d)++ = p->im_id;
	len = d;
	*((CARD16 *)d)++ = 0; /* dummy */
	while ((d - q) % 4)
		*(d)++ = 0;
	b = d;
	for (c = p->extension; c != NULL; c = c->next) {
		d = Write_EXT(c->data, d);
	}
	*((CARD16 *)len) = d - b;
	return (d);
}

static CARD8 *
Write_XIM_SET_IM_VALUES_REPLY(XIM_SET_IM_VALUES_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->unused;
	return (d);
}

static CARD8 *
Write_XIM_GET_IM_VALUES_REPLY(XIM_GET_IM_VALUES_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;
	LIST *c;
	CARD8 *b, *len;

	*((CARD16 *)d)++ = p->im_id;
	len = d;
	*((CARD16 *)d)++ = 0; /* dummy */
	while ((d - q) % 4)
		*(d)++ = 0;
	b = d;
	for (c = p->im_attribute; c != NULL; c = c->next) {
		d = Write_XIMATTRIBUTE(c->data, d);
	}
	*((CARD16 *)len) = d - b;
	return (d);
}

static CARD8 *
Write_XIM_CREATE_IC_REPLY(XIM_CREATE_IC_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_DESTROY_IC_REPLY(XIM_DESTROY_IC_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_SET_IC_VALUES_REPLY(XIM_SET_IC_VALUES_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_GET_IC_VALUES_REPLY(XIM_GET_IC_VALUES_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;
	LIST *c;
	CARD8 *b, *len;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	len = d;
	*((CARD16 *)d)++ = 0; /* dummy */
	while ((d - q) % 4)
		*(d)++ = 0;
	b = d;
	for (c = p->ic_attribute; c != NULL; c = c->next) {
		d = Write_XICATTRIBUTE(c->data, d);
	}
	*((CARD16 *)len) = d - b;
	return (d);
}

static CARD8 *
Write_XIM_FORWARD_EVENT(XIM_FORWARD_EVENT *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD16 *)d)++ = p->flag;
	*((CARD16 *)d)++ = p->serial;
	memcpy((XEVENT *)d, &(p->event), sizeof(XEVENT));
	d += sizeof(XEVENT);
	return (d);
}

static CARD8 *
Write_XIM_SYNC(XIM_SYNC *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_SYNC_REPLY(XIM_SYNC_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_COMMIT_CHARS(XIM_COMMIT_CHARS *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD16 *)d)++ = p->flag;
	*((CARD16 *)d)++ = p->string.len;
	memcpy(d, p->string.val, p->string.len);
	d += p->string.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

static CARD8 *
Write_XIM_COMMIT_KEYSYM(XIM_COMMIT_KEYSYM *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD16 *)d)++ = p->flag;
	*((CARD16 *)d)++ = p->unused;
	*((CARD32 *)d)++ = p->keysym;
	return (d);
}

static CARD8 *
Write_XIM_RESET_IC_REPLY(XIM_RESET_IC_REPLY *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD16 *)d)++ = p->preedit.len;
	memcpy(d, p->preedit.val, p->preedit.len);
	d += p->preedit.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	return (d);
}

static CARD8 *
Write_XIM_PREEDIT_START(XIM_PREEDIT_START *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

static CARD8 *
Write_XIM_PREEDIT_DRAW(XIM_PREEDIT_DRAW *p, CARD8 *q)
{
	CARD8 *d = q;
	int k;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	*((CARD32 *)d)++ = p->caret;
	*((CARD32 *)d)++ = p->chg_first;
	*((CARD32 *)d)++ = p->chg_length;
	*((CARD32 *)d)++ = p->status;
	*((CARD16 *)d)++ = p->string.len;
	memcpy(d, p->string.val, p->string.len);
	d += p->string.len;
	while ((d - q) % 4)
		*(d)++ = 0;
	*((CARD16 *)d)++ = p->feedback.num * sizeof(CARD32);
	while ((d - q) % 4)
		*(d)++ = 0;
	for (k = 0; k < p->feedback.num; ++k)
		*((CARD32 *)d)++ = p->feedback.val[k];
	return (d);
}

static CARD8 *
Write_XIM_PREEDIT_DONE(XIM_PREEDIT_DONE *p, CARD8 *q)
{
	CARD8 *d = q;

	*((CARD16 *)d)++ = p->im_id;
	*((CARD16 *)d)++ = p->ic_id;
	return (d);
}

int
Sizeof_STRING(STRING *p)
{
	int s = 0;

	s += sizeof(CARD16);
	s += p->len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

int
Sizeof_XIMATTR(XIMATTR *p)
{
	int s = 0;

	s += sizeof(p->id);
	s += sizeof(p->type);
	s += sizeof(CARD16);
	s += p->name.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

int
Sizeof_XICATTR(XICATTR *p)
{
	int s = 0;

	s += sizeof(p->id);
	s += sizeof(p->type);
	s += sizeof(CARD16);
	s += p->name.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

int
Sizeof_XIMTRIGGERKEY(XIMTRIGGERKEY *p)
{
	int s = 0;

	s += sizeof(p->keysym);
	s += sizeof(p->modifier);
	s += sizeof(p->mask);
	return (s);
}

int
Sizeof_EXT(EXT *p)
{
	int s = 0;

	s += sizeof(p->major_opcode);
	s += sizeof(p->minor_opcode);
	s += sizeof(CARD16);
	s += p->name.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

int
Sizeof_XIMSTYLES(XIMSTYLES *p)
{
	int s = 0;
	int k;

	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (k = 0; k < p->style.num; ++k)
		s += sizeof(CARD32);
	return (s);
}

int
Sizeof_XIMATTRIBUTE(XIMATTRIBUTE *p)
{
	int s = 0;

	s += sizeof(p->id);
	s += sizeof(CARD16);
	s += p->data.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

int
Sizeof_XICATTRIBUTE(XICATTRIBUTE *p)
{
	int s = 0;

	s += sizeof(p->id);
	s += sizeof(CARD16);
	s += p->data.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

static int
Sizeof_XIM_ERROR(XIM_ERROR *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(p->flag);
	s += sizeof(p->code);
	s += sizeof(CARD16);
	s += p->detail.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

static int
Sizeof_XIM_CONNECT_REPLY(XIM_CONNECT_REPLY *p)
{
	int s = 0;

	s += sizeof(p->major_version);
	s += sizeof(p->minor_version);
	return (s);
}

static int
Sizeof_XIM_OPEN_REPLY(XIM_OPEN_REPLY *p)
{
	int s = 0;
	LIST *c;

	s += sizeof(p->im_id);
	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (c = p->im_attr; c != NULL; c = c->next) {
		s += Sizeof_XIMATTR(c->data);
	}
	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (c = p->ic_attr; c != NULL; c = c->next) {
		s += Sizeof_XICATTR(c->data);
	}
	return (s);
}

static int
Sizeof_XIM_CLOSE_REPLY(XIM_CLOSE_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->unused);
	return (s);
}

static int
Sizeof_XIM_SET_EVENT_MASK(XIM_SET_EVENT_MASK *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(p->forward_mask);
	s += sizeof(p->sync_mask);
	return (s);
}

static int
Sizeof_XIM_REGISTER_TRIGGERKEYS(XIM_REGISTER_TRIGGERKEYS *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->unused);
	s += sizeof(p->on_keys_length);
	s += Sizeof_XIMTRIGGERKEY(&(p->on_keys));
	s += sizeof(p->off_keys_length);
	s += Sizeof_XIMTRIGGERKEY(&(p->off_keys));
	return (s);
}

static int
Sizeof_XIM_TRIGGER_NOTIFY_REPLY(XIM_TRIGGER_NOTIFY_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_ENCODING_NEGOTIATION_REPLY(XIM_ENCODING_NEGOTIATION_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->category);
	s += sizeof(p->index);
	s += sizeof(p->unused);
	return (s);
}

static int
Sizeof_XIM_QUERY_EXTENSION_REPLY(XIM_QUERY_EXTENSION_REPLY *p)
{
	int s = 0;
	LIST *c;

	s += sizeof(p->im_id);
	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (c = p->extension; c != NULL; c = c->next) {
		s += Sizeof_EXT(c->data);
	}
	return (s);
}

static int
Sizeof_XIM_SET_IM_VALUES_REPLY(XIM_SET_IM_VALUES_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->unused);
	return (s);
}

static int
Sizeof_XIM_GET_IM_VALUES_REPLY(XIM_GET_IM_VALUES_REPLY *p)
{
	int s = 0;
	LIST *c;

	s += sizeof(p->im_id);
	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (c = p->im_attribute; c != NULL; c = c->next) {
		s += Sizeof_XIMATTRIBUTE(c->data);
	}
	return (s);
}

static int
Sizeof_XIM_CREATE_IC_REPLY(XIM_CREATE_IC_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_DESTROY_IC_REPLY(XIM_DESTROY_IC_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_SET_IC_VALUES_REPLY(XIM_SET_IC_VALUES_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_GET_IC_VALUES_REPLY(XIM_GET_IC_VALUES_REPLY *p)
{
	int s = 0;
	LIST *c;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (c = p->ic_attribute; c != NULL; c = c->next) {
		s += Sizeof_XICATTRIBUTE(c->data);
	}
	return (s);
}

static int
Sizeof_XIM_FORWARD_EVENT(XIM_FORWARD_EVENT *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(p->flag);
	s += sizeof(p->serial);
	s += sizeof(XEVENT);
	return (s);
}

static int
Sizeof_XIM_SYNC(XIM_SYNC *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_SYNC_REPLY(XIM_SYNC_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_COMMIT_CHARS(XIM_COMMIT_CHARS *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(p->flag);
	s += sizeof(CARD16);
	s += p->string.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

static int
Sizeof_XIM_COMMIT_KEYSYM(XIM_COMMIT_KEYSYM *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(p->flag);
	s += sizeof(p->unused);
	s += sizeof(p->keysym);
	return (s);
}

static int
Sizeof_XIM_RESET_IC_REPLY(XIM_RESET_IC_REPLY *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(CARD16);
	s += p->preedit.len;
	s += (4 - ((s) % 4)) % 4;
	return (s);
}

static int
Sizeof_XIM_PREEDIT_START(XIM_PREEDIT_START *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

static int
Sizeof_XIM_PREEDIT_DRAW(XIM_PREEDIT_DRAW *p)
{
	int s = 0;
	int k;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	s += sizeof(p->caret);
	s += sizeof(p->chg_first);
	s += sizeof(p->chg_length);
	s += sizeof(p->status);
	s += sizeof(CARD16);
	s += p->string.len;
	s += (4 - ((s) % 4)) % 4;
	s += sizeof(CARD16);
	s += (4 - ((s) % 4)) % 4;
	for (k = 0; k < p->feedback.num; ++k)
		s += sizeof(CARD32);
	return (s);
}

static int
Sizeof_XIM_PREEDIT_DONE(XIM_PREEDIT_DONE *p)
{
	int s = 0;

	s += sizeof(p->im_id);
	s += sizeof(p->ic_id);
	return (s);
}

STR *
Recv_STR(CARD8 *p)
{
	STR *q;

	if ((q = (STR *)ldmalloc(sizeof(STR))) != NULL) {
		Read_STR(q, p);
	}
	return (q);
}

STRING *
Recv_STRING(CARD8 *p)
{
	STRING *q;

	if ((q = (STRING *)ldmalloc(sizeof(STRING))) != NULL) {
		Read_STRING(q, p);
	}
	return (q);
}

XIMATTR *
Recv_XIMATTR(CARD8 *p)
{
	XIMATTR *q;

	if ((q = (XIMATTR *)ldmalloc(sizeof(XIMATTR))) != NULL) {
		Read_XIMATTR(q, p);
	}
	return (q);
}

XICATTR *
Recv_XICATTR(CARD8 *p)
{
	XICATTR *q;

	if ((q = (XICATTR *)ldmalloc(sizeof(XICATTR))) != NULL) {
		Read_XICATTR(q, p);
	}
	return (q);
}

XIMTRIGGERKEY *
Recv_XIMTRIGGERKEY(CARD8 *p)
{
	XIMTRIGGERKEY *q;

	if ((q = (XIMTRIGGERKEY *)ldmalloc(sizeof(XIMTRIGGERKEY))) != NULL) {
		Read_XIMTRIGGERKEY(q, p);
	}
	return (q);
}

EXT *
Recv_EXT(CARD8 *p)
{
	EXT *q;

	if ((q = (EXT *)ldmalloc(sizeof(EXT))) != NULL) {
		Read_EXT(q, p);
	}
	return (q);
}

XIMSTYLES *
Recv_XIMSTYLES(CARD8 *p)
{
	XIMSTYLES *q;

	if ((q = (XIMSTYLES *)ldmalloc(sizeof(XIMSTYLES))) != NULL) {
		Read_XIMSTYLES(q, p);
	}
	return (q);
}

XIMATTRIBUTE *
Recv_XIMATTRIBUTE(CARD8 *p)
{
	XIMATTRIBUTE *q;

	if ((q = (XIMATTRIBUTE *)ldmalloc(sizeof(XIMATTRIBUTE))) != NULL) {
		Read_XIMATTRIBUTE(q, p);
	}
	return (q);
}

XICATTRIBUTE *
Recv_XICATTRIBUTE(CARD8 *p)
{
	XICATTRIBUTE *q;

	if ((q = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE))) != NULL) {
		Read_XICATTRIBUTE(q, p);
	}
	return (q);
}

XIM_ERROR *
Recv_XIM_ERROR(CARD8 *p)
{
	XIM_ERROR *q;

	if ((q = (XIM_ERROR *)ldmalloc(sizeof(XIM_ERROR))) != NULL) {
		Read_XIM_ERROR(q, p);
	}
	return (q);
}

XIM_CONNECT *
Recv_XIM_CONNECT(CARD8 *p)
{
	XIM_CONNECT *q;

	if ((q = (XIM_CONNECT *)ldmalloc(sizeof(XIM_CONNECT))) != NULL) {
		Read_XIM_CONNECT(q, p);
	}
	return (q);
}

XIM_OPEN *
Recv_XIM_OPEN(CARD8 *p)
{
	XIM_OPEN *q;

	if ((q = (XIM_OPEN *)ldmalloc(sizeof(XIM_OPEN))) != NULL) {
		Read_XIM_OPEN(q, p);
	}
	return (q);
}

XIM_CLOSE *
Recv_XIM_CLOSE(CARD8 *p)
{
	XIM_CLOSE *q;

	if ((q = (XIM_CLOSE *)ldmalloc(sizeof(XIM_CLOSE))) != NULL) {
		Read_XIM_CLOSE(q, p);
	}
	return (q);
}

XIM_TRIGGER_NOTIFY *
Recv_XIM_TRIGGER_NOTIFY(CARD8 *p)
{
	XIM_TRIGGER_NOTIFY *q;

	if ((q = (XIM_TRIGGER_NOTIFY *)ldmalloc(sizeof(XIM_TRIGGER_NOTIFY))) != NULL) {
		Read_XIM_TRIGGER_NOTIFY(q, p);
	}
	return (q);
}

XIM_ENCODING_NEGOTIATION *
Recv_XIM_ENCODING_NEGOTIATION(CARD8 *p)
{
	XIM_ENCODING_NEGOTIATION *q;

	if ((q = (XIM_ENCODING_NEGOTIATION *)ldmalloc(sizeof(XIM_ENCODING_NEGOTIATION))) != NULL) {
		Read_XIM_ENCODING_NEGOTIATION(q, p);
	}
	return (q);
}

XIM_QUERY_EXTENSION *
Recv_XIM_QUERY_EXTENSION(CARD8 *p)
{
	XIM_QUERY_EXTENSION *q;

	if ((q = (XIM_QUERY_EXTENSION *)ldmalloc(sizeof(XIM_QUERY_EXTENSION))) != NULL) {
		Read_XIM_QUERY_EXTENSION(q, p);
	}
	return (q);
}

XIM_SET_IM_VALUES *
Recv_XIM_SET_IM_VALUES(CARD8 *p)
{
	XIM_SET_IM_VALUES *q;

	if ((q = (XIM_SET_IM_VALUES *)ldmalloc(sizeof(XIM_SET_IM_VALUES))) != NULL) {
		Read_XIM_SET_IM_VALUES(q, p);
	}
	return (q);
}

XIM_GET_IM_VALUES *
Recv_XIM_GET_IM_VALUES(CARD8 *p)
{
	XIM_GET_IM_VALUES *q;

	if ((q = (XIM_GET_IM_VALUES *)ldmalloc(sizeof(XIM_GET_IM_VALUES))) != NULL) {
		Read_XIM_GET_IM_VALUES(q, p);
	}
	return (q);
}

XIM_CREATE_IC *
Recv_XIM_CREATE_IC(CARD8 *p)
{
	XIM_CREATE_IC *q;

	if ((q = (XIM_CREATE_IC *)ldmalloc(sizeof(XIM_CREATE_IC))) != NULL) {
		Read_XIM_CREATE_IC(q, p);
	}
	return (q);
}

XIM_DESTROY_IC *
Recv_XIM_DESTROY_IC(CARD8 *p)
{
	XIM_DESTROY_IC *q;

	if ((q = (XIM_DESTROY_IC *)ldmalloc(sizeof(XIM_DESTROY_IC))) != NULL) {
		Read_XIM_DESTROY_IC(q, p);
	}
	return (q);
}

XIM_SET_IC_VALUES *
Recv_XIM_SET_IC_VALUES(CARD8 *p)
{
	XIM_SET_IC_VALUES *q;

	if ((q = (XIM_SET_IC_VALUES *)ldmalloc(sizeof(XIM_SET_IC_VALUES))) != NULL) {
		Read_XIM_SET_IC_VALUES(q, p);
	}
	return (q);
}

XIM_GET_IC_VALUES *
Recv_XIM_GET_IC_VALUES(CARD8 *p)
{
	XIM_GET_IC_VALUES *q;

	if ((q = (XIM_GET_IC_VALUES *)ldmalloc(sizeof(XIM_GET_IC_VALUES))) != NULL) {
		Read_XIM_GET_IC_VALUES(q, p);
	}
	return (q);
}

XIM_SET_IC_FOCUS *
Recv_XIM_SET_IC_FOCUS(CARD8 *p)
{
	XIM_SET_IC_FOCUS *q;

	if ((q = (XIM_SET_IC_FOCUS *)ldmalloc(sizeof(XIM_SET_IC_FOCUS))) != NULL) {
		Read_XIM_SET_IC_FOCUS(q, p);
	}
	return (q);
}

XIM_UNSET_IC_FOCUS *
Recv_XIM_UNSET_IC_FOCUS(CARD8 *p)
{
	XIM_UNSET_IC_FOCUS *q;

	if ((q = (XIM_UNSET_IC_FOCUS *)ldmalloc(sizeof(XIM_UNSET_IC_FOCUS))) != NULL) {
		Read_XIM_UNSET_IC_FOCUS(q, p);
	}
	return (q);
}

XIM_FORWARD_EVENT *
Recv_XIM_FORWARD_EVENT(CARD8 *p)
{
	XIM_FORWARD_EVENT *q;

	if ((q = (XIM_FORWARD_EVENT *)ldmalloc(sizeof(XIM_FORWARD_EVENT))) != NULL) {
		Read_XIM_FORWARD_EVENT(q, p);
	}
	return (q);
}

XIM_SYNC *
Recv_XIM_SYNC(CARD8 *p)
{
	XIM_SYNC *q;

	if ((q = (XIM_SYNC *)ldmalloc(sizeof(XIM_SYNC))) != NULL) {
		Read_XIM_SYNC(q, p);
	}
	return (q);
}

XIM_SYNC_REPLY *
Recv_XIM_SYNC_REPLY(CARD8 *p)
{
	XIM_SYNC_REPLY *q;

	if ((q = (XIM_SYNC_REPLY *)ldmalloc(sizeof(XIM_SYNC_REPLY))) != NULL) {
		Read_XIM_SYNC_REPLY(q, p);
	}
	return (q);
}

XIM_RESET_IC *
Recv_XIM_RESET_IC(CARD8 *p)
{
	XIM_RESET_IC *q;

	if ((q = (XIM_RESET_IC *)ldmalloc(sizeof(XIM_RESET_IC))) != NULL) {
		Read_XIM_RESET_IC(q, p);
	}
	return (q);
}

XIM_PREEDIT_START_REPLY *
Recv_XIM_PREEDIT_START_REPLY(CARD8 *p)
{
	XIM_PREEDIT_START_REPLY *q;

	if ((q = (XIM_PREEDIT_START_REPLY *)ldmalloc(sizeof(XIM_PREEDIT_START_REPLY))) != NULL) {
		Read_XIM_PREEDIT_START_REPLY(q, p);
	}
	return (q);
}


void
Send_XIMATTR(XIMATTR *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIMATTR(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIMATTR(p, *r);
	}
}

void
Send_XICATTR(XICATTR *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XICATTR(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XICATTR(p, *r);
	}
}

void
Send_XIMTRIGGERKEY(XIMTRIGGERKEY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIMTRIGGERKEY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIMTRIGGERKEY(p, *r);
	}
}

void
Send_EXT(EXT *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_EXT(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_EXT(p, *r);
	}
}

void
Send_XIMSTYLES(XIMSTYLES *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIMSTYLES(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIMSTYLES(p, *r);
	}
}

void
Send_XIMATTRIBUTE(XIMATTRIBUTE *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIMATTRIBUTE(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIMATTRIBUTE(p, *r);
	}
}

void
Send_XICATTRIBUTE(XICATTRIBUTE *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XICATTRIBUTE(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XICATTRIBUTE(p, *r);
	}
}

void
Send_XIM_ERROR(XIM_ERROR *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_ERROR(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_ERROR(p, *r);
	}
}

void
Send_XIM_CONNECT_REPLY(XIM_CONNECT_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_CONNECT_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_CONNECT_REPLY(p, *r);
	}
}

void
Send_XIM_OPEN_REPLY(XIM_OPEN_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_OPEN_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_OPEN_REPLY(p, *r);
	}
}

void
Send_XIM_CLOSE_REPLY(XIM_CLOSE_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_CLOSE_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_CLOSE_REPLY(p, *r);
	}
}

void
Send_XIM_SET_EVENT_MASK(XIM_SET_EVENT_MASK *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_SET_EVENT_MASK(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_SET_EVENT_MASK(p, *r);
	}
}

void
Send_XIM_REGISTER_TRIGGERKEYS(XIM_REGISTER_TRIGGERKEYS *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_REGISTER_TRIGGERKEYS(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_REGISTER_TRIGGERKEYS(p, *r);
	}
}

void
Send_XIM_TRIGGER_NOTIFY_REPLY(XIM_TRIGGER_NOTIFY_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_TRIGGER_NOTIFY_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_TRIGGER_NOTIFY_REPLY(p, *r);
	}
}

void
Send_XIM_ENCODING_NEGOTIATION_REPLY(XIM_ENCODING_NEGOTIATION_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_ENCODING_NEGOTIATION_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_ENCODING_NEGOTIATION_REPLY(p, *r);
	}
}

void
Send_XIM_QUERY_EXTENSION_REPLY(XIM_QUERY_EXTENSION_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_QUERY_EXTENSION_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_QUERY_EXTENSION_REPLY(p, *r);
	}
}

void
Send_XIM_SET_IM_VALUES_REPLY(XIM_SET_IM_VALUES_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_SET_IM_VALUES_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_SET_IM_VALUES_REPLY(p, *r);
	}
}

void
Send_XIM_GET_IM_VALUES_REPLY(XIM_GET_IM_VALUES_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_GET_IM_VALUES_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_GET_IM_VALUES_REPLY(p, *r);
	}
}

void
Send_XIM_CREATE_IC_REPLY(XIM_CREATE_IC_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_CREATE_IC_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_CREATE_IC_REPLY(p, *r);
	}
}

void
Send_XIM_DESTROY_IC_REPLY(XIM_DESTROY_IC_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_DESTROY_IC_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_DESTROY_IC_REPLY(p, *r);
	}
}

void
Send_XIM_SET_IC_VALUES_REPLY(XIM_SET_IC_VALUES_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_SET_IC_VALUES_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_SET_IC_VALUES_REPLY(p, *r);
	}
}

void
Send_XIM_GET_IC_VALUES_REPLY(XIM_GET_IC_VALUES_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_GET_IC_VALUES_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_GET_IC_VALUES_REPLY(p, *r);
	}
}

void
Send_XIM_FORWARD_EVENT(XIM_FORWARD_EVENT *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_FORWARD_EVENT(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_FORWARD_EVENT(p, *r);
	}
}

void
Send_XIM_SYNC(XIM_SYNC *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_SYNC(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_SYNC(p, *r);
	}
}

void
Send_XIM_SYNC_REPLY(XIM_SYNC_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_SYNC_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_SYNC_REPLY(p, *r);
	}
}

void
Send_XIM_COMMIT_CHARS(XIM_COMMIT_CHARS *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_COMMIT_CHARS(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_COMMIT_CHARS(p, *r);
	}
}

void
Send_XIM_COMMIT_KEYSYM(XIM_COMMIT_KEYSYM *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_COMMIT_KEYSYM(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_COMMIT_KEYSYM(p, *r);
	}
}

void
Send_XIM_RESET_IC_REPLY(XIM_RESET_IC_REPLY *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_RESET_IC_REPLY(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_RESET_IC_REPLY(p, *r);
	}
}

void
Send_XIM_PREEDIT_START(XIM_PREEDIT_START *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_PREEDIT_START(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_PREEDIT_START(p, *r);
	}
}

void
Send_XIM_PREEDIT_DRAW(XIM_PREEDIT_DRAW *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_PREEDIT_DRAW(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_PREEDIT_DRAW(p, *r);
	}
}

void
Send_XIM_PREEDIT_DONE(XIM_PREEDIT_DONE *p, SerializedPacket **r, int *s)
{
	int len;

	len = Sizeof_XIM_PREEDIT_DONE(p);
	*s = len;
	if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {
		Write_XIM_PREEDIT_DONE(p, *r);
	}
}

void
Free_SerializedPacket(SerializedPacket *p)
{
	ldfree(p);
}

void
Free_STR(STR *p)
{
	Release_STR(p);
	ldfree(p);
}

void
Free_STRING(STRING *p)
{
	Release_STRING(p);
	ldfree(p);
}

void
Free_XIMATTR(XIMATTR *p)
{
	Release_XIMATTR(p);
	ldfree(p);
}

void
Free_XICATTR(XICATTR *p)
{
	Release_XICATTR(p);
	ldfree(p);
}

void
Free_XIMTRIGGERKEY(XIMTRIGGERKEY *p)
{
	ldfree(p);
}

void
Free_EXT(EXT *p)
{
	Release_EXT(p);
	ldfree(p);
}

void
Free_XIMSTYLES(XIMSTYLES *p)
{
	Release_XIMSTYLES(p);
	ldfree(p);
}

void
Free_XIMATTRIBUTE(XIMATTRIBUTE *p)
{
	Release_XIMATTRIBUTE(p);
	ldfree(p);
}

void
Free_XICATTRIBUTE(XICATTRIBUTE *p)
{
	Release_XICATTRIBUTE(p);
	ldfree(p);
}

void
Free_XIM_ERROR(XIM_ERROR *p)
{
	Release_XIM_ERROR(p);
	ldfree(p);
}

void
Free_XIM_CONNECT(XIM_CONNECT *p)
{
	Release_XIM_CONNECT(p);
	ldfree(p);
}

void
Free_XIM_CONNECT_REPLY(XIM_CONNECT_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_OPEN(XIM_OPEN *p)
{
	Release_XIM_OPEN(p);
	ldfree(p);
}

void
Free_XIM_OPEN_REPLY(XIM_OPEN_REPLY *p)
{
	Release_XIM_OPEN_REPLY(p);
	ldfree(p);
}

void
Free_XIM_CLOSE(XIM_CLOSE *p)
{
	ldfree(p);
}

void
Free_XIM_CLOSE_REPLY(XIM_CLOSE_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_SET_EVENT_MASK(XIM_SET_EVENT_MASK *p)
{
	ldfree(p);
}

void
Free_XIM_REGISTER_TRIGGERKEYS(XIM_REGISTER_TRIGGERKEYS *p)
{
	ldfree(p);
}

void
Free_XIM_TRIGGER_NOTIFY(XIM_TRIGGER_NOTIFY *p)
{
	ldfree(p);
}

void
Free_XIM_TRIGGER_NOTIFY_REPLY(XIM_TRIGGER_NOTIFY_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_ENCODING_NEGOTIATION(XIM_ENCODING_NEGOTIATION *p)
{
	Release_XIM_ENCODING_NEGOTIATION(p);
	ldfree(p);
}

void
Free_XIM_ENCODING_NEGOTIATION_REPLY(XIM_ENCODING_NEGOTIATION_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_QUERY_EXTENSION(XIM_QUERY_EXTENSION *p)
{
	Release_XIM_QUERY_EXTENSION(p);
	ldfree(p);
}

void
Free_XIM_QUERY_EXTENSION_REPLY(XIM_QUERY_EXTENSION_REPLY *p)
{
	Release_XIM_QUERY_EXTENSION_REPLY(p);
	ldfree(p);
}

void
Free_XIM_SET_IM_VALUES(XIM_SET_IM_VALUES *p)
{
	Release_XIM_SET_IM_VALUES(p);
	ldfree(p);
}

void
Free_XIM_SET_IM_VALUES_REPLY(XIM_SET_IM_VALUES_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_GET_IM_VALUES(XIM_GET_IM_VALUES *p)
{
	Release_XIM_GET_IM_VALUES(p);
	ldfree(p);
}

void
Free_XIM_GET_IM_VALUES_REPLY(XIM_GET_IM_VALUES_REPLY *p)
{
	Release_XIM_GET_IM_VALUES_REPLY(p);
	ldfree(p);
}

void
Free_XIM_CREATE_IC(XIM_CREATE_IC *p)
{
	Release_XIM_CREATE_IC(p);
	ldfree(p);
}

void
Free_XIM_CREATE_IC_REPLY(XIM_CREATE_IC_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_DESTROY_IC(XIM_DESTROY_IC *p)
{
	ldfree(p);
}

void
Free_XIM_DESTROY_IC_REPLY(XIM_DESTROY_IC_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_SET_IC_VALUES(XIM_SET_IC_VALUES *p)
{
	Release_XIM_SET_IC_VALUES(p);
	ldfree(p);
}

void
Free_XIM_SET_IC_VALUES_REPLY(XIM_SET_IC_VALUES_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_GET_IC_VALUES(XIM_GET_IC_VALUES *p)
{
	Release_XIM_GET_IC_VALUES(p);
	ldfree(p);
}

void
Free_XIM_GET_IC_VALUES_REPLY(XIM_GET_IC_VALUES_REPLY *p)
{
	Release_XIM_GET_IC_VALUES_REPLY(p);
	ldfree(p);
}

void
Free_XIM_SET_IC_FOCUS(XIM_SET_IC_FOCUS *p)
{
	ldfree(p);
}

void
Free_XIM_UNSET_IC_FOCUS(XIM_UNSET_IC_FOCUS *p)
{
	ldfree(p);
}

void
Free_XIM_FORWARD_EVENT(XIM_FORWARD_EVENT *p)
{
	ldfree(p);
}

void
Free_XIM_SYNC(XIM_SYNC *p)
{
	ldfree(p);
}

void
Free_XIM_SYNC_REPLY(XIM_SYNC_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_COMMIT_CHARS(XIM_COMMIT_CHARS *p)
{
	Release_XIM_COMMIT_CHARS(p);
	ldfree(p);
}

void
Free_XIM_COMMIT_KEYSYM(XIM_COMMIT_KEYSYM *p)
{
	ldfree(p);
}

void
Free_XIM_RESET_IC(XIM_RESET_IC *p)
{
	ldfree(p);
}

void
Free_XIM_RESET_IC_REPLY(XIM_RESET_IC_REPLY *p)
{
	Release_XIM_RESET_IC_REPLY(p);
	ldfree(p);
}

void
Free_XIM_PREEDIT_START(XIM_PREEDIT_START *p)
{
	ldfree(p);
}

void
Free_XIM_PREEDIT_START_REPLY(XIM_PREEDIT_START_REPLY *p)
{
	ldfree(p);
}

void
Free_XIM_PREEDIT_DRAW(XIM_PREEDIT_DRAW *p)
{
	Release_XIM_PREEDIT_DRAW(p);
	ldfree(p);
}

void
Free_XIM_PREEDIT_DONE(XIM_PREEDIT_DONE *p)
{
	ldfree(p);
}
