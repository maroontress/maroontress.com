extern void (*UndofixBranch[])(Connection *, InputContext *,
			       XIM_FORWARD_EVENT *);
