typedef struct Candidate {
    struct Candidate *next;
    SylText *applicant;
} Candidate;

typedef struct Phrase {
    struct Phrase *next;
    struct Phrase *prev;
    int offset;         /* $BFI$_J8;zNsCf$NJ8@a3+;O0LCV(B */
    int length;         /* $BFI$_J8;zNsCf$N8=:_$NJ8@aJ8;z?t(B */
    int original;       /* $BFI$_J8;zNsCf$N=i4|$NJ8@aJ8;z?t(B */
    SylText *chosen;    /* $BI=<($5$l$F$$$k8uJdJ8;zNs(B */
    SylText *applicant; /* $B8=:_$NC1J8@a8uJdJ8;zNs(B */
    Candidate *top;     /* $BC1J8@a8uJd%j%9%H(B */
} Phrase;

Candidate *CreateCandidate(SylText *);
void FreeCandidate(Candidate *);

Phrase * CreatePhrase(SylText *, int bgn, int end);
Phrase * CreateSinglePhrase(SylText *, int bgn, int end);
Phrase * CreateKatakanaPhrase(SylText *, int bgn, int end);
Phrase * CreateHiraganaPhrase(SylText *, int bgn, int end);
Phrase * CreateHankakuPhrase(SylText *, int bgn, int end);
Phrase * CreateZenkakuPhrase(SylText *, int bgn, int end);
void FreePhrase(Phrase *);

int BeginningOfPhrase(Phrase *, Phrase *);
int LengthOfPhrase(Phrase *);
int CaretPositionOfPhrase(Phrase *, Phrase *);
wchar_t * CreateWCStringFromPhrase(Phrase *);
CARD32 * CreateFeedbackFromPhrase(Phrase *, Phrase *);
void ChangeNextRankOfPhrase(Phrase *, SylText *);
void ChangePrevRankOfPhrase(Phrase *, SylText *);
void StudyPhrase(Phrase *head, SylText *txt);
Phrase * ShortenPhrase(Phrase *view, SylText *txt);
Phrase * LengthenPhrase(Phrase *view, SylText *txt);
void ChangeKatakanaPhrase(Phrase *p, SylText *txt);
void ChangeHiraganaPhrase(Phrase *p, SylText *txt);
void ChangeHankakuPhrase(Phrase *p, SylText *txt);
void ChangeZenkakuPhrase(Phrase *p, SylText *txt);
