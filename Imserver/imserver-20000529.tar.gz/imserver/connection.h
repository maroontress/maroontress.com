typedef struct InputContext {
    struct InputContext *next;
    int ic_id;
    int input_style;
    Window client_window;
    Window focus_window;

    SylFontSet preedit_fontset;
    unsigned long preedit_foreground;
    unsigned long preedit_background;
    XPoint preedit_spot_location;

    Window status_window;
    GC status_gc;
    SylFontSet status_fontset;
    unsigned long status_foreground;
    unsigned long status_background;
    XRectangle status_area;

    Window candidate_window;
    SylFontSet *candidate_fontset;

    int forward;
    int focus;
    int romaji;
    int max_preedit_chars; /* $B%/%i%$%"%s%H$N4uK>(B */

    SylText *preedit;
    SylText *fixed;
    int caret;

    Phrase *head;
    Phrase *view;
} InputContext;

typedef struct Connection {
    struct Connection *next;
    Display *disp;
    Window client;
    Window server;
    int im_id;
    InputContext *work;
    InputContext *idle;
    int next_ic_id;

    XContext status;
    XContext candidate;
} Connection;

Connection * CreateConnection(XClientMessageEvent *);
void FreeConnection(Connection *);

InputContext * CreateInputContext(Connection *);
InputContext * SerachInputContext(Connection *, int);
void FreeInputContext(Connection *, int);
