/*
        send.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

void PrintSend(FILE *, PacketList *);
