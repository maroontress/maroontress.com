/*
        send.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "send.h"

void
PrintSend(FILE *fp, PacketList *pl)
{
    Packet *ptr;

    fprintf(fp, "\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Read)
	    continue;
	fprintf(fp,
		"\n"
		"void\n"
		"Send_%s(%s *p, int q, Packet **r, int *s)\n"
		"{\n"
		"\t" "int len;\n"
		"\t" "Chunk pac;\n"
		"\n"
		"\t" "len = Sizeof_%s(p, 0);\n"
		"\t" "*s = sizeof(Packet) + len;\n"
		"\t" "if ((*r = (Packet *)ldmalloc(*s)) != NULL) {\n"
		"\t\t" "(*r)->major_opcode = q;\n"
		"\t\t" "(*r)->minor_opcode = 0;\n"
		"\t\t" "(*r)->length = (len + 3) / 4;\n"
		"\t\t" "pac.s = (*r)->data;\n"
		"\t\t" "pac.c = (*r)->data;\n"
		"\t\t" "Write_%s(p, &pac);\n"
		"\t" "}\n"
		"}\n",
		ptr->type, ptr->type, ptr->type, ptr->type);
    }
}
