/*
	$Id: optimize.c,v 1.3 2003/07/06 16:25:15 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>

#include "Resource.h"
#include "Tokenizer.h"

#include "optimize.h"

#define STRATEGY_REVERSE_CARET "ReverseCaret"
#define STRATEGY_NO_FEEDBACK "NoFeedback"
#define STRATEGY_ANOTHER_FEEDBACK "AnotherFeedback"
#define STRATEGY_PREDICTION_DATABASE "PredictionDatabase"

static const char *ReservedWords[] = {
    STRATEGY_REVERSE_CARET,
    STRATEGY_NO_FEEDBACK,
    STRATEGY_ANOTHER_FEEDBACK,
    STRATEGY_PREDICTION_DATABASE,
    NULL};

typedef struct {
    const char *name;
    int value;
} StrategyTable;

static const StrategyTable Strategy[] = {
    {STRATEGY_REVERSE_CARET, OPT_REVERSE_CARET},
    {STRATEGY_NO_FEEDBACK, OPT_NO_FEEDBACK},
    {STRATEGY_ANOTHER_FEEDBACK, OPT_ANOTHER_FEEDBACK},
    {STRATEGY_PREDICTION_DATABASE, OPT_PREDICTION_DATABASE}};
#define N_STRATEGIES (sizeof(Strategy) / sizeof(StrategyTable))

typedef struct OptimizationRule {
    struct OptimizationRule *next;
    char *client_name;
    int strategy;
    char *database;
} OptimizationRule;

static void
FreeOptimizationRule(OptimizationRule *opt)
{
    free(opt->client_name);
    free(opt->database);
    free(opt);
}

static OptimizationRule *
AddToOptimizationRule(OptimizationRule *top, char *client_name, int strategy,
		      char *database)
{
    OptimizationRule *opt;

    if ((opt = (OptimizationRule *)malloc(sizeof(OptimizationRule))) == NULL)
	return (NULL);
    opt->client_name = NULL;
    opt->database = NULL;
    if ((opt->client_name = strdup(client_name)) == NULL
	|| (database != NULL && (opt->database = strdup(database)) == NULL)) {
	FreeOptimizationRule(opt);
	return (NULL);
    }
    opt->strategy = strategy;
    opt->next = top;
    return (opt);
}

typedef struct {
    const char *str;
    int len;
} Token;

typedef enum  {
    TOKEN_RESERVED,
    TOKEN_UNTERMINATED_STR,
    TOKEN_EMPTY_STR,
    TOKEN_STRCONST,
    TOKEN_EQUAL,
    TOKEN_SEMICOLON,
    TOKEN_COMMA,
    TOKEN_UNEXPECTED
} TokenType;

static int
IsEqualToken(Token *w, const char *s)
{
    return ((unsigned)w->len == strlen(s) && memcmp(s, w->str, w->len) == 0);
}

static int
TokenToStrategy(Token *w)
{
    unsigned int n;

    for (n = 0; n < N_STRATEGIES && !IsEqualToken(w, Strategy[n].name); ++n)
	;
    return ((n >= N_STRATEGIES) ? 0 : Strategy[n].value);
}

static int
GetNextToken(SylTokenizer *tok, Token *w)
{
    int type;

    while ((type = GetTokenFromSylTokenizer(tok, &w->str, &w->len))
	   == SYL_TOKEN_EMPTYLINES) {
	continue;
    }
    switch (type) {
    case EOF:
	return (EOF);
    case SYL_TOKEN_RESERVED:
	return (TOKEN_RESERVED);
    case SYL_TOKEN_UNTERMINATED_STR:
	return (TOKEN_UNTERMINATED_STR);
    case SYL_TOKEN_STRCONST:
	return ((w->len <= 2) ? TOKEN_EMPTY_STR : TOKEN_STRCONST);
    case SYL_TOKEN_OPERATOR:
	return (IsEqualToken(w, "=") ? TOKEN_EQUAL : TOKEN_UNEXPECTED);
    case SYL_TOKEN_PUNCTUATOR:
	if (w->len == 1 && *(w->str) == ';')
	    return (TOKEN_SEMICOLON);
	else if (w->len == 1 && *(w->str) == ',')
	    return (TOKEN_COMMA);
        /* FALLTHROUGH */
    default:
	return (TOKEN_UNEXPECTED);
    }
}

static void
CopyTokenIntoString(char *s, Token *t)
{
    sprintf(s, "%.*s", t->len - 2, t->str + 1);
}

static OptimizationRule *
AddRule(OptimizationRule *rule, Token *client_name, int strategy,
	Token *database)
{
    char *name, *path;

    if ((name = (char *)alloca(client_name->len - 1)) == NULL)
	return (NULL);
    CopyTokenIntoString(name, client_name);

    if (strategy & OPT_PREDICTION_DATABASE) {
	if ((path = (char *)alloca(database->len - 1)) == NULL)
	    return (NULL);
	CopyTokenIntoString(path, database);
    }
    else {
	path = NULL;
    }
#if 0
    printf("\"%s\" 0x%x; %s\n", name, strategy, path);
#endif    
    return (AddToOptimizationRule(rule, name, strategy, path));
}

typedef enum {
    SUCCESS,
    UNEXPECTED_EOS,
    UNTERMINATED_STR,
    EMPTY_STR,
    EQUAL_EXPECTED,
    SEMICOLON_EXPECTED,
    PARSE_ERROR,
    TOO_SHORT_MEMORY
} Result;

static Result
GetStrategies(SylTokenizer *tok, int *strategies, Token *database)
{
    Token w;
    int type, val;

    val = 0;
    do {
	if ((type = GetNextToken(tok, &w)) == EOF)
	    return (UNEXPECTED_EOS);
	else if (type != TOKEN_RESERVED)
	    return (PARSE_ERROR);
	else if (IsEqualToken(&w, STRATEGY_PREDICTION_DATABASE)) {
	    if ((type = GetNextToken(tok, &w)) == EOF)
		return (UNEXPECTED_EOS);
	    else if (type != TOKEN_EQUAL)
		return (EQUAL_EXPECTED);
	    else if ((type = GetNextToken(tok, database)) == EOF)
		return (UNEXPECTED_EOS);
	    else if (type == TOKEN_UNTERMINATED_STR)
		return (UNTERMINATED_STR);
	    else if (type == TOKEN_EMPTY_STR)
		return (EMPTY_STR);
	    else if (type != TOKEN_STRCONST)
		return (PARSE_ERROR);
	    else
		val |= OPT_PREDICTION_DATABASE;
	}
	else {
	    val |= TokenToStrategy(&w);
	}
    } while ((type = GetNextToken(tok, &w)) == TOKEN_COMMA);

    if (type == EOF)
	return (UNEXPECTED_EOS);
    else if (type != TOKEN_SEMICOLON)
	return (SEMICOLON_EXPECTED);

    *strategies = val;
    return (SUCCESS);
}

static Result
GetOptimizationRule(SylTokenizer *tok, OptimizationRule **rule)
{
    OptimizationRule *next;
    int type, val;
    Token name, database;
    Result s;

    while ((type = GetNextToken(tok, &name)) != EOF) {
	if (type == TOKEN_UNTERMINATED_STR)
	    return (UNTERMINATED_STR);
	else if (type == TOKEN_EMPTY_STR)
	    return (EMPTY_STR);
	else if (type != TOKEN_STRCONST)
	    return (PARSE_ERROR);
	else if ((s = GetStrategies(tok, &val, &database)) != SUCCESS)
	    return (s);
	else if ((next = AddRule(*rule, &name, val, &database)) == NULL)
	    return (TOO_SHORT_MEMORY);
	*rule = next;
    }
    return (SUCCESS);
}

static OptimizationRule *
LoadOptimizationRule(char *name, SylSetting *opt)
{
    OptimizationRule *rule = NULL;
    SylTokenizer *tok;

    if ((tok = CreateSylTokenizer(opt->spec)) == NULL)
	return (NULL);
    SetReservedWordsToSylTokenizer(tok, ReservedWords);
    switch (GetOptimizationRule(tok, &rule)) {
    case SUCCESS:
	break;
    case UNEXPECTED_EOS:
	warnx("%s.%s: line %d, unexpected EOS.\n",  name, opt->name,
	      LineOfSylTokenizer(tok));
	break;
    case UNTERMINATED_STR:
	warnx("%s.%s: line %d, unterminated string.\n", name, opt->name,
	      LineOfSylTokenizer(tok));
	break;
    case EMPTY_STR:
	warnx("%s.%s: line %d, empty string.\n", name, opt->name,
	      LineOfSylTokenizer(tok));
	break;
    case EQUAL_EXPECTED:
	warnx("%s.%s: line %d, `%s'; `=' expected.\n", name, opt->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case SEMICOLON_EXPECTED:
	warnx("%s.%s: line %d, `%s'; `,' or `;' expected.\n", name, opt->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case PARSE_ERROR:
	warnx("%s.%s: line %d, parse error `%s'.\n", name, opt->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case TOO_SHORT_MEMORY:
	warnx("%s.%s: line %d, too short memory.\n",
	      name, opt->name, LineOfSylTokenizer(tok));
	break;
    }
    FreeSylTokenizer(tok);
    return (rule);
}

static OptimizationRule *ReliefRule = NULL;

void
LoadClientOptimization(Display *disp, char *name, char *class, SylSetting *opt)
{
    GetSylSetting(disp, name, class, opt);
    ReliefRule = LoadOptimizationRule(name, opt);
}

static OptimizationRule *
QueryOptimizationRule(char *client_name)
{
    OptimizationRule *r;

    for (r = ReliefRule; r != NULL && strcmp(r->client_name, client_name);
	 r = r->next) {
	continue;
    }
    return (r);
}

static OptimizationRule *
LookupOptimizationRule(XClassHint *ch)
{
    OptimizationRule *rule;

    if ((rule = QueryOptimizationRule(ch->res_name)) == NULL)
	rule = QueryOptimizationRule(ch->res_class);
    return (rule);
}

static Window
ParentWindow(Display *disp, Window window)
{
    Window root, parent, *childp;
    unsigned int children;

    if (XQueryTree(disp, window, &root, &parent, &childp, &children))
        XFree(childp);
    return (parent);
}

int
GetOptimization(Display *dpy, Window w, int *strategy, char **database)
{
    XClassHint ch; 
    OptimizationRule *rule;

    for (; w != None && XGetClassHint(dpy, w, &ch) == 0;
	 w = ParentWindow(dpy, w)) {
	continue;
    }
    if (w == None)
	return (False);
    if ((rule = LookupOptimizationRule(&ch)) != NULL) {
	*strategy = rule->strategy;
	*database = rule->database;
    }
    else {
	*strategy = 0;
	*database = NULL;
    }
#ifdef DEBUG
    printf("\tToplevel 0x%lx %s/%s 0x%x %s\n", w, ch.res_name, ch.res_class,
	   *strategy, *database);
#endif
    XFree(ch.res_name);
    XFree(ch.res_class);
    return (True);
}
