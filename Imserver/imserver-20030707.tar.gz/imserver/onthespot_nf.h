/*
	$Id: onthespot_nf.h,v 1.1 2003/06/01 17:22:48 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

extern ICPreeditDrawMethods *ICPreeditDrawOnTheSpotNF;
