/*
	$Id: leakdetect.h,v 1.1 2000/10/03 18:45:25 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void * ldmalloc(unsigned int);
void ldfree(void *);
unsigned int ldusing(void);
