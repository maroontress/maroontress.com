/*
	$Id: canna.c,v 1.6 2003/03/05 11:29:45 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <sys/types.h>
#include <unistd.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <canna/RK.h>

#include "Resource.h"
#include "WCString.h"
#include "Text.h"
#include "leakdetect.h"
#include "phrase.h"
#include "engine.h"
#include "canna.h"

static int
OpenConversionServerWithCanna(char *server __unused)
{
    int k, n_dics;
    char *dhdpath = CANNA_DIR "/dic";
    char buf[4096], *p;

    (void)RkInitialize(dhdpath);
    n_dics = RkGetDicList(0, buf, sizeof(buf));
    for (p = buf, k = 0; k < n_dics; ++k) {
	(void)RkMountDic(0, p, 0);
#ifdef DEBUG
	printf("[%d]: %s\n", k, p);
#endif
	p += strlen(p) + 1;
    }
    return (0);
}

static void
CloseConversionServerWithCanna(void)
{
    RkFinalize();
}

#ifdef linux
static void
PreverifyMBString(char *mbs)
{
    wchar_t buf[1024];
    
    if ((int)mbstowcs(buf, mbs, 1024) < 0)
	strcpy(mbs, "?");
}
#endif

static void
GetCandidateListWithCanna(Phrase *p, wchar_t *wcs)
{
    SylText *txt;
    unsigned char mbs[1024];
    const int len = sizeof(mbs);

    wcstombs(mbs, wcs, len);
    AddCandidateToPhrase(p, CreateCandidate(p->applicant));
    (void)RkBgnBun(0, mbs, strlen(mbs), RK_XFER);
    (void)RkResize(0, strlen(mbs));
    do {
	(void)RkGetKanji(0, mbs, sizeof(mbs));
#ifdef linux
	PreverifyMBString(mbs);
#endif
	txt = CreateSylTextFromMBString(mbs, False);
	if (HasCandidateOfPhrase(p, txt) == NULL) {
	    AddCandidateToPhrase(p, CreateCandidate(txt));
	}
	FreeSylText(txt);
    } while (RkNext(0) > 0);
    RkEndBun(0, False); /* Don't study */
}

static Phrase *
ConvertSinglePhraseWithCanna(wchar_t *wcs, int offset, int length)
{
    Phrase *p;
    unsigned char mbs[1024];
    const int len = sizeof(mbs);

    wcstombs(mbs, wcs, len);
    (void)RkBgnBun(0, mbs, strlen(mbs), RK_XFER);
    (void)RkResize(0, strlen(mbs));
    (void)RkGetKanji(0, mbs, sizeof(mbs));
#ifdef linux
    PreverifyMBString(mbs);
#endif
    RkEndBun(0, False); /* Don't study */

    p = (Phrase *)ldmalloc(sizeof(Phrase));
    p->next = NULL;
    p->prev = NULL;
    p->offset = offset;
    p->length = length;
    p->original = length;
    p->chosen = CreateSylTextFromMBString(mbs, False);
    p->applicant = CreateSylTextFromMBString(mbs, False);
    p->predicted = PHRASE_NOT_PREDICTED;
    p->head = NULL;
    p->tail = NULL;
    return (p);
}

static Phrase *
ConvertWithCanna(wchar_t *wcs, int offset)
{
    int n, status, length;
    Phrase *p, *head = NULL, *tail = NULL;
    unsigned char mbs[1024];
    const int len = sizeof(mbs);
    SylText *txt;

    wcstombs(mbs, wcs, len);
    if ((status = RkBgnBun(0, mbs, strlen(mbs), RK_XFER)) <= 0)
	return (NULL);
    for (n = 0; n < status && (p = (Phrase *)ldmalloc(sizeof(Phrase))) != NULL;
	 (offset += p->length), ++n, (void)RkRight(0)) {
	(void)RkGetYomi(0, mbs, sizeof(mbs));
	txt = CreateSylTextFromMBString(mbs, False);
	length = LengthOfSylText(txt);
	FreeSylText(txt);

	(void)RkGetKanji(0, mbs, sizeof(mbs));
#ifdef linux
	PreverifyMBString(mbs);
#endif
	p->next = NULL;
	p->prev = tail;
	p->offset = offset;
	p->length = length;
	p->original = length;
	p->chosen = CreateSylTextFromMBString(mbs, False);
	p->applicant = CreateSylTextFromMBString(mbs, False);
	p->predicted = PHRASE_NOT_PREDICTED;
	p->head = NULL;
	p->tail = NULL;
	if (head == NULL)
	    head = p;
	else
	    tail->next = p;
	tail = p;
    }
    RkEndBun(0, False); /* Don't study */
    return (head);
}

static void
StudyPhraseWithCanna(Phrase *head, SylText *txt)
{
    Phrase *p;
    char *mbs, buf[1024];

    mbs = CreateMBStringFromSylText0(txt);
    (void)RkBgnBun(0, mbs, strlen(mbs), RK_XFER);
    free(mbs);
    for (p = head; p != NULL; p = p->next) {
	mbs = CreateMBStringFromSylText(txt, p->offset, p->offset + p->length);
	(void)RkResize(0, strlen(mbs));
	free(mbs);
	
	mbs = CreateMBStringFromSylText0(p->chosen);
	do {
	    (void)RkGetKanji(0, buf, sizeof(buf));
#ifdef linux
	    PreverifyMBString(buf);
#endif
	    if (strcmp(buf, mbs) == 0) {
		break;
	    }
	} while (RkNext(0) > 0);
	free(mbs);

	(void)RkRight(0);
    }
    RkEndBun(0, True); /* Do study */
}

static Engine EnginePoweredByCanna = {
    OpenConversionServerWithCanna,
    CloseConversionServerWithCanna,
    ConvertWithCanna,
    ConvertSinglePhraseWithCanna,
    GetCandidateListWithCanna,
    StudyPhraseWithCanna};

Engine * CannaEngine = &EnginePoweredByCanna;
