/*
	$Id: phrase.h,v 1.7 2003/06/01 16:36:11 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

typedef struct Candidate {
    struct Candidate *next;
    struct Candidate *prev;
    SylText *applicant;
    SylText *phonetic;
} Candidate;

typedef enum {
    PHRASE_NOT_PREDICTED,
    PHRASE_PRIMARY_PREDICTED,
    PHRASE_SECONDARY_PREDICTED
} PhraseType;

typedef struct Phrase {
    struct Phrase *next;
    struct Phrase *prev;
    int offset;         /* �ɤ�ʸ�������ʸ�ᳫ�ϰ��� */
    int length;         /* �ɤ�ʸ������θ��ߤ�ʸ��ʸ���� */
    int original;       /* �ɤ�ʸ������ν����ʸ��ʸ���� */
    SylText *chosen;    /* ɽ������Ƥ������ʸ���� */
    SylText *applicant; /* ���ߤ�ñʸ�����ʸ���� */
    Candidate *head;    /* ñʸ�����ꥹ�Ȥ���Ƭ */
    Candidate *tail;    /* ñʸ�����ꥹ�Ȥ����� */
    PhraseType predicted;
} Phrase;

Candidate *CreateCandidate(SylText *);
void FreeCandidate(Candidate *);

Phrase * CreatePhrase(SylText *, int bgn, int end);
Phrase * CreateSinglePhrase(SylText *, int bgn, int end);
Phrase * CreateKatakanaPhrase(SylText *, int bgn, int end);
Phrase * CreateHiraganaPhrase(SylText *, int bgn, int end);
Phrase * CreateHankakuPhrase(SylText *, int bgn, int end);
Phrase * CreateZenkakuPhrase(SylText *, int bgn, int end);
void FreePhrase(Phrase *);

int BeginningOfPhrase(Phrase *, Phrase *);
int LengthOfPhrase(Phrase *);
int CaretPositionOfPhrase(Phrase *, Phrase *);
wchar_t * CreateWCStringFromPhrase(Phrase *);
SylText * CreateSylTextFromPhrase(Phrase *);
void ChangeNextRankOfPhrase(Phrase *, SylText *);
void ChangePrevRankOfPhrase(Phrase *, SylText *);
void StudyPhrase(Phrase *head, SylText *txt);
Phrase * ShortenPhrase(Phrase *view, SylText *txt);
Phrase * LengthenPhrase(Phrase *view, SylText *txt);
void ChangeKatakanaPhrase(Phrase *p, SylText *txt);
void ChangeHiraganaPhrase(Phrase *p, SylText *txt);
void ChangeHankakuPhrase(Phrase *p, SylText *txt);
void ChangeZenkakuPhrase(Phrase *p, SylText *txt);

Candidate * HasCandidateOfPhrase(Phrase *p, SylText *t);
Candidate * LookupCandidateOfPhrase(Phrase *p);
void AddCandidateToPhrase(Phrase *p, Candidate *c);
