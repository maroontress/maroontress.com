/*
	$Id: trigger.c,v 1.2 2003/05/31 14:12:53 syl Exp $

	Copyright (C) 1999, 2000, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <err.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"
#include "Tokenizer.h"

#include "xim.h"
#include "trigger.h"

static const char *ReservedWords[] = {
    "keysym",
    "modifier",
    "mask",
    NULL};

typedef struct {
    const char *name;
    unsigned int code;
} ModifierTable;

static const ModifierTable Modifier[] = {
    {"None", 0},
    {"Shift", ShiftMask},
    {"Control", ControlMask},
    {"Mod1", Mod1Mask},
    {"Mod2", Mod2Mask},
    {"Mod3", Mod3Mask},
    {"Mod4", Mod4Mask},
    {"Mod5", Mod5Mask}};
#define N_MODIFIERS (sizeof(Modifier) / sizeof(ModifierTable))

typedef struct {
    const char *str;
    int len;
} Token;

typedef enum  {
    TOKEN_RESERVED,
    TOKEN_HYPHEN,
    TOKEN_UNEXPECTED
} TokenType;

static int
IsEqualToken(Token *w, const char *s)
{
    return ((unsigned)w->len == strlen(s) && memcmp(s, w->str, w->len) == 0);
}

static int
TokenToModifier(Token *w, CARD32 *mod)
{
    unsigned int n;

    for (n = 0; n < N_MODIFIERS && !IsEqualToken(w, Modifier[n].name); ++n)
	;
    if (n >= N_MODIFIERS)
	return (False);
    *mod |= Modifier[n].code;
    return (True);
}

static int
GetNextToken(SylTokenizer *tok, Token *w)
{
    int type;

    while ((type = GetTokenFromSylTokenizer(tok, &w->str, &w->len))
	   == SYL_TOKEN_EMPTYLINES) {
        continue;
    }
    switch (type) {
    case EOF:
	return (EOF);
    case SYL_TOKEN_RESERVED:
	return (TOKEN_RESERVED);
    case SYL_TOKEN_OPERATOR:
	if (IsEqualToken(w, "-"))
	    return (TOKEN_HYPHEN);
	/* FALLTHROUGH */
    default:
	return (TOKEN_UNEXPECTED);
    }
}

typedef enum {
    SUCCESS,
    UNEXPECTED_EOS,
    PARSE_ERROR,
    UNKNOWN_KEYSYM,
    UNKNOWN_MODIFIER,
    UNKNOWN_MASK
} Result;

static KeySym
TokenToKeysym(Token *w)
{
    char *s;

    if ((s = (char *)alloca(w->len + 1)) == NULL)
	return (None);
    sprintf(s, "%.*s", w->len, w->str);
    return (XStringToKeysym(s));
}

static Result
GetTriggerKey(SylTokenizer *tok, XIMTRIGGERKEY *t)
{
    int type;
    Token w;

    t->modifier = 0;
    t->mask = 0;
    if ((type = GetNextToken(tok, &w)) == EOF)
	return (UNEXPECTED_EOS);
    else if (type != TOKEN_RESERVED || !IsEqualToken(&w, "keysym"))
	return (PARSE_ERROR);
    else if ((type = GetNextToken(tok, &w)) == EOF)
	return (UNEXPECTED_EOS);
    else if ((t->keysym = TokenToKeysym(&w)) == NoSymbol)
	return (UNKNOWN_KEYSYM);
    else if ((type = GetNextToken(tok, &w)) != EOF) {
	if (IsEqualToken(&w, "modifier")) {
	    do {
		if ((type = GetNextToken(tok, &w)) == EOF)
		    return (UNEXPECTED_EOS);
		else if (TokenToModifier(&w, &(t->modifier)) == 0)
		    return (UNKNOWN_MODIFIER);
		else if ((type = GetNextToken(tok, &w)) == EOF)
		    return (SUCCESS);
	    } while (type == TOKEN_HYPHEN);
	}
	if (IsEqualToken(&w, "mask")) {
	    do {
		if ((type = GetNextToken(tok, &w)) == EOF)
		    return (UNEXPECTED_EOS);
		else if (TokenToModifier(&w, &(t->mask)) == 0)
		    return (UNKNOWN_MASK);
		else if ((type = GetNextToken(tok, &w)) == EOF)
		    return (SUCCESS);
	    } while (type == TOKEN_HYPHEN);
	}
	return (PARSE_ERROR);
    }
    return (SUCCESS);
}

void
LoadTriggerKeys(Display *disp, char *name, char *class,
		SylSetting *key, XIMTRIGGERKEY *tri)
{
    SylTokenizer *tok;

    GetSylSetting(disp, name, class, key);
    if ((tok = CreateSylTokenizer(key->spec)) == NULL) {
	warnx("%s.%s: CreateSylTokenizer() failed.\n", name, key->name);
	return;
    }
    SetReservedWordsToSylTokenizer(tok, ReservedWords);
    switch (GetTriggerKey(tok, tri)) {
    case SUCCESS:
	break;
    case UNEXPECTED_EOS:
	warnx("%s.%s: line %d, unexpected EOS.\n", name, key->name,
	      LineOfSylTokenizer(tok));
	break;
    case PARSE_ERROR:
	warnx("%s.%s: line %d, parse error `%s'.\n", name, key->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case UNKNOWN_KEYSYM:
	warnx("%s.%s: line %d, unknown keysym `%s'.\n", name, key->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case UNKNOWN_MODIFIER:
	warnx("%s.%s: line %d, unknown modifier `%s'.\n", name, key->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case UNKNOWN_MASK:
	warnx("%s.%s: line %d, unknown mask `%s'.\n", name, key->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    }
    FreeSylTokenizer(tok);
}
