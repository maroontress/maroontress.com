/*
	$Id: preedit.c,v 1.11 2003/07/06 16:42:16 syl Exp $

	Copyright (C) 1999, 2000, 2001, 2002, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h"
#include "message.h"
#include "status.h"
#include "commit.h"
#include "preconv.h"
#include "predict.h"
#include "preedit.h"

static unsigned char *
KanaToMBSrting(unsigned char c)
{
    static unsigned char *table[] = {
	/* */ "��", "��", "��", "��", "��", "��", "��",
        "��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��"};
    c -= 0xa1;
    return (table[c]);
}

static wchar_t
VoicedSound(wchar_t w)
{
    static char *before[] = {
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", NULL};
    static char *after[] = {
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��",
	"��", "��", "��", "��", "��", "��", "��", "��", "��", "��", NULL};
    char **ptr;
    wchar_t c;
    int n;

    for (n = 0, ptr = before; *ptr != NULL; ++n, ++ptr) {
	mbtowc(&c, *ptr, 2);
	if (c == w) {
	    mbtowc(&w, after[n], 2);
	    return (w);
	}
    }
    return (0);
}

static wchar_t
SemivoicedSound(wchar_t w)
{
    static char *before[] = {"��", "��", "��", "��", "��", NULL};
    static char *after[] = {"��", "��", "��", "��", "��", NULL};
    char **ptr;
    wchar_t c;
    int n;

    for (n = 0, ptr = before; *ptr != NULL; ++n, ++ptr) {
	mbtowc(&c, *ptr, 2);
	if (c == w) {
	    mbtowc(&w, after[n], 2);
	    return (w);
	}
    }
    return (0);
}

void
PreeditInsertChar(XIM_FORWARD_EVENT *ev, Connection *con, unsigned char *buf)
{ 
    const int TenTen = 0xde; /* "��" */
    const int Maru = 0xdf; /* "��" */
    wchar_t w, snd, *wcs;
    int chg_first, chg_length, back, forward;
    InputContext *ic;

    if ((ic = SerachInputContext(con, ev->ic_id)) == NULL)
	return;
    if (ic->head != NULL) {
	ClearString(con, ic); 
	EchoXIMForwardEvent(con, ev);
	CommitString(con, ic);
	CommitStatus(con, ic);
	return;
    }
    if (0xa1 <= *buf && *buf <= 0xdf)
	mbtowc(&w, KanaToMBSrting(*buf), 2);
    else
	w = *buf;
    chg_first = ic->caret;
    chg_length = 0;
    if (ic->caret > 0) {
	wcs = CreateWCStringFromSylText(ic->preedit, ic->caret - 1, ic->caret);
	if ((*buf == TenTen && (snd = VoicedSound(*wcs)) != 0)
	    || ((*buf == Maru && (snd = SemivoicedSound(*wcs)) != 0))) {
	    --(ic->caret);
	    DeleteCharOfSylText(ic->preedit, ic->caret);
	    w = snd;
	    chg_first = ic->caret;
	    chg_length = 1;
	}
	free(wcs); /* CreateWCStringFromSylText() */
    }
    InsertWCharIntoSylText(ic->preedit, ic->caret, w);
    ++(ic->caret);
    if (ic->preconversion >= PRECONVERSION_SINGLE
	&& Preconvert(ic->preedit, ic->caret, &back, &forward, False)) {
	chg_first -= back - 1;
	chg_length += back - 1;
	ic->caret += (forward - back);
    }
    if (ic->preconversion >= PRECONVERSION_DOUBLE) {
	ReplaceSymbolSystem(ic->preedit, chg_first, ic->caret, True);
    }
    ic->preedit_draw->replace(con, ic, chg_first, chg_length);
    CommitPrediction(con, ic);
}

static void
FinalizePreconversion(InputContext *ic)
{
    int forward, back, chg_first = ic->caret;

    if (ic->preconversion >= PRECONVERSION_SINGLE
	&& Preconvert(ic->preedit, ic->caret, &back, &forward, True)) {
	chg_first -= back - 1;
	ic->caret += (forward - back);
    }
    if (ic->preconversion >= PRECONVERSION_DOUBLE) {
	ReplaceSymbolSystem(ic->preedit, chg_first, ic->caret, True);
    }
}

static void
PreeditSpecifiedConvert(Connection *con, InputContext *ic,
			Phrase *(*create_phrase)(SylText *, int, int))
{
    FinalizePreconversion(ic);
    ic->head = create_phrase(ic->preedit, 0, LengthOfSylText(ic->preedit));
    ic->view = ic->head;
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->convert(con, ic);
    CommitStatus(con, ic);
    CommitSecondaryPrediction(con, ic);
}

static void
PreeditConvert(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    PreeditSpecifiedConvert(con, ic, CreatePhrase);
}

static void
PreeditConvertSingle(Connection *con, InputContext *ic,
		     XIM_FORWARD_EVENT *ev __unused)
{
    PreeditSpecifiedConvert(con, ic, CreateSinglePhrase);
}

static void
PreeditHiragana(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    PreeditSpecifiedConvert(con, ic, CreateHiraganaPhrase);
}

static void
PreeditKatakana(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    PreeditSpecifiedConvert(con, ic, CreateKatakanaPhrase);
}

static void
PreeditZenkaku(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    PreeditSpecifiedConvert(con, ic, CreateZenkakuPhrase);
}

static void
PreeditHankaku(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    PreeditSpecifiedConvert(con, ic, CreateHankakuPhrase);
}

static void
PreeditBackSpace(Connection *con, InputContext *ic,
		 XIM_FORWARD_EVENT *ev __unused)
{
    if (ic->caret <= 0)
	return;
    --(ic->caret);
    DeleteCharOfSylText(ic->preedit, ic->caret);
    ic->preedit_draw->delete_char(con, ic);
    CommitPrediction(con, ic);
}

static void
PreeditDelete(Connection *con, InputContext *ic,
	      XIM_FORWARD_EVENT *ev __unused)
{
    if (ic->caret == LengthOfSylText(ic->preedit))
	return;
    DeleteCharOfSylText(ic->preedit, ic->caret);
    ic->preedit_draw->delete_char(con, ic);
    CommitPrediction(con, ic);
}

static void
PreeditCaretRight(Connection *con, InputContext *ic,
		  XIM_FORWARD_EVENT *ev __unused)
{
    if (ic->caret >= LengthOfSylText(ic->preedit))
	return;
    ++(ic->caret);
    ic->preedit_draw->move_caret(con, ic);
}

static void
PreeditCaretLeft(Connection *con, InputContext *ic,
		 XIM_FORWARD_EVENT *ev __unused)
{
    if (ic->caret <= 0)
	return;
    --(ic->caret);
    ic->preedit_draw->move_caret(con, ic);
}

static void
PreeditCaretHead(Connection *con, InputContext *ic,
		 XIM_FORWARD_EVENT *ev __unused)
{
    if (ic->caret <= 0)
	return;
    ic->caret = 0;
    ic->preedit_draw->move_caret(con, ic);
}

static void
PreeditCaretTail(Connection *con, InputContext *ic,
		 XIM_FORWARD_EVENT *ev __unused)
{
    if (ic->caret >= LengthOfSylText(ic->preedit))
	return;
    ic->caret = LengthOfSylText(ic->preedit);
    ic->preedit_draw->move_caret(con, ic);
}

static void
PreeditLineFeed(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    FinalizePreconversion(ic);
    ClearString(con, ic); 
    EchoXIMForwardEvent(con, ev);
    CommitString(con, ic);
    CommitStatus(con, ic);
}

static void
PreeditCommit(Connection *con, InputContext *ic,
	      XIM_FORWARD_EVENT *ev __unused)
{
    FinalizePreconversion(ic);
    ClearString(con, ic); 
    CommitString(con, ic);
    CommitStatus(con, ic);
}

static void
PreeditCancel(Connection *con, InputContext *ic,
	      XIM_FORWARD_EVENT *ev __unused)
{
    ClearString(con, ic); 
    DeleteStringOfSylText(ic->preedit, 0, LengthOfSylText(ic->preedit));
    ic->caret = 0;
}

static void
DoublePreconversionMode(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_DOUBLE;
    CommitStatus(con, ic);
}

static void
SinglePreconversionMode(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_SINGLE;
    CommitStatus(con, ic);
}

static void
DirectInputMode(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_NONE;
    CommitStatus(con, ic);
}

static void
Predict(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev __unused)
{
    Phrase *p;

    if ((p = PredictedPhrase(ic->prediction_database, ic->preedit,
			     PHRASE_PRIMARY_PREDICTED)) == NULL) {
	return;
    }
    ic->head = p;
    ic->view = p;
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->convert(con, ic);
    CommitStatus(con, ic);
    CommitSecondaryPrediction(con, ic);
}

void (*PreeditBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverPreedit.branch"
};
