/*
	$Id: onthespot_nf.c,v 1.3 2005/01/09 09:32:19 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "message.h"
#include "status.h"
#include "commit.h"
#include "onthespot_nf.h"

#define NO_STRING 1
#define NO_FEEDBACK 2

static int
NumberOfPhrase(Phrase *p)
{
    int n;

    for (n = 0; p != NULL; p = p->next)
        ++n;
    return (n);
}

static int
OffsetOfPhrase(Phrase *p, Phrase *q)
{
    int n;

    for (n = 0; p != NULL && p != q; p = p->next)
        ++n;
    return (n);
}

static wchar_t *
CreateSeparatedWCStringFromPhrase(Phrase *head, Phrase *view)
{
    Phrase *p;
    SylText *txt;
    wchar_t *wcs;
    int offset;

    txt = CreateSylTextFromMBString(" ", False);
    for (p = head; p != NULL; p = p->next) {
        InsertSylTextIntoSylText0(txt, LengthOfSylText(txt), p->chosen);
	InsertWCharIntoSylText(txt, LengthOfSylText(txt), ' ');
    }
    wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);
    offset = 0;
    for (p = head; p != NULL && p != view; p = p->next) {
        offset += LengthOfSylText(p->chosen) + 1;
    }
    wcs[offset] = '<';
    wcs[offset + LengthOfSylText(view->chosen) + 1] = '>';
    return (wcs);
}

static void
PreeditDraw(Connection *con, XIM_PREEDIT_DRAW *xim_preedit_draw)
{
    SerializedPacket *req;
    int len;

    xim_preedit_draw->status |= NO_FEEDBACK;
    xim_preedit_draw->feedback.num = 0;
    xim_preedit_draw->feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static int
DrawnLength(Phrase *p)
{
    return (LengthOfPhrase(p) + NumberOfPhrase(p) + 1);
}

static void
Clear(Connection *con, InputContext *ic)
{ 
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    
    if ((len = LengthOfSylText(ic->preedit)) <= 0)
	return;
    if (ic->head != NULL)
	len = DrawnLength(ic->head);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = 0;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = len;
    xim_preedit_draw.status = NO_STRING;
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    PreeditDraw(con, &xim_preedit_draw);
    ic->last_drawn_length = 0;
}

static void
ChangePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    int offset = OffsetOfPhrase(ic->head, ic->view) + 1;

    len = LengthOfSylText(ic->view->chosen);
    wcs = CreateWCStringFromSylText0(ic->view->chosen);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = offset + ic->caret;
    xim_preedit_draw.chg_first = offset + chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    PreeditDraw(con, &xim_preedit_draw);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText0() */
    ic->last_drawn_length = DrawnLength(ic->head);
}

static void
ResizePhrase(Connection *con, InputContext *ic,
	     int chg_first __unused, int chg_length __unused)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    XTextProperty t;
    wchar_t *wcs;
    int offset = OffsetOfPhrase(ic->head, ic->view) + 1;

    wcs = CreateSeparatedWCStringFromPhrase(ic->head, ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = offset + ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = ic->last_drawn_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    PreeditDraw(con, &xim_preedit_draw);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateSeparatedWCStringFromPhrase() */
    ic->last_drawn_length = DrawnLength(ic->head);
}

static void
Cancel(Connection *con, InputContext *ic,
       int chg_first __unused, int chg_length __unused)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    wchar_t *wcs;
    XTextProperty t;

    wcs = CreateWCStringFromSylText0(ic->preedit);
    len = LengthOfSylText(ic->preedit);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = ic->last_drawn_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    PreeditDraw(con, &xim_preedit_draw);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText0() */
    ic->last_drawn_length = len;
}

static void
SelectPhrase(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    XTextProperty t;
    wchar_t *wcs;
    int offset = OffsetOfPhrase(ic->head, ic->view) + 1;

    wcs = CreateSeparatedWCStringFromPhrase(ic->head, ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = offset + ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = wstrlen(wcs);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    PreeditDraw(con, &xim_preedit_draw);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateSeparatedWCStringFromPhrase() */
    ic->last_drawn_length = DrawnLength(ic->head);
}

static void
DeleteSubstring(Connection *con, InputContext *ic, int length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;

    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = length;
    xim_preedit_draw.status = NO_STRING;
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    PreeditDraw(con, &xim_preedit_draw);
    ic->last_drawn_length = LengthOfSylText(ic->preedit);
}

static void
Replace(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XTextProperty t;
    XIM_PREEDIT_DRAW xim_preedit_draw;
    wchar_t *wcs;
 
    if (ic->caret == chg_first) {
	/*
	  onthespot.c$B$N(BReplace()$B$N%3%a%s%H$r;2>H!#(BQt$B$G$b$A$c$s$H=hM}$G$-(B
	  $B$J$$!#(B
	*/
	DeleteSubstring(con, ic, chg_length);
	return;
    }
    wcs = CreateWCStringFromSylText(ic->preedit, chg_first, ic->caret);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    PreeditDraw(con, &xim_preedit_draw);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText() */
    ic->last_drawn_length = LengthOfSylText(ic->preedit);
}

static void
Convert(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    XTextProperty t;
    wchar_t *wcs;
    int offset = OffsetOfPhrase(ic->head, ic->view) + 1;

    wcs = CreateSeparatedWCStringFromPhrase(ic->head, ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = offset + ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfSylText(ic->preedit);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    PreeditDraw(con, &xim_preedit_draw);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateSeparatedWCStringFromPhrase() */
    ic->last_drawn_length = DrawnLength(ic->head);
}

static void
DeleteChar(Connection *con, InputContext *ic)
{
    DeleteSubstring(con, ic, 1);
}

static void
MoveCaret(Connection *con, InputContext *ic)
{
#if 0
    XIM_PREEDIT_DRAW xim_preedit_draw;

    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 0;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    PreeditDraw(con, &xim_preedit_draw);
    ic->last_drawn_length = LengthOfSylText(ic->preedit);
#else
    /*
      $B$=$b$=$b%U%#!<%I%P%C%/$r$^$H$b$KIA2h$G$-$J$$$h$&$J(BXIM$B%/%i%$%"%s%H(B
      $B$,%-%c%l%C%H$r$A$c$s$HIA2h$G$-$k$H4|BT$9$k$3$H$,4V0c$$$+$b$7$l$J$$!#(B
    */
    Cancel(con, ic, 0, LengthOfSylText(ic->preedit));
#endif
}

static void
DoNothing(Connection *con __unused, InputContext *ic __unused)
{
}

static ICPreeditDrawMethods methods = {
    Clear,
    ChangePhrase,
    ResizePhrase,
    Cancel,
    SelectPhrase,
    Replace,
    Convert,
    DeleteChar,
    MoveCaret,
    DoNothing/* focus_in */,
    DoNothing/* focus_out */,
    DoNothing/* destroy */};

ICPreeditDrawMethods *ICPreeditDrawOnTheSpotNF = &methods;
