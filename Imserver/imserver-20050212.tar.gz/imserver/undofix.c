/*
	$Id: undofix.c,v 1.7 2004/02/15 19:06:26 syl Exp $

	Copyright (C) 1999, 2000, 2001, 2004 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "commit.h"
#include "predict.h"
#include "mode.h"
#include "undofix.h"

static void
UndofixPreedit(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    InsertSylTextIntoSylText0(ic->preedit, 0, ic->fixed);
    ic->caret = LengthOfSylText(ic->preedit);
    ic->preedit_draw->cancel(con, ic, 0, 0);
    CommitPrediction(con, ic);
}

static void
PassImmediately(Connection *con, InputContext *ic __unused,
		XIM_FORWARD_EVENT *ev)
{
    EchoXIMForwardEvent(con, ev);
}

void (*UndofixBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverUndofix.branch"
};
