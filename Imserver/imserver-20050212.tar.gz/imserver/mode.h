/*
	$Id: mode.h,v 1.1 2004/02/15 18:49:06 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

void DoublePreconversionMode(Connection *, InputContext *,
			     XIM_FORWARD_EVENT *);
void SinglePreconversionMode(Connection *, InputContext *,
			     XIM_FORWARD_EVENT *);
void DirectInputMode(Connection *, InputContext *, XIM_FORWARD_EVENT *);
void EnableReferenceMode(Connection *, InputContext *, XIM_FORWARD_EVENT *);
void DisableReferenceMode(Connection *, InputContext *, XIM_FORWARD_EVENT *);
