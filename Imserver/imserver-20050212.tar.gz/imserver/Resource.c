/*
	$Id: Resource.c,v 1.5 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1998, 1999, 2001, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <sys/param.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <pwd.h>
#include <err.h>
#include <time.h>

#ifndef MAXHOSTNAMELEN /* for Solaris */ 
#define MAXHOSTNAMELEN 256
#endif

#include "Resource.h"

static XrmDatabase
GetXdefaultsDatabase(void)
{
    char path[MAXPATHLEN];
    struct passwd *user;

    if ((user = getpwuid(getuid())) == NULL)
	return (NULL);
    snprintf(path, sizeof(path), "%s/.Xdefaults", user->pw_dir);
    return (XrmGetFileDatabase(path));
}

static void
CombineXdefaultsHostnameDatabase(XrmDatabase *db)
{
    char path[MAXPATHLEN], hostname[MAXHOSTNAMELEN];
    struct passwd *user;

    if ((user = getpwuid(getuid())) == NULL
	|| gethostname(hostname, MAXHOSTNAMELEN) < 0) /* XXX */
	return;
    snprintf(path, sizeof(path), "%s/.Xdefaults-%s", user->pw_dir, hostname);
    XrmCombineFileDatabase(path, db, True);    
}

XrmDatabase
SylMergedResourceDatabase(Display *disp)
{
    char *mgr_str, *env_file;
    XrmDatabase db;

    if ((mgr_str = XResourceManagerString(disp)) != NULL)
	db = XrmGetStringDatabase(mgr_str);
    else
	db = GetXdefaultsDatabase();
    if ((env_file = getenv("XENVIRONMENT")) != NULL)
	XrmCombineFileDatabase(env_file, &db, True);
    else
	CombineXdefaultsHostnameDatabase(&db);
    XrmSetDatabase(disp, db);
    return (db);
}

int
FQLength(const char *base, const char *componet)
{
    return (strlen(base) + 1 + strlen(componet));
}

void
FQCompose(const char *base, const char *componet, char *buf)
{
    (void)sprintf(buf, "%s.%s", base, componet);
}

void
GetSylSetting(Display *disp, const char *name, const char *class,
	      SylSetting *s)
{
    char *fq_name, *fq_class, *type;
    XrmValue value;
    XrmDatabase db;
    FILE *fp;
    char *out;

    db = XrmGetDatabase(disp);
    s->spec = s->orig;
    if ((fq_name = (char *)alloca(FQLength(name, s->name) + 1)) == NULL)
	return;
    FQCompose(name, s->name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(class, s->class) + 1)) == NULL)
	return;
    FQCompose(class, s->class, fq_class);
    if ((out = getenv("DEFAULT_RESOURCE")) && (fp = fopen(out, "a"))) {
	fprintf(fp, "%s %s %s\n", fq_name, fq_class, s->orig);
	fclose(fp);
    }
    if (XrmGetResource(db, fq_name, fq_class, &type, &value) == False)
	return;
    s->spec = (char *)value.addr;
}

void
LoadSylColors(Display *disp, char *base_name, char *base_class,
	      SylSetting **s, unsigned long *p)
{
    Colormap cmap;
    XColor color;

    cmap = DefaultColormap(disp, DefaultScreen(disp));
    for (; *s != NULL; ++p, ++s) {
	GetSylSetting(disp, base_name, base_class, *s);
        if (XParseColor(disp, cmap, (*s)->spec, &color) == 0) {
            warnx("%s.%s: color \"%s\" is not available.",
		  base_name, (*s)->name, (*s)->spec);
            continue;
        }
        if (XAllocColor(disp, cmap, &color) == 0) {
            warnx("%s.%s: no available color cell for \"%s\".",
		  base_name, (*s)->name, (*s)->spec);
            continue;
        }
        *p = color.pixel;
    }
}

unsigned long *
CreateSylColors(SylSetting **s)
{
    int n;

    for (n = 0; *s != NULL; ++n)
	++s;
    if (n == 0)
	return (NULL);
    return ((unsigned long *)malloc(sizeof(unsigned long) * n));
}

void
FreeSylColors(unsigned long *p)
{
    free(p);
}

static XFontSet
CreateFontset(Display *disp, const char *fontlist, SylFontSet *fsp)
{
    XFontSet fs;
    int n_missings, n_fontinfos;
    char **missing, *alternation, **fontname;
    XFontStruct **fontinfo;

    if ((fs = XCreateFontSet(disp, fontlist, &missing, &n_missings,
			     &alternation)) == NULL) {
#ifdef DEBUG
        warnx("%s: XCreateFontSet() failed: %s", __FUNCTION__, fontlist);
#endif
        return (NULL);
    }
    if (n_missings > 0) {
#ifdef DEBUG
        int n;

        for (n = 0; n < n_missings; ++n)
            warnx("%s: missing, %s", __FUNCTION__, missing[n]);
#endif
        XFreeStringList(missing);
    }
#ifdef DEBUG
    if (alternation != NULL) {
	warnx("%s: def_string %s(%d)", __FUNCTION__, alternation,
	      strlen(alternation));
    }
#endif
    if ((n_fontinfos = XFontsOfFontSet(fs, &fontinfo, &fontname)) < 1) {
#ifdef DEBUG
        warnx("%s: XFontsOfFontSet() failed: %s", __FUNCTION__, fontlist);
#endif
        XFreeFontSet(disp, fs);
        return (NULL);
    }
    fsp->id = fs;
    fsp->width = abs(XmbTextEscapement(fs, "x", 1));
    fsp->height = fontinfo[0]->ascent + fontinfo[0]->descent;
    fsp->ascent = fontinfo[0]->ascent;
    fsp->descent = fontinfo[0]->descent;
    fsp->tabsep = fsp->width * 8;
    return (fs);
}

static void
FreeFontset(Display *disp, SylFontSet *fsp)
{
    XFreeFontSet(disp, fsp->id);
}

typedef struct SharedFontset {
    struct SharedFontset *next;
    Display *disp;
    char *name;
    int ref;
    time_t stamp;
    SylFontSet fs;
} SharedFontset;

static SharedFontset *sf_top = NULL;
#define EXPIRATION 60

#ifndef BUGGY_XFONTSET
static void
Cleanup(void)
{
    SharedFontset *sf, *next ,*alive = NULL;
    time_t stamp;

    stamp = time(NULL);
    for (sf = sf_top; sf != NULL; sf = next) {
	next = sf->next;
	if (sf->ref > 0 || difftime(stamp, sf->stamp) < EXPIRATION) {
	    sf->next = alive;
	    alive = sf;
	}
	else {
	    free(sf->name);
	    FreeFontset(sf->disp, &sf->fs);
	    free(sf);
	}
    }
    sf_top = alive;
}
#endif

void
CleanupSylFontSet(void)
{
    SharedFontset *sf, *next;

    for (sf = sf_top; sf != NULL; sf = next) {
	next = sf->next;
#ifdef DEBUG
	if (sf->ref > 0) {
	    warnx("%s: %d references: %s", __FUNCTION__, sf->ref, sf->name);
	}
#endif
	free(sf->name);
	FreeFontset(sf->disp, &sf->fs);
	free(sf);
    }
    sf_top = NULL;
}

XFontSet
CreateSylFontSet(Display *disp, const char *name, SylFontSet *fsp)
{
    SharedFontset *sf;
    char *fsname;

    /* 1. �ꥹ�Ȥ򸡺� */
    for (sf = sf_top; sf != NULL; sf = sf->next) {
	if (sf->disp != disp || strcmp(sf->name, name) != 0)
	    continue;
	++(sf->ref);
	*fsp = sf->fs;
	return (fsp->id);
    }

#ifndef BUGGY_XFONTSET
    /* 2. �����������������˻��Ȳ��0�θŤ��ե���ȥ��åȤ���� */
    Cleanup();
#endif

    /* 3. �ե���ȥ��åȤ����� */
    if (CreateFontset(disp, name, fsp) == NULL)
	return (NULL);
    if ((sf = (SharedFontset *)malloc(sizeof(SharedFontset))) == NULL)
	return (fsp->id);
    if ((fsname = strdup(name)) == NULL) {
	free(sf);
	return (fsp->id);
    }
    sf->next = sf_top;
    sf->disp = disp;
    sf->name = fsname;
    sf->ref = 1;
    sf->stamp = time(NULL);
    sf->fs = *fsp;
    sf_top = sf;
    return (fsp->id);
}

void
FreeSylFontSet(Display *disp, SylFontSet *fsp)
{
    SharedFontset *sf;

    for (sf = sf_top; sf != NULL; sf = sf->next) {
	if (sf->disp != disp || sf->fs.id != fsp->id)
	    continue;
	--(sf->ref);
	sf->stamp = time(NULL);
	return;
    }
    FreeFontset(disp, fsp);
}

#ifdef DEBUG
void
StatSylFontSet(void)
{
    SharedFontset *sf;

    printf("%s: ", __FUNCTION__);
    for (sf = sf_top; sf != NULL; sf = sf->next) {
	printf("[%d]", sf->ref);
    }
    printf("\n");
}
#endif

void
LoadSylFontSets(Display *disp, const char *base_name, const char *base_class,
		SylSetting **s, SylFontSet *p)
{
    for (; *s != NULL; ++p, ++s) {
	GetSylSetting(disp, base_name, base_class, *s);
        if (CreateSylFontSet(disp, (*s)->spec, p) == None) {
            warnx("%s.%s: fontset \"%s\" is not available.",
		  base_name, (*s)->name, (*s)->spec);
        }
    }
}

void
SetFQClassHint(Display *disp, Window win, char *name, char *class,
	       Window target)
{
    char *fq_name, *fq_class;
    XClassHint ch, fq;

    if (XGetClassHint(disp, win, &ch) == 0)
	return;
    if ((fq_name = (char *)alloca(FQLength(ch.res_name, name) + 1)) == NULL)
	goto error_short_memory; 
    FQCompose(ch.res_name, name, fq_name);
    if ((fq_class = (char *)alloca(FQLength(ch.res_class, class) + 1)) == NULL)
	goto error_short_memory; 
    FQCompose(ch.res_class, class, fq_class);
    fq.res_name = fq_name;
    fq.res_class = fq_class;
    XSetClassHint(disp, target, &fq);
 error_short_memory:
    XFree(ch.res_name);
    XFree(ch.res_class);
}

#define STRING_PARSE_EMPTYLINES       0
#define STRING_PARSE_KEYWORD          1
#define	STRING_PARSE_PUNCTUATOR       2
#define STRING_PARSE_NUMBER           3
#define STRING_PARSE_OPERATOR         4
#define STRING_PARSE_TOO_LONG_KEYWORD 5
#define STRING_PARSE_UNKNOWN_OPERATOR 6

typedef struct {
    const char *ptr;
} StringParse;

static int
GetChar(StringParse *p)
{
    int c;

    if ((c = *(p->ptr)) == 0)
	return (EOF);
    ++(p->ptr);
    return (c);
}

static void
UngetChar(int c, StringParse *p)
{
    if (c != EOF)
	--(p->ptr);
}

static int
IsDelimiter(int c)
{
    return (strchr(" \t\n", c) != NULL);
}

static int
IsName(int c)
{
    return (isalnum(c) || c == '_');
}
#define IsFirstName(c) IsName(c)

static int
IsPunctuator(int c)
{
    return (strchr("[](){},;:", c) != NULL);
}

static int
GetOperator(StringParse *p, char *buf, int c)
{
    int w;

    *buf++ = c;
    if (c == '-') { /* Group1: "X" "X>" "XX" "X=" */
	if ((w = GetChar(p)) == '>' || w == '-' || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("+&|=", c) != NULL) { /* Group2: "X" "XX" "X=" */
	if ((w = GetChar(p)) == c || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (c == '<' || c == '>') { /* Group3: "X" "XX" "X=" "XX=" */
	if ((w = GetChar(p)) == c)
	    *buf++ = w;
	else
	    UngetChar(w, p);
	if ((w = GetChar(p)) == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("*%^!~", c) != NULL) { /* Group4: "X" "X=" */
	if ((w = GetChar(p)) == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (c == '.') { /* Group5: "X" "XXX" */
	if ((w = GetChar(p)) != c)
	    UngetChar(w, p);	
	else if ((w = GetChar(p)) != (*buf++ = c)) {
	    *buf = 0;
	    return (1); /* parse error */
	}
	else
	    *buf++ = c;
    }
    else if (c == '/') { /* Group6: "X" "X=" "X*" */
	if ((w = GetChar(p)) == '*' || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("#?\"\'", c) == NULL) {
	*buf = 0;
	return (1); /* parse error */
    }
    *buf = 0;
    return (0);
}

static int
GetTokenFromString(StringParse *p, char *top)
{
    int c, n = 0;
    char *buf = top;

    while ((c = GetChar(p)) != EOF && IsDelimiter(c))
	;
    if (c == EOF) {
	*buf = 0;
	return (EOF);
    }
    else if (IsFirstName(c)) {
	for (n = 0, *buf++ = c; IsName(c = GetChar(p)) && n < 64; ++buf, ++n)
	    *buf = c;
	UngetChar(c, p);
	*buf = 0;
	if (n == 64 && IsName(c))
	    return (STRING_PARSE_TOO_LONG_KEYWORD);
	return (STRING_PARSE_KEYWORD);
    }
    else if (IsPunctuator(c)) {
	buf[0] = c;
	buf[1] = 0;
	return (STRING_PARSE_PUNCTUATOR);
    }
    else if (isdigit(c)) {
	*buf++ = c;
	if (c != '0') { /* 10����� */
	    while (isdigit(c = GetChar(p)))
		*buf++ = c;
	}
	else if (tolower(c = GetChar(p)) == 'x') { /* 16����� */
	    for (*buf++ = c; isxdigit(c = GetChar(p)); ++buf)
		*buf = c;
	}	    
	else if (isdigit(c)) { /* 8����� */
	    for (*buf++ = c; isdigit(c = GetChar(p)); ++buf)
		*buf = c;
	}
	/* �����Ǥʤ����0 */
	while (tolower(c) == 'u' || tolower(c) == 'l') { /* ������ */
	    *buf++ = c;
	    c = GetChar(p);
	}
	UngetChar(c, p);
	*buf = 0;
	return (STRING_PARSE_NUMBER);
    }
    else if (GetOperator(p, buf, c) == 0)
	return (STRING_PARSE_OPERATOR);
    return (STRING_PARSE_UNKNOWN_OPERATOR);
}

static int
GetNextWord(StringParse *p, char *w)
{
    int type;

    while ((type = GetTokenFromString(p, w)) == STRING_PARSE_EMPTYLINES)
	;
    return (type);
}

static int
AddKeymap(SylKeymap **map, unsigned int mod, unsigned int func)
{
    SylKeymap *cur;

    if ((cur = (SylKeymap *)malloc(sizeof(SylKeymap))) == NULL)
	return (1);
    cur->mod = mod;
    cur->func = func;
    cur->next = *map;
    *map = cur;
    return (0);
}

typedef struct {
    const char *name;
    unsigned int code;
} ModifierTable;
static ModifierTable Modifier[] = {
    {"Shift",   ShiftMask},
    {"Control", ControlMask},
    {"Meta",    Mod1Mask}};
#define N_MODIFIERS (sizeof(Modifier) / sizeof(ModifierTable))

static int
GetModifier(char *name, int *mod)
{
    unsigned int n;

    for (n = 0; n < N_MODIFIERS; ++n) {
	if (strcmp(Modifier[n].name, name) == 0) {
	    *mod |= Modifier[n].code;
	    return (1);
	}
    }
    return (0);
}

static int
GetKeybinding(Display *disp, const char *base, const char *name,
	      int func, const char *s, SylKeymap **map)
{
    int type;
    unsigned int mod;
    KeyCode code;
    KeySym sym;
    StringParse p;
    char w[64];

    p.ptr = s;
    do {
	mod = 0;
	while ((type = GetNextWord(&p, w)) == STRING_PARSE_KEYWORD
	       && GetModifier(w, &mod)) {
	    if ((type = GetNextWord(&p, w)) == EOF) {
		warnx("%s.%s: unexpected EOS.", base, name);
		return (1);
	    }
	    else if (strcmp(w, "-") != 0) {
		warnx("%s.%s: %s, parse error.", base, name, w);
		return (1);
	    }
	}
	if (type == EOF) {
	    warnx("%s.%s: unexpected EOS.", base, name);
	    return (1);
	}
	else if (type != STRING_PARSE_KEYWORD) {
	    warnx("%s.%s: %s, parse error.", base, name, w);
	    return (1);
	}
	else if ((sym = XStringToKeysym(w)) == NoSymbol) {
	    warnx("%s.%s: %s, unknown KeySym.", base, name, w);
	    return (1);
	}
	else if ((code = XKeysymToKeycode(disp, sym)) == 0) {
	    warnx("%s.%s: %s, unknown KeyCode.", base, name, w);
	    return (1);
	}
	else if (AddKeymap(&map[code], mod, func)) {
	    warnx("%s.%s: too short memory.", base, name);
	    return (1);
	}
    } while ((type = GetNextWord(&p, w)) == STRING_PARSE_PUNCTUATOR
	     && strcmp(w, ",") == 0);
    if (type != EOF) {
	warnx("%s.%s: %s, parse error.", base, name, w);
	return (1);
    }
    return (0);
}

void
LoadSylKeymap(Display *disp, const char *base_name, const char *base_class,
	      SylSetting **s, SylKeymap **map)
{
    int n;

    for (n = 0; *s != NULL; ++n, ++s) {
	GetSylSetting(disp, base_name, base_class, *s);
	GetKeybinding(disp, base_name, (*s)->name, n, (*s)->spec, map);
    }
}

SylKeymap **
CreateSylKeymap(void)
{
    int n;
    SylKeymap **km;

    if ((km = (SylKeymap **)malloc(sizeof(SylKeymap *) * 256)) == NULL)
	return (NULL);
    for (n = 0; n < 256; ++n)
        km[n] = NULL;
    return (km);
}

void
FreeSylKeymap(SylKeymap **km)
{
    int n;
    SylKeymap *map, *next;

    for (n = 0; n < 256; ++n) {
        for (map = km[n]; map != NULL; map = next) {
            next = map->next;
            free(map);
        }
    }
    free(km);
}

static int
StringToIMStyle(char *s)
{
    if (strcmp(s, "PreeditArea") == 0)
	return (XIMPreeditArea);
    else if (strcmp(s, "PreeditCallbacks") == 0)
	return (XIMPreeditCallbacks);
    else if (strcmp(s, "PreeditPosition") == 0)
	return (XIMPreeditPosition);
    else if (strcmp(s, "PreeditNothing") == 0)
	return (XIMPreeditNothing);
    else if (strcmp(s, "PreeditNone") == 0)
	return (XIMPreeditNone);
    else if (strcmp(s, "StatusArea") == 0)
	return (XIMStatusArea);
    else if (strcmp(s, "StatusCallbacks") == 0)
	return (XIMStatusCallbacks);
    else if (strcmp(s, "StatusNothing") == 0)
	return (XIMStatusNothing);
    else if (strcmp(s, "StatusNone") == 0)
	return (XIMStatusNone);
    return (0);
}

static int
GetIMStyle(const char *base, const char *name, const char *str,
	   XIMStyle *im_style)
{
    int type, style;
    StringParse p;
    char w[64];

    *im_style = 0;
    p.ptr = str;
    do {
	if ((type = GetNextWord(&p, w)) == EOF) {
	    warnx("%s.%s: unexpected EOS.", base, name);
	    return (1);
	}
	else if (type != STRING_PARSE_KEYWORD) {
	    warnx("%s.%s: %s, parse error.", base, name, w);
	    return (1);
	}
	else if ((style = StringToIMStyle(w)) == 0) {
	    warnx("%s.%s: %s, unknown XIM style.", base, name, w);
	    return (1);
	}
	*im_style |= style;
    } while ((type = GetNextWord(&p, w)) == STRING_PARSE_PUNCTUATOR
	     && strcmp(w, ",") == 0);
    if (type != EOF) {
	warnx("%s.%s: %s, parse error.", base, name, w);
	return (1);
    }
    return (0);
}

void
LoadSylIMStyles(Display *disp, const char *base_name, const char *base_class,
		SylSetting **s, XIMStyle *p)
{
    for (; *s != NULL; ++p, ++s) {
	GetSylSetting(disp, base_name, base_class, *s);
	GetIMStyle(base_name, (*s)->name, (*s)->spec, p);
    }
}

static int
StringToGravity(const char *str)
{
    if (strcmp(str, "NorthWest") == 0)
        return (NorthWestGravity);
    else if (strcmp(str, "North") == 0)
        return (NorthGravity);
    else if (strcmp(str, "NorthEast") == 0)
        return (NorthEastGravity);
    else if (strcmp(str, "West") == 0)
        return (WestGravity);
    else if (strcmp(str, "Center") == 0)
        return (CenterGravity);
    else if (strcmp(str, "East") == 0)
        return (EastGravity);
    else if (strcmp(str, "SouthWest") == 0)
        return (SouthWestGravity);
    else if (strcmp(str, "South") == 0)
        return (SouthGravity);
    else if (strcmp(str, "SouthEast") == 0)
        return (SouthEastGravity);
    else 
        return (ForgetGravity);
}

static int
GetGravity(const char *base, const char *name, const char *str, int *gravity)
{
    int g;

    if ((g = StringToGravity(str)) == ForgetGravity) {
	warnx("%s.%s: %s, unknown gravity.", base, name, str);
	*gravity = CenterGravity;
	return (1);
    }
    *gravity = g;
    return (0);
}

void
LoadSylGravities(Display *disp, const char *base_name, const char *base_class,
		 SylSetting **s, int *g)
{
    for (; *s != NULL; ++g, ++s) {
	GetSylSetting(disp, base_name, base_class, *s);
	GetGravity(base_name, (*s)->name, (*s)->spec, g);
    }
}

int
Syl_X(int parent_width, int width, int gravity)
{
    switch (gravity) {
    case NorthWestGravity:
    case WestGravity:
    case SouthWestGravity:
	return (0);
    case NorthEastGravity:
    case EastGravity:
    case SouthEastGravity:
	return (parent_width - width);
    }
    return ((parent_width - width) / 2);
}

int
Syl_Y(int parent_height, int height, int gravity)
{
    switch (gravity) {
    case NorthWestGravity:
    case NorthGravity:
    case NorthEastGravity:
	return (0);
    case SouthWestGravity:
    case SouthGravity:
    case SouthEastGravity:
	return (parent_height - height);
    }
    return ((parent_height - height) / 2);
}

#ifdef PASSIVE_FOCUS_MODEL
static Window CurrentFocusWindow = None;

void
SylSetInputFocus(Display *disp, Window w, int r, Time tm)
{
    XFocusChangeEvent ev;

    if (CurrentFocusWindow != None) {
        ev.type = FocusOut;
        ev.display = disp;
        ev.window = CurrentFocusWindow;
        ev.mode = NotifyNormal;
        ev.detail = NotifyDetailNone;
        XSendEvent(disp, CurrentFocusWindow, False, 0, (XEvent *)&ev);
    }
    CurrentFocusWindow = w;
    if (CurrentFocusWindow != None) {
        ev.type = FocusIn;
        ev.display = disp;
        ev.window = CurrentFocusWindow;
        ev.mode = NotifyNormal;
        ev.detail = NotifyDetailNone;
        XSendEvent(disp, CurrentFocusWindow, False, 0, (XEvent *)&ev);
    }
}

void
SylSendKeyEvent(XKeyEvent *org)
{
    XKeyEvent ev = *org;

    if (CurrentFocusWindow == None)
	return;
    ev.window = CurrentFocusWindow;
    XSendEvent(ev.display, CurrentFocusWindow, False, 0, (XEvent *)&ev); 
}
#endif
