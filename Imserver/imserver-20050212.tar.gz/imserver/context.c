/*
	$Id: context.c,v 1.1 2005/01/16 18:16:26 syl Exp $

	Copyright (C) 2005 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef linux
#include "db.h"
#else
#include <db.h>
#endif
#include <fcntl.h>
#include <limits.h>
#include <string.h>
#include <err.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "connection.h"
#include "context.h"

typedef struct {
    ContextID id;
    Window w;
} ContextKey;

static DB *db = NULL;

static int
get_value(ContextKey *key, ContextValue **val, int *len)
{
    DBT k, v;
    int s;

    k.data = key;
    k.size = sizeof(*key);
    *val = NULL;
    *len = 0;
    if ((s = db->get(db, &k, &v, 0)) != 0)
	return s;
    *val = v.data;
    *len = v.size / sizeof(**val);
    return 0;
}

static int
put_value(ContextKey *key, ContextValue *val, int len)
{
    DBT k, v;

    k.data = key;
    k.size = sizeof(*key);
    v.data = val;
    v.size = sizeof(*val) * len;
    return db->put(db, &k, &v, 0);
}

static int
del_value(ContextKey *key)
{
    DBT k;

    k.data = key;
    k.size = sizeof(*key);
    return db->del(db, &k, 0);
}

void
InitializeContext(void)
{
    const int flags = O_CREAT | O_RDWR;
    const int mode = S_IRUSR | S_IWUSR;

    if ((db = dbopen(NULL, flags, mode, DB_BTREE, NULL)) == NULL) {
	errx(1, "dbopen() failed.");
    }
}

void
FinalizeContext(void)
{
    db->close(db);
}

int
AddContext(ContextID id, Window w, ContextValue *val)
{
    ContextKey key;
    ContextValue *v, *n;
    int len;

    key.id = id;
    key.w = w;
    if (get_value(&key, &v, &len)) {
	return put_value(&key, val, 1);
    }
    if ((n = (ContextValue *)alloca(sizeof(*n) * (len + 1))) == NULL)
	return -1;
    bcopy(v, n, sizeof(*n) * len);
    bcopy(val, n + len, sizeof(*n));
    return put_value(&key, n, len + 1);
}

int
RemoveContext(ContextID id, Window w, ContextValue *val)
{
    ContextKey key;
    ContextValue *v, *n;
    int k, len;

    key.id = id;
    key.w = w;
    if (get_value(&key, &v, &len)) {
	return -1;
    }
    for (k = 0; k < len && bcmp(val, v + k, sizeof(*val)); ++k)
	;
    if (k == len)
	return -1;
    if (len == 1)
	return del_value(&key);
    if ((n = (ContextValue *)alloca(sizeof(*n) * (len - 1))) == NULL)
	return -1;
    bcopy(v, n, sizeof(*n) * k);
    bcopy(v + k + 1, n + k, sizeof(*n) * (len - 1 - k));
    return put_value(&key, n, len - 1);
}

int
GetContext(ContextID id, Window w, ContextValue **val, int *n_vals)
{
    ContextKey key;

    key.id = id;
    key.w = w;
    return get_value(&key, val, n_vals);
}
