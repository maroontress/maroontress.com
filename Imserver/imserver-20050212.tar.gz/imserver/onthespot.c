/*
	$Id: onthespot.c,v 1.11 2005/01/09 09:32:19 syl Exp $

	Copyright (C) 1999, 2000, 2001, 2002, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "message.h"
#include "status.h"
#include "commit.h"
#include "optimize.h"
#include "feedback.h"
#include "onthespot.h"

#define NO_STRING 1
#define NO_FEEDBACK 2

static void
PreeditDraw(Connection *con, XIM_PREEDIT_DRAW *xim_preedit_draw)
{
    SerializedPacket *req;
    int len;

    Send_XIM_PREEDIT_DRAW(xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
Clear(Connection *con, InputContext *ic)
{ 
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    
    if ((len = LengthOfSylText(ic->preedit)) <= 0)
	return;
    if (ic->head != NULL)
	len = LengthOfPhrase(ic->head);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = 0;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = len;
    xim_preedit_draw.status = NO_STRING | NO_FEEDBACK;
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    PreeditDraw(con, &xim_preedit_draw);
}

static void
ChangePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    
    len = LengthOfSylText(ic->view->chosen);
    wcs = CreateWCStringFromSylText0(ic->view->chosen);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateSelectedPhraseFeedback(ic, ic->view, ic->view->next);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    PreeditDraw(con, &xim_preedit_draw);
    free(feedback); /* CreateSelectedPhraseFeedback() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText0() */
}

static void
ResizePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    CARD32 *feedback;
    XTextProperty t;
    wchar_t *wcs;

    wcs = CreateWCStringFromPhrase(ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateSelectedPhraseFeedback(ic, ic->view, NULL);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = LengthOfPhrase(ic->view);
    xim_preedit_draw.feedback.val = feedback;
    PreeditDraw(con, &xim_preedit_draw);
    free(feedback); /* CreateSelectedPhraseFeedback() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
Cancel(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    wchar_t *wcs;
    XTextProperty t;
    CARD32 *feedback;
    
    wcs = CreateWCStringFromSylText0(ic->preedit);
    len = LengthOfSylText(ic->preedit);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreatePreeditFeedback(ic, len);
    if ((ic->optimization & OPT_REVERSE_CARET) && ic->caret < len)
	feedback[ic->caret] = ic->reverse_feedback;
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    PreeditDraw(con, &xim_preedit_draw);
    free(feedback); /* CreatePreeditFeedback() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText0() */
}

static void
SelectPhrase(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;

    /*
      ʸ�������Ǥ�ʸ���󤽤Τ�Τ��ѹ��Ϥʤ��Τǡ��ե����ɥХå�������
      �ѹ������������������ե����ɥХå��������ѹ��������ơ�status�ե���
      ��ɤ�NO_STRING (== 1) �ӥåȤ����򥻥åȤ��Ƥ⡢������Ū��ã����
      ���ʤ���

      NO_STRING�ӥåȤ���ꤹ���XIMPreeditDrawCallbackStruct��text�ե���
      ��ɤ�NULL�ˤʤ��XIM�λ��ͽ�˵��Ҥ���Ƥ��롣���Τ��ᡢ�ե�����
      �Хå��������ѹ����뤳�ȤϤǤ��ʤ���
      
      typedef struct _XIMPreeditDrawCallbackStruct {
          int caret;
	  int chg_first;
	  int chg_length;
	  XIMText *text;
      } XIMPreeditDrawCallbackStruct;

      typedef struct _XIMText {
          unsigned short length;
	  XIMFeedback *feedback;
	  Bool encoding_is_wchar; 
	  union {
	      char *multi_byte;
	      wchar_t *wide_char;
	  } string; 
      } XIMText;
      
      ���Τ��ᡢ�����Ǥϥե����ɥХå��������ѹ��������Τ�����ʸ������
      ��ƺ�������׵᤹�롣�ʤ���status�ե�����ɤΰ�̣�Τ����ȹ礻�ϡ�
      �����̤�Ǥ��롣

      status == 0�ξ��: text����NULL, text->feedback����NULL
      status == 1�ξ��: text��NULL
      status == 2�ξ��: text����NULL, text->feedback��NULL
      status == 3�ξ��: text��NULL

      xc/lib/X11/imCallbk.c�δؿ�_read_text_from_packet()�κǸ�����ˤϡ�
      status�ե�����ɤ�NO_FEEDBACK (== 2) �ӥåȤ����åȤ���Ƥ��ơ���
      ��NO_STRING�ӥåȤ����åȤ���Ƥ��륱������ͤ��Ƥ�����ʬ�����롣
      ��������NO_STRING�ӥåȤ����åȤ���Ƥ���ȡ�������ʬ�Υ����ɤˤ�
      ��ã���ʤ���

      �¤�Xlib�λ��ͽ�ˤϡ��ե����ɥХå��������ѹ����뤳�Ȥ��Ǥ���Ȼ�
      �碌��褦�ʵ��Ҥ����롣����Xlib�Υ��������ɤ������Ƥ����ȡ�R6��
      �����Ǥ�status == 1�ξ���ư����ߤΤ�ΤȰۤʤꡢ�ե����ɥХ�
      ���������ѹ�����ư��ˤʤäƤ��뤳�Ȥ��狼�롣
    */
    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreatePhraseFeedback(ic);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfPhrase(ic->head);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    PreeditDraw(con, &xim_preedit_draw);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
DeleteSubstring(Connection *con, InputContext *ic, int length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;

    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = length;
    xim_preedit_draw.status = NO_STRING | NO_FEEDBACK;
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    PreeditDraw(con, &xim_preedit_draw);
}

static void
Replace(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XTextProperty t;
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    wchar_t *wcs;
    CARD32 *feedback;
 
    if ((len = ic->caret - chg_first) == 0) {
	/*
	  if�θ�Υ����ɤ� len��0�ʤĤޤ��ִ����ʸ���󤬶��ˤξ�硢
	  Mozilla��XIM�����ǤϤ��ޤ���������OpenOffice�Ϥ����Ƚ����Ǥ�
	  �ʤ���
	*/
	DeleteSubstring(con, ic, chg_length);
	return;
    }
    wcs = CreateWCStringFromSylText(ic->preedit, chg_first, ic->caret);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreatePreeditFeedback(ic, len);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    PreeditDraw(con, &xim_preedit_draw);
    free(feedback); /* CreatePreeditFeedback() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText() */
}

static void
Convert(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;

    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreatePhraseFeedback(ic);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfSylText(ic->preedit);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    PreeditDraw(con, &xim_preedit_draw);
    free(feedback); /* CreatePhraseFeedback() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
DeleteChar(Connection *con, InputContext *ic)
{
    DeleteSubstring(con, ic, 1);
}

static void
DrawCaret(Connection *con, InputContext *ic)
{
#ifdef USE_CARET_CALLBACK
    /*
      �����åȥ�����Хå����Ѥ��������Ʊ���ꥯ�����ȤˤʤäƤ��ޤ���
    */
    XIM_PREEDIT_CARET xim_preedit_caret;
    SerializedPacket *req;
    int len;

    xim_preedit_caret.im_id = con->im_id;
    xim_preedit_caret.ic_id = ic->ic_id;
    xim_preedit_caret.position = ic->caret;
    xim_preedit_caret.direction = XIMAbsolutePosition;
    xim_preedit_caret.style = XIMIsPrimary;
    Send_XIM_PREEDIT_CARET(&xim_preedit_caret, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_CARET, req, len);
    Free_SerializedPacket(req);
#else /* USE_CARET_CALLBACK */
    /*
      ��äȤ��ñ�ʼ�������Ʊ���ꥯ�����ȤΤ����Ψ��褤��
    */
    XIM_PREEDIT_DRAW xim_preedit_draw;

    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 0;
    xim_preedit_draw.status = NO_FEEDBACK;
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    PreeditDraw(con, &xim_preedit_draw);
#endif /* USE_CARET_CALLBACK */
}

static void
MoveCaret(Connection *con, InputContext *ic)
{
    if (ic->optimization & OPT_REVERSE_CARET)
	Cancel(con, ic, 0, LengthOfSylText(ic->preedit));
    else
	DrawCaret(con, ic);
}

static void
DoNothing(Connection *con __unused, InputContext *ic __unused)
{
}

static ICPreeditDrawMethods methods = {
    Clear,
    ChangePhrase,
    ResizePhrase,
    Cancel,
    SelectPhrase,
    Replace,
    Convert,
    DeleteChar,
    MoveCaret,
    DoNothing/* focus_in */,
    DoNothing/* focus_out */,
    DoNothing/* destroy */};

ICPreeditDrawMethods *ICPreeditDrawOnTheSpot = &methods;
