/*
	$Id: engine.h,v 1.2 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

typedef struct {
    int (*open)(const char *);
    void (*close)(void);
    Phrase * (*convert)(wchar_t *, int);
    Phrase * (*convert_single_phrase)(wchar_t *, int, int);
    void (*get_candidate_list)(Phrase *, wchar_t *);
    void (*study)(Phrase *, SylText *);
} Engine;

int OpenEngine(const char *);
void CloseEngine(void);
void ChangeNextRankOfPhraseWithEngine(Phrase *, wchar_t *);
void ChangePrevRankOfPhraseWithEngine(Phrase *, wchar_t *);
Phrase * ConvertSinglePhraseWithEngine(wchar_t *, int, int);
Phrase * ConvertWithEngine(wchar_t *, int);
void StudyPhraseWithEngine(Phrase *, SylText *);
