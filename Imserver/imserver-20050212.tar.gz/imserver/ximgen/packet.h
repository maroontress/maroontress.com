/*
	$Id: packet.h,v 1.2 2004/04/18 20:05:33 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

enum Modifier {Normal = 0, Array, Listof, Multi};

typedef struct Type {
    struct Type *next;
    enum Modifier mod;
    char *name;
    char *member;
} Type;

Type * CreateType(enum Modifier, const char *, const char *);

enum Category {Basic, Read, Write, Both};

typedef struct Packet {
    struct Packet *next;
    enum Category to_do;
    int cardinal_only;
    char *type;
    Type *head;
    Type *tail;
} Packet;

Packet * CreatePacket(const char *, enum Category);
void AppendTypeToPacket(Packet *, Type *);

typedef struct PacketList {
    Packet *top;
    Packet *last;
} PacketList;

PacketList * CreatePacketList(void);
void AddtoPacketList(PacketList *, Packet *, int);
int IsAlreadyDefined(PacketList *, char *);
int IsCardinalOnly(PacketList *, char *);
