/*
	$Id: context.h,v 1.1 2005/01/16 18:16:26 syl Exp $

	Copyright (C) 2005 Syllabub
	Maroontress Fast Software.
*/

typedef enum {
    CONTEXT_CLIENT_WINDOW
} ContextID;

typedef struct {
    Connection *con;
    InputContext *ic;
} ContextValue;

void InitializeContext(void);
void FinalizeContext(void);

int AddContext(ContextID, Window, ContextValue *);
int RemoveContext(ContextID, Window, ContextValue *);
int GetContext(ContextID, Window, ContextValue **, int *);
