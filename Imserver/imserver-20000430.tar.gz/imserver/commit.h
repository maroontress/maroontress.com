void ClearString(Connection *con, InputContext *ic);
void CommitString(Connection *con, InputContext *ic);
void EchoXIMForwardEvent(Connection *con, XIM_FORWARD_EVENT *ev);
