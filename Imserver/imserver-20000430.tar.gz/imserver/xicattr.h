LIST *ic_attrs_set;
