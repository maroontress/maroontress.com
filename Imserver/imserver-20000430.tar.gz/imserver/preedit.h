void PreeditInsertChar(XIM_FORWARD_EVENT *, Connection *, unsigned char *);
extern void (*PreeditBranch[])(Connection *, InputContext *,
			       XIM_FORWARD_EVENT *);
