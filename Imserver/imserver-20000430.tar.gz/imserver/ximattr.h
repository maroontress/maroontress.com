LIST *im_attrs_set;
