#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xlocale.h>
#include <stdio.h>

int
main(int ac, char **av)
{
    Display *disp;
    XFontSet fs;
    int n_missings;
    char **missing, *alternation, *fontlist;
    
    if ((disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: Cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    
    fontlist =
	"-sony-fixed-medium-r-normal--16-120-100-100-c-80-iso8859-1,"
	"-ricoh-fixed-medium-r-normal--16-120-100-100-c-160-jisx0208.1983-0,"
	"-sony-fixed-medium-r-normal--16-120-100-100-c-80-jisx0201.1976-0";
    fs = XCreateFontSet(disp, fontlist, &missing, &n_missings, &alternation);
    exit(0);
    return (0);
}
