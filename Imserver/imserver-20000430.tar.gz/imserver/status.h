void DrawStatusWindow(Display *, InputContext *);
void RaiseStatusWindow(Display *, InputContext *);
