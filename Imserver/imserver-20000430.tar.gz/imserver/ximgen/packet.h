/*
        packet.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

enum Modifier {Normal = 0, Array, Listof, Multi};

typedef struct Type {
    struct Type *next;
    enum Modifier mod;
    char *name;
    char *member;
} Type;

Type * CreateType(enum Modifier, char *, char *);

enum Category {Basic, Read, Write, Both};

typedef struct Packet {
    struct Packet *next;
    enum Category to_do;
    int cardinal_only;
    char *type;
    Type *head;
    Type *tail;
} Packet;

Packet * CreatePacket(char *, enum Category);
void AppendTypeToPacket(Packet *, Type *);

typedef struct PacketList {
    Packet *top;
    Packet *last;
} PacketList;

PacketList * CreatePacketList(void);
void AddtoPacketList(PacketList *, Packet *, int);
int IsAlreadyDefined(PacketList *, char *);
int IsCardinalOnly(PacketList *, char *);
