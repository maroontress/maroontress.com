Window CreateCandidateWindow(Display *disp, Window parent);
void ResizeCandidateWindow(Display *disp, InputContext *ic);
void DrawCandidateWindow(Display *disp, InputContext *ic);
