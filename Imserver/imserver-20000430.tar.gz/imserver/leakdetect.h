void * ldmalloc(unsigned int);
void ldfree(void *);
unsigned int ldusing(void);
