/*
        load.h 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1997 Syllabub
        Maroontress Fast Software.
*/

#define LOAD_PARSE_ERROR 0
#define LOAD_UNTERMINATED_STRING 1
#define LOAD_TOO_SHORT_MEMORY 2
#define LOAD_CANNOT_OPEN 3
#define LOAD_EMPTY 4
#define LOAD_UNEXPECTED_EOF 5
#define LOAD_UNDEFINED_TYPE 6
#define LOAD_PREVIOUSLY_DEFINED 7

extern int LoadErrorCode;
extern int LoadErrorLine;
extern char LoadErrorWord[];

int Load(char *, PacketList *);
