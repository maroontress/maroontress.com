#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <string.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "romaji.h"

typedef struct {
    unsigned char *s;
    unsigned char *d;
} StringMapping;

static StringMapping RomajiToKana[] = {
#include "romaji_kana.h"
};
static int Mappings = sizeof(RomajiToKana) / sizeof(StringMapping);

static int
LengthOfMBString(unsigned char *mbs)
{
    SylText *t;
    int len;

    t = CreateSylTextFromMBString(mbs, False);
    len = LengthOfSylText(t);
    FreeSylText(t);
    return (len);
}

static unsigned char *
CreateMappedString(unsigned char *mbs, int *srclen, int *dstlen)
{
    int n, m, len;
    unsigned char *xch;

    len = strlen(mbs);
    for (n = 0; n < Mappings; ++n) {
	if ((m = len - strlen(RomajiToKana[n].s)) < 0)
	    continue;
	if (strcasecmp(&mbs[m], RomajiToKana[n].s) == 0) {
	    /* printf("%s %s\n", &mbs[m], RomajiToKana[n].d); */
	    len = m + strlen(RomajiToKana[n].d);
	    if ((xch = (unsigned char *)malloc(len + 1)) == NULL)
		return (NULL);
	    strncpy(xch, mbs, m);
	    strcpy(xch + m, RomajiToKana[n].d);
	    /* printf("%s\n", xch); */
	    *srclen = LengthOfMBString(RomajiToKana[n].s);
	    *dstlen = LengthOfMBString(RomajiToKana[n].d);
	    return (xch);
	}
    }
    return (NULL);
}

int
ConvertRomajiIntoKana(SylText *txt, int caret, int *back, int *forward)
{
    int len;
    wchar_t *wcs;
    unsigned char *mbs, *xch;

    if ((mbs = (unsigned char *)alloca(sizeof(wchar_t) * (caret + 1))) == NULL)
	return (False);
    wcs = CreateWCStringFromSylText(txt, 0, caret);
    wcstombs(mbs, wcs, sizeof(wchar_t) * (caret + 1));
    free(wcs);
    if ((xch = CreateMappedString(mbs, back, forward)) == NULL)
	return (False);
    len = strlen(xch);
    if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * (len + 1))) == NULL)
	return (False);
    mbstowcs(wcs, xch, len + 1);
    DeleteWCStringOfSylText(txt, 0, caret);
    InsertWCStringIntoSylText(txt, 0, wcs);
    return (True);
}
