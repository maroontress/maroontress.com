#include        <X11/Xlib.h>
#include        <X11/Xutil.h>
#include        <X11/Xatom.h>
#include        <stdio.h>
#include        <stdlib.h>

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif

typedef unsigned long Pixel;

static Display *disp;
static int screen = 1;
static Window window;
static GC gc;
static Pixel fgcolor, bgcolor;
static int MainPower = 1;
static Atom TARGETS, COMPOUND_TEXT, TEXT, DELETE, NET_ADDRESS, SPAN;
static Atom CATEGORY, LOCALES, TRANSPORT;
static Atom WM_PROTOCOLS, WM_REQUEST[2], WM_DELETE_WINDOW, WM_TAKE_FOCUS;

void
SetProperties(Display *disp, Window w, char *title, char *name, char *class,
              int ac, char **av, int maxw, int maxh, int minw, int minh,
              int incw, int inch)
{
    XWindowAttributes attrs;
    XSizeHints xsize;
    XClassHint xclass;
    XWMHints xwm;

    XGetWindowAttributes(disp, w, &attrs);
    xsize.width = attrs.width;
    xsize.height = attrs.height;
    xsize.width_inc = incw;
    xsize.height_inc = inch;
    xsize.flags = PSize | PResizeInc;
    if (minw > 0 && minh > 0) {
        xsize.min_width = minw;
        xsize.min_height = minh; 
        xsize.flags |=  PMinSize;
    }
    if (maxw > 0 && maxh > 0) {
        xsize.max_width = max(maxw, minw);
        xsize.max_height = max(maxh, minh);
        xsize.flags |=  PMaxSize;
    }
    xwm.flags = InputHint /* | XUrgencyHint */;
    xwm.input = True;
    xclass.res_name = name;
    xclass.res_class = class;
    XmbSetWMProperties(disp, w, title, title, av, ac, &xsize, &xwm, &xclass);

    WM_PROTOCOLS = XInternAtom(disp, "WM_PROTOCOLS", False);
    WM_TAKE_FOCUS = XInternAtom(disp, "WM_TAKE_FOCUS", False);
    WM_DELETE_WINDOW = XInternAtom(disp, "WM_DELETE_WINDOW", False);
    WM_REQUEST[0] = WM_TAKE_FOCUS;
    WM_REQUEST[1] = WM_DELETE_WINDOW;
    XSetWMProtocols(disp, w, WM_REQUEST, 2);
}

static void
print_targets(char **av, int n_items, Atom *contents)
{
    int n;
    char *atom;

    for (n = 0; n < n_items; ++n) {
	atom = XGetAtomName(disp, contents[n]);
	printf("%s: contents[%d]: %s\n", av[0], n, atom);
	XFree(atom);
	if (contents[n] != TARGETS && contents[n] != DELETE) {
	    XConvertSelection(disp,
			      CATEGORY,
			      contents[n],
			      contents[n],
			      window,
			      CurrentTime);
	}
    }
}

static void
print_atoms(char **av, int n_items, Atom *contents)
{
    int n;
    char *atom;

    for (n = 0; n < n_items; ++n) {
	atom = XGetAtomName(disp, contents[n]);
	printf("%s: contents[%d]: %s\n", av[0], n, atom);
	XFree(atom);
    }
}

static void
print_string(char **av, int n_items, char *contents)
{
    printf("%s: contents: %s\n", av[0], contents);
}

static void
print_integer(char **av, int n_items, int *contents)
{
    int n;

    for (n = 0; n < n_items; ++n) {
	printf("%s: contents[%d]: %d (0x%x)\n",
	       av[0], n, contents[n], contents[n]);
    }
}

static void
print_net_address(char **av, int n_items, unsigned char *contents)
{
    int n;

    for (n = 0; n < n_items; ++n) {
	printf("%s: contents[%d]: %d (0x%x)\n",
	       av[0], n, contents[n], contents[n]);
    }
}

int
main(int ac, char **av)
{
    XEvent ev;
    char *atom;
    Atom property_type, *contents;
    int format;
    long n_items, remain;

    if ((disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: Cannot open display.\n", av[0]);
        exit(1);
    }
    screen = DefaultScreen(disp);
    bgcolor = WhitePixel(disp, DefaultScreen(disp));
    fgcolor = BlackPixel(disp, DefaultScreen(disp));
    window = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
	0, 0, 320, 160, 1, fgcolor, bgcolor);
    SetProperties(disp, window, "selection", "selection",
		  "Selection", ac, av, 0, 0, 0, 0, 0, 0);
    gc = XCreateGC(disp, window, 0, 0);
    XSetFunction(disp, gc, GXcopy);
    XSelectInput(disp, window, ButtonPressMask);
    /*XMapRaised(disp, window);*/

    TARGETS = XInternAtom(disp, "TARGETS", False);
    LOCALES = XInternAtom(disp, "LOCALES", False);
    TRANSPORT = XInternAtom(disp, "TRANSPORT", False);
    CATEGORY = XInternAtom(disp, "@server=vje", False);
    COMPOUND_TEXT = XInternAtom(disp, "COMPOUND_TEXT", False);
    TEXT = XInternAtom(disp, "TEXT", False);
    DELETE = XInternAtom(disp, "DELETE", False);
    NET_ADDRESS = XInternAtom(disp, "NET_ADDRESS", False);
    SPAN = XInternAtom(disp, "SPAN", False);
    if (XGetSelectionOwner(disp, CATEGORY) == None) {
	printf("%s: CATEGORY selection not found.\n", av[0]);
	exit(1);
    }
    XConvertSelection(disp,
		      CATEGORY, /* $B%;%l%/%7%g%sL>(B */
		      LOCALES, /* $B%?!<%2%C%H%"%H%`(B */
		      LOCALES, /* $B%W%m%Q%F%#L>!J%?!<%2%C%H$HF1L>$K$7$?!K(B */
		      window,
		      CurrentTime);
    XConvertSelection(disp,
		      CATEGORY, /* $B%;%l%/%7%g%sL>(B */
		      TRANSPORT, /* $B%?!<%2%C%H%"%H%`(B */
		      TRANSPORT, /* $B%W%m%Q%F%#L>!J%?!<%2%C%H$HF1L>$K$7$?!K(B */
		      window,
		      CurrentTime);

    while (MainPower) {
	switch (ev.type) {
	case MappingNotify:
	    XRefreshKeyboardMapping(&(ev.xmapping));
	    break;
	case SelectionNotify:
	    atom = XGetAtomName(disp, ev.xselection.selection);
	    printf("\n%s: SelectionNotify: selection: %s\n", av[0], atom);
	    XFree(atom);
	    if (ev.xselection.property == None) {
		printf("%s: property: None\n", av[0]);
		break;
	    }
	    atom = XGetAtomName(disp, ev.xselection.property);
	    printf("%s: property: %s\n", av[0], atom);
	    XFree(atom);
	    if (XGetWindowProperty(disp, window, ev.xselection.property,
				   0, 8192, False, AnyPropertyType,
				   &property_type, &format, &n_items,
				   &remain, (void *)&contents) != Success) {
		printf("%s: XGetWindowProperty() failed.\n", av[0]);
		break;
	    }
	    atom = XGetAtomName(disp, property_type);
	    printf("%s: type: %s\n", av[0], atom);
	    XFree(atom);
	    printf("%s: format: %d\n", av[0], format);
	    printf("%s: %ld items\n", av[0], n_items);
	    printf("%s: remain: %ld\n", av[0], remain);
	    if (ev.xselection.property == TARGETS && property_type == XA_ATOM)
		print_targets(av, n_items, (Atom *)contents);
	    else if (property_type == XA_ATOM)
		print_atoms(av, n_items, (Atom *)contents);
	    else if (property_type == XA_STRING
		     || property_type == COMPOUND_TEXT
		     || property_type == LOCALES
		     || property_type == TRANSPORT)
		print_string(av, n_items, (char *)contents);
	    else if (property_type == XA_INTEGER
		     || property_type == XA_WINDOW
		     || property_type == SPAN)
		print_integer(av, n_items, (int *)contents);
	    else if (property_type == NET_ADDRESS)
		print_net_address(av, n_items, (unsigned char *)contents);
	    else
		printf("%s: unknown contents\n", av[0]);
	    XFree(contents);
	    fflush(stdout);
	    break;
	}
        XNextEvent(disp, &ev);
    }
    XDestroyWindow(disp, window);
    XCloseDisplay(disp);
    exit(0);
}
