/*
	$Id: feedback.c,v 1.1 2003/06/01 16:34:03 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "feedback.h"

XIMFeedback *
CreatePreeditFeedback(InputContext *ic, int len)
{
    XIMFeedback *fb;
    int n;

    if ((fb = (XIMFeedback *)malloc(sizeof(XIMFeedback) * len)) == NULL)
	return (NULL);
    for (n = 0; n < len; ++n)
	fb[n] = ic->underline_feedback;
    return (fb);
}

XIMFeedback *
CreateSelectedPhraseFeedback(InputContext *ic, Phrase *head, Phrase *last)
{
    Phrase *p;
    XIMFeedback *fb;
    int n, m, len;
    Phrase *view = ic->view;

    len = 0;
    for (p = head; p != NULL && p != last; p = p->next)
	len += LengthOfSylText(p->chosen);
    if ((fb = (XIMFeedback *)malloc(sizeof(XIMFeedback) * len)) == NULL)
	return (NULL);
    n = 0;
    for (p = head; p != NULL && p != last; p = p->next) {
	for (m = n + LengthOfSylText(p->chosen); n < m; ++n) {
	    fb[n] = ((p == view) ? ic->reverse_feedback : ic->normal_feedback);
	}
    }    
    return (fb);
}

XIMFeedback *
CreatePhraseFeedback(InputContext *ic)
{
    return (CreateSelectedPhraseFeedback(ic, ic->head, NULL));
}
