/*
	$Id: status.h,v 1.5 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void CommitStatus(Connection *, InputContext *);
void LoadStatusPreference(Display *, const char *, const char *);
