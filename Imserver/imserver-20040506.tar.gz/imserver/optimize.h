/*
	$Id: optimize.h,v 1.5 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#define OPT_REVERSE_CARET       0x0001
#define OPT_NO_FEEDBACK         0x0002
#define OPT_FEEDBACK_OO10       0x0004
#define OPT_FEEDBACK_OO11       0x0008
#define OPT_PREDICTION_DATABASE 0x0010

int GetOptimization(Display *, Window, int *, char **);
void LoadClientOptimization(Display *, const char *, const char *,
			    SylSetting *);
