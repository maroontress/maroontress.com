/*
	$Id: trigger.h,v 1.2 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void LoadTriggerKeys(Display *, const char *, const char *,
		     SylSetting *, XIMTRIGGERKEY *);
