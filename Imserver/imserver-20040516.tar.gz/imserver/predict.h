/*
	$Id: predict.h,v 1.6 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

void LoadPredictionPreference(Display *, const char *, const char *);
void RecordCommittedPhrase(const char *, wchar_t *, wchar_t *);
Phrase * PredictedPhrase(const char *, int, SylText *, PhraseType);

void CommitPrediction(Connection *, InputContext *);
void CommitSecondaryPrediction(Connection *, InputContext *);
void ClearPrediction(Connection *, InputContext *);
void FocusInPrediction(Connection *, InputContext *);
void FocusOutPrediction(Connection *, InputContext *);
