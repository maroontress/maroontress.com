/*
	$Id: preconv.h,v 1.4 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1999, 2000, 2003 Syllabub
	Maroontress Fast Software.
*/

void LoadPreconversionRule(Display *, const char *, const char *, SylSetting *,
			   SylSetting *);
int Preconvert(SylText *txt, int caret, int *back, int *forward, int is_final);

void LoadSymbolSystemMapping(Display *, const char *, const char *,
			     SylSetting *);
void ReplaceSymbolSystem(SylText *, int, int, int);

void LoadSymbolWidthMapping(Display *, const char *, const char *,
			    SylSetting *);
void ReplaceSymbolWidth(SylText *, int, int, int);
