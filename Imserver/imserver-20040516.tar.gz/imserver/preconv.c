/*
	$Id: preconv.c,v 1.10 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1999, 2000, 2001, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <err.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"
#include "Tokenizer.h"

#include "preconv.h"

typedef struct ConversionRule {
    struct ConversionRule *next;
    wchar_t *src_wcs;
    int src_len;
    wchar_t *dst_wcs;
    int dst_len;
} ConversionRule;

static void
FreeConversionRule(ConversionRule *top)
{
    ConversionRule *next;

    for (; top != NULL; top = next) {
	next = top->next;
	free(top->src_wcs);
	free(top->dst_wcs);
	free(top);
    }
}

static ConversionRule *
AddToConversionRule(ConversionRule *top, char *src, char *dst)
{
    ConversionRule *map, *p;
    SylText *txt;

    if ((map = (ConversionRule *)malloc(sizeof(ConversionRule))) == NULL)
	return (NULL);
    map->next = NULL;
    map->src_wcs = NULL;
    map->dst_wcs = NULL;

    if ((txt = CreateSylTextFromMBString(src, False)) == NULL) {
	FreeConversionRule(map);
	return (NULL);
    }
    map->src_len = LengthOfSylText(txt);
    map->src_wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);

    if ((txt = CreateSylTextFromMBString(dst, False)) == NULL) {
	FreeConversionRule(map);
	return (NULL);
    }
    map->dst_len = LengthOfSylText(txt);
    map->dst_wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);

    if (top == NULL || top->src_len <= map->src_len) {
	map->next = top;
	return (map);
    }
    for (p = top; p->next != NULL && p->next->src_len > map->src_len;
	 p = p->next) {
	continue;
    }
    if (p->next != NULL) {
	map->next = p->next;
    }
    p->next = map;
    return (top);
}

typedef struct {
    const char *str;
    int len;
} Token;

typedef enum  {
    TOKEN_UNTERMINATED_STR,
    TOKEN_EMPTY_STR,
    TOKEN_STRCONST,
    TOKEN_EQUAL,
    TOKEN_UNEXPECTED
} TokenType;

static int
GetNextToken(SylTokenizer *tok, Token *w)
{
    int type;

    while ((type = GetTokenFromSylTokenizer(tok, &w->str, &w->len))
	   == SYL_TOKEN_EMPTYLINES) {
	continue;
    }
    switch (type) {
    case EOF:
	return (EOF);
    case SYL_TOKEN_UNTERMINATED_STR:
	return (TOKEN_UNTERMINATED_STR);
    case SYL_TOKEN_STRCONST:
	return ((w->len <= 2) ? TOKEN_EMPTY_STR : TOKEN_STRCONST);
    case SYL_TOKEN_OPERATOR:
	if (w->len == 1 && *(w->str) == '=')
	    return (TOKEN_EQUAL);
        /* FALLTHROUGH */
    default:
	return (TOKEN_UNEXPECTED);
    }
}

static void
CopyTokenIntoString(char *d, Token *t)
{
    const char *s = t->str + 1;
    int k, len = t->len - 2;

    for (k = 0; k < len; ++k) {
	if (*s == '\\') {
	    ++s;
	    ++k;
	}
	*d = *s;
	++s;
	++d;
    }
    *d = 0;
}

static ConversionRule *
AddRule(ConversionRule *rule, Token *src, Token *dst)
{
    char *s, *d;

    if ((s = (char *)alloca(src->len - 1)) == NULL
	|| (d = (char *)alloca(dst->len - 1)) == NULL) {
	return (NULL);
    }
    CopyTokenIntoString(s, src);
    CopyTokenIntoString(d, dst);
#if 0
    printf("\"%s\" -> \"%s\"\n", s, d);
#endif    
    return (AddToConversionRule(rule, s, d));
}

typedef enum {
    SUCCESS,
    UNEXPECTED_EOS,
    UNTERMINATED_STR,
    EMPTY_STR,
    PARSE_ERROR,
    EQUAL_EXPECTED,
    TOO_SHORT_MEMORY
} Result;

static Result
GetConversionRule(SylTokenizer *tok, ConversionRule **rule)
{
    ConversionRule *next;
    int type;
    Token src, eq, dst;

    while ((type = GetNextToken(tok, &src)) != EOF) {
	if (type == TOKEN_UNTERMINATED_STR)
	    return (UNTERMINATED_STR);
	else if (type == TOKEN_EMPTY_STR)
	    return (EMPTY_STR);
	else if (type != TOKEN_STRCONST)
	    return (PARSE_ERROR);
	else if ((type = GetNextToken(tok, &eq)) == EOF)
	    return (UNEXPECTED_EOS);
	else if (type != TOKEN_EQUAL)
	    return (EQUAL_EXPECTED);
	else if ((type = GetNextToken(tok, &dst)) == EOF)
	    return (UNEXPECTED_EOS);
	else if (type == TOKEN_UNTERMINATED_STR)
	    return (UNTERMINATED_STR);
	else if (type == TOKEN_EMPTY_STR)
	    return (EMPTY_STR);
	else if (type != TOKEN_STRCONST)
	    return (PARSE_ERROR);
	else if ((next = AddRule(*rule, &src, &dst)) == NULL)
	    return (TOO_SHORT_MEMORY);
	*rule = next;
    }
    return (SUCCESS);
}

static ConversionRule *
LoadConversionRule(const char *name, SylSetting *map)
{
    ConversionRule *rule = NULL;
    SylTokenizer *tok;

    if ((tok = CreateSylTokenizer(map->spec)) == NULL)
	return (NULL);
    switch (GetConversionRule(tok, &rule)) {
    case SUCCESS:
	break;
    case UNEXPECTED_EOS:
	warnx("%s.%s: line %d, unexpected EOS.\n",  name, map->name,
	      LineOfSylTokenizer(tok));
	break;
    case UNTERMINATED_STR:
	warnx("%s.%s: line %d, unterminated string.\n", name, map->name,
	      LineOfSylTokenizer(tok));
	break;
    case EMPTY_STR:
	warnx("%s.%s: line %d, empty string.\n", name, map->name,
	      LineOfSylTokenizer(tok));
	break;
    case PARSE_ERROR:
	warnx("%s.%s: line %d, parse error `%s'.\n", name, map->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case EQUAL_EXPECTED:
	warnx("%s.%s: line %d, `%s'; `=' expected.\n", name, map->name,
	      LineOfSylTokenizer(tok), TokenStringOfSylTokenizer(tok));
	break;
    case TOO_SHORT_MEMORY:
	warnx("%s.%s: line %d, too short memory.\n",
	      name, map->name, LineOfSylTokenizer(tok));
	break;
    }
    FreeSylTokenizer(tok);
    return (rule);
}

static wchar_t *
FindMappedString(ConversionRule *ptr, wchar_t *wcs, int len,
		 int *srclen, int *dstlen)
{
    int m;

    for (; ptr != NULL; ptr = ptr->next) {
	if ((m = len - ptr->src_len) < 0)
	    continue;
	if (wstrcmp(wcs + m, ptr->src_wcs) == 0) {
	    *srclen = ptr->src_len;
	    *dstlen = ptr->dst_len;
	    return (ptr->dst_wcs);
	}
    }
    return (NULL);
}

static int
Convert(ConversionRule *rule, SylText *txt, int caret, int *back, int *forward)
{
    wchar_t *wcs, *xch;

    wcs = CreateWCStringFromSylText(txt, 0, caret);
    if ((xch = FindMappedString(rule, wcs, caret, back, forward)) == NULL) {
	free(wcs);
	return (False);
    }
    DeleteStringOfSylText(txt, caret - *back, caret);
    InsertWCStringIntoSylText(txt, caret - *back, xch);
    free(wcs);
    return (True);
}

static ConversionRule *BasicRule = NULL;
static ConversionRule *FinalRule = NULL;

void
LoadPreconversionRule(Display *disp, const char *name, const char *class,
		      SylSetting *basic, SylSetting *final)
{
    GetSylSetting(disp, name, class, basic);
    BasicRule = LoadConversionRule(name, basic);

    GetSylSetting(disp, name, class, final);
    FinalRule = LoadConversionRule(name, final);
}

int
Preconvert(SylText *txt, int caret, int *back, int *forward, int is_final)
{
    ConversionRule *rule = (is_final ? FinalRule : BasicRule);

    return (Convert(rule, txt, caret, back, forward));
}

/* */

static int
GetCharPosition(wchar_t *wcs, wchar_t c)
{
    int n;

    for (n = 0; wcs[n] != 0 && wcs[n] != c; ++n)
	;
    return (n);
}

static wchar_t
NormalReplacer(ConversionRule *r, wchar_t c)
{
    int pos;

    for (; r != NULL && (pos = GetCharPosition(r->src_wcs, c)) >= r->src_len;
	 r = r->next) {
	continue;
    }
    return ((r == NULL || pos >= r->dst_len) ? c : r->dst_wcs[pos]);
}

static wchar_t
ReverseReplacer(ConversionRule *r, wchar_t c)
{
    int pos;

    for (; r != NULL && (pos = GetCharPosition(r->dst_wcs, c)) >= r->dst_len;
	 r = r->next) {
	continue;
    }
    return ((r == NULL || pos >= r->src_len) ? c : r->src_wcs[pos]);
}

static void
ReplaceText(ConversionRule *rule, SylText *txt, int bgn, int end, int dir)
{
    int k, n;
    wchar_t (*replacer)(ConversionRule *, wchar_t);
    
    replacer = ((dir) ? NormalReplacer : ReverseReplacer);
    if ((n = LengthOfSylText(txt)) > end)
	n = end;
    for (k = bgn; k < n; ++k) {
	ReplaceCharOfSylText(txt, k, replacer(rule, GetCharOfSylText(txt, k)));
    }
}

static ConversionRule *SymbolSystem = NULL;

void
LoadSymbolSystemMapping(Display *disp, const char *name, const char *class,
			SylSetting *map)
{
    GetSylSetting(disp, name, class, map);
    SymbolSystem = LoadConversionRule(name, map);
}

void
ReplaceSymbolSystem(SylText *txt, int bgn, int end, int dir)
{
    ReplaceText(SymbolSystem, txt, bgn, end, dir);
}

static ConversionRule *SymbolWidth = NULL;

void
LoadSymbolWidthMapping(Display *disp, const char *name, const char *class,
		       SylSetting *map)
{
    GetSylSetting(disp, name, class, map);
    SymbolWidth = LoadConversionRule(name, map);
}

void
ReplaceSymbolWidth(SylText *txt, int bgn, int end, int dir)
{
    ReplaceText(SymbolWidth, txt, bgn, end, dir);
}
