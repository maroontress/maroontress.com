/*
	$Id: message.c,v 1.3 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "message.h"

static const char *ServerAtoms[] = {
    "_server0", "_server1", "_server2", "_server3", "_server4", "_server5",
    "_server6", "_server7", "_server8", "_server9", "_server10", "_server11", 
    "_server12", "_server13", "_server14", "_server15"};
#define N_SERVER_ATOMS 16

static Atom _XIM_PROTOCOL;
static Atom _server[N_SERVER_ATOMS];

void
InitializeWire(Display *disp)
{
    _XIM_PROTOCOL = XInternAtom(disp, "_XIM_PROTOCOL", False);
    XInternAtoms(disp, (char **)ServerAtoms, N_SERVER_ATOMS, False, _server);
}

void
SendIntoWire(Connection *con, int opcode, SerializedPacket *ptr, int len)
{
    static int n = 0;
    XEvent reply;
    Message *msg;
    
    msg = alloca(sizeof(Message) + len);
    msg->major_opcode = opcode;
    msg->minor_opcode = 0;
    msg->length = (len + 3) / 4;
    if (len > 0)
	memcpy(msg->data, ptr, len);
    XChangeProperty(con->disp, con->client, _server[n], XA_STRING, 8,
		    PropModeAppend, (void *)msg, sizeof(Message) + len);
    reply.xclient.type = ClientMessage;
    reply.xclient.window = con->client;
    reply.xclient.message_type = _XIM_PROTOCOL;
    reply.xclient.format = 32;
    reply.xclient.data.l[0] = sizeof(Message) + len;
    reply.xclient.data.l[1] = (long)_server[n];
    XSendEvent(con->disp, con->client, False, 0, &reply);
    if (++n >= N_SERVER_ATOMS)
	n = 0;
}
