/*
	$Id: overthespot.h,v 1.2 2004/04/10 20:34:05 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

extern ICPreeditDrawMethods *ICPreeditDrawOverTheSpot;

void UpdateSpotLocation(Connection *, InputContext *);
void UpdateFontset(Connection *, InputContext *);
