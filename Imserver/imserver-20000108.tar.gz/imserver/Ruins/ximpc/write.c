/*
        write.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "write.h"

static void
InsertPAD(FILE *fp)
{
    fprintf(fp, "\t" "while ((q->c - q->s) %% 4)\n" "\t\t" "*(q->c)++ = 0;\n");
}

static int
IsCardinal(char *name)
{
    return (strcmp(name, "CARD8") == 0
	    || strcmp(name, "CARD16") == 0
	    || strcmp(name, "CARD32") == 0);
}

static void
WriteAny(FILE *fp, char *name, char *member)
{
    if (IsCardinal(name)) {
	fprintf(fp, "\t" "*((%s *)q->c)++ = p->%s;\n", name, member);
    }
    else if (strcmp(name, "XEVENT") == 0) {
	fprintf(fp,
		"\t" "memcpy((XEVENT *)q->c, &(p->%s), sizeof(XEVENT));\n"
		"\t" "q->c += sizeof(XEVENT);\n",
		member);
    }
    else {
	fprintf(fp, "\t" "Write_%s(&(p->%s), q);\n", name, member);
    }
}

static void
AllocateArray(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "*((CARD16 *)q->c)++ = p->%s.num;\n", member);
    InsertPAD(fp);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "*((%s *)q->c)++ = *(p->%s.val[k]);\n",
		name, member);
    }
    else {
	fprintf(fp, "\t\t" "Write_%s(p->%s.val[k], q);\n",
		name, member);
    }
}

static void
AllocateList(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "len = q->c;\n");
    fprintf(fp, "\t" "*((CARD16 *)q->c)++ = 0; /* dummy */\n");
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t" "b = q->c;\n");
    fprintf(fp, "\t"
	    "for (c = p->%s; c != NULL; c = c->next) {\n", member);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "*((%s *)q->c)++ = *((%s *)c->data);\n",
		name, name);
    }
    else {
	fprintf(fp, "\t\t" "Write_%s(c->data, q);\n", name);
    }
    fprintf(fp, "\t" "}\n");
    fprintf(fp, "\t" "*((CARD16 *)len) = q->c - b;\n");
}

static void
AllocateMulti(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "*((CARD16 *)q->c)++ = p->%s.num * sizeof(%s);\n",
	    member, name);
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    fprintf(fp, "\t\t" "*((%s *)q->c)++ = p->%s.val[k];\n", name, member);
}

void
PrintWrite(FILE *fp, PacketList *pl)
{
    int n;
    Type *t;
    Packet *ptr;

    fprintf(fp,
#if 0
            "\n"
            "static void\n"
            "Write_STR(STR *p, Chunk *q)\n"
            "{\n"
	    "\t" "*((CARD8 *)q->c)++ = p->len;\n"
	    "\t" "memcpy(q->c, p->val, p->len);\n"
	    "\t" "q->c += p->len;\n"
	    "}\n"
#endif
	    "\n"
            "void\n"
            "Write_STRING(STRING *p, Chunk *q)\n"
            "{\n"
	    "\t" "*((CARD16 *)q->c)++ = p->len;\n"
	    "\t" "memcpy(q->c, p->val, p->len);\n"
	    "\t" "q->c += p->len;\n"
	    "\t" "while ((q->c - q->s) %% 4)\n"
	    "\t\t" "*(q->c)++ = 0;\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do != Write && ptr->to_do != Both)
	    continue;
	fprintf(fp,
		"\n"
		"void\n"
		"Write_%s(%s *p, Chunk *q)\n"
		"{\n",
		ptr->type, ptr->type);
	n = NoList;
	for (t = ptr->head; t != NULL; t = t->next) {
	    if (n < t->is_list)
		n = t->is_list;
	}
	if (n == 1) {
	    fprintf(fp, "\t" "int k;\n");
	    fprintf(fp, "\n");
	}
	else if (n == 2) {
	    fprintf(fp, "\t" "LIST *c;\n");
	    fprintf(fp, "\t" "CARD8 *b, *len;\n");
	    fprintf(fp, "\n");
	}
	else if (n == 3) {
	    fprintf(fp, "\t" "int k;\n");
	    fprintf(fp, "\n");
	}
	
	for (t = ptr->head; t != NULL; t = t->next) {
	    if (strcmp(t->name, "PAD") == 0)
		InsertPAD(fp);
	    else if (t->is_list == Array)
		AllocateArray(fp, t->name, t->member);
	    else if (t->is_list == Listof)
		AllocateList(fp, t->name, t->member);
	    else if (t->is_list == Multi)
		AllocateMulti(fp, t->name, t->member);
	    else
		WriteAny(fp, t->name, t->member);
	}
	fprintf(fp, "}\n");
    }
}
