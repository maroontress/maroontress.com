#include <stdio.h>

#include "packet.h"
#include "load.h"
#include "prototype.h"
#include "read.h"
#include "release.h"
#include "write.h"
#include "sizeof.h"
#include "recv.h"
#include "send.h"
#include "free.h"

static void
LoadError(char **av)
{
    switch (LoadErrorCode) {
    case LOAD_PARSE_ERROR:
        fprintf(stderr, "%s: file %s, parse error `%s' at %d line.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_UNTERMINATED_STRING:
        fprintf(stderr, "%s: file %s, unterminated string at %d line.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>", LoadErrorLine);
        break;
    case LOAD_TOO_SHORT_MEMORY:
        fprintf(stderr, "%s: file %s, too short memory, while reading"
                "at %d line.\n", av[0],
                (av[1] != NULL) ? av[1] : "<stdin>", LoadErrorLine);
            break;
    case LOAD_CANNOT_OPEN:
        fprintf(stderr, "%s: cannot open file %s.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>");
        break;
    case LOAD_PREVIOUSLY_DEFINED:
        fprintf(stderr, "%s: file %s, `%s' previously defined at %d line.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_UNDEFINED_TYPE:
        fprintf(stderr, "%s: file %s, unknown function `%s' at %d line.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>",
                LoadErrorWord, LoadErrorLine);
        break;
    case LOAD_EMPTY:
        fprintf(stderr, "%s: no menu defined in file %s.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>");
        break;
    case LOAD_UNEXPECTED_EOF:
        fprintf(stderr, "%s: file %s, unexpected EOF at %d line.\n",
                av[0], (av[1] != NULL) ? av[1] : "<stdin>", LoadErrorLine);
        break;
    }
}

int
main(int ac, char **av)
{
    FILE *fp;
    PacketList *pl;

    if (ac != 2) {
	fprintf(stderr, "usage: %s filename\n", av[0]);
	exit(1);
    }
    if ((pl = CreatePacketList()) == NULL) {
	fprintf(stderr, "%s: too short memory\n", av[0]);
	exit(1);
    }
    if (Load(av[1], pl) != EOF) {
	fprintf(stderr, "%s: load error\n", av[0]);
	LoadError(av);
	exit(1);
    }

    if ((fp = fopen("xim.h", "w")) == NULL) {
	fprintf(stderr, "%s: cannot write xim.h\n", av[0]);
	exit(1);
    }
    PrintPrototype(fp, pl);
    fclose(fp);

    if ((fp = fopen("xim.c", "w")) == NULL) {
	fprintf(stderr, "%s: cannot write xim.c\n", av[0]);
	exit(1);
    }
    fprintf(fp,
	    "/*\n"
	    "\t" "This file is generated automatically by ximpc.\n"
	    "\t" "Don't edit this file.\n"
	    "*/\n"
	    "\n"
            "#include <X11/Xproto.h>\n"
            "#include <string.h>\n"
            "#include <stdlib.h>\n"
            "#include \"leakdetect.h\"\n"
            "#include \"%s.h\"\n",
	    "xim");
    PrintRead(fp, pl);
    PrintRelease(fp, pl);
    PrintWrite(fp, pl);
    PrintSizeof(fp, pl);
    PrintRecv(fp, pl);
    PrintSend(fp, pl);
    PrintFree(fp, pl);
    fclose(fp);
    exit(0);
}
