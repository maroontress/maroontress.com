void LoadPreconversionMapping(Display *, char *, char *, SylSetting *);
int Preconvert(SylText *txt, int caret, int *back, int *forward);
