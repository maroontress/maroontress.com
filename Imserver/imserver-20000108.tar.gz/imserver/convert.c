#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h" /* only for Feedback[] */
#include "message.h"
#include "status.h"
#include "commit.h"
#include "convert.h"

static void
ConvertPhrase(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev,
	      void (*change_phrase)(Phrase *, SylText *))
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    int chg_first, chg_length;
    
    chg_first = BeginningOfPhrase(ic->head, ic->view);
    chg_length = LengthOfSylText(ic->view->chosen);
    change_phrase(ic->view, ic->preedit);
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);
    
    len = LengthOfSylText(ic->view->chosen);
    wcs = CreateWCStringFromSylText(ic->view->chosen, 0, len);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->view, ic->view); /* XXX */
    
    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
ConvertZenkaku(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ConvertPhrase(con, ic, ev, ChangeZenkakuPhrase);
}

static void
ConvertHankaku(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ConvertPhrase(con, ic, ev, ChangeHankakuPhrase);
}

static void
ConvertKatakana(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ConvertPhrase(con, ic, ev, ChangeKatakanaPhrase);
}

static void
ConvertHiragana(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ConvertPhrase(con, ic, ev, ChangeHiraganaPhrase);
}

static void
ConvertNextChoice(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ConvertPhrase(con, ic, ev, ChangeNextRankOfPhrase);
}

static void
ConvertPrevChoice(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ConvertPhrase(con, ic, ev, ChangePrevRankOfPhrase);
}

static void
ConvertShorten(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    int len, chg_first, chg_length;

    if (ic->head == NULL)
	return;
    if (ic->view->length <= 1)
	return;
    chg_first = BeginningOfPhrase(ic->head, ic->view);
    chg_length = LengthOfPhrase(ic->view);

    if (ic->head == ic->view) {
	ic->head = ShortenPhrase(ic->head, ic->preedit);
	ic->view = ic->head;
    }
    else {
	ic->view = ShortenPhrase(ic->view, ic->preedit);
    }
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    wcs = CreateWCStringFromPhrase(ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->view, ic->view);

    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = LengthOfPhrase(ic->view);
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
ConvertLengthen(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    int len, chg_first, chg_length;
    
    if (ic->head == NULL)
	return;
    if (ic->view->offset + ic->view->length >= LengthOfSylText(ic->preedit))
	return;
    chg_first = BeginningOfPhrase(ic->head, ic->view);
    chg_length = LengthOfPhrase(ic->view);

    if (ic->head == ic->view) {
	ic->head = LengthenPhrase(ic->head, ic->preedit);
	ic->view = ic->head;
    }
    else {
	ic->view = LengthenPhrase(ic->view, ic->preedit);
    }
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    wcs = CreateWCStringFromPhrase(ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->view, ic->view);

    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = LengthOfPhrase(ic->view);
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
ConvertCancel(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int n, len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    
    ClearString(con, ic);
    FreePhrase(ic->head);
    ic->head = NULL;
    ic->view = NULL;
    len = LengthOfSylText(ic->preedit);
    wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);
    ic->caret = len;
    
    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfPhrase(ic->head);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    for (n = 0; n < len; ++n)
	xim_preedit_draw.feedback.val[n] = 2;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    ldfree(feedback);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
    DrawStatusWindow(con->disp, ic);
}

static void
ConvertPhraseRight(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    
    if (ic->view->next == NULL)
	return;
    ic->view = ic->view->next;
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);
    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view);
    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfPhrase(ic->head);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
ConvertPhraseLeft(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
	
    if (ic->view->prev == NULL)
	return;
    ic->view = ic->view->prev;
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);
    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view);
    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfPhrase(ic->head);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}    

static void
ConvertLineFeed(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ClearString(con, ic); 
    EchoXIMForwardEvent(con, ev);
    CommitString(con, ic);
}

static void
ConvertCommit(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ev = NULL; /* warning: unused parameter `ev' */
    ClearString(con, ic); 
    CommitString(con, ic);
}

void (*ConvertBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverConvert.branch"
};
