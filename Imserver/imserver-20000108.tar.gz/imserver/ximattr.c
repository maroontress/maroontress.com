#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xlocale.h>
#include <X11/Xproto.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xim.h"

#define CONST_STRING(x) {sizeof(x), x}

static XIMATTR im_attrs_0_item = {0, 10, CONST_STRING(XNQueryInputStyle)};

static LIST im_attrs_0 = {NULL, (void *)&im_attrs_0_item};

LIST *im_attrs_set = &im_attrs_0;
