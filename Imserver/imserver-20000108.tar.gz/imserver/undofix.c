#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h" /* only for Feedback[] */
#include "message.h"
#include "status.h"
#include "commit.h"
#include "undofix.h"

static void
UndofixPreedit(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int n, len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;

    len = LengthOfSylText(ic->fixed);
    wcs = CreateWCStringFromSylText(ic->fixed, 0, len);
    InsertWCStringIntoSylText(ic->preedit, 0, wcs);
    ic->caret = len;
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);

    xim_preedit_draw.im_id = ev->im_id;
    xim_preedit_draw.ic_id = ev->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = 0;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    for (n = 0; n < len; ++n)
	xim_preedit_draw.feedback.val[n] = 2;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    ldfree(feedback);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
RomajiHenkanMode(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ev = NULL; /* warning: unused parameter `ev' */
    ic->romaji = True;
    DrawStatusWindow(con->disp, ic);
}

static void
DirectKanaInputMode(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ev = NULL; /* warning: unused parameter `ev' */
    ic->romaji = False;
    DrawStatusWindow(con->disp, ic);
}

static void
PassImmediately(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ic = NULL; /* warning: unused parameter `ev' */
    EchoXIMForwardEvent(con, ev);
}

void (*UndofixBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverUndofix.branch"
};
