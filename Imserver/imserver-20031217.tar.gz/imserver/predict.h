/*
	$Id: predict.h,v 1.4 2003/07/06 16:39:35 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

void LoadPredictionPreference(Display *, char *, char *);
void RecordCommittedPhrase(const char *, wchar_t *, wchar_t *);
Phrase * PredictedPhrase(const char *, SylText *, PhraseType);

void CommitPrediction(Connection *, InputContext *);
void CommitSecondaryPrediction(Connection *, InputContext *);
void ClearPrediction(Connection *, InputContext *);
void FocusInPrediction(Connection *, InputContext *);
void FocusOutPrediction(Connection *, InputContext *);
