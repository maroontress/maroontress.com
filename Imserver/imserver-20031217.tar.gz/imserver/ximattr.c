/*
	$Id: ximattr.c,v 1.2 2003/05/20 13:12:57 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xlocale.h>
#include <X11/Xproto.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xim.h"

#define CONST_STRING(x) {sizeof(x), x}

#ifdef USE_XIM_RESOURCE_NAME_CLASS
static XIMATTR im_attrs_0_item = {0, 10, CONST_STRING(XNQueryInputStyle)};
static XIMATTR im_attrs_1_item = {1, 4, CONST_STRING(XNResourceName)};
static XIMATTR im_attrs_2_item = {2, 4, CONST_STRING(XNResourceClass)};

static LIST im_attrs_2 = {NULL, (void *)&im_attrs_2_item};
static LIST im_attrs_1 = {&im_attrs_2, (void *)&im_attrs_1_item};
static LIST im_attrs_0 = {&im_attrs_1, (void *)&im_attrs_0_item};
#else /* USE_XIM_RESOURCE_NAME_CLASS */
static XIMATTR im_attrs_0_item = {0, 10, CONST_STRING(XNQueryInputStyle)};

static LIST im_attrs_0 = {NULL, (void *)&im_attrs_0_item};
#endif /* USE_XIM_RESOURCE_NAME_CLASS */

LIST *im_attrs_set = &im_attrs_0;
