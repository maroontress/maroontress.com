/*
	$Id: onthearea.h,v 1.1 2001/02/12 12:11:26 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

extern ICPreeditDrawMethods *ICPreeditDrawOnTheArea;
extern ICStatusDrawMethods *ICStatusDrawOnTheArea;
