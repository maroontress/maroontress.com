/*
	$Id: status.h,v 1.4 2001/06/02 14:16:42 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void CommitStatus(Connection *, InputContext *);
void LoadStatusPreference(Display *, char *, char *);
