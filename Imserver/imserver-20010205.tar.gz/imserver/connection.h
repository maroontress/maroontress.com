/*
	$Id: connection.h,v 1.3 2001/02/04 18:35:04 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

struct ICPreeditDrawMethods;

typedef enum {
    PRECONVERSION_NONE,
    PRECONVERSION_SINGLE,
    PRECONVERSION_DOUBLE
} PreconversionLevel;

typedef struct InputContext {
    struct InputContext *next;
    int ic_id;
    int input_style;
    Window client_window;
    Window focus_window;

    Window preedit_window;
    SylFontSet preedit_fontset;
    char *preedit_fontset_name;
    unsigned long preedit_foreground;
    unsigned long preedit_background;
    XPoint preedit_spot_location;

    Window status_window;
    GC status_gc;
    SylFontSet status_fontset;
    char *status_fontset_name;
    unsigned long status_foreground;
    unsigned long status_background;
    XRectangle status_area;

    Window candidate_window;
    SylFontSet *candidate_fontset;

    int forward;
    int focus;
    PreconversionLevel preconversion;
    int max_preedit_chars; /* ���饤����Ȥδ�˾ */

    SylText *preedit;
    SylText *fixed;
    int caret;

    Phrase *head;
    Phrase *view;

    struct ICPreeditDrawMethods *preedit_draw;
} InputContext;

typedef struct Connection {
    struct Connection *next;
    Display *disp;
    Window client;
    Window server;
    int im_id;
    InputContext *work;
    InputContext *idle;
    int next_ic_id;

    XContext preedit;
    XContext status;
    XContext candidate;
} Connection;

typedef struct ICPreeditDrawMethods {
    void (*clear)(Connection *, InputContext *);
    void (*change_phrase)(Connection *, InputContext *, int, int);
    void (*resize_phrase)(Connection *, InputContext *, int, int);
    void (*cancel)(Connection *, InputContext *, int, int);
    void (*select_phrase)(Connection *, InputContext *);
    void (*replace)(Connection *, InputContext *, int, int);
    void (*convert)(Connection *, InputContext *);
    void (*delete_char)(Connection *, InputContext *);
    void (*move_caret)(Connection *, InputContext *);
    void (*focus_in)(Connection *, InputContext *);
    void (*focus_out)(Connection *, InputContext *);
} ICPreeditDrawMethods;

Connection * CreateConnection(XClientMessageEvent *);
void FreeConnection(Connection *);

InputContext * CreateInputContext(Connection *);
InputContext * SerachInputContext(Connection *, int);
void FreeInputContext(Connection *, int);
