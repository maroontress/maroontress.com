/*
	$Id: ontheroot.c,v 1.3 2001/01/23 15:13:12 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <X11/Xatom.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "connection.h"
#include "leakdetect.h"
#include "ontheroot.h"

static void
SetPreeditSignature(Display *disp, unsigned short im, unsigned short ic)
{
    XTextProperty t;
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_SIGNATURE", False);
    char head[] = "syl", buf[sizeof(head) + 8], *ptr = buf;

    sprintf(ptr, "%s%04x%04x", head, im, ic);
    if (XStringListToTextProperty(&ptr, 1, &t) < 0) {
	return;
    }
    XSetTextProperty(disp, root, &t, atom);
    XFree(t.value);
}

static int
IsPreeditSignature(Display *disp, unsigned short im, unsigned short ic)
{
    XTextProperty t;
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_SIGNATURE", False);
    char head[] = "syl", buf[sizeof(head) + 8], *ptr = buf, **list;
    int n_lists, result;

    sprintf(ptr, "%s%04x%04x", head, im, ic);
    if (XGetTextProperty(disp, root, &t, atom) == 0) {
        XDeleteProperty(disp, root, atom);
        return (False);
    } 
    if (XTextPropertyToStringList(&t, &list, &n_lists) < 0) {
        XFree(t.value);
        return (False);
    }
    XFree(t.value);
    if (n_lists <= 0) {
	XFreeStringList(list);
        return (False);
    }
    result = (strcmp(*list, ptr) == 0);
    XFreeStringList(list);
    return (result);
}

static void
SetPreeditString(Display *disp, wchar_t *wcs)
{
    XICCEncodingStyle style = XCompoundTextStyle;
    XTextProperty t;
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_STRING", False);

    if (wcs == NULL) {
	XDeleteProperty(disp, root, atom);
	return;
    }
    if (XwcTextListToTextProperty(disp, &wcs, 1, style, &t) < 0) {
	return;
    }
    XSetTextProperty(disp, root, &t, atom);
    XFree(t.value);
}

static void
SetPreeditCaret(Display *disp, int caret)
{
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_CARET", False);

    XChangeProperty(disp, root, atom, XA_INTEGER, 32, PropModeReplace,
		    (unsigned char *)&caret, 1);
}

static void
SetPreeditFeedback(Display *disp, CARD32 *feedback, int len)
{
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_FEEDBACK", False);

    if (feedback == NULL) {
	XDeleteProperty(disp, root, atom);
	return;
    }
    XChangeProperty(disp, root, atom, XA_INTEGER, 32, PropModeReplace,
		    (unsigned char *)feedback, len);
}

static void
Clear(Connection *con, InputContext *ic __unused)
{ 
    SetPreeditString(con->disp, NULL);
#ifdef DEBUG
    printf("|\n");
#endif
}

static void
ChangePhrase(Connection *con, InputContext *ic, int chg_first __unused,
	     int chg_length __unused)
{
    int n, len, size;
    wchar_t *wcs;
    CARD32 *feedback;
#ifdef DEBUG
    char mb[MB_LEN_MAX + 1];
#endif

    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view); /* XXX */

    SetPreeditString(con->disp, wcs);
    SetPreeditCaret(con->disp, ic->caret);
    SetPreeditFeedback(con->disp, feedback, len);
#ifdef DEBUG
    for (n = 0; n < len; ++n) {
	if ((size = wctomb(mb, wcs[n])) < 0)
	    strcpy(mb, "?");
	else
	    mb[size] = 0;
	printf("%s%s", feedback[n] ? "\033[7m" : "\033[m", mb);
    }
    printf("\033[m\n");
#endif
    
    free(feedback); /* CreateFeedbackFromPhrase() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
ResizePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    ChangePhrase(con, ic, chg_first, chg_length);
}

static void
Cancel(Connection *con, InputContext *ic, int chg_first __unused,
       int chg_length __unused)
{
    int n, len;
    wchar_t *wcs;
    CARD32 *feedback;
#ifdef DEBUG
    char *mbs;
#endif

    len = LengthOfSylText(ic->preedit);
    wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);
    for (n = 0; n < len; ++n)
	feedback[n] = 2;

    SetPreeditString(con->disp, wcs);
    SetPreeditCaret(con->disp, ic->caret);
    SetPreeditFeedback(con->disp, feedback, len);
    free(wcs); /* CreateWCStringFromSylText() */
    ldfree(feedback); /* ldmalloc() */

#ifdef DEBUG
    mbs = CreateMBStringFromSylText(ic->preedit, 0, len);
    printf("\033[4m%s\033[m|\n", mbs);
    free(mbs); /* CreateMBStringFromSylText() */
#endif
}

static void
SelectPhrase(Connection *con, InputContext *ic)
{
    ChangePhrase(con, ic, 0, 0);
}

static void
Replace(Connection *con, InputContext *ic, int chg_first __unused,
	int chg_length __unused)
{
    int n, len, size;
    wchar_t *wcs;
    CARD32 *feedback;
#ifdef DEBUG
    char mb[MB_LEN_MAX + 1];
#endif

    len = LengthOfSylText(ic->preedit);
    wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);
    for (n = 0; n < len; ++n)
	feedback[n] = 2;

    SetPreeditString(con->disp, wcs);
    SetPreeditCaret(con->disp, ic->caret);
    SetPreeditFeedback(con->disp, feedback, len);

#ifdef DEBUG
    printf("\033[4m");
    for (n = 0; n < ic->caret; ++n) {
	if ((size = wctomb(mb, wcs[n])) < 0)
	    strcpy(mb, "?");
	else
	    mb[size] = 0;
	printf("%s", mb);
    }
    printf("\033[m" "|" "\033[4m");
    for (; n < len; ++n) {
	if ((size = wctomb(mb, wcs[n])) < 0)
	    strcpy(mb, "?");
	else
	    mb[size] = 0;
	printf("%s", mb);
    }
    printf("\033[m\n");
#endif
    
    free(wcs); /* CreateWCStringFromPhrase() */
    ldfree(feedback); /* ldmalloc() */
}

static void
Convert(Connection *con, InputContext *ic)
{
    ChangePhrase(con, ic, 0, 0);
}

static void
DeleteChar(Connection *con, InputContext *ic)
{
    Replace(con, ic, 0, 0);
}

static void
MoveCaret(Connection *con, InputContext *ic)
{
    Replace(con, ic, 0, 0);
}

static void
HoldFocus(Connection *con, InputContext *ic)
{
    int n, len;
    wchar_t *wcs;
    CARD32 *feedback;

    if (ic->head != NULL) {
	wcs = CreateWCStringFromPhrase(ic->head);
	len = LengthOfPhrase(ic->head);
	feedback = CreateFeedbackFromPhrase(ic->head, ic->view); /* XXX */
    }
    else {
	len = LengthOfSylText(ic->preedit);
	wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
	feedback = (CARD32 *)malloc(sizeof(CARD32) * len);
	for (n = 0; n < len; ++n)
	    feedback[n] = 2;
    }
    SetPreeditSignature(con->disp, con->im_id, ic->ic_id);
    SetPreeditString(con->disp, wcs);
    SetPreeditCaret(con->disp, ic->caret);
    SetPreeditFeedback(con->disp, feedback, len);
    free(wcs); /* CreateWCStringFromPhrase() or CreateWCStringFromSylText() */
    free(feedback); /* CreateFeedbackFromPhrase() or malloc() */

    if (ic->candidate_window != None
	&& ic->head != NULL
	&& ic->view->top != NULL
	&& CompareSylText(ic->view->chosen, ic->view->applicant) == 0) {
	XMapRaised(con->disp, ic->candidate_window);
    }
}

static void
LostFocus(Connection *con, InputContext *ic)
{
    if (IsPreeditSignature(con->disp, con->im_id, ic->ic_id)) {
	SetPreeditString(con->disp, NULL);
    }

    if (ic->candidate_window != None)
	XUnmapWindow(con->disp, ic->candidate_window);
}

static ICPreeditDrawMethods methods = {
    Clear,
    ChangePhrase,
    ResizePhrase,
    Cancel,
    SelectPhrase,
    Replace,
    Convert,
    DeleteChar,
    MoveCaret,
    HoldFocus,
    LostFocus};

ICPreeditDrawMethods *ICPreeditDrawOnTheRoot = &methods;
