/*
	$Id: status.c,v 1.3 2001/02/04 20:21:23 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <string.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "phrase.h"
#include "connection.h"
#include "status.h"

static SylSetting
    MSG_ActiveLabel = {"activeLabel", "ActiveLabel", "%s%p", NULL},
    MSG_InactiveLabel = {"inactiveLabel", "InactiveLabel", "%s", NULL},
    MSG_InactiveState = {"inactiveState", "InactiveState", "Off", NULL},
    MSG_InputState = {"inputState", "InputState", "����", NULL},
    MSG_ConvertState = {"convertState", "ConvertState", "�Ѵ�", NULL},
    MSG_DirectMode = {"directMode", "DirectMode", "", NULL},
    MSG_SingleMode = {"singleMode", "SingleMode", "*", NULL},
    MSG_DoubleMode = {"doubleMode", "DoubleMode", "**", NULL};

void
LoadStatusPreference(Display *disp, char *name, char *class)
{
    GetSylSetting(disp, name, class, &MSG_ActiveLabel);
    GetSylSetting(disp, name, class, &MSG_InactiveLabel);
    GetSylSetting(disp, name, class, &MSG_InactiveState);
    GetSylSetting(disp, name, class, &MSG_InputState);
    GetSylSetting(disp, name, class, &MSG_ConvertState);
    GetSylSetting(disp, name, class, &MSG_DirectMode);
    GetSylSetting(disp, name, class, &MSG_SingleMode);
    GetSylSetting(disp, name, class, &MSG_DoubleMode);
}

static char *
addState(char *d, char *d_max, InputContext *ic)
{
    int n, m;
    char *s;

    if (ic->forward == False)
	s = MSG_InactiveState.spec;
    else if (ic->head == NULL)
	s = MSG_InputState.spec;
    else
	s = MSG_ConvertState.spec;
    n = d_max - d;
    m = strlen(s);
    strncpy(d, s, n);
    d += (n > m) ? m : n;
    return d;
}

static char *
addMode(char *d, char *d_max, InputContext *ic)
{
    int n, m;
    char *s;

    if (ic->preconversion == PRECONVERSION_NONE) 
	s = MSG_DirectMode.spec;
    else if (ic->preconversion == PRECONVERSION_SINGLE)
	s = MSG_SingleMode.spec;
    else 
	s = MSG_DoubleMode.spec;
    n = d_max - d;
    m = strlen(s);
    strncpy(d, s, n);
    d += (n > m) ? m : n;
    return d;
}

#define MAX_LENGTH 16

void
DrawStatusWindow(Display *disp, InputContext *ic)
{
    unsigned char buf[MAX_LENGTH];
    char *s, *d, *x = buf + MAX_LENGTH - 1;

    if (ic->status_window == None)
	return;
    s = (ic->forward) ? MSG_ActiveLabel.spec : MSG_InactiveLabel.spec;
    d = buf;
    while (*s && d < x) {
	if (*s == '%') {
	    switch (*++s) {
	    case 0:
		break;
	    case '%':
		*d++ = '%';
		++s;
		break;
	    case 's':
		d = addState(d, x, ic);
		++s;
		break;
	    case 'p':
		d = addMode(d, x, ic);
		++s;
		break;
	    default:
		++s;
		break;
	    }
	}
	else {
	    *d++ = *s;
	    ++s;
	}
    }
    *d = 0;

    XSetForeground(disp, ic->status_gc, ic->status_background);
    XFillRectangle(disp, ic->status_window, ic->status_gc, 0, 0,
		   ic->status_area.width, ic->status_area.height);
    XSetForeground(disp, ic->status_gc, ic->status_foreground);
    XmbDrawString(disp, ic->status_window, ic->status_fontset.id,
		  ic->status_gc, 0, ic->status_fontset.ascent,
		  buf, strlen(buf));
}

void
RaiseStatusWindow(Display *disp, InputContext *ic)
{
    if (ic->status_window == None)
	return;
    XRaiseWindow(disp, ic->status_window);
}
