/*
	$Id: status.h,v 1.2 2001/02/04 18:43:17 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void DrawStatusWindow(Display *, InputContext *);
void RaiseStatusWindow(Display *, InputContext *);
void LoadStatusPreference(Display *, char *, char *);
