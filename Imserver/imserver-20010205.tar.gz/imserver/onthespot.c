/*
	$Id: onthespot.c,v 1.1 2000/10/03 18:45:26 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h" /* only for Feedback[] */
#include "message.h"
#include "status.h"
#include "commit.h"
#include "ontheroot.h"

static void
Clear(Connection *con, InputContext *ic)
{ 
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    
    if ((len = LengthOfSylText(ic->preedit)) <= 0)
	return;
    if (ic->head != NULL)
	len = LengthOfPhrase(ic->head);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = 0;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = len;
    xim_preedit_draw.status = 1 & 2; /* NO_STRING & NO_FEEDBACK */
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
ChangePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    
    len = LengthOfSylText(ic->view->chosen);
    wcs = CreateWCStringFromSylText(ic->view->chosen, 0, len);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->view, ic->view); /* XXX */
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
ResizePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    CARD32 *feedback;
    XTextProperty t;
    wchar_t *wcs;
    int len;

    wcs = CreateWCStringFromPhrase(ic->view);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->view, ic->view);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = LengthOfPhrase(ic->view);
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
Cancel(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int n, len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;
    
    len = LengthOfSylText(ic->preedit);
    wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    for (n = 0; n < len; ++n)
	xim_preedit_draw.feedback.val[n] = 2;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    ldfree(feedback);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
SelectPhrase(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;

    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfPhrase(ic->head);
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
Replace(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    const CARD32 Underline = 2;
    XTextProperty t;
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int n, len;
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(ic->preedit, chg_first, ic->caret);
    len = ic->caret - chg_first;
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = chg_first;
    xim_preedit_draw.chg_length = chg_length;
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = ldmalloc(sizeof(CARD32) * len);
    for (n = 0; n < len; ++n)
	xim_preedit_draw.feedback.val[n] = Underline;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    ldfree(xim_preedit_draw.feedback.val);
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText() */
}

static void
Convert(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    CARD32 *feedback;

    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view);
    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = 0;
    xim_preedit_draw.chg_length = LengthOfSylText(ic->preedit);
    /*
      BUG: ����status��NO_STRING (1) �ӥåȤ򥻥åȤ�����硢���饤�����
      ¦��XIMPreeditDrawCallbackStruct�Υ���text��NULL�ˤʤäƤ��ޤ���
      ������xc/lib/X11/imCallbk.c�δؿ�_read_text_from_packet()�ΥХ���
    */
    xim_preedit_draw.status = 0;
    xim_preedit_draw.string.len = t.nitems;
    xim_preedit_draw.string.val = t.value;
    xim_preedit_draw.feedback.num = len;
    xim_preedit_draw.feedback.val = feedback;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
    free(feedback); /* CreateFeedbackFromPhrase() */
    XFree(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateMBStringFromPhrase() */
}

static void
DeleteChar(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;

    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 1;
    xim_preedit_draw.status = 1 & 2; /* NO_STRING & NO_FEEDBACK */
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
MoveCaret(Connection *con, InputContext *ic)
{
    XIM_PREEDIT_DRAW xim_preedit_draw;
    SerializedPacket *req;
    int len;

    xim_preedit_draw.im_id = con->im_id;
    xim_preedit_draw.ic_id = ic->ic_id;
    xim_preedit_draw.caret = ic->caret;
    xim_preedit_draw.chg_first = ic->caret;
    xim_preedit_draw.chg_length = 0;
    xim_preedit_draw.status = 1 & 2; /* NO_STRING & NO_FEEDBACK */
    xim_preedit_draw.string.len = 0;
    xim_preedit_draw.string.val = NULL;
    xim_preedit_draw.feedback.num = 0;
    xim_preedit_draw.feedback.val = NULL;
    Send_XIM_PREEDIT_DRAW(&xim_preedit_draw, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DRAW, req, len);
    Free_SerializedPacket(req);
}

static void
HoldFocus(Connection *con, InputContext *ic)
{
}

static void
LostFocus(Connection *con, InputContext *ic)
{
}

static ICPreeditDrawMethods methods = {
    Clear,
    ChangePhrase,
    ResizePhrase,
    Cancel,
    SelectPhrase,
    Replace,
    Convert,
    DeleteChar,
    MoveCaret,
    HoldFocus,
    LostFocus};

ICPreeditDrawMethods *ICPreeditDrawOnTheSpot = &methods;
