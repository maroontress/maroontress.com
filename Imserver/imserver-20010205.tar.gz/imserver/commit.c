/*
	$Id: commit.c,v 1.1 2000/10/03 18:45:23 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include <stdio.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "message.h"
#include "status.h"
#include "commit.h"

void
ClearString(Connection *con, InputContext *ic)
{
    ic->preedit_draw->clear(con, ic);
}

void
CommitString(Connection *con, InputContext *ic)
{ 
    XIM_COMMIT_CHARS xim_commit;
    SerializedPacket *req;
    int len;
    XTextProperty t;
    wchar_t *wcs;

    if ((len = LengthOfSylText(ic->preedit)) <= 0)
	return;

    FreeSylText(ic->fixed);
    ic->fixed = ic->preedit;
    ic->preedit = CreateSylTextFromMBString("", False);

    if (ic->head != NULL) {
	StudyPhrase(ic->head, ic->fixed);
	wcs = CreateWCStringFromPhrase(ic->head);
	len = LengthOfPhrase(ic->head);
	FreePhrase(ic->head);
	if (ic->candidate_window != None)
	    XUnmapWindow(con->disp, ic->candidate_window);
	ic->head = NULL;
	ic->view = NULL;
    }
    else {
	wcs = CreateWCStringFromSylText(ic->fixed, 0, len);
    }
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_commit.im_id = con->im_id;
    xim_commit.ic_id = ic->ic_id;
    xim_commit.flag = 2; /* XLookupChars */
    xim_commit.string.len = t.nitems;
    xim_commit.string.val = t.value;
    Send_XIM_COMMIT_CHARS(&xim_commit, &req, &len);
    SendIntoWire(con, OPCODE_XIM_COMMIT, req, len);
    Free_SerializedPacket(req);
    free(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText() */
    ic->caret = 0;
#if 1
    /* CommitString()��Ƥ�¦��DrawStatusWindow()��Ƥ֤褦���ѹ�? */
    DrawStatusWindow(con->disp, ic);
#endif
}

void
EchoXIMForwardEvent(Connection *con, XIM_FORWARD_EVENT *ev)
{
    SerializedPacket *req;
    int len;

    ev->flag = 0;
    Send_XIM_FORWARD_EVENT(ev, &req, &len);
    SendIntoWire(con, OPCODE_XIM_FORWARD_EVENT, req, len);
    Free_SerializedPacket(req);
}
