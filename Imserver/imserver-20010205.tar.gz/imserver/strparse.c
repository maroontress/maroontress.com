/*
	$Id: strparse.c,v 1.1 2000/10/03 18:45:28 syl Exp $

	Copyright (C) 1997, 1998, 1999 Syllabub
	Maroontress Fast Software.
*/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "strparse.h"

int StrParseErrorCode;
int StrParseErrorLine;

StrParse *
OpenStrParse(char *string, int max_keyword_len, char **reserved)
{
    StrParse *p;

    if ((p = (StrParse *)malloc(sizeof(StrParse))) == NULL) {
	StrParseErrorCode = STR_PARSE_TOO_SHORT_MEMORY;
	return (NULL);
    }
    p->line = 1;
    p->sp = string;
    p->max_keyword_len = max_keyword_len; /* added syl 1999-09-30 */
    p->reserved = reserved;
    return (p);    
}

void
CloseStrParse(StrParse *p)
{
    if (p == NULL)
	return;
    free(p);
}

int
GetChar(StrParse *p)
{
    int c;

    if ((c = *(p->sp)) == 0)
        return (EOF);
    ++(p->sp);
    if (c == '\n')
        ++(p->line);
    return (c);
}

void
UngetChar(int c, StrParse *p)
{
    if (c == '\n')
	--(p->line);
#if 0
    /* p->ps��ɬ������񤭹���ʤ���strdup()����褦���ѹ�����٤��� */
    if (c != EOF)
        *--(p->sp) = c;
#else
    if (c != EOF)
        --(p->sp);
#endif
}

static int
IsDelimiter(int c)
{
    return (strchr(" \t", c) != NULL);
}

static int
IsFirstName(int c)
{
    return (isalpha(c) || c == '_');
}

static int
IsName(int c)
{
    return (isalnum(c) || c == '_');
}

static int
IsPuncuator(int c)
{
    return (strchr("[](){},;:", c) != NULL);
}

static int
GetOperator(StrParse *p, char *buf, int c)
{
    int w;

    *buf++ = c;
    if (c == '-') { /* Group1: "X" "X>" "XX" "X=" */
	if ((w = GetChar(p)) == '>' || w == '-' || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("+&|=", c) != NULL) { /* Group2: "X" "XX" "X=" */
	if ((w = GetChar(p)) == c || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (c == '<' || c == '>') { /* Group3: "X" "XX" "X=" "XX=" */
	if ((w = GetChar(p)) == c)
	    *buf++ = w;
	else
	    UngetChar(w, p);
	if ((w = GetChar(p)) == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("*%^!", c) != NULL) { /* Group4: "X" "X=" */
	if ((w = GetChar(p)) == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (c == '.') { /* Group5: "X" "XXX" */
	if ((w = GetChar(p)) != c)
	    UngetChar(w, p);	
	else if ((w = GetChar(p)) != (*buf++ = c)) {
	    *buf = 0;
	    return (1); /* parse error */
	}
	else
	    *buf++ = c;
    }
    else if (c == '/') { /* Group5: "X" "X=" "X*" */
	if ((w = GetChar(p)) == '*' || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("#?\"\'", c) == NULL) {
	*buf = 0;
	return (1); /* parse error */
    }
    *buf = 0;
    return (0);
}

static int
GetWord(StrParse *p, char *top, void (*drain)(int))
{
    int c, n = 0;
    char *buf = top;

    while (IsDelimiter(c = GetChar(p)) || c == '\n') {
	if (c == '\n')
	    ++n;
	if (drain != NULL) /* modified Apr 2, 1997 Syl */
	    drain(c);
    }
    if (n > 1) {
	UngetChar(c, p);
	buf[0] = '\n';
	buf[1] = 0;
	return (STR_PARSE_EMPTYLINES);
    }
    else if (c == EOF) {
	*buf = 0;
	return (EOF);
    }
    else if (IsFirstName(c)) {
	for (n = 0, *buf++ = c; IsName(c = GetChar(p))
		 && n < p->max_keyword_len; ++buf, ++n) {
	    *buf = c;
	}
	UngetChar(c, p);
	*buf = 0;
	if (n == p->max_keyword_len && IsName(c)) {
	    StrParseErrorCode = STR_PARSE_TOO_LONG_KEYWORD;
	    StrParseErrorLine = p->line;
	    return (STR_PARSE_TOO_LONG_KEYWORD);
	}
	return (STR_PARSE_KEYWORD);
    }
    else if (IsPuncuator(c)) {
	buf[0] = c;
	buf[1] = 0;
	return (STR_PARSE_PUNCTUATOR);
    }
    else if (isdigit(c)) {
	*buf++ = c;
	if (c != '0') { /* 10����� */
	    while (isdigit(c = GetChar(p)))
		*buf++ = c;
	}
	else if (tolower(c = GetChar(p)) == 'x') { /* 16����� */
	    for (*buf++ = c; isxdigit(c = GetChar(p)); ++buf)
		*buf = c;
	}	    
	else if (isdigit(c)) { /* 8����� */
	    for (*buf++ = c; isdigit(c = GetChar(p)); ++buf)
		*buf = c;
	}
	/* �����Ǥʤ����0 */
	while (tolower(c) == 'u' || tolower(c) == 'l') { /* ������ */
	    *buf++ = c;
	    c = GetChar(p);
	}
	UngetChar(c, p);
	*buf = 0;
	return (STR_PARSE_NUMBER);
    }
    else if (GetOperator(p, buf, c) == 0)
	return (STR_PARSE_OPERATOR);
    else {
	StrParseErrorCode = STR_PARSE_UNKNOWN_OPERATOR;
	StrParseErrorLine = p->line;
	return (STR_PARSE_UNKNOWN_OPERATOR);
    }
}

static int
IsReservedKeyword(char *key, char **reserved)
{
    char **ptr;

    for (ptr = reserved; (*ptr) != NULL; ++ptr) {
	if (strcmp(*ptr, key) == 0)
	    return (1);
    }
    return (0);
}

int
GetToken(StrParse *p, char *buf, void (*drain)(int))
{
    int type;

    type = GetWord(p, buf, drain);
    if (type == STR_PARSE_KEYWORD && IsReservedKeyword(buf, p->reserved))
	return (STR_PARSE_RESERVED);
    else if (type != STR_PARSE_OPERATOR)
	return (type);
    else if (strcmp(buf, "#") == 0) /* preprocessor command */
	return (STR_PARSE_CPPCMD);
    else if (strcmp(buf, "\"") == 0) /* string const*/
	return (STR_PARSE_STRCONST);
    else if (strcmp(buf, "\'") == 0) /* char const */
	return (STR_PARSE_CHARCONST);
    else if (strcmp(buf, "/*") == 0) /* comment */
	return (STR_PARSE_COMMENT);
    else
	return (type);
}
