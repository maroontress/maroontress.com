/*
	$Id: Tokenizer.c,v 1.1 2003/05/31 14:41:20 syl Exp $

	Copyright (C) 1997, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "Tokenizer.h"

#define TokenLengthOfSylTokenizer(tok) \
	(((tok)->string == NULL) ? 0 : (tok)->ptr - (tok)->string)

static int
IsFirstName(int c)
{
    return (isalpha(c) || c == '_');
}

static int
IsName(int c)
{
    return (isalnum(c) || c == '_');
}

static int
IsDelimiter(int c)
{
    return (strchr(" \t\n", c) != NULL);
}

static int
IsPunctuator(int c)
{
    return (strchr("[](){},;:", c) != NULL);
}

static const SylCharAppraiser DefaultCA = {
    IsFirstName,
    IsName,
    IsDelimiter,
    IsPunctuator};

SylTokenizer *
CreateSylTokenizer(const char *top)
{
    return (CreateSylTokenizerWithCA(top, &DefaultCA));
}

SylTokenizer *
CreateSylTokenizerWithCA(const char *top, const SylCharAppraiser *ca)
{
    SylTokenizer *tok;

    if ((tok = (SylTokenizer *)malloc(sizeof(SylTokenizer))) == NULL)
	return (NULL);
    tok->top = top;
    tok->ptr = top;
    tok->string = NULL;
    tok->line = 1;
    tok->reserved_words = NULL;
    tok->ca = ca;
    tok->drain = NULL;
    tok->token = NULL;
    return (tok);
}

void
FreeSylTokenizer(SylTokenizer *tok)
{
    free(tok->token);
    free(tok);
}

void
SetReservedWordsToSylTokenizer(SylTokenizer *tok, const char **reserved_words)
{
    tok->reserved_words = reserved_words;
}

void
SetDrainToSylTokenizer(SylTokenizer *tok, void (*drain)(SylTokenizer *, int))
{
    tok->drain = drain;
}

static int
GetChar(SylTokenizer *tok)
{
    int c;

    if ((c = *(tok->ptr)) == 0)
        return (EOF);
    ++(tok->ptr);
    if (c == '\n')
	++(tok->line);
    return (c);
}

static void
UngetChar(SylTokenizer *tok, int c)
{
    if (c != EOF && tok->top < tok->ptr)
        --(tok->ptr);
    if (c == '\n')
	--(tok->line);
}

static int
GetOperator(SylTokenizer *tok, int c)
{
    int w;

    if (c == '-') { /* Group1: "X" "X>" "XX" "X=" */
	if ((w = GetChar(tok)) != '>' && w != '-' && w != '=')
	    UngetChar(tok, w);
    }
    else if (strchr("+&|=", c) != NULL) { /* Group2: "X" "XX" "X=" */
	if ((w = GetChar(tok)) != c && w != '=')
	    UngetChar(tok, w);
    }
    else if (c == '<' || c == '>') { /* Group3: "X" "XX" "X=" "XX=" */
	if ((w = GetChar(tok)) != c)
	    UngetChar(tok, w);
	if ((w = GetChar(tok)) != '=')
	    UngetChar(tok, w);
    }
    else if (strchr("*%^!~", c) != NULL) { /* Group4: "X" "X=" */
	if ((w = GetChar(tok)) != '=')
	    UngetChar(tok, w);
    }
    else if (c == '.') { /* Group5: "X" "XXX" */
	if ((w = GetChar(tok)) != c)
	    UngetChar(tok, w);	
	else if ((w = GetChar(tok)) != c)
	    return (1); /* parse error */
    }
    else if (c == '/') { /* Group6: "X" "X=" "X*" */
	if ((w = GetChar(tok)) != '*' && w != '=')
	    UngetChar(tok, w);
    }
    else if (strchr("#?\"\'", c) == NULL) {
	return (1); /* parse error */
    }
    return (0);
}

static int
GetWord(SylTokenizer *tok)
{
    int c, n;

    n = 0;
    while (tok->ca->is_delimitor(c = GetChar(tok)) || c == '\n') {
	if (c == '\n')
	    ++n;
	if (tok->drain != NULL)
	    tok->drain(tok, c);
    }
    if (n > 1) {
	UngetChar(tok, c);
	tok->string = NULL;
	return (SYL_TOKEN_EMPTYLINES);
    }
    if (c == EOF) {
	tok->string = NULL;
	return (EOF);
    }

    tok->string = tok->ptr - 1;
    if (tok->ca->is_first_name(c)) {
	while ((c = GetChar(tok)) != EOF && tok->ca->is_name(c))
	    ;
	UngetChar(tok, c);
	return (SYL_TOKEN_KEYWORD);
    }
    if (tok->ca->is_punctuator(c)) {
	return (SYL_TOKEN_PUNCTUATOR);
    }
    if (isdigit(c)) {
	if (c != '0') { /* 10����� */
	    while ((c = GetChar(tok)) != EOF && isdigit(c))
		;
	}
	else if (tolower(c = GetChar(tok)) == 'x') { /* 16����� */
	    while ((c = GetChar(tok)) != EOF && isxdigit(c))
		;
	}	    
	else if (isdigit(c)) { /* 8����� */
	    while ((c = GetChar(tok)) != EOF && isdigit(c))
		;
	}
	/* �����Ǥʤ����0 */
	while (tolower(c) == 'u' || tolower(c) == 'l') { /* ������ */
	    c = GetChar(tok);
	}
	UngetChar(tok, c);
	return (SYL_TOKEN_NUMBER);
    }
    if (GetOperator(tok, c) == 0) {
	return (SYL_TOKEN_OPERATOR);
    }
    return (SYL_TOKEN_UNKNOWN_OPERATOR);
}

static int
IsEqualToString(SylTokenizer *tok, const char *s)
{
    unsigned int n = TokenLengthOfSylTokenizer(tok);

    return (strlen(s) == n && strncmp(s, tok->string, n) == 0);
}

static int
IsReservedWord(SylTokenizer *tok)
{
    const char **s = tok->reserved_words;

    if (s == NULL)
	return 0;
    for (; *s != NULL && !IsEqualToString(tok, *s); ++s)
	;
    return (*s != NULL);
}

static int
GetStringConst(SylTokenizer *tok)
{
    int c;

    while ((c = GetChar(tok)) != EOF
	   && c != '\"'
	   && (c != '\\' || (c = GetChar(tok)) != EOF)) {
	continue;
    }
    return ((c == EOF) ? SYL_TOKEN_UNTERMINATED_STR : SYL_TOKEN_STRCONST);
}

static int
GetCharConst(SylTokenizer *tok)
{
    int c;

    while ((c = GetChar(tok)) != EOF
	   && c != '\''
	   && (c != '\\' || (c = GetChar(tok)) != EOF)) {
	continue;
    }
    return ((c == EOF) ? SYL_TOKEN_UNTERMINATED_CHAR : SYL_TOKEN_CHARCONST);
}

static int
GetComment(SylTokenizer *tok)
{
    int c, is_reach = 0;

    while ((c = GetChar(tok)) != EOF && (!is_reach || c != '/')) {
	is_reach = (c == '*');
    }
    return ((c == EOF) ? SYL_TOKEN_UNTERMINATED_COMMENT : SYL_TOKEN_COMMENT);
}

static int
GetCppCommand(SylTokenizer *tok)
{
    int c;

    while ((c = GetChar(tok)) != EOF
	   && c != '\n'
	   && (c != '\\' || (c = GetChar(tok)) != EOF)) {
	continue;
    }
    return ((c == EOF) ? SYL_TOKEN_UNTERMINATED_CPPCMD : SYL_TOKEN_CPPCMD);
}

static int
GetToken(SylTokenizer *tok)
{
    int type;

    if ((type = GetWord(tok)) == SYL_TOKEN_KEYWORD && IsReservedWord(tok))
	return (SYL_TOKEN_RESERVED);
    else if (type != SYL_TOKEN_OPERATOR)
	return (type);
    else if (IsEqualToString(tok, "\"")) /* string const*/
	return (GetStringConst(tok));
    else if (IsEqualToString(tok, "\'")) /* char const */
	return (GetCharConst(tok));
    else if (IsEqualToString(tok, "/*")) /* comment */
	return (GetComment(tok));
    else if (IsEqualToString(tok, "#")) /* preprocessor command */
	return (GetCppCommand(tok));
    else
	return (type);
}

int
GetTokenFromSylTokenizer(SylTokenizer *tok, const char **data, int *size)
{
    int type;

    type = GetToken(tok);
    *data = tok->string;
    *size = TokenLengthOfSylTokenizer(tok);
    return (type);
}

char *
TokenStringOfSylTokenizer(SylTokenizer *tok)
{
    int len = TokenLengthOfSylTokenizer(tok);

    free(tok->token);
    if (tok->string == NULL) {
	tok->token = NULL;
	return NULL;
    }
    if ((tok->token = (char *)malloc(len + 1)) == NULL)
	return (NULL);
    sprintf(tok->token, "%.*s", len, tok->string);
    return (tok->token);
}
