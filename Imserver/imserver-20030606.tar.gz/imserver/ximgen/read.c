/*
	$Id: read.c,v 1.2 2003/03/16 14:16:20 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdio.h>
#include <string.h>

#include "packet.h"
#include "read.h"

static void
InsertPAD(FILE *fp)
{
    fprintf(fp, "\td += (4 - ((d - q) %% 4)) %% 4;\n");
}

static int
IsCardinal(char *n)
{
    return (strcmp(n, "CARD8") == 0 || strcmp(n, "CARD16") == 0
	    || strcmp(n, "CARD32") == 0);
}

static void
ReadAny(FILE *fp, char *n, char *m)
{
    if (IsCardinal(n)) {
	fprintf(fp, "\t" "p->%s = *((%s *)d)++;\n", m, n);
    }
    else if (strcmp(n, "XEVENT") == 0) {
	fprintf(fp,
		"\t" "memcpy(&(p->%s), (XEVENT *)d, sizeof(XEVENT));\n"
		"\t" "d += sizeof(XEVENT);\n",
		m);
    }
    else if (strcmp(n, "STR") == 0) {
	fprintf(fp,
		"\t" "p->%s.len = *((CARD8 *)d)++;\n"
		"\t" "if ((p->%s.val = (STRING8)ldmalloc(sizeof(CARD8) * "
		/**/ "(p->%s.len + 1))) != NULL) {\n"
		"\t\t" "memcpy(p->%s.val, d, p->%s.len);\n"
                "\t\t" "p->%s.val[p->%s.len] = 0;\n"
		"\t" "}\n"
		"\t" "d += p->%s.len;\n",
		m, m, m, m, m, m, m, m);
    }
    else if (strcmp(n, "STRING") == 0) {
	fprintf(fp,
		"\t" "p->%s.len = *((CARD16 *)d)++;\n"
		"\t" "if ((p->%s.val = (STRING8)ldmalloc(sizeof(CARD8) * "
		/**/ "(p->%s.len + 1))) != NULL) {\n"
		"\t\t" "memcpy(p->%s.val, d, p->%s.len);\n"
                "\t\t" "p->%s.val[p->%s.len] = 0;\n"
		"\t" "}\n"
		"\t" "d += p->%s.len;\n",
		m, m, m, m, m, m, m, m);
	InsertPAD(fp);
    }
    else {
	fprintf(fp, "\t" "d = Read_%s(&(p->%s), d);\n", n, m);
    }
}

static void
ReadArray(FILE *fp, char *n, char *m)
{
    fprintf(fp, "\t" "p->%s.num = *((CARD16 *)d)++;\n", m);
    InsertPAD(fp);
    fprintf(fp,
	    "\t" "p->%s.val = (%s **)ldmalloc(sizeof(%s *) * "
	    /**/ "(p->%s.num + 1));\n"
	    "\t" "for (k = 0; k < p->%s.num; ++k) {\n"
	    "\t\t" "p->%s.val[k] = (%s *)ldmalloc(sizeof(%s));\n",
	    m, n, n,
	    m,
	    m,
	    m, n, n);
    if (IsCardinal(n))
	fprintf(fp, "\t\t" "*(p->%s.val[k]) = *((%s *)d)++;\n", m, n);
    else
	fprintf(fp, "\t\t" "d = Read_%s(p->%s.val[k], d);\n", n, m);
    fprintf(fp, "\t" "}\n");
}

static void
ReadList(FILE *fp, char *n, char *m)
{
    fprintf(fp, "\t" "k = *((CARD16 *)d)++;\n");
    if (!IsCardinal(n))
	InsertPAD(fp);
    fprintf(fp,
	    "\t" "p->%s = NULL;\n"
	    "\t" "for (c = &(p->%s), b = d; d - b < k; c = &((*c)->next)) {\n"
	    "\t\t" "(*c) = (LIST *)ldmalloc(sizeof(LIST));\n"
	    "\t\t" "(*c)->data = (%s *)ldmalloc(sizeof(%s));\n"
	    "\t\t" "(*c)->next = NULL;\n",
	    m,
	    m,
	    n, n);
    if (IsCardinal(n))
	fprintf(fp, "\t\t" "*((%s *)(*c)->data) = *((%s *)d)++;\n", n, n);
    else
	fprintf(fp, "\t\t" "d = Read_%s((*c)->data, d);\n", n);
    fprintf(fp, "\t" "}\n");
}

static void
ReadMulti(FILE *fp, char *n, char *m)
{
    fprintf(fp,
	    "\t" "p->%s.num = *((CARD16 *)d)++;\n"
	    "\t" "p->%s.num /= sizeof(%s);\n",
	    m,
	    m, n);
    if (strcmp(n, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp,
	    "\t" "p->%s.val = (%s *)ldmalloc(sizeof(%s) * (p->%s.num + 1));\n"
	    "\t" "for (k = 0; k < p->%s.num; ++k)\n"
	    "\t\t" "p->%s.val[k] = *((%s *)d)++;\n",
	    m, n, n, m,
	    m,
	    m, n);
}

void
PrintRead(FILE *fp, PacketList *pl)
{
    int n;
    Type *t;
    Packet *ptr;

    fprintf(fp,
            "\n"
            "CARD8 *\n"
            "Read_STR(STR *p, CARD8 *d)\n"
            "{\n"
            "\t" "p->len = *((CARD8 *)d)++;\n"
            "\t" "if ((p->val = (STRING8)ldmalloc(sizeof(CARD8)"
	    /**/ " * (p->len + 1))) != NULL) {\n"
	    "\t\t" "memcpy(p->val, d, p->len);\n"
	    "\t\t" "p->val[p->len] = 0;\n"
	    "\t" "}\n"
	    "\t" "d += p->len;\n"
	    "\t" "return (d);\n"
	    "}\n"
	    "\n"
            "CARD8 *\n"
            "Read_STRING(STRING *p, CARD8 *q)\n"
            "{\n"
	    "\t" "CARD8 *d = q;\n"
	    "\n"
            "\t" "p->len = *((CARD16 *)d)++;\n"
            "\t" "if ((p->val = (STRING8)ldmalloc(sizeof(CARD8)"
	    /**/ " * (p->len + 1))) != NULL) {\n"
	    "\t\t" "memcpy(p->val, d, p->len);\n"
	    "\t\t" "p->val[p->len] = 0;\n"
	    "\t" "}\n"
	    "\t" "d += p->len;\n"
	    "\t" "d += (4 - ((d - q) %% 4)) %% 4;\n"
	    "\t" "return (d);\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Write)
	    continue;
	fprintf(fp,
		"\n"
		"%sCARD8 *\n"
		"Read_%s(%s *p, CARD8 *q)\n"
		"{\n"
		"\t" "CARD8 *d = q;\n ",
		((ptr->to_do == Basic) ? "" : "static "),
		ptr->type, ptr->type);
	n = 0;
	for (t = ptr->head; t != NULL; t = t->next)
	    n |= (1 << t->mod);
	if (n > 1) {
	    fprintf(fp, "\t" "int k;\n");
	    if (n & (1 << Listof)) {
		fprintf(fp, "\t" "LIST **c;\n");
		fprintf(fp, "\t" "CARD8 *b;\n");
	    }
	}
	fprintf(fp, "\n");
	for (t = ptr->head; t != NULL; t = t->next) {
	    if (strcmp(t->name, "PAD") == 0)
		InsertPAD(fp);
	    else if (t->mod == Array)
		ReadArray(fp, t->name, t->member);
	    else if (t->mod == Listof)
		ReadList(fp, t->name, t->member);
	    else if (t->mod == Multi)
		ReadMulti(fp, t->name, t->member);
	    else
		ReadAny(fp, t->name, t->member);
	}
	fprintf(fp,
		"\t" "return (d);\n"
		"}\n");
    }
}
