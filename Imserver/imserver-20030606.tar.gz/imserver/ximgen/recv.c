/*
	$Id: recv.c,v 1.1 2000/10/03 18:46:03 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "recv.h"

void
PrintRecv(FILE *fp, PacketList *pl)
{
    Packet *ptr;

    fprintf(fp,
            "\n"
            "STR *\n"
            "Recv_STR(CARD8 *p)\n"
            "{\n"
            "\t" "STR *q;\n"
	    "\n"
            "\t" "if ((q = (STR *)ldmalloc(sizeof(STR))) != NULL) {\n"
	    "\t\t" "Read_STR(q, p);\n"
	    "\t" "}\n"
	    "\t" "return (q);\n"
	    "}\n"
	    "\n"
            "STRING *\n"
            "Recv_STRING(CARD8 *p)\n"
            "{\n"
            "\t" "STRING *q;\n"
	    "\n"
            "\t" "if ((q = (STRING *)ldmalloc(sizeof(STRING))) != NULL) {\n"
	    "\t\t" "Read_STRING(q, p);\n"
	    "\t" "}\n"
	    "\t" "return (q);\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Write)
	    continue;
	fprintf(fp,
		"\n"
		"%s *\n"
		"Recv_%s(CARD8 *p)\n"
		"{\n"
		"\t" "%s *q;\n"
		"\n"
		"\t" "if ((q = (%s *)ldmalloc(sizeof(%s))) != NULL) {\n"
		"\t\t" "Read_%s(q, p);\n"
		"\t" "}\n"
		"\t" "return (q);\n"
		"}\n",
		ptr->type, ptr->type, ptr->type,
		ptr->type, ptr->type, ptr->type);
    }
}
