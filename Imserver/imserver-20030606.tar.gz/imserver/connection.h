/*
	$Id: connection.h,v 1.11 2003/06/03 15:34:21 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

struct ICPreeditDrawMethods;
struct ICStatusDrawMethods;

typedef enum {
    PRECONVERSION_NONE,
    PRECONVERSION_SINGLE,
    PRECONVERSION_DOUBLE
} PreconversionLevel;

typedef struct InputContext {
    struct InputContext *next;
    int ic_id;
    int input_style;
    Window client_window;
    Window focus_window;
    XIMResetState reset_state;
    int optimization;
    XIMFeedback normal_feedback;
    XIMFeedback underline_feedback;
    XIMFeedback reverse_feedback;

    Window preedit_window;
    SylFontSet preedit_fontset;
    char *preedit_fontset_name;
    unsigned long preedit_foreground;
    unsigned long preedit_background;
    XPoint preedit_spot_location;
    XIMPreeditState preedit_init_state;
    XIMPreeditState preedit_state;

    Window status_window;
    Pixmap status_pixmap;
    GC status_gc;
    SylFontSet status_fontset;
    char *status_fontset_name;
    unsigned long status_foreground;
    unsigned long status_background;
    XRectangle status_area;

    Window candidate_window;
    SylFontSet *candidate_fontset;

    int forward;
    int focus;
    PreconversionLevel preconversion;
    int max_preedit_chars; /* ���饤����Ȥδ�˾ */

    SylText *preedit;
    SylText *fixed;
    int caret;

    Phrase *head;
    Phrase *view;
    int last_drawn_length;

    struct ICPreeditDrawMethods *preedit_draw;
    struct ICStatusDrawMethods *status_draw;

    struct InputContext *nice_next;
    void (*nice_func)(struct InputContext *, void *);
    void *nice_data;
} InputContext;

typedef struct Connection {
    struct Connection *next;
    Display *disp;
    Window client;
    Window server;
    int im_id;
#ifdef USE_XIM_RESOURCE_NAME_CLASS
    char *resource_name;
    char *resource_class;
#endif /* USE_XIM_RESOURCE_NAME_CLASS */
    InputContext *work;
    InputContext *idle;
    int next_ic_id;

    XContext preedit;
    XContext status;
    XContext candidate;
} Connection;

typedef struct ICPreeditDrawMethods {
    void (*clear)(Connection *, InputContext *);
    void (*change_phrase)(Connection *, InputContext *, int, int);
    void (*resize_phrase)(Connection *, InputContext *, int, int);
    void (*cancel)(Connection *, InputContext *, int, int);
    void (*select_phrase)(Connection *, InputContext *);
    void (*replace)(Connection *, InputContext *, int, int);
    void (*convert)(Connection *, InputContext *);
    void (*delete_char)(Connection *, InputContext *);
    void (*move_caret)(Connection *, InputContext *);
    void (*focus_in)(Connection *, InputContext *);
    void (*focus_out)(Connection *, InputContext *);
    void (*destroy)(Connection *, InputContext *);
} ICPreeditDrawMethods;

typedef struct ICStatusDrawMethods {
    void (*commit)(Connection *, InputContext *, char *);
    void (*focus_in)(Connection *, InputContext *);
    void (*focus_out)(Connection *, InputContext *);
    void (*destroy)(Connection *, InputContext *);
} ICStatusDrawMethods;

Connection * CreateConnection(XClientMessageEvent *);
void FreeConnection(Connection *);

InputContext * CreateInputContext(Connection *);
InputContext * SerachInputContext(Connection *, int);
void FreeInputContext(Connection *, int);
int NiceInputContext(void);
void DeferInputContext(InputContext *, void (*)(InputContext *, void *),
		       void *);
