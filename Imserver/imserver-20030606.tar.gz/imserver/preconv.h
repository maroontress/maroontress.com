/*
	$Id: preconv.h,v 1.3 2003/03/10 15:33:15 syl Exp $

	Copyright (C) 1999, 2000, 2003 Syllabub
	Maroontress Fast Software.
*/

void LoadPreconversionRule(Display *, char *, char *, SylSetting *,
			   SylSetting *);
int Preconvert(SylText *txt, int caret, int *back, int *forward, int is_final);

void LoadSymbolSystemMapping(Display *, char *, char *, SylSetting *);
void ReplaceSymbolSystem(SylText *, int, int, int);

void LoadSymbolWidthMapping(Display *, char *, char *, SylSetting *);
void ReplaceSymbolWidth(SylText *, int, int, int);
