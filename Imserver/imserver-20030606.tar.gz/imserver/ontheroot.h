/*
	$Id: ontheroot.h,v 1.2 2001/02/12 11:57:01 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

extern ICPreeditDrawMethods *ICPreeditDrawOnTheRoot;
extern ICStatusDrawMethods *ICStatusDrawOnTheRoot;
