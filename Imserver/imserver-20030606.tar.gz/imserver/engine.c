/*
	$Id: engine.c,v 1.2 2002/09/08 17:13:01 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "engine.h"

#if defined(USE_CANNA)
#include "canna.h"
#elif defined(USE_SJ3)
#include "sj3.h"
#endif

static Engine *concrete = NULL;

int
OpenEngine(char *server)
{
#if defined(USE_CANNA)
    concrete = CannaEngine;
#elif defined(USE_SJ3)
    concrete = Sj3Engine;
#endif
    return concrete->open(server);
}

void
CloseEngine(void)
{
    concrete->close();
    concrete = NULL;
}

static void
ChangePhrase(Phrase *p, SylText *txt)
{
    FreeSylText(p->chosen);
    p->chosen = DuplicateSylText(txt);
    FreeSylText(p->applicant);
    p->applicant = DuplicateSylText(txt);
}

void
ChangeNextRankOfPhraseWithEngine(Phrase *p, wchar_t *wcs)
{
    Candidate *ptr;
    SylText *txt;

    if (p->head == NULL) {
	concrete->get_candidate_list(p, wcs);
    }

    txt = p->applicant;
    if ((ptr = LookupCandidateOfPhrase(p)) != NULL) {
	ptr = ptr->next;
	txt = (ptr == NULL) ? p->head->applicant : ptr->applicant;
    }
    ChangePhrase(p, txt);
}

void
ChangePrevRankOfPhraseWithEngine(Phrase *p, wchar_t *wcs)
{
    Candidate *ptr;
    SylText *txt;

    if (p->head == NULL) {
	concrete->get_candidate_list(p, wcs);
    }

    txt = p->applicant;
    if ((ptr = LookupCandidateOfPhrase(p)) != NULL) {
	ptr = ptr->prev;
	txt = (ptr == NULL) ? p->tail->applicant : ptr->applicant;
    }
    ChangePhrase(p, txt);
}

Phrase *
ConvertSinglePhraseWithEngine(wchar_t *wcs, int offset, int length)
{
    return (concrete->convert_single_phrase(wcs, offset, length));
}

Phrase *
ConvertWithEngine(wchar_t *wcs, int offset)
{
    return (concrete->convert(wcs, offset));
}

void
StudyPhraseWithEngine(Phrase *p, SylText *txt)
{
    concrete->study(p, txt);
}
