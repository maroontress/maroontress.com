/*
	$Id: optimize.h,v 1.2 2003/06/01 17:17:50 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#define OPT_REVERSE_CARET    0x0001
#define OPT_NO_FEEDBACK      0x0002
#define OPT_ANOTHER_FEEDBACK 0x0004

int GetOptimization(Display *, Window);
void LoadClientOptimization(Display *, char *, char *, SylSetting *);
