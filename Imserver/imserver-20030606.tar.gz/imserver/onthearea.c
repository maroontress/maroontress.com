/*
	$Id: onthearea.c,v 1.4 2003/03/16 14:18:52 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <X11/Xatom.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "connection.h"
#include "leakdetect.h"
#include "status.h"
#include "onthearea.h"

static void
UpdateBackgroundPixmap(Display *disp, Window window, Pixmap pixmap)
{
    XSetWindowBackgroundPixmap(disp, window, pixmap);			       
    XClearWindow(disp, window);
}

static void
StatusCommit(Connection *con, InputContext *ic, char *mbs)
{
    if (ic->status_window == None)
	return;

    XSetForeground(con->disp, ic->status_gc, ic->status_background);
    XFillRectangle(con->disp, ic->status_pixmap, ic->status_gc, 0, 0,
		   ic->status_area.width, ic->status_area.height);
    XSetForeground(con->disp, ic->status_gc, ic->status_foreground);
    XmbDrawString(con->disp, ic->status_pixmap, ic->status_fontset.id,
		  ic->status_gc, 0, ic->status_fontset.ascent,
		  mbs, strlen(mbs));
    XCopyArea(con->disp, ic->status_pixmap, ic->status_window, ic->status_gc,
	      0, 0, ic->status_area.width, ic->status_area.height, 0, 0);
    UpdateBackgroundPixmap(con->disp, ic->status_window, ic->status_pixmap);
}

static void
StatusHoldFocus(Connection *con, InputContext *ic)
{
    if (ic->status_window == None)
	return;
    XMapRaised(con->disp, ic->status_window);
}

static void
DoNothing(Connection *con __unused, InputContext *ic __unused)
{
}

static ICStatusDrawMethods StatusMethods = {
    StatusCommit,
    StatusHoldFocus,
    DoNothing/* focus_out */,
    DoNothing/* destroy */};

ICStatusDrawMethods *ICStatusDrawOnTheArea = &StatusMethods;
