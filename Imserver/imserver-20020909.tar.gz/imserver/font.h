/*
	$Id: font.h,v 1.1 2001/09/22 14:53:36 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

XFontSet CreateSharedFontset(Display *, char *, SylFontSet *);
void FreeSharedFontset(Display *, SylFontSet *);
#ifdef DEBUG
void PrintSharedFontset(void);
#endif
