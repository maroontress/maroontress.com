/*
	$Id: candidate.h,v 1.1 2000/10/03 18:45:23 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

Window CreateCandidateWindow(Display *disp, Window parent);
void ResizeCandidateWindow(Display *disp, InputContext *ic);
void DrawCandidateWindow(Display *disp, InputContext *ic);
