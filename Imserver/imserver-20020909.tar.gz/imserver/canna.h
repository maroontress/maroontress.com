/*
	$Id: canna.h,v 1.1 2001/05/23 13:53:12 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

extern Engine * CannaEngine;
