/*
	$Id: predict.h,v 1.3 2002/09/08 18:48:45 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

void LoadPredictionPreference(Display *, char *, char *);
void RecordCommittedPhrase(wchar_t *, wchar_t *);
Phrase * PredictedPhrase(SylText *, PhraseType);

void CommitPrediction(Connection *, InputContext *);
void CommitSecondaryPrediction(Connection *, InputContext *);
void ClearPrediction(Connection *, InputContext *);
void FocusInPrediction(Connection *, InputContext *);
void FocusOutPrediction(Connection *, InputContext *);
