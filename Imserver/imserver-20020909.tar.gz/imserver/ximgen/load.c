/*
	$Id: load.c,v 1.1 2000/10/03 18:46:01 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parse.h"
#include "packet.h"
#include "load.h"

#define MAXLEN 255

int LoadErrorCode;
int LoadErrorLine;
char LoadErrorWord[MAXLEN + 1];

static char *Reserved[] = {"array", "listof", "multi", NULL};
static char *Predefined[] = {"PAD", "CARD8", "BYTE", "CARD16", "CARD32",
			     "STRING", "STR", "XEVENT", NULL};

static void
ErrorAlreadyDefined(Parse *p, char *w)
{
    LoadErrorCode = LOAD_PREVIOUSLY_DEFINED;
    LoadErrorLine = ParseLine(p);
    if (strlen(w) >= MAXLEN) {
	strncpy(LoadErrorWord, w, MAXLEN);
	LoadErrorWord[MAXLEN - 3] = 0;
	strcat(LoadErrorWord, "...");
    }
    else {
	strcpy(LoadErrorWord, w);
    }
}

static void
ErrorUndefinedType(Parse *p, char *w)
{
    LoadErrorCode = LOAD_UNDEFINED_TYPE;
    LoadErrorLine = ParseLine(p);
    if (strlen(w) >= MAXLEN) {
	strncpy(LoadErrorWord, w, MAXLEN);
	LoadErrorWord[MAXLEN - 3] = 0;
	strcat(LoadErrorWord, "...");
    }
    else {
	strcpy(LoadErrorWord, w);
    }
}

#if 0
static void
ErrorUnterminatedString(Parse *p)
{
    LoadErrorCode = LOAD_UNTERMINATED_STRING;
    LoadErrorLine = ParseLine(p);
}
#endif

static void
ErrorUnexpectedEOF(Parse *p)
{
    LoadErrorCode = LOAD_UNEXPECTED_EOF;
    LoadErrorLine = ParseLine(p);
}

static void
ErrorTooShortMemory(Parse *p)
{
    LoadErrorCode = LOAD_TOO_SHORT_MEMORY;
    LoadErrorLine = ParseLine(p);
}

static void
ErrorParseError(Parse *p, char *w)
{
    LoadErrorCode = LOAD_PARSE_ERROR;
    LoadErrorLine = ParseLine(p);
    strcpy(LoadErrorWord, w);
}

#define STRING_MAX 256

static int
IgnoreComment(Parse *p)
{
    int c;

    while ((c = GetChar(p)) != EOF && c != '\n')
	;
    return (c);
}

#if 0
static int
GetString(Parse *p, char *str, int limit)
{
    int n, c;

    for (n = 0; (c = GetChar(p)) != EOF && n < limit; ++n) {
	if (c == '"')
	    break;
	else if (c == '\\') {
	    if ((c = GetChar(p)) == EOF)
		return (EOF);
	    else if (c != '\n')
		str[n] = c;
	}
	else if (c == '\n')
	    return (c);
	else
	    str[n] = c;
    }
    str[n] = 0;
    return ((c == EOF) ? EOF : 0);
}
#endif

static int
NextWord(Parse *p, char *w)
{
    int type;

    while ((type = GetToken(p, w, NULL)) == PARSE_EMPTYLINES
	   || (type == PARSE_CPPCMD && IgnoreComment(p) == '\n'))
	;
    return (type);
}

static int
TypeOfList(char *str)
{
    int t;
    char **ptr;

    for (t = 1, ptr = Reserved; *ptr != NULL; ++t, ++ptr) {
	if (strcmp(*ptr, str) == 0)
	    return (t);
    }
    /* never reached */
    return (0);
}

static int
IsStatic(char *str)
{
    return (strcmp(str, "CARD8") == 0 || strcmp(str, "CARD16") == 0
	    || strcmp(str, "CARD32") == 0 || strcmp(str, "PAD") == 0
	    || strcmp(str, "XEVENT") == 0 || strcmp(str, "BYTE") == 0);
}

static Packet *
GetPacket(Parse *p, PacketList *pl, enum Category to_do)
{
    int type, is_list, cardinal_only = 1;
    char w[MAXLEN + 1], m[MAXLEN + 1]; /* needs (MAXLEN + 1) bytes at least. */
    Packet *pac;
    Type *mem;
    
    if ((type = NextWord(p, w)) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (IsAlreadyDefined(pl, w)) {
	ErrorAlreadyDefined(p, w);
	return (NULL);
    }
    else if ((pac = CreatePacket(w, to_do)) == NULL) {
	ErrorTooShortMemory(p);
	return (NULL);
    }
    else if (NextWord(p, w) == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "{") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    while ((type = NextWord(p, w)) == PARSE_KEYWORD
	   || type == PARSE_RESERVED) {
	if (type == PARSE_RESERVED) {
	    is_list = TypeOfList(w); /* never 0 */
	    cardinal_only = 0;
	    if ((type = NextWord(p, w)) == EOF) {
		ErrorUnexpectedEOF(p);
		return (NULL);
	    }
	    else if (strcmp(w, "(") != 0) {
		ErrorParseError(p, w);
		return (NULL);
	    }
	    else if ((type = NextWord(p, m)) == EOF) {
		ErrorUnexpectedEOF(p);
		return (NULL);
	    }
	    else if (type != PARSE_KEYWORD) {
		ErrorParseError(p, m);
		return (NULL);
	    }
	    else if (!IsAlreadyDefined(pl, m)) {
		ErrorUndefinedType(p, m);
	    }
	    else if ((type = NextWord(p, w)) == EOF) {
		ErrorUnexpectedEOF(p);
		return (NULL);
	    }
	    else if (strcmp(w, ")") != 0) {
		ErrorParseError(p, w);
		return (NULL);
	    }
	}
	else {
	    is_list = 0;
	    strcpy(m, w);
	}
	if (strcmp(m, "PAD") == 0) {
	    if ((mem = CreateType(is_list, m, "unused")) == NULL) {
		ErrorTooShortMemory(p);
		return (NULL);
	    }
	}
	else {
	    if ((type = NextWord(p, w)) == EOF) {
		ErrorUnexpectedEOF(p);
		return (NULL);
	    }
	    else if (type != PARSE_KEYWORD) {
		ErrorParseError(p, w);
		return (NULL);
	    }
	    else if ((mem = CreateType(is_list, m, w)) == NULL) {
		ErrorTooShortMemory(p);
		return (NULL);
	    }
	}
	if (!IsCardinalOnly(pl, m))
	    cardinal_only = 0;
	AppendTypeToPacket(pac, mem);
	if ((type = NextWord(p, w)) == EOF) {
	    ErrorUnexpectedEOF(p);
	    return (NULL);
	}
	else if (strcmp(w, ";") != 0) {
	    ErrorParseError(p, w);
	    return (NULL);
	}
    }
    if (type == EOF) {
	ErrorUnexpectedEOF(p);
	return (NULL);
    }
    else if (strcmp(w, "}") != 0) {
	ErrorParseError(p, w);
	return (NULL);
    }
    AddtoPacketList(pl, pac, cardinal_only);
    return (pac);
}

int
Load(char *file, PacketList *pl)
{
    int type;
    char **str, w[MAXLEN + 1]; /* needs (MAXLEN + 1) bytes at least. */
    Parse *p;
    Packet *pre;

    if ((p = OpenParse(file, Reserved)) == NULL) {
	LoadErrorCode = LOAD_CANNOT_OPEN;
	return (NULL);
    }
    LoadErrorCode = LOAD_EMPTY;
    for (str = Predefined; *str != NULL; ++str) {
	if ((pre = CreatePacket(*str, Both)) == NULL) {
	    ErrorTooShortMemory(p);
	    break;
	}
	AddtoPacketList(pl, pre, IsStatic(*str));
    }
    while ((type = NextWord(p, w)) != EOF) {
	if (strcmp(w, "basic") == 0) {
	    if (GetPacket(p, pl, Basic) == NULL)
		break;
	}
	else if (strcmp(w, "recv") == 0) {
	    if (GetPacket(p, pl, Read) == NULL)
		break;
	}
	else if (strcmp(w, "send") == 0) {
	    if (GetPacket(p, pl, Write) == NULL)
		break;
	}
	else if (strcmp(w, "both") == 0) {
	    if (GetPacket(p, pl, Both) == NULL)
		break;
	}
	else {
	    ErrorParseError(p, w);
	    break;
	}
    }
    CloseParse(p);
    return ((pl->top == NULL) ? 0 : type);
}
