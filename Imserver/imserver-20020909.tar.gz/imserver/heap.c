/*
	$Id: heap.c,v 1.2 2001/09/09 16:10:51 syl Exp $

	Copyright (C) 1999, 2000, 2001 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>
#include "heap.h"

static HeapNode *
CreateHeapNode(HeapCell c)
{
    HeapNode *n;
    
    if ((n = (HeapNode *)malloc(sizeof(HeapNode))) == NULL)
        return (NULL);
    n->next = NULL;
    n->prev = NULL;
    n->parent = NULL;
    n->left = NULL;
    n->right = NULL;
    n->value = c;
    return (n);
}

static void
FreeHeapNode(HeapNode *n)
{
    free(n);
}

Heap *
CreateHeap(int (*compare)(HeapCell, HeapCell))
{
    Heap *h;

    if ((h = (Heap *)malloc(sizeof(Heap))) == NULL)
	return (NULL);
    h->root = NULL;
    h->last = NULL;
    h->n_nodes = 0;
    h->compare = compare;
    return (h);
}

void
FreeHeap(Heap *h)
{
    HeapNode *n, *next;
    
    for (n = h->root; n != NULL; n = next) {
	next = n->next;
	FreeHeapNode(n);
    }
    free(h);
}

#define Compare(h, p, q) ((h)->compare((p)->value, (q)->value))

static void
Swap(HeapNode *p, HeapNode *q)
{
    HeapCell c;

    c = p->value;
    p->value = q->value;
    q->value = c;
}

static void
ReconfigureAtTail(Heap *h)
{
    HeapNode *n, *p;

    for (n = h->last; (p = n->parent) != NULL && Compare(h, n, p) < 0; n = p)
	Swap(n, p);
}

static void
Add(Heap *h, HeapNode *n)
{
    HeapNode *parent = h->last->parent;

    if (parent == NULL) {
	/* LN�οƤ�NULL => LN�ϥ롼��,  IP�ϥ롼�Ȥκ��λ� */
	parent = h->root;
	parent->left = n;
    }
    else if (parent->right == NULL) {
	/* LN�οƤα��λҤ�NULL => IP�οƤ�LN�οơ�IP��LN�ȷ���� */
	parent->right = n;
    }
    else {
        /* LN�οƤϻҤ�2�Ĥ�� => IP�οƤ�LN�οƤΡּ��פΥΡ��� */
	parent = parent->next;
	parent->left = n;
    }
    n->prev = h->last;
    n->parent = parent;
    h->last->next = n;
    h->last = n;
}

int
InsertIntoHeap(Heap *h, HeapCell c)
{
    HeapNode *n;

    if ((n = CreateHeapNode(c)) == NULL) {
	return HEAP_ERROR;
    }
    if (h->root == NULL) {
	h->root = n;
	h->last = n;
	h->n_nodes = 1;
	return HEAP_SUCCESS;
    }
    Add(h, n);
    ReconfigureAtTail(h);
    ++(h->n_nodes);
    return HEAP_SUCCESS;
}

static HeapNode *
MinChild(Heap *h, HeapNode *n)
{
    if (n->left == NULL)
	return (NULL);
    if (n->right == NULL || Compare(h, n->left, n->right) < 0)
	return (n->left);
    return (n->right);
}

static void
ReconfigureAtRoot(Heap *h)
{
    HeapNode *n, *c;

    for (n = h->root; (c = MinChild(h, n)) != NULL
	     && Compare(h, n, c) > 0; n = c) {
	Swap(n, c);
    }
}

static void
DeleteLast(Heap *h)
{
    HeapNode *parent, *last;
    
    parent = h->last->parent;
    last = h->last->prev;
    if (parent == NULL) {
	/* LN�οƤ�NULL => LN�ϥ롼�� */
	h->root = NULL;
	/* ���ΤȤ� last == NULL */
    }
    else if (parent->right == h->last) {
	/* LN�οƤα��λҤ�LN */
	parent->right = NULL;
	last->next = NULL;
    }
    else {
	/* LN�οƤκ��λҤ�LN */
	parent->left = NULL;
	last->next = NULL;
    }
    FreeHeapNode(h->last);
    h->last = last;
    --(h->n_nodes);
}

HeapCell
TakeMinOfHeap(Heap *h)
{
    HeapCell value;

    if (h->root == NULL)
	return (NULL);
    value = h->root->value;
    h->root->value = h->last->value;
    ReconfigureAtRoot(h);
    DeleteLast(h);
    return (value);
}

void
ForEachOfHeap(Heap *h, void (*callback)(HeapCell))
{
    HeapNode *n;

    for (n = h->root; n != NULL; n = n->next) {
	callback(n->value);
    }
}
