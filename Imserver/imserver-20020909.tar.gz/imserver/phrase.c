/*
	$Id: phrase.c,v 1.8 2002/09/08 17:13:01 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"
#include "leakdetect.h"
#include "phrase.h"
#include "engine.h"

typedef struct {
    char c;
    wchar_t w;
} CharWCharMapping;

static CharWCharMapping HanZenMapping[] = {
    {',', 0x0000a1a4},
    {'.', 0x0000a1a5},
    {':', 0x0000a1a7},
    {';', 0x0000a1a8},
    {'?', 0x0000a1a9},
    {'!', 0x0000a1aa},
    {'^', 0x0000a1b0},
    {'_', 0x0000a1b2},
    {'/', 0x0000a1bf},
    {'\\', 0x0000a1c0},
    {'~', 0x0000a1c1},
    {'|', 0x0000a1c3},
    {'`', 0x0000a1c6},
    {'\'', 0x0000a1c7},
    {'"', 0x0000a1c9},
    {'(', 0x0000a1ca},
    {')', 0x0000a1cb},
    {'[', 0x0000a1ce},
    {']', 0x0000a1cf},
    {'{', 0x0000a1d0},
    {'}', 0x0000a1d1},
    {'+', 0x0000a1dc},
    {'-', 0x0000a1dd},
    {'=', 0x0000a1e1},
    {'<', 0x0000a1e3},
    {'>', 0x0000a1e4},
    {'$', 0x0000a1f0},
    {'%', 0x0000a1f3},
    {'#', 0x0000a1f4},
    {'&', 0x0000a1f5},
    {'*', 0x0000a1f6},
    {'@', 0x0000a1f7}};

void
ChangeZenkakuPhrase(Phrase *p, SylText *txt)
{
    int n, k, m;
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    for (n = 0; n < p->length; ++n) {
	if ((wcs[n] >= 0x00000030 && wcs[n] <= 0x00000039)
	    || (wcs[n] >= 0x00000041 && wcs[n] <= 0x0000005a)
	    || (wcs[n] >= 0x00000061 && wcs[n] <= 0x0000007a)) {
	    wcs[n] += 0x0000a380;
	}
	else {
	    m = sizeof(HanZenMapping) / sizeof(CharWCharMapping);
	    for (k = 0; k < m; ++k) {
		if (wcs[n] == HanZenMapping[k].c) {
		    wcs[n] = HanZenMapping[k].w;
		    break;
		}
	    }
	}
    }
    DeleteStringOfSylText(p->chosen, 0, LengthOfSylText(p->chosen));
    InsertWCStringIntoSylText(p->chosen, 0, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangeHankakuPhrase(Phrase *p, SylText *txt)
{
    int n, k, m;
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    for (n = 0; n < p->length; ++n) {
	if ((wcs[n] >= 0x0000a3b0 && wcs[n] <= 0x0000a3b9)
	    || (wcs[n] >= 0x0000a3c1 && wcs[n] <= 0x0000a3da)
	    || (wcs[n] >= 0x0000a3e1 && wcs[n] <= 0x0000a3fa)) {
	    wcs[n] -= 0x0000a380;
	}
	else {
	    m = sizeof(HanZenMapping) / sizeof(CharWCharMapping);
	    for (k = 0; k < m; ++k) {
		if (wcs[n] == HanZenMapping[m].w) {
		    wcs[n] = HanZenMapping[m].c;
		    break;
		}
	    }
	}
    }
    DeleteStringOfSylText(p->chosen, 0, LengthOfSylText(p->chosen));
    InsertWCStringIntoSylText(p->chosen, 0, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangeHiraganaPhrase(Phrase *p, SylText *txt)
{
    int n;
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    for (n = 0; n < p->length; ++n) {
	if (wcs[n] >= 0x0000a5a1 && wcs[n] <= 0x0000a5f3) {
	    wcs[n] -= 0x100;
	}
    }
    DeleteStringOfSylText(p->chosen, 0, LengthOfSylText(p->chosen));
    InsertWCStringIntoSylText(p->chosen, 0, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangeKatakanaPhrase(Phrase *p, SylText *txt)
{
    int n;
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    for (n = 0; n < p->length; ++n) {
	if (wcs[n] >= 0x0000a4a1 && wcs[n] <= 0x0000a4f3) {
	    wcs[n] += 0x100;
	}
    }
    DeleteStringOfSylText(p->chosen, 0, LengthOfSylText(p->chosen));
    InsertWCStringIntoSylText(p->chosen, 0, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangeNextRankOfPhrase(Phrase *p, SylText *txt)
{
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    ChangeNextRankOfPhraseWithEngine(p, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangePrevRankOfPhrase(Phrase *p, SylText *txt)
{
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    ChangePrevRankOfPhraseWithEngine(p, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

Phrase *
CreateSinglePhrase(SylText *txt, int bgn, int end)
{
    wchar_t *wcs;
    Phrase *p;

    wcs = CreateWCStringFromSylText(txt, bgn, end);
    p = ConvertSinglePhraseWithEngine(wcs, bgn, end - bgn);
    free(wcs); /* CreateWCStringFromSylText() */
    return (p);
}

static Phrase *
CreateAnyPhrase(SylText *txt, int bgn, int end,
		void (*changer)(Phrase *, SylText *))
{
    wchar_t *wcs;
    Phrase *p;

    wcs = CreateWCStringFromSylText(txt, bgn, end);
    p = ConvertSinglePhraseWithEngine(wcs, bgn, end - bgn);
    changer(p, txt);
    free(wcs); /* CreateWCStringFromSylText() */
    return (p);
}

Phrase *
CreateHiraganaPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeHiraganaPhrase));
}    

Phrase *
CreateKatakanaPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeKatakanaPhrase));
}    

Phrase *
CreateZenkakuPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeZenkakuPhrase));
}    

Phrase *
CreateHankakuPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeHankakuPhrase));
}    

Phrase *
CreatePhrase(SylText *txt, int bgn, int end)
{
    wchar_t *wcs;
    Phrase *p;

    wcs = CreateWCStringFromSylText(txt, bgn, end);
    p = ConvertWithEngine(wcs, bgn);
    free(wcs); /* CreateWCStringFromSylText() */
    return (p);
}

Candidate *
CreateCandidate(SylText *txt)
{
    Candidate *c;

    if ((c = (Candidate *)ldmalloc(sizeof(Candidate))) == NULL)
	return (NULL);
    c->applicant = DuplicateSylText(txt);
    c->phonetic = NULL;
    c->next = NULL;
    c->prev = NULL;
    return (c);
}

void
FreeCandidate(Candidate *top)
{
    Candidate *p, *next;

    for (p = top; p != NULL; p = next) {
	next = p->next;
	FreeSylText(p->applicant);
	if (p->phonetic != NULL) {
	    FreeSylText(p->phonetic);
	}
	ldfree(p);
    }
}

void
FreePhrase(Phrase *head)
{
    Phrase *p, *next;
    
    for (p = head; p != NULL; p = next) {
	next = p->next;
	FreeSylText(p->chosen);
	FreeSylText(p->applicant);
	FreeCandidate(p->head);
	ldfree(p);
    }
}

wchar_t *
CreateWCStringFromPhrase(Phrase *head)
{
    Phrase *p;
    SylText *txt;
    wchar_t *wcs;

    txt = CreateSylTextFromMBString("", False);
    for (p = head; p != NULL; p = p->next) {
	InsertSylTextIntoSylText0(txt, LengthOfSylText(txt), p->chosen);
    }
    wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);
    return (wcs);
}

SylText *
CreateSylTextFromPhrase(Phrase *head)
{
    Phrase *p;
    SylText *txt;

    txt = CreateSylTextFromMBString("", False);
    for (p = head; p != NULL; p = p->next) {
	InsertSylTextIntoSylText0(txt, LengthOfSylText(txt), p->chosen);
    }
    return (txt);
}

CARD32 *
CreateFeedbackFromPhrase(Phrase *head, Phrase *view)
{
    Phrase *p;
    CARD32 *feedback;
    int n, m, len;

    len = 0;
    for (p = head; p != NULL; p = p->next)
	len += LengthOfSylText(p->chosen);
    if ((feedback = (CARD32 *)malloc(sizeof(CARD32) * (len + 1))) == NULL)
	return (NULL);
    n = 0;
    for (p = head; p != NULL; p = p->next) {
	for (m = n + LengthOfSylText(p->chosen); n < m; ++n) {
	    feedback[n] = ((p == view) ? 1 : 0);
	}
    }    
    return (feedback);
}

int
CaretPositionOfPhrase(Phrase *head, Phrase *view)
{
    int len;
    Phrase *p;

    len = 0;
    for (p = head; p != view; p = p->next)
	len += LengthOfSylText(p->chosen);
#if 0
    len += LengthOfSylText(p->chosen);
#endif
    return (len);
}

int
LengthOfPhrase(Phrase *head)
{
    int len;
    Phrase *p;

    len = 0;
    for (p = head; p != NULL; p = p->next)
	len += LengthOfSylText(p->chosen);
    return (len);
}

int
BeginningOfPhrase(Phrase *head, Phrase *view)
{
    int len;
    Phrase *p;

    len = 0;
    for (p = head; p != view && p != NULL; p = p->next)
	len += LengthOfSylText(p->chosen);
    return (len);
}

static Phrase *
ChangeLengthOfPhrase(Phrase *view, SylText *txt)
{
    int length, offset, original;
    Phrase *prev, *next;

    length = view->length;
    offset = view->offset;
    original = view->original;
    prev = view->prev;
    FreePhrase(view);
    
    view = CreateSinglePhrase(txt, offset, offset + length);
    if (prev != NULL)
	prev->next = view;
    view->prev = prev;
    view->original = original;
    
    if ((offset += length) < LengthOfSylText(txt)) {
	next = CreatePhrase(txt, offset, LengthOfSylText(txt));
	view->next = next;
	next->prev = view;
    }
    else {
	view->next = NULL;
    }
    return (view);
}

Phrase *
ShortenPhrase(Phrase *view, SylText *txt)
{
    --(view->length);
    return (ChangeLengthOfPhrase(view, txt));
}

Phrase *
LengthenPhrase(Phrase *view, SylText *txt)
{
    ++(view->length);
    return (ChangeLengthOfPhrase(view, txt));
}

void
StudyPhrase(Phrase *head, SylText *txt)
{
    StudyPhraseWithEngine(head, txt);
}

Candidate *
HasCandidateOfPhrase(Phrase *p, SylText *t)
{
    Candidate *c;
    
    for (c = p->head; c != NULL && CompareSylText(c->applicant, t);
	 c = c->next)
	;
    return (c);
}

Candidate *
LookupCandidateOfPhrase(Phrase *p)
{
    return (HasCandidateOfPhrase(p, p->applicant));

}

void
AddCandidateToPhrase(Phrase *p, Candidate *c)
{
    if (p->head == NULL) {
	p->head = c;
	p->tail = c;
    }
    else {
	p->tail->next = c;
	c->prev = p->tail;
	p->tail = c;
    }
}
