/*
	$Id: overthespot.h,v 1.1 2001/01/23 14:31:21 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

extern ICPreeditDrawMethods *ICPreeditDrawOverTheSpot;
