/*
	$Id: imserver.c,v 1.19 2002/07/22 14:25:39 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xlocale.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <X11/keysym.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "ximattr.h"
#include "xicattr.h"
#include "leakdetect.h"
#include "engine.h"
#include "message.h"
#include "commit.h"
#include "undofix.h"
#include "preedit.h"
#include "convert.h"
#include "status.h"
#include "candidate.h"
#include "preconv.h"
#include "trigger.h"
#include "onthespot.h"
#include "ontheroot.h"
#include "overthespot.h"
#include "onthearea.h"
#include "predict.h"
#include "font.h"

#define THIS_CLASS "XIMServer"

#define DEFAULT_FONTSET "-*-*-medium-r-normal-*-14-*-*-*-*-*-*-*"
#define DEFAULT_TRIGGER_KEY "keysym Henkan_Mode modifier Mod1 mask Mod1"

static SylSetting
    PreconversionMode = {"preconversion", "Preconversion", "single", NULL},
    Mapping = {"preconversionMapping", "PreconversionMapping", "", NULL},
    TriggerOn = {"onTriggerKey", "TriggerKey", DEFAULT_TRIGGER_KEY, NULL},
    TriggerOff = {"offTriggerKey", "TriggerKey", DEFAULT_TRIGGER_KEY, NULL},
    FontSet0 = {"candidate.fontset", "Candidate.Fontset",
		DEFAULT_FONTSET, NULL},
    *FontSet[] = {&FontSet0, NULL};

#include "imserverUndofix.bind"
#include "imserverPreedit.bind"
#include "imserverConvert.bind"

static SylKeymap **UndofixKeymap;
static SylKeymap **PreeditKeymap;
static SylKeymap **ConvertKeymap;
static SylFontSet CandidateFontSet;
static Window Toplevel;
static XContext Context;
static XContext PreeditWindow;
static XContext StatusWindow;
static XContext CandidateWindow;
static Atom LOCALES;
static Atom TRANSPORT;
#define DEFAULT_LOCALES "@locale=ja"
#define DEFAULT_TRANSPORT "@transport=X/"
static Atom _XIM_XCONNECT;
static Atom _XIM_PROTOCOL;
static Atom _XIM_MOREDATA;

static XIMStyle xim_styles_0 = XIMPreeditCallbacks | XIMStatusArea;
static XIMStyle xim_styles_1 = XIMPreeditCallbacks | XIMStatusNothing;
static XIMStyle xim_styles_2 = XIMPreeditNothing | XIMStatusArea;
static XIMStyle xim_styles_3 = XIMPreeditNothing | XIMStatusNothing;
static XIMStyle xim_styles_4 = XIMPreeditPosition | XIMStatusArea;
static XIMStyle xim_styles_5 = XIMPreeditPosition | XIMStatusNothing;
static XIMStyle *xim_styles[] = {&xim_styles_0, &xim_styles_1, &xim_styles_2,
				 &xim_styles_3, &xim_styles_4, &xim_styles_5,
				 NULL};
static XIMSTYLES xim_styles_set = {{6, xim_styles}};

static unsigned int xim_filter_event = 0;

static XIMTRIGGERKEY on_key;
static XIMTRIGGERKEY off_key;

#ifdef DEBUG
#define __DEBUG_USED
#else
#define __DEBUG_USED __unused
#endif

#ifdef DUMP_DEBUG
static void
DumpData(unsigned char *data, int len)
{    
    int n;

    printf("\t" "read/write DATA:\n");
    for (n = 0; n < len; ++n)
	printf(" 0x%02x", data[n]);
    printf("\n");
}
#endif

static int
ErrorCB(Display *dpy __unused, XErrorEvent *ev)
{
    char buf[256];

    XGetErrorText(ev->display, ev->error_code, buf, sizeof(buf));
    fprintf(stderr, "XErrorEvent\n"
	    "\tserial: #%lu\n"
	    "\terror: %s\n"
	    "\top-code: %d.%d\n"
	    "\tresource-id: %lu\n",
	    ev->serial, buf, ev->request_code, ev->minor_code,
	    ev->resourceid);
    return (0);
}

static void
SendXIMConnectReply(Connection *con)
{
    XIM_CONNECT_REPLY xim_connect_reply;
    SerializedPacket *ack;
    int len;

    xim_connect_reply.major_version = 1;
    xim_connect_reply.minor_version = 0;
    Send_XIM_CONNECT_REPLY(&xim_connect_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_CONNECT_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
RespondXIMConnect(Connection *con, Message *req)
{
    XIM_CONNECT *xim_connect;

    xim_connect = Recv_XIM_CONNECT(req->data);
#ifdef DEBUG
    {
	int n;
	printf(
	    "\tXIM_CONNECT (%d bytes)\n"
	    "\t\tbyte order: %c\n"
	    "\t\tclient-major-protocol-version: %d\n"
	    "\t\tclient-minor-protocol-version: %d\n"
	    "\t\tnumber of client-auth-protocol-names: %d\n",
	    req->length * 4,
	    xim_connect->byte_order,
	    xim_connect->major_version,
	    xim_connect->minor_version,
	    xim_connect->auth.num);
	for (n = 0; n < xim_connect->auth.num; ++n) {
	    printf("\t\tclient-auth-protocol[%d]: %s\n",
		   n, xim_connect->auth.val[n]->val);
	}
    }
#endif
    SendXIMConnectReply(con);
    Free_XIM_CONNECT(xim_connect);
}

static void
RespondXIMDisconnect(Connection *con, Message *req __DEBUG_USED)
{
#ifdef DEBUG
    printf(
	"\tXIM_DISCONNECT (%d bytes)\n",
	req->length * 4);
#endif
    SendIntoWire(con, OPCODE_XIM_DISCONNECT_REPLY, NULL, 0);
}

static void
SendXIMOpenReply(Connection *con)
{
    XIM_OPEN_REPLY xim_open_reply;
    SerializedPacket *ack;
    int len;

    xim_open_reply.im_id = con->im_id; /* New Input-Method-ID */
    xim_open_reply.im_attr = im_attrs_set;
    xim_open_reply.ic_attr = ic_attrs_set;
    Send_XIM_OPEN_REPLY(&xim_open_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_OPEN_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
SendXIMRegisterTriggerkeys(Connection *con)
{
    XIM_REGISTER_TRIGGERKEYS xim_register_triggerkeys;
    SerializedPacket *req;
    int len;

    xim_register_triggerkeys.im_id = con->im_id;
    xim_register_triggerkeys.on_keys_length = sizeof(XIMTRIGGERKEY);
    xim_register_triggerkeys.on_keys = on_key;
    xim_register_triggerkeys.off_keys_length = sizeof(XIMTRIGGERKEY);
    xim_register_triggerkeys.off_keys = off_key;
    Send_XIM_REGISTER_TRIGGERKEYS(&xim_register_triggerkeys, &req, &len);
    SendIntoWire(con, OPCODE_XIM_REGISTER_TRIGGERKEYS, req, len);
    Free_SerializedPacket(req);
}

static void
SendXIMSetEventMask(Connection *con)
{
    XIM_SET_EVENT_MASK xim_set_event_mask;
    SerializedPacket *req;
    int len;

    xim_set_event_mask.im_id = con->im_id;
    xim_set_event_mask.ic_id = 0;
    xim_set_event_mask.forward_mask = 0;
    xim_set_event_mask.sync_mask = 0;
    Send_XIM_SET_EVENT_MASK(&xim_set_event_mask, &req, &len);
    SendIntoWire(con, OPCODE_XIM_SET_EVENT_MASK, req, len);
    Free_SerializedPacket(req);
}

static void
RespondXIMOpen(Connection *con, Message *req)
{
    XIM_OPEN *xim_open;

    xim_open = Recv_XIM_OPEN(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_OPEN (%d bytes)\n"
	"\t\tlocale_name: %s\n",
	req->length * 4,
	xim_open->locale.val);
#endif
    SendXIMOpenReply(con);
    SendXIMRegisterTriggerkeys(con);
    SendXIMSetEventMask(con);
    Free_XIM_OPEN(xim_open);
}

static void
SendXIMCloseReply(Connection *con)
{
    XIM_CLOSE_REPLY xim_close_reply;
    SerializedPacket *ack;
    int len;

    xim_close_reply.im_id = con->im_id;
    Send_XIM_CLOSE_REPLY(&xim_close_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_CLOSE_REPLY, ack, len);    
    Free_SerializedPacket(ack);
}

static void
RespondXIMClose(Connection *con, Message *req)
{
    XIM_CLOSE *xim_close;
    
    xim_close = Recv_XIM_CLOSE(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_CLOSE (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n",
	req->length * 4,
	xim_close->im_id);
#endif
    /* xim_close->im_id == con->im_id �Υ����å��Ͼ�ά�� */
    SendXIMCloseReply(con);
    Free_XIM_CLOSE(xim_close);
}

static void
SendXIMQueryExtensionReply(Connection *con, XIM_QUERY_EXTENSION *req)
{
    XIM_QUERY_EXTENSION_REPLY *xim_query_extension_reply;
    SerializedPacket *ack;
    int len;
    LIST *p, *top = NULL;

    for (p = req->extension; p != NULL; p = p->next) {
	STR *d = (STR *)p->data;
	if (strcmp(d->val, "XIM_EXT_SET_EVENT_MASK") == 0) {
	    LIST *cur = (LIST *)ldmalloc(sizeof(LIST));
	    EXT *ext = (EXT *)ldmalloc(sizeof(EXT));
	    ext->major_opcode = 0x81;
	    ext->minor_opcode = 0x00;
	    ext->name.len = d->len;
	    ext->name.val = (CARD8 *)ldmalloc(ext->name.len);
	    memcpy(ext->name.val, d->val, d->len);
	    cur->data = ext;
	    cur->next = top;
	    top = cur;
	}
    }
    xim_query_extension_reply = ldmalloc(sizeof(XIM_QUERY_EXTENSION_REPLY));
    xim_query_extension_reply->im_id = req->im_id;
    xim_query_extension_reply->extension = top;
    Send_XIM_QUERY_EXTENSION_REPLY(xim_query_extension_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_QUERY_EXTENSION_REPLY, ack, len);
    Free_SerializedPacket(ack);
    Free_XIM_QUERY_EXTENSION_REPLY(xim_query_extension_reply);
}

static void
RespondXIMQueryExtension(Connection *con, Message *req)
{
    XIM_QUERY_EXTENSION *xim_query_extension;
    
    xim_query_extension = Recv_XIM_QUERY_EXTENSION(req->data);
#ifdef DEBUG
    {
	LIST *p;
	printf(
	    "\tXIM_QUERY_EXTENSION (%d bytes)\n"
	    "\t\tinput_method_id: 0x%x\n",
	    req->length * 4,
	    xim_query_extension->im_id);
	for (p = xim_query_extension->extension; p != NULL; p = p->next) {
	    STR *d = (STR *)p->data;
	    printf("\t\textensions supported by IM library: %s(%d)\n",
		   d->val, d->len);
	}
    }
#endif	    
    SendXIMQueryExtensionReply(con, xim_query_extension);
    Free_XIM_QUERY_EXTENSION(xim_query_extension);
}

static void
SendXIMEncodingNegotiationReply(Connection *con, XIM_ENCODING_NEGOTIATION *req)
{
    XIM_ENCODING_NEGOTIATION_REPLY xim_encoding_negotiation_reply;
    SerializedPacket *ack;
    int len, index, category;
    LIST *p;

    category = 0;
    index = 0;
    for (p = req->encoding; p != NULL; p = p->next) {
	STRING *d = (STRING *)p->data;
	if (strcmp(d->val, "COMPOUND_TEXT") == 0)
	    break;
	++index;
    }
#if 0 /* detailed data�ˤϲ����񤤤Ƥ���Τ��狼��ޤ��� */
    if (p == NULL) {
	category = 1;
	index = 0;
	for (p = req->detail; p != NULL; p = p->next) {
	    STRING *d = (STRING *)p->data;
	    if (strcmp(d->val, "COMPOUND_TEXT") == 0)
		break;
	    ++index;
	}
    }
#endif
    if (p == NULL)
	index = -1;
    xim_encoding_negotiation_reply.im_id = req->im_id;
    xim_encoding_negotiation_reply.category = category;
    xim_encoding_negotiation_reply.index = index;
    Send_XIM_ENCODING_NEGOTIATION_REPLY(&xim_encoding_negotiation_reply,
					&ack, &len);
    SendIntoWire(con, OPCODE_XIM_ENCODING_NEGOTIATION_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
RespondXIMEncodingNegotiation(Connection *con, Message *req)
{
    XIM_ENCODING_NEGOTIATION *xim_encoding_negotiation;
    
    xim_encoding_negotiation = Recv_XIM_ENCODING_NEGOTIATION(req->data);
#ifdef DEBUG 
    {
	LIST *p;
	printf(
	    "\tXIM_ENCODING_NEGOTIATION (%d bytes)\n"
	    "\t\tinput_method_id: 0x%x\n",
	    req->length * 4,
	    xim_encoding_negotiation->im_id);
	for (p = xim_encoding_negotiation->encoding; p != NULL; p = p->next) {
	    STR *d = (STR *)p->data;
	    printf("\t\tencoding supported by IM library: %s(%d)\n",
		   d->val, d->len);
	}
	for (p = xim_encoding_negotiation->detail; p != NULL; p = p->next) {
	    STRING *d = (STRING *)p->data;
	    printf("\t\tdetail supported by IM library: %s(%d)\n",
	       d->val, d->len);
	}
    }
#endif	    
    SendXIMEncodingNegotiationReply(con, xim_encoding_negotiation);
    Free_XIM_ENCODING_NEGOTIATION(xim_encoding_negotiation);
}

static void
SendXIMGetIMValuesReply(Connection *con, XIM_GET_IM_VALUES *req)
{
    XIM_GET_IM_VALUES_REPLY *xim_get_im_values_reply;
    SerializedPacket *ack;
    int n, len;
    LIST *top = NULL;

    for (n = 0; n < req->im_attribute_id.num; ++n) {
	CARD16 id = req->im_attribute_id.val[n];
	if (id == 0) /* XXX */ {
	    XIMATTRIBUTE *attr;
	    LIST *cur = (LIST *)ldmalloc(sizeof(LIST));
	    attr = (XIMATTRIBUTE *)ldmalloc(sizeof(XIMATTRIBUTE));
	    attr->id = id;
#if 0
	    attr->data.len = Sizeof_XIMSTYLES(&xim_styles_set);
	    attr->data.val = (CARD8 *)ldmalloc(attr->data.len);
	    Write_XIMSTYLES(&xim_styles_set, attr->data.val);
#else
	    Send_XIMSTYLES(&xim_styles_set, &ack, &len);
	    attr->data.val = ack;
	    attr->data.len = len;
#endif
	    cur->data = attr;
	    cur->next = top;
	    top = cur;
	}
    }
    xim_get_im_values_reply = ldmalloc(sizeof(XIM_GET_IM_VALUES_REPLY));
    xim_get_im_values_reply->im_id = req->im_id;
    xim_get_im_values_reply->im_attribute = top;
    Send_XIM_GET_IM_VALUES_REPLY(xim_get_im_values_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_GET_IM_VALUES_REPLY, ack, len);
    Free_SerializedPacket(ack);
    Free_XIM_GET_IM_VALUES_REPLY(xim_get_im_values_reply);
}

static void
RespondXIMGetIMValues(Connection *con, Message *req)
{
    XIM_GET_IM_VALUES *xim_get_im_values;
	
    xim_get_im_values = Recv_XIM_GET_IM_VALUES(req->data);
#ifdef DEBUG
    {
	int n;
	printf(
	    "\tXIM_GET_IM_VALUES (%d bytes)\n"
	    "\t\tinput_method_id: 0x%x\n",
	    req->length * 4,
	    xim_get_im_values->im_id);
	for (n = 0; n < xim_get_im_values->im_attribute_id.num; ++n) {
	    CARD16 d = xim_get_im_values->im_attribute_id.val[n];
	    printf("\t\tim_attribute_id: %d\n", d);
	}
    }
#endif	    
    SendXIMGetIMValuesReply(con, xim_get_im_values);
    Free_XIM_GET_IM_VALUES(xim_get_im_values);
}

static Pixmap
CreateBehindPixmap(Display *disp, Window w)
{
    XWindowAttributes attr;

    XGetWindowAttributes(disp, w, &attr);
    return (XCreatePixmap(disp, w, attr.width, attr.height, attr.depth));
}

static void
SetICPreeditAttributes(Connection *con, InputContext *ic, XICATTRIBUTE *d)
{
    STRING *fs;
    void UpdateSpotLocation(Connection *, InputContext *);
    void UpdateFontset(Connection *, InputContext *);

    switch (d->id) {
    case 14: /* fontSet */
	fs = Recv_STRING(d->data.val);
	if (ic->preedit_fontset_name != NULL) {
	    if (strcmp(fs->val, ic->preedit_fontset_name) == 0) {
		Free_STRING(fs);
		break;
	    }
	    free(ic->preedit_fontset_name);
	}
	ic->preedit_fontset_name = strdup(fs->val);
	if (ic->preedit_fontset.id != NULL)
	    FreeSharedFontset(con->disp, &ic->preedit_fontset);
	CreateSharedFontset(con->disp, fs->val, &ic->preedit_fontset);
	UpdateFontset(con, ic);
	Free_STRING(fs);
	break;
    case 11: /* foreground */
	ic->preedit_foreground = ((CARD32 *)d->data.val)[0];
	break;
    case 12: /* background */
	ic->preedit_background = ((CARD32 *)d->data.val)[0];
	break;
    case 8: /* spotLocation */
	if (ic->input_style & XIMPreeditPosition) {
	    ic->preedit_spot_location.x = ((CARD16 *)d->data.val)[0];
	    ic->preedit_spot_location.y = ((CARD16 *)d->data.val)[1];
	    UpdateSpotLocation(con, ic);
	}
	break;
    }
}

static void
SetICStatusAttributes(Connection *con, InputContext *ic, XICATTRIBUTE *d)
{
    int width, height;
    STRING *fs;

    switch (d->id) {
    case 14: /* fontSet */
	fs = Recv_STRING(d->data.val);
	if (ic->status_fontset_name != NULL) {
	    if (strcmp(fs->val, ic->status_fontset_name) == 0) {
		Free_STRING(fs);
		break;
	    }
	    free(ic->status_fontset_name);
	}
	ic->status_fontset_name = strdup(fs->val);
	if (ic->status_fontset.id != NULL)
	    FreeSharedFontset(con->disp, &ic->status_fontset);
	CreateSharedFontset(con->disp, fs->val, &ic->status_fontset);	
	Free_STRING(fs);
	break;
    case 11: /* foreground */
	ic->status_foreground = ((CARD32 *)d->data.val)[0];
	break;
    case 12: /* background */
	ic->status_background = ((CARD32 *)d->data.val)[0];
	break;
    case 6: /* area */
	width = ((CARD16 *)d->data.val)[2];
	height = ((CARD16 *)d->data.val)[3];
	if (width <= 0 || height <= 0)
	    break;
	ic->status_area.x = ((CARD16 *)d->data.val)[0];
	ic->status_area.y = ((CARD16 *)d->data.val)[1];
	ic->status_area.width = width;
	ic->status_area.height = height;
	if (ic->status_window == None)
	    break;
	XMoveResizeWindow(con->disp, ic->status_window, 
			  ic->status_area.x, ic->status_area.y, width, height);
	XFreePixmap(con->disp, ic->status_pixmap);
	ic->status_pixmap = CreateBehindPixmap(con->disp, ic->status_window);
	CommitStatus(con, ic);
	break;
    }
}

static void
SetICAttribute(Connection *con, InputContext *ic, XICATTRIBUTE *d)
{
    int k, s;
    XICATTRIBUTE *n;

    switch (d->id) {
    case 0: /* inputStyle */
	ic->input_style = ((CARD32 *)d->data.val)[0];
	if (ic->input_style & XIMPreeditCallbacks)
	    ic->preedit_draw = ICPreeditDrawOnTheSpot;
	else if (ic->input_style & XIMPreeditNothing)
	    ic->preedit_draw = ICPreeditDrawOnTheRoot;
	else if (ic->input_style & XIMPreeditPosition)
	    ic->preedit_draw = ICPreeditDrawOverTheSpot;
	if (ic->input_style & XIMStatusArea)
	    ic->status_draw = ICStatusDrawOnTheArea;
	else if (ic->input_style & XIMStatusNothing)
	    ic->status_draw = ICStatusDrawOnTheRoot;
	break;
    case 1: /* clientWindow */
	ic->client_window = ((CARD32 *)d->data.val)[0];
	break;
    case 2: /* focusWindow */
	ic->focus_window = ((CARD32 *)d->data.val)[0];
	break;
    case 4: /* preeditAttributes */
	for (k = 0; k < d->data.len; k += s) {
	    n = Recv_XICATTRIBUTE(d->data.val + k);
	    s = Sizeof_XICATTRIBUTE(n);
	    SetICPreeditAttributes(con, ic, n);
	    Free_XICATTRIBUTE(n);
	}
	break;
    case 5: /* statusAttributes */
	for (k = 0; k < d->data.len; k += s) {
	    n = Recv_XICATTRIBUTE(d->data.val + k);
	    s = Sizeof_XICATTRIBUTE(n);
	    SetICStatusAttributes(con, ic, n);
	    Free_XICATTRIBUTE(n);
	}
	break;
    }
}

static void
CheckAndSetupCandidateWindow(Connection *con, InputContext *ic)
{
    Window parent;

    if (ic->candidate_window != None || ic->client_window == None)
	return;
    parent = (ic->input_style & (XIMPreeditNothing | XIMPreeditPosition))
	? DefaultRootWindow(con->disp) : ic->client_window;
    ic->candidate_window = CreateCandidateWindow(con->disp, parent);
    XSaveContext(con->disp, ic->candidate_window, CandidateWindow,
		 (XPointer)ic);
    ic->candidate_fontset = &CandidateFontSet; /* ���Ȥ����������ɬ�פʤ� */
#if 0
    if (ic->preedit_fontset.id != NULL)
	ic->candidate_fontset = &ic->preedit_fontset;
    else if (ic->status_fontset.id != NULL)
	ic->candidate_fontset = &ic->status_fontset;
#endif
}

static void
CheckAndSetupStatusWindow(Connection *con, InputContext *ic)
{
    if ((ic->input_style & XIMStatusArea) != 0
	&& ic->status_window == None && ic->client_window != None
	&& ic->status_area.width > 0 && ic->status_area.height > 0) {
	ic->status_window = XCreateSimpleWindow(con->disp, ic->client_window,
	    ic->status_area.x, ic->status_area.y,
	    ic->status_area.width, ic->status_area.height,
	    0, ic->status_foreground, ic->status_background);
	XSelectInput(con->disp, ic->status_window, StructureNotifyMask);
	XSaveContext(con->disp, ic->status_window, StatusWindow, (XPointer)ic);
	ic->status_pixmap = CreateBehindPixmap(con->disp, ic->status_window);
	ic->status_gc = XCreateGC(con->disp, ic->status_window, 0, 0);
	CommitStatus(con, ic);
    }
}

static void
CheckAndSetupPreeditWindow(Connection *con, InputContext *ic)
{ 
    void UpdateSpotLocation(Connection *, InputContext *);
    void UpdateFontset(Connection *, InputContext *);

    if ((ic->input_style & XIMPreeditPosition) != 0
	&& ic->preedit_window == None && ic->client_window != None) {
	ic->preedit_window = XCreateSimpleWindow(con->disp, ic->client_window,
	    0, 0, 1, 1, 0, 0, 0);
	XSelectInput(con->disp, ic->preedit_window, StructureNotifyMask);
	XSaveContext(con->disp, ic->preedit_window, PreeditWindow,
		     (XPointer)ic);
	UpdateSpotLocation(con, ic);
	UpdateFontset(con, ic);
    }
}

static void
SendXIMCreateICReply(Connection *con, XIM_CREATE_IC *req)
{
    XIM_CREATE_IC_REPLY xim_create_ic_reply;
    SerializedPacket *ack;
    int len;
    InputContext *ic;
    LIST *p;

    if ((ic = CreateInputContext(con)) == NULL) {
	fprintf(stderr, "Warning: cannot create new IC.\n");
	return;
    }
    if (strcasecmp(PreconversionMode.spec, "single") == 0)
	ic->preconversion = PRECONVERSION_SINGLE;
    else if (strcasecmp(PreconversionMode.spec, "double") == 0)
	ic->preconversion = PRECONVERSION_DOUBLE;
    for (p = req->ic_attribute; p != NULL; p = p->next) {
	SetICAttribute(con, ic, (XICATTRIBUTE *)p->data);
    }
    if (ic->preedit_draw == NULL) {
	fprintf(stderr, "Warning: invalid XIM style specified for preedit.");
	ic->preedit_draw = ICPreeditDrawOnTheRoot;
    }
    if (ic->status_draw == NULL) {
	fprintf(stderr, "Warning: invalid XIM style specified for status.");
	ic->status_draw = ICStatusDrawOnTheRoot;
    }
    CheckAndSetupCandidateWindow(con, ic);
    CheckAndSetupStatusWindow(con, ic);
    CheckAndSetupPreeditWindow(con, ic);
    xim_create_ic_reply.im_id = con->im_id;
    xim_create_ic_reply.ic_id = ic->ic_id;
    Send_XIM_CREATE_IC_REPLY(&xim_create_ic_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_CREATE_IC_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

#ifdef DEBUG
typedef struct {
    int type;
    char *name;
} Attributes;

static Attributes ic_input_style = {3, XNInputStyle};
static Attributes ic_client_window = {5, XNClientWindow};
static Attributes ic_focus_window = {5, XNFocusWindow};
static Attributes ic_filter_events = {3, XNFilterEvents};
static Attributes ic_preedit_attributes = {0x7fff, XNPreeditAttributes};
static Attributes ic_status_attributes = {0x7fff, XNStatusAttributes};
static Attributes ic_area = {11, XNArea};
static Attributes ic_area_needed = {11, XNAreaNeeded};
static Attributes ic_spot_location = {12, XNSpotLocation};
static Attributes ic_colormap = {3, XNColormap};
static Attributes ic_std_colormap = {3, XNStdColormap};
static Attributes ic_foreground = {3, XNForeground};
static Attributes ic_background = {3, XNBackground};
static Attributes ic_background_pixmap = {3, XNBackgroundPixmap};
static Attributes ic_font_set = {13, XNFontSet};
static Attributes ic_line_space = {2, XNLineSpace};
static Attributes ic_cursor = {3, XNCursor};
static Attributes ic_separator_of_nested_list = {0, XNSeparatorofNestedList};
static Attributes *ic_attrs[] = {
    &ic_input_style, &ic_client_window, &ic_focus_window, &ic_filter_events,
    &ic_preedit_attributes, &ic_status_attributes, &ic_area, &ic_area_needed,
    &ic_spot_location, &ic_colormap, &ic_std_colormap, &ic_foreground,
    &ic_background, &ic_background_pixmap, &ic_font_set, &ic_line_space,
    &ic_cursor, &ic_separator_of_nested_list, NULL};

static void
PrintAttributes(XICATTRIBUTE *d)
{
    printf("\t\tic_attribute: %s (length = %d)\n", 
	   ic_attrs[d->id]->name, d->data.len);
    if (ic_attrs[d->id]->type == 13) {
	STRING *fs = Recv_STRING(d->data.val);
	printf("\t\tfontset: %s(%d)\n", fs->val, fs->len);
	Free_STRING(fs);
    }
    else if (ic_attrs[d->id]->type == 3) {
	int num = ((CARD32 *)d->data.val)[0];
	printf("\t\tlong data: 0x%x\n", num);
    }
    else if (ic_attrs[d->id]->type == 5) {
	int num = ((CARD32 *)d->data.val)[0];
	printf("\t\tWindow: 0x%x\n", num);
    }
    else if (ic_attrs[d->id]->type == 12) {
	int x = ((CARD16 *)d->data.val)[0];
	int y = ((CARD16 *)d->data.val)[1];
	printf("\t\tXPoint: (%d %d)\n", x, y);
    }
    else if (ic_attrs[d->id]->type == 11) {
	int x = ((CARD16 *)d->data.val)[0];
	int y = ((CARD16 *)d->data.val)[1];
	int w = ((CARD16 *)d->data.val)[2];
	int h = ((CARD16 *)d->data.val)[3];
	printf("\t\tXRectangle: (%d %d %d %d)\n",
	       x, y, w, h);
    }
    else if (ic_attrs[d->id]->type == 0x7fff) {
	int k = 0;
	printf("\t\tNestedList: {\n");
	while (k < d->data.len) {
	    XICATTRIBUTE *n = Recv_XICATTRIBUTE(d->data.val + k);
	    PrintAttributes(n);
	    k += Sizeof_XICATTRIBUTE(n);
	    Free_XICATTRIBUTE(n);
	}
	printf("\t\t}\n");
    }
}
#endif

static void
RespondXIMCreateIC(Connection *con, Message *req)
{
    XIM_CREATE_IC *xim_create_ic;

    xim_create_ic = Recv_XIM_CREATE_IC(req->data);
#ifdef DEBUG
    {
	LIST *p;
	printf(
	    "\tXIM_CREATE_IC (%d bytes)\n"
	    "\t\tinput_method_id: 0x%x\n",
	    req->length * 4,
	    xim_create_ic->im_id);

	for (p = xim_create_ic->ic_attribute; p != NULL; p = p->next) {
	    XICATTRIBUTE *d = (XICATTRIBUTE *)p->data;
	    PrintAttributes(d);
	}
    }
#endif
    SendXIMCreateICReply(con, xim_create_ic);
    Free_XIM_CREATE_IC(xim_create_ic);
}

static void
SendXIMDestroyICReply(Connection *con, XIM_DESTROY_IC *req)
{
    XIM_DESTROY_IC_REPLY xim_destroy_ic_reply;
    SerializedPacket *ack;
    int len;

    FreeInputContext(con, req->ic_id);
    xim_destroy_ic_reply.im_id = req->im_id;
    xim_destroy_ic_reply.ic_id = req->ic_id;
    Send_XIM_DESTROY_IC_REPLY(&xim_destroy_ic_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_DESTROY_IC_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
RespondXIMDestroyIC(Connection *con, Message *req)
{
    XIM_DESTROY_IC *xim_destroy_ic;

    xim_destroy_ic = Recv_XIM_DESTROY_IC(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_DESTROY_IC (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n",
	req->length * 4,
	xim_destroy_ic->im_id,
	xim_destroy_ic->ic_id);
#endif
    SendXIMDestroyICReply(con, xim_destroy_ic);
    Free_XIM_DESTROY_IC(xim_destroy_ic);
}

static void
SendXIMGetICValues(Connection *con, XIM_GET_IC_VALUES *req)
{
    XIM_GET_IC_VALUES_REPLY *xim_get_ic_values_reply;
    SerializedPacket *ack;
    int n, len;
    LIST *top = NULL;
    InputContext *ic;

    if ((ic = SerachInputContext(con, req->ic_id)) == NULL)
	return;
    for (n = 0; n < req->ic_attribute_id.num; ++n) {
	CARD16 id = req->ic_attribute_id.val[n];
	if (id == 3) { /* XNFilterEvent */
	    XICATTRIBUTE *attr;
	    LIST *cur = (LIST *)ldmalloc(sizeof(LIST));
	    attr = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE));
	    attr->id = id;
	    attr->data.len = sizeof(CARD32);
	    attr->data.val = (CARD8 *)ldmalloc(sizeof(CARD32));
	    memcpy(attr->data.val, &xim_filter_event, sizeof(CARD32));
	    cur->data = attr;
	    cur->next = top;
	    top = cur;
	}
	else if (id == 5) { /* StatusAttributes */
	    LIST *nested_top = NULL;
	    for (++n; (id = req->ic_attribute_id.val[n]) != 17; ++n) {
		if (id == 7) { /* AreaNeeded */
		    XICATTRIBUTE *nested;
		    LIST *nested_cur = (LIST *)ldmalloc(sizeof(LIST));
		    XRectangle area = {0, 0, 0, 0};
		    if (ic->status_fontset.id != NULL) {
			area.width = ic->status_fontset.width * 8; /* XXX */
			area.height = ic->status_fontset.height;
		    }
		    nested = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE));
		    nested->id = id;
		    nested->data.len = sizeof(XRectangle);
		    nested->data.val = (CARD8 *)ldmalloc(sizeof(XRectangle));
		    memcpy(nested->data.val, &area, sizeof(XRectangle));
		    nested_cur->data = nested;
		    nested_cur->next = nested_top;
		    nested_top = nested_cur;
		}
		else if (id == 6) { /* Area */
		    XICATTRIBUTE *nested;
		    LIST *nested_cur = (LIST *)ldmalloc(sizeof(LIST));
		    nested = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE));
		    nested->id = id;
		    nested->data.len = sizeof(XRectangle);
		    nested->data.val = (CARD8 *)ldmalloc(sizeof(XRectangle));
		    memcpy(nested->data.val, &ic->status_area,
			   sizeof(XRectangle));
		    nested_cur->data = nested;
		    nested_cur->next = nested_top;
		    nested_top = nested_cur;
		}
	    }
	    if (nested_top != NULL) {
		XICATTRIBUTE *attr;
		LIST *cur = (LIST *)ldmalloc(sizeof(LIST));
		XIM_GET_IC_VALUES_REPLY *tmp;
		tmp = ldmalloc(sizeof(XIM_GET_IC_VALUES_REPLY));
		tmp->im_id = req->im_id;
		tmp->ic_id = req->ic_id;
		tmp->ic_attribute = nested_top;
		Send_XIM_GET_IC_VALUES_REPLY(tmp, &ack, &len);
		len -= 4;
		attr = (XICATTRIBUTE *)ldmalloc(sizeof(XICATTRIBUTE));
		attr->id = 5;
		attr->data.len = len;
		attr->data.val = (CARD8 *)ldmalloc(len);
		memcpy(attr->data.val, ack + 4, len);
		cur->data = attr;
		cur->next = top;
		top = cur;
		Free_SerializedPacket(ack);
		Free_XIM_GET_IC_VALUES_REPLY(tmp);
	    }
	}
    }
    xim_get_ic_values_reply = ldmalloc(sizeof(XIM_GET_IC_VALUES_REPLY));
    xim_get_ic_values_reply->im_id = req->im_id;
    xim_get_ic_values_reply->ic_id = req->ic_id;
    xim_get_ic_values_reply->ic_attribute = top;
    Send_XIM_GET_IC_VALUES_REPLY(xim_get_ic_values_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_GET_IC_VALUES_REPLY, ack, len);
    Free_SerializedPacket(ack);
    Free_XIM_GET_IC_VALUES_REPLY(xim_get_ic_values_reply);
}

static void
RespondXIMGetICValues(Connection *con, Message *req)
{
    XIM_GET_IC_VALUES *xim_get_ic_values;

    xim_get_ic_values = Recv_XIM_GET_IC_VALUES(req->data);
#ifdef DEBUG
    {
	int n;
	printf(
	    "\tXIM_GET_IC_VALUES (%d bytes)\n"
	    "\t\tinput_method_id: 0x%x\n"
	    "\t\tinput_context_id: 0x%x\n",
	    req->length * 4,
	    xim_get_ic_values->im_id,
	    xim_get_ic_values->ic_id);
	for (n = 0; n < xim_get_ic_values->ic_attribute_id.num; ++n) {
	    CARD16 id = xim_get_ic_values->ic_attribute_id.val[n];
	    printf("\t\tic_attribute_id: %d\n", id);
	}
    }
#endif	    
    SendXIMGetICValues(con, xim_get_ic_values);
    Free_XIM_GET_IC_VALUES(xim_get_ic_values);
}

static void
SendXIMSetICValues(Connection *con, XIM_SET_IC_VALUES *req)
{
    XIM_SET_IC_VALUES_REPLY xim_set_ic_values_reply;
    SerializedPacket *ack;
    int len;
    InputContext *ic;
    LIST *p;

    if ((ic = SerachInputContext(con, req->ic_id)) == NULL)
	return;
    for (p = req->ic_attribute; p != NULL; p = p->next) {
	SetICAttribute(con, ic, (XICATTRIBUTE *)p->data);
    }
    CheckAndSetupCandidateWindow(con, ic);
    CheckAndSetupStatusWindow(con, ic);
    CheckAndSetupPreeditWindow(con, ic);
    xim_set_ic_values_reply.im_id = req->im_id;
    xim_set_ic_values_reply.ic_id = req->ic_id;
    Send_XIM_SET_IC_VALUES_REPLY(&xim_set_ic_values_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_SET_IC_VALUES_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
RespondXIMSetICValues(Connection *con, Message *req)
{
    XIM_SET_IC_VALUES *xim_set_ic_values;
    
    xim_set_ic_values = Recv_XIM_SET_IC_VALUES(req->data);
#ifdef DEBUG
    {
	LIST *p;
	printf(
	    "\tXIM_SET_IC_VALUES (%d bytes)\n"
	    "\t\tinput_method_id: 0x%x\n"
	    "\t\tinput_context_id: 0x%x\n",
	    req->length * 4,
	    xim_set_ic_values->im_id,
	    xim_set_ic_values->ic_id);
	for (p = xim_set_ic_values->ic_attribute; p != NULL; p = p->next) {
	    XICATTRIBUTE *d = (XICATTRIBUTE *)p->data;
	    PrintAttributes(d);
	}
    }
#endif
    SendXIMSetICValues(con, xim_set_ic_values);
    Free_XIM_SET_IC_VALUES(xim_set_ic_values);
}

static void
FocusInCB(InputContext *ic, void *data)
{
    Connection *con = (Connection *)data;
    int (*existing)(Display *, XErrorEvent *);

    existing = XSetErrorHandler(ErrorCB);
    ic->preedit_draw->focus_in(con, ic);
    ic->status_draw->focus_in(con, ic);
    FocusInPrediction(con, ic);
    XSync(con->disp, False);
    (void)XSetErrorHandler(existing);
}

static void
RespondXIMSetICFocus(Connection *con, Message *req)
{
    XIM_SET_IC_FOCUS *xim_set_ic_focus;
    InputContext *ic;

    xim_set_ic_focus = Recv_XIM_SET_IC_FOCUS(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_SET_IC_FOCUS (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n",
	req->length * 4,
	xim_set_ic_focus->im_id,
	xim_set_ic_focus->ic_id);
#endif
    if ((ic = SerachInputContext(con, xim_set_ic_focus->ic_id)) != NULL) {
	ic->focus = True;
	DeferInputContext(ic, FocusInCB, (void *)con);
    }
    Free_XIM_SET_IC_FOCUS(xim_set_ic_focus);
}

static void
FocusOutCB(InputContext *ic, void *data)
{
    Connection *con = (Connection *)data;
    int (*existing)(Display *, XErrorEvent *);

    existing = XSetErrorHandler(ErrorCB);
    ic->preedit_draw->focus_out(con, ic);
    ic->status_draw->focus_out(con, ic);
    FocusOutPrediction(con, ic);
    XSync(con->disp, False);
    (void)XSetErrorHandler(existing);
}

static void
RespondXIMUnsetICFocus(Connection *con, Message *req)
{
    XIM_UNSET_IC_FOCUS *xim_unset_ic_focus;
    InputContext *ic;
    
    xim_unset_ic_focus = Recv_XIM_UNSET_IC_FOCUS(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_UNSET_IC_FOCUS (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n",
	req->length * 4,
	xim_unset_ic_focus->im_id,
	xim_unset_ic_focus->ic_id);
#endif
    if ((ic = SerachInputContext(con, xim_unset_ic_focus->ic_id)) != NULL) {
	ic->focus = False;
	/*
	  1999-10-30: UNSET_IC_FOCUS����Ʊ���ꥯ�����ȤʤΤǡ����Ǥ�
	  ���饤����ȤϽ�λ���Ƥ����ǽ�������롣�������äơ������������
	  ���ƤϤʤ�ʤ���
	*/
	DeferInputContext(ic, FocusOutCB, (void *)con);
    }
    Free_XIM_UNSET_IC_FOCUS(xim_unset_ic_focus);
}

static void
SelectForKeyEvent(Connection *con, XIM_TRIGGER_NOTIFY *ev)
{
    XIM_SET_EVENT_MASK xim_set_event_mask;
    SerializedPacket *req;
    int len;

    xim_set_event_mask.im_id = ev->im_id;
    xim_set_event_mask.ic_id = ev->ic_id;
    xim_set_event_mask.forward_mask = KeyPressMask;
    xim_set_event_mask.sync_mask = KeyPressMask;
    Send_XIM_SET_EVENT_MASK(&xim_set_event_mask, &req, &len);
    SendIntoWire(con, OPCODE_XIM_SET_EVENT_MASK, req, len);
    Free_SerializedPacket(req);
}

static void
SendXIMPreeditStart(Connection *con, XIM_TRIGGER_NOTIFY *ev)
{
    XIM_PREEDIT_START xim_preedit_start;
    SerializedPacket *req;
    int len;

    xim_preedit_start.im_id = ev->im_id;
    xim_preedit_start.ic_id = ev->ic_id;
    Send_XIM_PREEDIT_START(&xim_preedit_start, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_START, req, len);
    Free_SerializedPacket(req);
}

static void
DeselectFromKeyEvent(Connection *con, XIM_TRIGGER_NOTIFY *ev)
{
    XIM_SET_EVENT_MASK xim_set_event_mask;
    SerializedPacket *req;
    int len;

    xim_set_event_mask.im_id = ev->im_id;
    xim_set_event_mask.ic_id = ev->ic_id;
    xim_set_event_mask.forward_mask = 0;
    xim_set_event_mask.sync_mask = 0;
    Send_XIM_SET_EVENT_MASK(&xim_set_event_mask, &req, &len);
    SendIntoWire(con, OPCODE_XIM_SET_EVENT_MASK, req, len);
    Free_SerializedPacket(req);
}

static void
SendXIMPreeditDone(Connection *con, XIM_TRIGGER_NOTIFY *ev)
{
    XIM_PREEDIT_DONE xim_preedit_done;
    SerializedPacket *req;
    int len;

    xim_preedit_done.im_id = ev->im_id;
    xim_preedit_done.ic_id = ev->ic_id;
    Send_XIM_PREEDIT_DONE(&xim_preedit_done, &req, &len);
    SendIntoWire(con, OPCODE_XIM_PREEDIT_DONE, req, len);
    Free_SerializedPacket(req);
}

static void
PreeditSwitching(Connection *con, XIM_TRIGGER_NOTIFY *req)
{
    InputContext *ic;

    if ((ic = SerachInputContext(con, req->ic_id)) == NULL)
	return;
    if (ic->forward == False) {
	ic->forward = True;
	SelectForKeyEvent(con, req);
	ic->preedit_draw->focus_in(con, ic);
	if (ic->input_style & XIMPreeditCallbacks) {
	    SendXIMPreeditStart(con, req);
	}
    }
    else {
	ic->forward = False;
	DeselectFromKeyEvent(con, req);
	ClearString(con, ic);
	CommitString(con, ic);
	if (ic->input_style & XIMPreeditCallbacks) {
	    SendXIMPreeditDone(con, req);
	}
    }
    CommitStatus(con, ic);
}

static void
SendXIMTriggerNotifyReply(Connection *con, XIM_TRIGGER_NOTIFY *req)
{
    XIM_TRIGGER_NOTIFY_REPLY xim_trigger_notify_reply;
    SerializedPacket *ack;
    int len;

    xim_trigger_notify_reply.im_id = req->im_id;
    xim_trigger_notify_reply.ic_id = req->ic_id;
    Send_XIM_TRIGGER_NOTIFY_REPLY(&xim_trigger_notify_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_TRIGGER_NOTIFY_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
RespondXIMTriggerNotify(Connection *con, Message *req)
{
    XIM_TRIGGER_NOTIFY *xim_trigger_notify;

    xim_trigger_notify = Recv_XIM_TRIGGER_NOTIFY(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_TRIGGER_NOTIFY (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n"
	"\t\tflag: 0x%lx\n"
	"\t\tindex: 0x%lx\n"
	"\t\tmask: 0x%lx\n",
	req->length * 4,
	xim_trigger_notify->im_id,
	xim_trigger_notify->ic_id,
	xim_trigger_notify->flag,
	xim_trigger_notify->index,
	xim_trigger_notify->mask);
#endif
    PreeditSwitching(con, xim_trigger_notify);
    SendXIMTriggerNotifyReply(con, xim_trigger_notify);
    Free_XIM_TRIGGER_NOTIFY(xim_trigger_notify);
}

static void
GetXKeyEvent(XKeyEvent *key, Connection *con, XIM_FORWARD_EVENT *ev)
{
    key->type = ev->event.u.u.type;
    key->serial = (ev->serial << 16) | ev->event.u.u.sequenceNumber;
    key->send_event = False;
    key->display = con->disp;
    key->window = ev->event.u.keyButtonPointer.event;
    key->root = ev->event.u.keyButtonPointer.root;
    key->subwindow = ev->event.u.keyButtonPointer.child;
    key->time = ev->event.u.keyButtonPointer.time;
    key->x = ev->event.u.keyButtonPointer.eventX;
    key->y = ev->event.u.keyButtonPointer.eventY;
    key->x_root = ev->event.u.keyButtonPointer.rootX;
    key->y_root = ev->event.u.keyButtonPointer.rootY;
    key->state = ev->event.u.keyButtonPointer.state;
    key->keycode = ev->event.u.u.detail;
    key->same_screen = ev->event.u.keyButtonPointer.sameScreen;
}

static int
RespondKeyPressEvent(Connection *con, XIM_FORWARD_EVENT *ev, XKeyEvent *key)
{
    SylKeymap *ptr, **keymap;
    InputContext *ic;
    void (**branch)(Connection *, InputContext *, XIM_FORWARD_EVENT *);

    if ((ic = SerachInputContext(con, ev->ic_id)) == NULL)
	return (False);
    if (key->state & Mod3Mask) {
	/* NEC PC-98xx: GRPH���� (Mod3Mask) ��Alt�����Ȥ��Ʋ�ᤵ���롣*/
	key->state &= ~Mod3Mask;
	key->state |= Mod1Mask;
    }
    key->state &= (ShiftMask | ControlMask | Mod1Mask);
    if (LengthOfSylText(ic->preedit) == 0) {
	keymap = UndofixKeymap;
	branch = UndofixBranch;
    }
    else if (ic->head == NULL) {
	keymap = PreeditKeymap;
	branch = PreeditBranch;
    }
    else {
	keymap = ConvertKeymap;
	branch = ConvertBranch; 
    }
    for (ptr = keymap[key->keycode]; ptr != NULL; ptr = ptr->next) {
	if (key->state == ptr->mod) {
	    (branch[ptr->func])(con, ic, ev);
	    return (True);
	}
    }
    return (False);
}

static void
RespondForwardedKeyPressEvent(Connection *con, XIM_FORWARD_EVENT *req)
{
    int XmuLookupKana(XKeyEvent *, char *, int, KeySym *, XComposeStatus *);
    unsigned char buf[64];
    KeySym ks;
    XKeyEvent key;
    int len;
    
    GetXKeyEvent(&key, con, req);
    len = XmuLookupKana(&key, buf, 64, &ks, NULL);
    if (RespondKeyPressEvent(con, req, &key) == False) {
	/*
	  2001-03-11: XEmacs�Υ᥿�������Ϥ��ñ�ˤ��뤿�ᡢALT������
	  ������Ƥ������Ϥ��Τޤޥե���ɤ���褦�ˤ�����
	*/
	if (len > 0 && isprint(*buf) /* isprint()�ϥ��������б� */
	    && (key.state & Mod1Mask) == 0) {
	    PreeditInsertChar(req, con, buf);
	}
	else {
	    EchoXIMForwardEvent(con, req);
	}
    }
}

static void
SendXIMSyncReply(Connection *con, XIM_FORWARD_EVENT *req)
{
    XIM_SYNC_REPLY xim_sync_reply;
    SerializedPacket *ack;
    int len;

    xim_sync_reply.im_id = req->im_id;
    xim_sync_reply.ic_id = req->ic_id;
    Send_XIM_SYNC_REPLY(&xim_sync_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_SYNC_REPLY, ack, len);
    Free_SerializedPacket(ack);
}

static void
RespondXIMForwardEvent(Connection *con, Message *req)
{
    int sync;
    XIM_FORWARD_EVENT *xim_forward_event;
    
    xim_forward_event = Recv_XIM_FORWARD_EVENT(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_FORWARD_EVENT (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n"
	"\t\tflag: 0x%x\n"
	"\t\tserial: %d\n"
	"\t\ttype: %d\n",
	req->length * 4,
	xim_forward_event->im_id,
	xim_forward_event->ic_id,
	xim_forward_event->flag,
	xim_forward_event->serial,
	xim_forward_event->event.u.u.type);
#endif
    sync = xim_forward_event->flag & 1;
    if (xim_forward_event->event.u.u.type == KeyPress)
	RespondForwardedKeyPressEvent(con, xim_forward_event);
    else
	EchoXIMForwardEvent(con, xim_forward_event);
    if (sync)
	SendXIMSyncReply(con, xim_forward_event);
    Free_XIM_FORWARD_EVENT(xim_forward_event);
}

static void
RespondXIMSyncReply(Connection *con __unused, Message *req)
{
    XIM_SYNC_REPLY *xim_sync_reply;
    
    xim_sync_reply = Recv_XIM_SYNC_REPLY(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_SYNC_REPLY (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n",
	req->length * 4,
	xim_sync_reply->im_id,
	xim_sync_reply->ic_id);
#endif
    Free_XIM_SYNC_REPLY(xim_sync_reply);
}

#if 0
static void
SendXIMSync(Connection *con, InputContext *ic)
{
    XIM_SYNC xim_sync;
    SerializedPacket *req;
    int len;

    xim_sync.im_id = con->im_id;
    xim_sync.ic_id = ic->ic_id;
    Send_XIM_SYNC(&xim_sync, &req, &len);
    SendIntoWire(con, OPCODE_XIM_SYNC, req, len);
    Free_SerializedPacket(req);
}
#endif

static void
SendXIMResetICReply(Connection *con, XIM_RESET_IC *req)
{
    XIM_RESET_IC_REPLY xim_reset_ic_reply;
    SerializedPacket *ack;
    int len;
    XTextProperty t;
    wchar_t *wcs;
    InputContext *ic;

    if ((ic = SerachInputContext(con, req->ic_id)) == NULL)
	return;
    wcs = CreateWCStringFromSylText0(ic->preedit);
    XwcTextListToTextProperty(con->disp, &wcs, 1, XCompoundTextStyle, &t);
    xim_reset_ic_reply.im_id = con->im_id;
    xim_reset_ic_reply.ic_id = ic->ic_id;
    xim_reset_ic_reply.preedit.len = t.nitems;
    xim_reset_ic_reply.preedit.val = t.value;
    Send_XIM_RESET_IC_REPLY(&xim_reset_ic_reply, &ack, &len);
    SendIntoWire(con, OPCODE_XIM_RESET_IC_REPLY, ack, len);
    Free_SerializedPacket(ack);
    free(t.value); /* XwcTextListToTextProperty() */
    free(wcs); /* CreateWCStringFromSylText0() */

    ClearString(con, ic);
    if (ic->head != NULL) {
	if (ic->candidate_window != None)
	    XUnmapWindow(con->disp, ic->candidate_window);
	FreePhrase(ic->head);
	ic->head = NULL;
	ic->view = NULL;
    }
    DeleteStringOfSylText(ic->preedit, 0, LengthOfSylText(ic->preedit));
    ic->caret = 0;
    CommitStatus(con, ic);
}

static void
RespondXIMResetIC(Connection *con, Message *req)
{
    XIM_RESET_IC *xim_reset_ic;
    
    xim_reset_ic = Recv_XIM_RESET_IC(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_RESET_IC (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n",
	req->length * 4,
	xim_reset_ic->im_id,
	xim_reset_ic->ic_id);
#endif
    SendXIMResetICReply(con, xim_reset_ic);
    Free_XIM_RESET_IC(xim_reset_ic);
}

static void
SetMaxPreeditChars(Connection *con, XIM_PREEDIT_START_REPLY *req)
{
    InputContext *ic;

    if ((ic = SerachInputContext(con, req->ic_id)) != NULL)
	ic->max_preedit_chars = req->value;
}

static void
RespondXIMPreeditStartReply(Connection *con, Message *req)
{
    XIM_PREEDIT_START_REPLY *xim_preedit_start_reply;

    xim_preedit_start_reply = Recv_XIM_PREEDIT_START_REPLY(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_PREEDIT_START_REPLY (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n"
	"\t\tvalue: 0x%lx\n",
	req->length * 4,
	xim_preedit_start_reply->im_id,
	xim_preedit_start_reply->ic_id,
	xim_preedit_start_reply->value);
#endif
    SetMaxPreeditChars(con, xim_preedit_start_reply);
    Free_XIM_PREEDIT_START_REPLY(xim_preedit_start_reply);
}

static void
RespondXIMError(Connection *con __unused, Message *req)
{
    XIM_ERROR *xim_error;
    
    xim_error = Recv_XIM_ERROR(req->data);
#ifdef DEBUG
    printf(
	"\tXIM_ERROR (%d bytes)\n"
	"\t\tinput_method_id: 0x%x\n"
	"\t\tinput_context_id: 0x%x\n"
	"\t\tflag: 0x%x\n"
	"\t\tcode: %d\n"
	"\t\tdetail: %s(%d)\n",
	req->length * 4,
	xim_error->im_id,
	xim_error->ic_id,
	xim_error->flag,
	xim_error->code,
	xim_error->detail.val, xim_error->detail.len);
#endif
    Free_XIM_ERROR(xim_error);
}

static void
RespondRequest(Connection *con, Message *req)
{
    switch (req->major_opcode) {
    case OPCODE_XIM_CONNECT:
	RespondXIMConnect(con, req);
	break;
    case OPCODE_XIM_DISCONNECT:
	RespondXIMDisconnect(con, req);
	break;
    case OPCODE_XIM_OPEN:
	RespondXIMOpen(con, req);
	break;
    case OPCODE_XIM_CLOSE:
	RespondXIMClose(con, req);
	break;
    case OPCODE_XIM_ERROR:
	RespondXIMError(con, req);
	break;
    case OPCODE_XIM_QUERY_EXTENSION:
	RespondXIMQueryExtension(con, req);
	break;
    case OPCODE_XIM_ENCODING_NEGOTIATION:
	RespondXIMEncodingNegotiation(con, req);
	break;
    case OPCODE_XIM_GET_IM_VALUES:
	RespondXIMGetIMValues(con, req);
	break;
    case OPCODE_XIM_CREATE_IC:
	RespondXIMCreateIC(con, req);
	break;
    case OPCODE_XIM_DESTROY_IC:
	RespondXIMDestroyIC(con, req);
	break;
    case OPCODE_XIM_SET_IC_VALUES:
	RespondXIMSetICValues(con, req);
	break;
    case OPCODE_XIM_GET_IC_VALUES:
	RespondXIMGetICValues(con, req);
	break;
    case OPCODE_XIM_SET_IC_FOCUS:
	RespondXIMSetICFocus(con, req);
	break;
    case OPCODE_XIM_UNSET_IC_FOCUS:
	RespondXIMUnsetICFocus(con, req);
	break;
    case OPCODE_XIM_FORWARD_EVENT:
	RespondXIMForwardEvent(con, req);
	break;
    case OPCODE_XIM_TRIGGER_NOTIFY:
	RespondXIMTriggerNotify(con, req);
	break;
    case OPCODE_XIM_PREEDIT_START_REPLY:
	RespondXIMPreeditStartReply(con, req);
	break;
    case OPCODE_XIM_SYNC_REPLY:
	RespondXIMSyncReply(con, req);
	break;
    case OPCODE_XIM_RESET_IC:
	RespondXIMResetIC(con, req);
	break;
    default:
	printf("\tUnknown OPCODE(%d)\n", req->major_opcode);
	exit(1);
	break;
    }
}

static void
RespondXIMXConnect(XClientMessageEvent *msg)
{
    XEvent reply;
    Connection *con;

#ifdef DEBUG
    printf("\tclient communication window ID: 0x%lx\n", msg->data.l[0]);
    printf("\tclient-major-transport-version: %ld\n", msg->data.l[1]);
    printf("\tclient-minor-transport-version: %ld\n", msg->data.l[2]);
#endif
    if ((con = CreateConnection(msg)) == NULL) {
	fprintf(stderr, "Too short memory to create new Connection.\n");
	return;
    }
    con->preedit = PreeditWindow;
    con->status = StatusWindow;
    con->candidate = CandidateWindow;
    XSaveContext(con->disp, con->server, Context, (XPointer)con);

    reply.xclient.type = ClientMessage;
    reply.xclient.window = con->client;
    reply.xclient.message_type = _XIM_XCONNECT;
    reply.xclient.format = 32;
    reply.xclient.data.l[0] = (long)con->server;
    reply.xclient.data.l[1] = 0;
    reply.xclient.data.l[2] = 0;
    reply.xclient.data.l[3] = 20;
    XSendEvent(con->disp, con->client, False, 0, &reply);
}

static void
RespondXIMProtocol(XClientMessageEvent *msg)
{
    Connection *con;

#ifdef DUMP_DEBUG
    DumpData(msg->data.b, 20);
#endif
    if (XFindContext(msg->display, msg->window, Context, (XPointer *)&con))
	return;
    RespondRequest(con, (Message *)msg->data.b);
}

static void
RespondXIMProtocolWithProperty(XClientMessageEvent *msg)
{
    Connection *con;
    char *contents;
    Atom property_type;
    int format;
    long n_items, remain;
    int (*existing)(Display *, XErrorEvent *);
    
#ifdef DEBUG
    {
	char *atom = XGetAtomName(msg->display, (Atom)msg->data.l[1]);
	printf("\t" "property name: %s\n", atom);
	XFree(atom); /* XGetAtomName() */
    }
#endif
    existing = XSetErrorHandler(ErrorCB);
    if (XGetWindowProperty(msg->display, msg->window, (Atom)msg->data.l[1],
			   0, msg->data.l[0], True, AnyPropertyType,
			   &property_type, &format, &n_items, &remain,
			   (void *)&contents) != Success) {
	(void)XSetErrorHandler(existing);
	return;
    }
    (void)XSetErrorHandler(existing);
#ifdef DUMP_DEBUG
    DumpData(contents, n_items);
#endif
    if (XFindContext(msg->display, msg->window, Context, (XPointer *)&con))
	return;
    RespondRequest(con, (Message *)contents);
    XFree(contents); /* XGetWindowProperty() */
}

static void
RespondClientMessage(XEvent *ev)
{
    XClientMessageEvent *msg = (XClientMessageEvent *)ev;
    
#ifdef DEBUG
    {
	char *atom = XGetAtomName(msg->display, msg->message_type);
	printf("\tmessage_type: %s\n", atom);
	XFree(atom); /* XGetAtomName() */
	printf("\tformat: %d\n", msg->format);
    }
#endif
    if (msg->message_type == _XIM_XCONNECT && msg->window == Toplevel) {
	RespondXIMXConnect(msg);
    }
    else if (msg->message_type == _XIM_PROTOCOL && msg->format == 8) {
	RespondXIMProtocol(msg);
    }
    else if (msg->message_type == _XIM_PROTOCOL && msg->format == 32) {
	RespondXIMProtocolWithProperty(msg);
    }
}

static void
RespondSelectionRequest(XEvent *ev)
{
    XSelectionRequestEvent *req = (XSelectionRequestEvent *)ev;
    XEvent reply;
    int (*existing)(Display *, XErrorEvent *);
    
    if (req->owner != Toplevel)
	return;
#ifdef DEBUG
    {
	char *atom;
	atom = XGetAtomName(req->display, req->selection);
	printf("\tselection: %s\n", atom);
	XFree(atom); /* XGetAtomName() */
	atom = XGetAtomName(req->display, req->target);
	printf("\ttarget: %s\n", atom);
	XFree(atom); /* XGetAtomName() */
	atom = XGetAtomName(req->display, req->property);
	printf("\tproperty: %s\n", atom);
	XFree(atom); /* XGetAtomName() */
    }
#endif
    reply.xselection.type = SelectionNotify;
    reply.xselection.requestor = req->requestor;
    reply.xselection.selection = req->selection;
    reply.xselection.target = req->target;
    reply.xselection.time = req->time;
    existing = XSetErrorHandler(ErrorCB);
    if (req->target == LOCALES) {
        XChangeProperty(req->display, req->requestor, req->property,
			LOCALES, 8, PropModeReplace,
			DEFAULT_LOCALES, strlen(DEFAULT_LOCALES));
        reply.xselection.property = req->property;
        XSendEvent(req->display, req->requestor, False, 0, &reply);
    }
    else if (req->target == TRANSPORT) {
        XChangeProperty(req->display, req->requestor, req->property,
			TRANSPORT, 8, PropModeReplace,
			DEFAULT_TRANSPORT, strlen(DEFAULT_TRANSPORT));
        reply.xselection.property = req->property;
        XSendEvent(req->display, req->requestor, False, 0, &reply);
    }
    else {
        reply.xselection.property = None;
        XSendEvent(req->display, req->requestor, False, 0, &reply);
    }
    (void)XSetErrorHandler(existing);
}

static void
RespondDestroyNotify(XEvent *ev)
{
    XDestroyWindowEvent *des = (XDestroyWindowEvent *)ev;
    Connection *con;
    InputContext *ic;

#ifdef DEBUG
    printf("\t" "Destroyed window ID: 0x%lx\n", des->window);
#endif
    if (!XFindContext(des->display, des->window, Context, (XPointer *)&con)) {
#ifdef DEBUG
	printf("\t" "Context\n");
#endif
	XDeleteContext(con->disp, con->server, Context);
	FreeConnection(con);
	return;
    }
    else if (!XFindContext(des->display, des->window, CandidateWindow,
			   (XPointer *)&ic)) {
#ifdef DEBUG
	printf("\t" "CandidateWindow\n");
#endif
	XDeleteContext(des->display, ic->candidate_window, CandidateWindow);
	ic->candidate_window = None;
	return;
    }
    else if (!XFindContext(des->display, des->window, StatusWindow,
			   (XPointer *)&ic)) {
#ifdef DEBUG
	printf("\t" "StatusWindow\n");
#endif
	XDeleteContext(des->display, ic->status_window, StatusWindow);
	XFreePixmap(des->display, ic->status_pixmap);
	XFreeGC(des->display, ic->status_gc);
	ic->status_window = None;
	ic->status_pixmap = None;
	ic->status_gc = None;
	return;
    }
    else if (!XFindContext(des->display, des->window, PreeditWindow,
			   (XPointer *)&ic)) {
#ifdef DEBUG
	printf("\t" "PreeditWindow\n");
#endif
	XDeleteContext(des->display, ic->preedit_window, PreeditWindow);
	ic->preedit_window = None;
	return;
    }
}

static void
RespondExpose(XEvent *ev)
{
    XExposeEvent *exp = (XExposeEvent *)ev;
    InputContext *ic;

#ifdef DEBUG
    printf("\t" "Expose window ID: 0x%lx\n", exp->window);
#endif
    if (!XFindContext(exp->display, exp->window, CandidateWindow,
		      (XPointer *)&ic)) {
	if (exp->count == 0)
	    DrawCandidateWindow(exp->display, ic);
	return;
    }
}

static void
RespondConfigureNotify(XEvent *ev)
{
    XConfigureEvent *cfg = (XConfigureEvent *)ev;
    InputContext *ic;

    if (!XFindContext(cfg->display, cfg->window, CandidateWindow,
		      (XPointer *)&ic)) {
#ifdef DEBUG
	printf("\t" "ConfigureNotify window ID: 0x%lx\n", cfg->window);
#endif
	ResizeCandidateWindow(cfg->display, ic);
    }
}

static void
GetToplevelPreferences(Display *disp)
{
    LoadSylKeymap(disp, "imserver.undofix", THIS_CLASS ".Undofix",
		  imserverUndofixKeyBinding, UndofixKeymap);
    LoadSylKeymap(disp, "imserver.preedit", THIS_CLASS ".Preedit",
		  imserverPreeditKeyBinding, PreeditKeymap);
    LoadSylKeymap(disp, "imserver.convert", THIS_CLASS ".Convert",
		  imserverConvertKeyBinding, ConvertKeymap);
    LoadSylFontSets(disp, "imserver", THIS_CLASS, FontSet, &CandidateFontSet);
    LoadTriggerKeys(disp, "imserver", THIS_CLASS, &TriggerOn, &on_key);
    LoadTriggerKeys(disp, "imserver", THIS_CLASS, &TriggerOff, &off_key);
    LoadPreconversionMapping(disp, "imserver", THIS_CLASS, &Mapping);
    GetSylSetting(disp, "imserver", THIS_CLASS, &PreconversionMode);
    LoadStatusPreference(disp, "imserver", THIS_CLASS);
    LoadPredictionPreference(disp, "imserver", THIS_CLASS);
}

int
main(int ac, char **av)
{
    Display *disp;
    Atom xim_servers, category, property_type, *contents;
    int format;
    long n_items, remain;
    XEvent ev;
    XrmDatabase xrdb;

    if (ac != 1) {
        printf("usage: %s\n", av[0]);
        exit(1);
    }
    if ((disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: Cannot open display.\n", av[0]);
        exit(1);
    }
    if (setlocale(LC_ALL, "") == NULL) {
        fprintf(stderr, "%s: cannot set locale.\n", av[0]);
        exit(1);
    }
    if (XSupportsLocale() == False) {
        fprintf(stderr, "%s: locale not supported.\n", av[0]);
        exit(1);
    }
    if (OpenEngine(NULL)) {
        fprintf(stderr, "%s: cannot open sj3.\n", av[0]);
        exit(1);
    }
    XrmInitialize();
    xrdb = SylMergedResourceDatabase(disp);
    if ((UndofixKeymap = CreateSylKeymap()) == NULL
	|| (PreeditKeymap = CreateSylKeymap()) == NULL
	|| (ConvertKeymap = CreateSylKeymap()) == NULL) {
        fprintf(stderr, "%s: cannot allocate SylKeymap.\n", av[0]);
        exit(1);
    }
    GetToplevelPreferences(disp);
    Toplevel = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
				 0, 0, 1, 1, 0, 0, 0);
    LOCALES = XInternAtom(disp, "LOCALES", False);
    TRANSPORT = XInternAtom(disp, "TRANSPORT", False);
    _XIM_XCONNECT = XInternAtom(disp, "_XIM_XCONNECT", False);
    _XIM_PROTOCOL = XInternAtom(disp, "_XIM_PROTOCOL", False);
    _XIM_MOREDATA = XInternAtom(disp, "_XIM_MOREDATA", False);

    category = XInternAtom(disp, "@server=syl", False);
    if (XGetSelectionOwner(disp, category) != None) {
        fprintf(stderr, "%s: Another imserver running.\n", av[0]);
	exit(1);
    }
    XSetSelectionOwner(disp, category, Toplevel, CurrentTime);

    /*
      �롼�ȥ�����ɥ��Υץ��ѥƥ�XIM_SERVERS��������롣XIM_SERVERS��
      ���ȥ�Υꥹ�ȤǤ��롣���Υꥹ�Ȥ˥��ȥ�category���ޤޤ�Ƥʤ���С�
      ������ɲä��롣�ޤޤ�Ƥ�����ϡ���ö�ꥹ�Ȥ����������塢�Ƥ�
      �ɲä����XRegisterIMInstantiateCallback���б����뤿��ˡ�
    */
    xim_servers = XInternAtom(disp, "XIM_SERVERS", False);
    XGrabServer(disp);
    if (XGetWindowProperty(disp, DefaultRootWindow(disp), xim_servers, 0, 8192,
			   False, AnyPropertyType, &property_type, &format,
			   &n_items, &remain, (void *)&contents) == Success) {
	int n;
	for (n = 0; n < n_items && contents[n] != category; ++n)
	    ;
	if (n < n_items) {
	    contents[n] = contents[n_items - 1];
	    XChangeProperty(disp, DefaultRootWindow(disp), xim_servers,
			    XA_ATOM, 32, PropModeReplace,
			    (void *)contents, n_items - 1);
	}
	XFree(contents); /* XGetWindowProperty() */
    }
    XChangeProperty(disp, DefaultRootWindow(disp), xim_servers,
		    XA_ATOM, 32, PropModeAppend, (void *)&category, 1);
    XUngrabServer(disp);

    InitializeWire(disp);
    Context = XUniqueContext();
    PreeditWindow = XUniqueContext();
    StatusWindow = XUniqueContext();
    CandidateWindow = XUniqueContext();
    /*
      1999-10-17: �̤���λ�Ŧ�ˤ�ꡢü�����饵���ڥ�ɤǤ��ʤ��褦�ˤ�����
      ���衢���饤�����¦����������XIM�����Фإꥯ�����Ȥ�����ʤ��褦��
      ���������ʤ���������Ū�ˤ��񤷤���
    */
    signal(SIGTSTP, SIG_IGN);
#if 0
    XMapRaised(disp, Toplevel);
#endif
    for (;;) {
        while (XEventsQueued(disp, QueuedAfterFlush) == 0
	       && NiceInputContext()) {
            ;
        }
#ifdef DEBUG
	printf("heap: %d\n", ldusing());
	PrintSharedFontset();
#endif
	XNextEvent(disp, &ev);
        switch (ev.type) {
	case MappingNotify:
	    XRefreshKeyboardMapping(&(ev.xmapping));
	    break;
	case SelectionRequest:
#ifdef DEBUG
	    printf("ev.type: SelectionRequest\n");
#endif
	    RespondSelectionRequest(&ev);
 	    break;
	case ClientMessage:
#ifdef DEBUG
	    printf("ev.type: ClientMessage\n");
#endif
	    RespondClientMessage(&ev);
	    break;
	case DestroyNotify:
#ifdef DEBUG
	    printf("ev.type: DestroyNotify\n");
#endif
	    RespondDestroyNotify(&ev);
	    break;
	case Expose:
#ifdef DEBUG
	    printf("ev.type: Expose\n");
#endif
	    RespondExpose(&ev);
	    break;	    
	case ConfigureNotify:
#ifdef DEBUG
	    printf("ev.type: ConfigureNotify\n");
#endif
	    RespondConfigureNotify(&ev);
	    break;	    
#ifdef DEBUG
	default:
	    printf("ev.type: %d\n", ev.type);
	    break;
#endif
	}
    }
}
