/*
	$Id: convert.c,v 1.4 2001/06/03 18:54:33 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h" /* only for Feedback[] */
#include "message.h"
#include "status.h"
#include "commit.h"
#include "candidate.h"
#include "predict.h"
#include "convert.h"

static void
UpdateCandidates(Connection *con, InputContext *ic)
{
    if (ic->candidate_window == None)
	return;
    if (ic->view->top == NULL
	|| CompareSylText(ic->view->chosen, ic->view->applicant) != 0) {
	XUnmapWindow(con->disp, ic->candidate_window);
    }
    else {
	/*
	  ������ResizeCandidateWindow()�μ����ϡ�����ʸ�����Ĺ����
	  �ɤ�ʸ�����Ĺ���ʲ��Ǥ���Ȥ�����������Ѥ��ơ�������ɥ�����
	  ��ñ�˷��ꤷ�Ƥ�����

	  ͽ¬�Ѵ���ǽ������������Ȥˤ�ꡢ�嵭�β������Ω���ʤ��ʤä���
	  ���ߤμ����Ǥ�������ʸ�����Ĺ����Ĵ�٤뤿�ᡢ������ɥ�����
	  ����ˤϤ��ʤꥳ���Ȥ�ɬ�פˤʤ롣

	  Ʊ��ʸ��ˤ����������䡢����������򤹤��硢���襦����ɥ�����
	  �ѹ�����ɬ�פϤʤ����������Ǥ���󥦥���ɥ�����׻����Ƥ��롣
	*/
	ResizeCandidateWindow(con->disp, ic);
	XMapRaised(con->disp, ic->candidate_window);
	DrawCandidateWindow(con->disp, ic);
    }
}

static void
ConvertPhrase(Connection *con, InputContext *ic,
	      void (*change_phrase)(Phrase *, SylText *))
{
    int chg_first, chg_length;
    
    chg_first = BeginningOfPhrase(ic->head, ic->view);
    chg_length = LengthOfSylText(ic->view->chosen);
    change_phrase(ic->view, ic->preedit);
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->change_phrase(con, ic, chg_first, chg_length);
    UpdateCandidates(con, ic);
    CommitSecondaryPrediction(con, ic);
}

static void
ConvertZenkaku(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    ConvertPhrase(con, ic, ChangeZenkakuPhrase);
}

static void
ConvertHankaku(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    ConvertPhrase(con, ic, ChangeHankakuPhrase);
}

static void
ConvertKatakana(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    ConvertPhrase(con, ic, ChangeKatakanaPhrase);
}

static void
ConvertHiragana(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    ConvertPhrase(con, ic, ChangeHiraganaPhrase);
}

static void
ConvertNextChoice(Connection *con, InputContext *ic,
		  XIM_FORWARD_EVENT *ev __unused)
{
    ConvertPhrase(con, ic, ChangeNextRankOfPhrase);
}

static void
ConvertPrevChoice(Connection *con, InputContext *ic,
		  XIM_FORWARD_EVENT *ev __unused)
{
    ConvertPhrase(con, ic, ChangePrevRankOfPhrase);
}

static void
ConvertShorten(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    int chg_first, chg_length;

    if (ic->head == NULL)
	return;
    if (ic->view->length <= 1)
	return;
    chg_first = BeginningOfPhrase(ic->head, ic->view);
    chg_length = LengthOfPhrase(ic->view);

    if (ic->head == ic->view) {
	ic->head = ShortenPhrase(ic->head, ic->preedit);
	ic->view = ic->head;
    }
    else {
	ic->view = ShortenPhrase(ic->view, ic->preedit);
    }
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->resize_phrase(con, ic, chg_first, chg_length);
    UpdateCandidates(con, ic);
    CommitSecondaryPrediction(con, ic);
}

static void
ConvertLengthen(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    int chg_first, chg_length;
    
    if (ic->head == NULL)
	return;
    if (ic->view->offset + ic->view->length >= LengthOfSylText(ic->preedit))
	return;
    chg_first = BeginningOfPhrase(ic->head, ic->view);
    chg_length = LengthOfPhrase(ic->view);

    if (ic->head == ic->view) {
	ic->head = LengthenPhrase(ic->head, ic->preedit);
	ic->view = ic->head;
    }
    else {
	ic->view = LengthenPhrase(ic->view, ic->preedit);
    }
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->resize_phrase(con, ic, chg_first, chg_length);
    UpdateCandidates(con, ic);
    CommitSecondaryPrediction(con, ic);
}

static void
ConvertCancel(Connection *con, InputContext *ic,
	      XIM_FORWARD_EVENT *ev __unused)
{
    int chg_first, chg_length;
    
    chg_first = 0;
    chg_length = LengthOfPhrase(ic->head);
    FreePhrase(ic->head);
    if (ic->candidate_window != None)
	XUnmapWindow(con->disp, ic->candidate_window);
    ic->head = NULL;
    ic->view = NULL;
    ic->caret = LengthOfSylText(ic->preedit);
    
    ic->preedit_draw->cancel(con, ic, chg_first, chg_length);
    CommitStatus(con, ic);
    CommitPrediction(con, ic);
}

static void
MovePhrase(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev __unused)
{
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->select_phrase(con, ic);
    UpdateCandidates(con, ic);
}

static void
ConvertPhraseRight(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    if (ic->view->next == NULL)
	return;
    ic->view = ic->view->next;
    MovePhrase(con, ic, ev);
}

static void
ConvertPhraseLeft(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    if (ic->view->prev == NULL)
	return;
    ic->view = ic->view->prev;
    MovePhrase(con, ic, ev);
}    

static void
ConvertLineFeed(Connection *con, InputContext *ic, XIM_FORWARD_EVENT *ev)
{
    ClearString(con, ic); 
    EchoXIMForwardEvent(con, ev);
    CommitString(con, ic);
    CommitStatus(con, ic);
    ClearPrediction(con, ic);
}

static void
ConvertCommit(Connection *con, InputContext *ic,
	      XIM_FORWARD_EVENT *ev __unused)
{
    ClearString(con, ic); 
    CommitString(con, ic);
    CommitStatus(con, ic);
    ClearPrediction(con, ic);
}

static void
ConvertPredict(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    Phrase *p;
    SylText *txt;
    int len;

    txt = CreateSylTextFromPhrase(ic->head);
    len = LengthOfSylText(txt);
    if ((p = PredictedPhrase(txt)) == NULL) {
	FreeSylText(txt);
	return;
    }
    FreeSylText(txt);
    FreePhrase(ic->head);

    ic->head = p;
    ic->view = p;
    ic->caret = CaretPositionOfPhrase(ic->head, ic->view);

    ic->preedit_draw->change_phrase(con, ic, 0, len);
    UpdateCandidates(con, ic);
    CommitSecondaryPrediction(con, ic);
}

void (*ConvertBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverConvert.branch"
};
