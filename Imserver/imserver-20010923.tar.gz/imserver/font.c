/*
	$Id: font.c,v 1.1 2001/09/22 14:53:36 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "Resource.h"
#include "font.h"

static XFontSet
CreateFontset(Display *disp, char *fontlist, SylFontSet *fsp)
{
    XFontSet fs;
    int n_missings, n_fontinfos;
    char **missing, *alternation, **fontname;
    XFontStruct **fontinfo;

    fs = XCreateFontSet(disp, fontlist, &missing, &n_missings, &alternation);
    if (fs == NULL) {
#ifdef DEBUG
        fprintf(stderr, "CreateFontset: no font_struct_list\n");
#endif
        return (NULL);
    }
    if (n_missings > 0) {
#ifdef DEBUG
        int n;

        for (n = 0; n < n_missings; ++n)
            fprintf(stderr, "CreateFontset: missing, %s\n", missing[n]);
        if (alternation != NULL) {
            fprintf(stderr, "CreateFontset: def_string %s(%d)\n",
                    alternation, strlen(alternation));
	}
#endif
        XFreeStringList(missing);
    }
    if ((n_fontinfos = XFontsOfFontSet(fs, &fontinfo, &fontname)) < 1) {
#ifdef DEBUG
        fprintf(stderr, "CreateFontset: no font_struct_list\n");
#endif
        XFreeFontSet(disp, fs);
        return (NULL);
    }
    fsp->id = fs;
    fsp->width = abs(XmbTextEscapement(fs, "x", 1));
    fsp->height = fontinfo[0]->ascent + fontinfo[0]->descent;
    fsp->ascent = fontinfo[0]->ascent;
    fsp->descent = fontinfo[0]->descent;
    fsp->tabsep = fsp->width * 8;
    return (fs);
}

static void
FreeFontset(Display *disp, SylFontSet *fsp)
{
    XFreeFontSet(disp, fsp->id);
}

typedef struct SharedFontset {
    struct SharedFontset *next;
    Display *disp;
    char *name;
    int ref;
    time_t stamp;
    SylFontSet fs;
} SharedFontset;

static SharedFontset *top = NULL;
#define EXPIRATION 60

#ifdef BUGGY_XFONTSET
static void
Cleanup(void)
{
    SharedFontset *sf, *prev;
    time_t stamp;

    stamp = time(NULL);
    for (prev = NULL, sf = top; sf != NULL; prev = sf, sf = sf->next) {
	if (sf->ref > 0 || difftime(stamp, sf->stamp) < EXPIRATION)
	    continue;
	if (prev == NULL) {
	    top = sf->next;
	}
	else {
	    prev->next = sf->next;
	}
	free(sf->name);
	FreeFontset(sf->disp, &sf->fs);
	free(sf);
	return;
    }
}
#endif

XFontSet
CreateSharedFontset(Display *disp, char *name, SylFontSet *fsp)
{
    SharedFontset *sf;

    /* 1. �ꥹ�Ȥ򸡺� */
    for (sf = top; sf != NULL; sf = sf->next) {
	if (sf->disp != disp || strcmp(sf->name, name) != 0)
	    continue;
	++(sf->ref);
	*fsp = sf->fs;
	return (fsp->id);
    }

#ifdef BUGGY_XFONTSET
    /* 2. �����������������˻��Ȳ��0�θŤ��ե���ȥ��åȤ���� */
    Cleanup();
#endif

    /* 3. �ե���ȥ��åȤ����� */
    if (CreateFontset(disp, name, fsp) == NULL)
	return (NULL);
    if ((sf = (SharedFontset *)malloc(sizeof(SharedFontset))) == NULL)
	return (fsp->id);
    if ((name = strdup(name)) == NULL) {
	free(sf);
	return (fsp->id);
    }
    sf->next = top;
    sf->disp = disp;
    sf->name = name;
    sf->ref = 1;
    sf->stamp = time(NULL);
    sf->fs = *fsp;
    top = sf;
    return (fsp->id);
}

void
FreeSharedFontset(Display *disp, SylFontSet *fsp)
{
    SharedFontset *sf;

    for (sf = top; sf != NULL; sf = sf->next) {
	if (sf->disp != disp || sf->fs.id != fsp->id)
	    continue;
	--(sf->ref);
	sf->stamp = time(NULL);
	return;
    }
    FreeFontset(disp, fsp);
}

#ifdef DEBUG
void
PrintSharedFontset(void)
{
    SharedFontset *sf;

    for (sf = top; sf != NULL; sf = sf->next) {
	printf("[%d]", sf->ref);
    }
    printf("\n");
}
#endif
