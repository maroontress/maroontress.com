/*
	$Id: xicattr.c,v 1.2 2003/03/04 13:03:57 syl Exp $

	Copyright (C) 1999, 2000, 2001, 2002, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xlocale.h>
#include <X11/Xproto.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "xim.h"

#define CONST_STRING(x) {sizeof(x), x}

static XICATTR ic_attrs_0_item = {0, 3, CONST_STRING(XNInputStyle)};
static XICATTR ic_attrs_1_item = {1, 5, CONST_STRING(XNClientWindow)};
static XICATTR ic_attrs_2_item = {2, 5, CONST_STRING(XNFocusWindow)};
static XICATTR ic_attrs_3_item = {3, 3, CONST_STRING(XNFilterEvents)};
static XICATTR ic_attrs_4_item = {4, 0x7fff, CONST_STRING(XNPreeditAttributes)};
static XICATTR ic_attrs_5_item = {5, 0x7fff, CONST_STRING(XNStatusAttributes)};
static XICATTR ic_attrs_6_item = {6, 11, CONST_STRING(XNArea)};
static XICATTR ic_attrs_7_item = {7, 11, CONST_STRING(XNAreaNeeded)};
static XICATTR ic_attrs_8_item = {8, 12, CONST_STRING(XNSpotLocation)};
static XICATTR ic_attrs_9_item = {9, 3, CONST_STRING(XNColormap)};
static XICATTR ic_attrs_10_item = {10, 3, CONST_STRING(XNStdColormap)};
static XICATTR ic_attrs_11_item = {11, 3, CONST_STRING(XNForeground)};
static XICATTR ic_attrs_12_item = {12, 3, CONST_STRING(XNBackground)};
static XICATTR ic_attrs_13_item = {13, 3, CONST_STRING(XNBackgroundPixmap)};
static XICATTR ic_attrs_14_item = {14, 13, CONST_STRING(XNFontSet)};
static XICATTR ic_attrs_15_item = {15, 2, CONST_STRING(XNLineSpace)};
static XICATTR ic_attrs_16_item = {16, 3, CONST_STRING(XNCursor)};
static XICATTR ic_attrs_17_item = {17, 0, CONST_STRING(XNSeparatorofNestedList)};
#if 1
/*
  The Input Method Protocol version 1.0
  (xc/doc/hardcopy/XIM/xim.PS.gz) ��6--7�ڡ����Ǥϡ�XICATTR�� `type of
  the value (*2)' �Ȥ��ơ�XIMPreeditState�� `value type' ��#18��
  XIMResetState�� `value type' ��#19��������Ƥ��롣

  ��������Xlib�μ����Ǥ�#18��#19��̤����Ǥ��ꡢ���ͤ˽��äƼ�������Ƥ�
  �ʤ������Τ���XIMPreeditState��XIMResetState�� `value type' ��#3
  (long data) �Ȥ���������롣
*/
static XICATTR ic_attrs_18_item = {18, 3, CONST_STRING(XNPreeditState)};
static XICATTR ic_attrs_19_item = {19, 3, CONST_STRING(XNResetState)};
#else
static XICATTR ic_attrs_18_item = {18, 18, CONST_STRING(XNPreeditState)};
static XICATTR ic_attrs_19_item = {19, 19, CONST_STRING(XNResetState)};
#endif

static LIST ic_attrs_19 = {NULL, (void *)&ic_attrs_19_item};
static LIST ic_attrs_18 = {&ic_attrs_19, (void *)&ic_attrs_18_item};
static LIST ic_attrs_17 = {&ic_attrs_18, (void *)&ic_attrs_17_item};
static LIST ic_attrs_16 = {&ic_attrs_17, (void *)&ic_attrs_16_item};
static LIST ic_attrs_15 = {&ic_attrs_16, (void *)&ic_attrs_15_item};
static LIST ic_attrs_14 = {&ic_attrs_15, (void *)&ic_attrs_14_item};
static LIST ic_attrs_13 = {&ic_attrs_14, (void *)&ic_attrs_13_item};
static LIST ic_attrs_12 = {&ic_attrs_13, (void *)&ic_attrs_12_item};
static LIST ic_attrs_11 = {&ic_attrs_12, (void *)&ic_attrs_11_item};
static LIST ic_attrs_10 = {&ic_attrs_11, (void *)&ic_attrs_10_item};
static LIST ic_attrs_9 = {&ic_attrs_10, (void *)&ic_attrs_9_item};
static LIST ic_attrs_8 = {&ic_attrs_9, (void *)&ic_attrs_8_item};
static LIST ic_attrs_7 = {&ic_attrs_8, (void *)&ic_attrs_7_item};
static LIST ic_attrs_6 = {&ic_attrs_7, (void *)&ic_attrs_6_item};
static LIST ic_attrs_5 = {&ic_attrs_6, (void *)&ic_attrs_5_item};
static LIST ic_attrs_4 = {&ic_attrs_5, (void *)&ic_attrs_4_item};
static LIST ic_attrs_3 = {&ic_attrs_4, (void *)&ic_attrs_3_item};
static LIST ic_attrs_2 = {&ic_attrs_3, (void *)&ic_attrs_2_item};
static LIST ic_attrs_1 = {&ic_attrs_2, (void *)&ic_attrs_1_item};
static LIST ic_attrs_0 = {&ic_attrs_1, (void *)&ic_attrs_0_item};

LIST *ic_attrs_set = &ic_attrs_0;
