/*
	$Id: write.c,v 1.2 2003/03/16 14:16:21 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdio.h>
#include <string.h>

#include "packet.h"
#include "write.h"

static void
InsertPAD(FILE *fp)
{
    fprintf(fp,
	    "\t" "while ((d - q) %% 4)\n"
	    "\t\t" "*(d)++ = 0;\n");
}

static int
IsCardinal(char *name)
{
    return (strcmp(name, "CARD8") == 0
	    || strcmp(name, "CARD16") == 0
	    || strcmp(name, "CARD32") == 0);
}

static void
WriteAny(FILE *fp, char *n, char *m)
{
    if (IsCardinal(n)) {
	fprintf(fp, "\t" "*((%s *)d)++ = p->%s;\n", n, m);
    }
    else if (strcmp(n, "XEVENT") == 0) {
	fprintf(fp,
		"\t" "memcpy((XEVENT *)d, &(p->%s), sizeof(XEVENT));\n"
		"\t" "d += sizeof(XEVENT);\n",
		m);
    }
    else if (strcmp(n, "STRING") == 0) {
	fprintf(fp,
		"\t" "*((CARD16 *)d)++ = p->%s.len;\n"
		"\t" "memcpy(d, p->%s.val, p->%s.len);\n"
		"\t" "d += p->%s.len;\n",
		m, m, m, m);
	InsertPAD(fp);
    }
    else {
	fprintf(fp, "\t" "d = Write_%s(&(p->%s), d);\n", n, m);
    }
}

static void
AllocateArray(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "*((CARD16 *)d)++ = p->%s.num;\n", member);
    InsertPAD(fp);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "*((%s *)d)++ = *(p->%s.val[k]);\n",
		name, member);
    }
    else {
	fprintf(fp, "\t\t" "d = Write_%s(p->%s.val[k], d);\n",
		name, member);
    }
}

static void
AllocateList(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "len = d;\n");
    fprintf(fp, "\t" "*((CARD16 *)d)++ = 0; /* dummy */\n");
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t" "b = d;\n");
    fprintf(fp, "\t"
	    "for (c = p->%s; c != NULL; c = c->next) {\n", member);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "*((%s *)d)++ = *((%s *)c->data);\n",
		name, name);
    }
    else {
	fprintf(fp, "\t\t" "d = Write_%s(c->data, d);\n", name);
    }
    fprintf(fp, "\t" "}\n");
    fprintf(fp, "\t" "*((CARD16 *)len) = d - b;\n");
}

static void
AllocateMulti(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "*((CARD16 *)d)++ = p->%s.num * sizeof(%s);\n",
	    member, name);
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    fprintf(fp, "\t\t" "*((%s *)d)++ = p->%s.val[k];\n", name, member);
}

void
PrintWrite(FILE *fp, PacketList *pl)
{
    int n;
    Type *t;
    Packet *ptr;

    fprintf(fp,
	    "\n"
            "CARD8 *\n"
            "Write_STRING(STRING *p, CARD8 *q)\n"
            "{\n"
	    "\t" "CARD8 *d = q;\n"
	    "\n"
	    "\t" "*((CARD16 *)d)++ = p->len;\n"
	    "\t" "memcpy(d, p->val, p->len);\n"
	    "\t" "d += p->len;\n"
	    "\t" "while ((d - q) %% 4)\n"
	    "\t\t" "*d++ = 0;\n"
	    "\t" "return (d);\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Read)
	    continue;
	fprintf(fp,
		"\n"
		"%sCARD8 *\n"
		"Write_%s(%s *p, CARD8 *q)\n"
		"{\n"
		"\t" "CARD8 *d = q;\n",
		((ptr->to_do == Basic) ? "" : "static "),
		ptr->type, ptr->type);
	n = 0;
	for (t = ptr->head; t != NULL; t = t->next)
	    n |= (1 << t->mod);
	if (n > 1) {
	    if (n & (1 << Array) || n & (1 << Multi))
		fprintf(fp, "\t" "int k;\n");
	    if (n & (1 << Listof)) {
		fprintf(fp, "\t" "LIST *c;\n");
		fprintf(fp, "\t" "CARD8 *b, *len;\n");
	    }
	}
	fprintf(fp, "\n");
	for (t = ptr->head; t != NULL; t = t->next) {
	    if (strcmp(t->name, "PAD") == 0)
		InsertPAD(fp);
	    else if (t->mod == Array)
		AllocateArray(fp, t->name, t->member);
	    else if (t->mod == Listof)
		AllocateList(fp, t->name, t->member);
	    else if (t->mod == Multi)
		AllocateMulti(fp, t->name, t->member);
	    else
		WriteAny(fp, t->name, t->member);
	}
	fprintf(fp,
		"\t" "return (d);\n"
		"}\n");
    }
}
