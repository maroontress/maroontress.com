/*
	$Id: sizeof.h,v 1.1 2000/10/03 18:46:04 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

void PrintSizeof(FILE *, PacketList *);
