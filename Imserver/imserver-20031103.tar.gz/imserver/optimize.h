/*
	$Id: optimize.h,v 1.4 2003/11/02 18:44:29 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

#define OPT_REVERSE_CARET       0x0001
#define OPT_NO_FEEDBACK         0x0002
#define OPT_FEEDBACK_OO10       0x0004
#define OPT_FEEDBACK_OO11       0x0008
#define OPT_PREDICTION_DATABASE 0x0010

int GetOptimization(Display *, Window, int *, char **);
void LoadClientOptimization(Display *, char *, char *, SylSetting *);
