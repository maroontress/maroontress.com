/*
	$Id: Tokenizer.h,v 1.1 2003/05/31 14:41:20 syl Exp $

	Copyright (C) 1999, 2003 Syllabub
	Maroontress Fast Software.
*/

typedef enum {
    SYL_TOKEN_EMPTYLINES,
    SYL_TOKEN_KEYWORD,
    SYL_TOKEN_RESERVED,
    SYL_TOKEN_PUNCTUATOR,
    SYL_TOKEN_NUMBER,
    SYL_TOKEN_OPERATOR,
    SYL_TOKEN_CPPCMD,
    SYL_TOKEN_STRCONST,
    SYL_TOKEN_CHARCONST,
    SYL_TOKEN_COMMENT,
    SYL_TOKEN_UNKNOWN_OPERATOR,
    SYL_TOKEN_UNTERMINATED_CPPCMD,
    SYL_TOKEN_UNTERMINATED_STR,
    SYL_TOKEN_UNTERMINATED_CHAR,
    SYL_TOKEN_UNTERMINATED_COMMENT
} SylTokenType;

typedef struct {
    int (*is_first_name)(int);
    int (*is_name)(int);
    int (*is_delimitor)(int);
    int (*is_punctuator)(int);
} SylCharAppraiser;

typedef struct SylTokenizer {
    const char *top;
    const char *ptr;
    const char *string;
    int line;
    const char **reserved_words;
    const SylCharAppraiser *ca;
    void (*drain)(struct SylTokenizer *, int);
    char *token;
} SylTokenizer;

SylTokenizer * CreateSylTokenizer(const char *);
SylTokenizer * CreateSylTokenizerWithCA(const char *,
					const SylCharAppraiser *);
void FreeSylTokenizer(SylTokenizer *);

int GetTokenFromSylTokenizer(SylTokenizer *, const char **, int *);

void SetReservedWordsToSylTokenizer(SylTokenizer *, const char **);
void SetDrainToSylTokenizer(SylTokenizer *, void (*)(SylTokenizer *, int));

char * TokenStringOfSylTokenizer(SylTokenizer *);
#define LineOfSylTokenizer(tok) (tok->line)
