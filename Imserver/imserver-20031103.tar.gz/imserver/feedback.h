/*
	$Id: feedback.h,v 1.1 2003/06/01 16:34:03 syl Exp $

	Copyright (C) 2003 Syllabub
	Maroontress Fast Software.
*/

XIMFeedback * CreatePreeditFeedback(InputContext *, int);
XIMFeedback * CreatePhraseFeedback(InputContext *);
XIMFeedback * CreateSelectedPhraseFeedback(InputContext *, Phrase *, Phrase *);
