#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xlocale.h>
#include <stdio.h>
#include <err.h>
#include "detection.h"

#define CHECKPOINT(x) printf(x " %d\n", allocated())

int
main(int ac, char **av)
{
    Display *display;
    XFontSet fs;
    char *base_font_name_list;
    char **missing_charset_list_return;
    int missing_charset_count_return;
    char *def_string_return;
    int k;

    if (ac != 2) {
        errx(1, "usage: %s font-set-name", av[0]);
    }
    base_font_name_list = av[1];

    CHECKPOINT("1");
    if (setlocale(LC_ALL, "") == NULL) {
        errx(1, "cannot set locale.");
    }
    if (XSupportsLocale() == False) {
        errx(1, "locale not supported.");
    }

    CHECKPOINT("2");
    if ((display = XOpenDisplay("")) == NULL) {
        errx(1, "cannot open display.");
    }

    CHECKPOINT("3");
    if ((fs = XCreateFontSet(display, base_font_name_list,
			     &missing_charset_list_return,
			     &missing_charset_count_return,
			     &def_string_return)) == NULL) {
	errx(1, "cannot create fontset.");
    }
    if (missing_charset_list_return != NULL) {
	warnx("missing_charset_count_return: %d",
	      missing_charset_count_return);
	for (k = 0; k < missing_charset_count_return; ++k) {
	    warnx("missing_charset_list_return[%d]: %s", k,
		  missing_charset_list_return[k]);
	}
	XFreeStringList(missing_charset_list_return);
    }

    CHECKPOINT("4");
    XFreeFontSet(display, fs);
#if 1
    CHECKPOINT("3");
    if ((fs = XCreateFontSet(display, base_font_name_list,
			     &missing_charset_list_return,
			     &missing_charset_count_return,
			     &def_string_return)) == NULL) {
	errx(1, "cannot create fontset.");
    }
    if (missing_charset_list_return != NULL) {
	warnx("missing_charset_count_return: %d",
	      missing_charset_count_return);
	for (k = 0; k < missing_charset_count_return; ++k) {
	    warnx("missing_charset_list_return[%d]: %s", k,
		  missing_charset_list_return[k]);
	}
	XFreeStringList(missing_charset_list_return);
    }

    CHECKPOINT("4");
    XFreeFontSet(display, fs);
#endif
    CHECKPOINT("5");
    XCloseDisplay(display);

    CHECKPOINT("6");
    exit(0);
    return (0);
}
