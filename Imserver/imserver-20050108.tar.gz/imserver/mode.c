/*
	$Id: mode.c,v 1.1 2004/02/15 18:49:06 syl Exp $

	Copyright (C) 2004 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "status.h"
#include "predict.h"
#include "mode.h"

void
DoublePreconversionMode(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_DOUBLE;
    CommitStatus(con, ic);
}

void
SinglePreconversionMode(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_SINGLE;
    CommitStatus(con, ic);
}

void
DirectInputMode(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_NONE;
    CommitStatus(con, ic);
}

void
EnableReferenceMode(Connection *con, InputContext *ic,
		    XIM_FORWARD_EVENT *ev __unused)
{
    ic->use_reference = True;
    CommitPrediction(con, ic);
    CommitStatus(con, ic);
}

void
DisableReferenceMode(Connection *con, InputContext *ic,
		     XIM_FORWARD_EVENT *ev __unused)
{
    ic->use_reference = False;
    CommitPrediction(con, ic);
    CommitStatus(con, ic);
}
