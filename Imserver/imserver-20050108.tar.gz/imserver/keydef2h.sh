#!/bin/sh

#	$Id: keydef2h.sh,v 1.1 2000/10/03 18:45:25 syl Exp $
#
#	Copyright (C) 1999, 2000 Syllabub
#	Maroontress Fast Software.

echo 'static SylSetting'

n=0
while read func name args
do
  c1=`echo $name | sed -e 's/^\(.\).*/\1/' | tr a-z A-Z`
  c2=`echo $name | sed -e 's/^.\(.*\)/\1/'`
  echo '  '$1'KeyBinding'$n' = {"'$name'"', '"'$c1$c2'"', '"'$args'"', 'NULL},'
  n=`expr $n + 1`
done

echo '  *'$1'KeyBinding[] = {'

m=0
while [ $m -lt $n ]
do
  echo '    &'$1'KeyBinding'$m','
  m=`expr $m + 1`
done

echo '    NULL};'
