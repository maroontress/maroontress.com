/*
	$Id: convert.h,v 1.1 2000/10/03 18:45:24 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

extern void (*ConvertBranch[])(Connection *, InputContext *,
			       XIM_FORWARD_EVENT *);
