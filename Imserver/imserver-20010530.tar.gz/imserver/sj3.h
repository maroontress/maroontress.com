/*
	$Id: sj3.h,v 1.2 2001/05/23 14:59:50 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

extern Engine * Sj3Engine;
