/*
	$Id: status.h,v 1.3 2001/02/12 12:10:24 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void CommitStatus(Connection *, InputContext *);
void DrawStatusWindow(XExposeEvent *, InputContext *);
void LoadStatusPreference(Display *, char *, char *);
