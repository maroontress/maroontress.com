/*
	$Id: predict.h,v 1.1 2001/05/07 20:12:53 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

void LoadPredictionPreference(Display *, char *, char *);
void RecordCommittedPhrase(wchar_t *, wchar_t *);
Phrase * PredictedPhrase(SylText *);

void CommitPrediction(Connection *, InputContext *);
void ClearPrediction(Connection *, InputContext *);
void FocusInPrediction(Connection *, InputContext *);
void FocusOutPrediction(Connection *, InputContext *);

