/*
	$Id: parse.c,v 1.1 2000/10/03 18:46:02 syl Exp $

	Copyright (C) 1997 Syllabub
	Maroontress Fast Software.
*/

#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "parse.h"

int ParseErrorCode;
int ParseErrorLine;

Parse *
OpenParse(char *file, char **reserved_keywords)
{
    Parse *p;

    if ((p = (Parse *)malloc(sizeof(Parse))) == NULL) {
	ParseErrorCode = PARSE_TOO_SHORT_MEMORY;
	return (NULL);
    }
    p->line = 1;
    p->fp = stdin;
    p->reserved_keywords = reserved_keywords;
    if (file != NULL && (p->fp = fopen(file, "r")) == NULL) {
	free(p);
	ParseErrorCode = PARSE_CANNOT_OPEN;
	return (NULL);
    }
    return (p);    
}

void
CloseParse(Parse *p)
{
    if (p == NULL)
	return;
    fclose(p->fp);
    free(p);
}

int
GetChar(Parse *p)
{
    int c;

    if ((c = getc(p->fp)) == '\n')
	++(p->line);
    return (c);
}

int
UngetChar(int c, Parse *p)
{
    if (c == '\n')
	--(p->line);
    return (ungetc(c, p->fp));
}

static int
IsDelimiter(int c)
{
    return (strchr(" \t", c) != NULL);
}

static int
IsFirstName(int c)
{
    return (isalpha(c) || c == '_');
}

static int
IsName(int c)
{
    return (isalnum(c) || c == '_');
}

static int
IsPuncuator(int c)
{
    return (strchr("[](){},;:", c) != NULL);
}


static int
GetOperator(Parse *p, char *buf, int c)
{
    int w;

    *buf++ = c;
    if (c == '-') { /* Group1: "X" "X>" "XX" "X=" */
	if ((w = GetChar(p)) == '>' || w == '-' || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("+&|=", c) != NULL) { /* Group2: "X" "XX" "X=" */
	if ((w = GetChar(p)) == c || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (c == '<' || c == '>') { /* Group3: "X" "XX" "X=" "XX=" */
	if ((w = GetChar(p)) == c)
	    *buf++ = w;
	else
	    UngetChar(w, p);
	if ((w = GetChar(p)) == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("*%^!", c) != NULL) { /* Group4: "X" "X=" */
	if ((w = GetChar(p)) == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (c == '.') { /* Group5: "X" "XXX" */
	if ((w = GetChar(p)) != c)
	    UngetChar(w, p);	
	else if ((w = GetChar(p)) != (*buf++ = c)) {
	    *buf = 0;
	    return (1); /* parse error */
	}
	else
	    *buf++ = c;
    }
    else if (c == '/') { /* Group5: "X" "X=" "X*" */
	if ((w = GetChar(p)) == '*' || w == '=')
	    *buf++ = w;
	else
	    UngetChar(w, p);
    }
    else if (strchr("#?\"\'", c) == NULL) {
	*buf = 0;
	return (1); /* parse error */
    }
    *buf = 0;
    return (0);
}

static int
GetWord(Parse *p, char *top, void (*drain)(int))
{
    int c, n = 0;
    char *buf = top;

    while (IsDelimiter(c = GetChar(p)) || c == '\n') {
	if (c == '\n')
	    ++n;
	if (drain != NULL) /* modified Apr 2, 1997 Syl */
	    drain(c);
    }
    if (n > 1) {
	UngetChar(c, p);
	buf[0] = '\n';
	buf[1] = 0;
	return (PARSE_EMPTYLINES);
    }
    else if (c == EOF) {
	*buf = 0;
	return (EOF);
    }
    else if (IsFirstName(c)) {
	for (n = 0, *buf++ = c; IsName(c = GetChar(p)) && n < 32; ++buf, ++n)
	    *buf = c;
	UngetChar(c, p);
	*buf = 0;
	if (n == 32 && IsName(c)) {
	    /* 32ʸ�������¤�ä���. Apr 3, 1997 Syl */
	    ParseErrorCode = PARSE_TOO_LONG_KEYWORD;
	    ParseErrorLine = p->line;
	    return (PARSE_TOO_LONG_KEYWORD);
	}
	return (PARSE_KEYWORD);
    }
    else if (IsPuncuator(c)) {
	buf[0] = c;
	buf[1] = 0;
	return (PARSE_PUNCTUATOR);
    }
    else if (isdigit(c)) {
	*buf++ = c;
	if (c != '0') { /* 10����� */
	    while (isdigit(c = GetChar(p)))
		*buf++ = c;
	}
	else if (tolower(c = GetChar(p)) == 'x') { /* 16����� */
	    for (*buf++ = c; isxdigit(c = GetChar(p)); ++buf)
		*buf = c;
	}	    
	else if (isdigit(c)) { /* 8����� */
	    for (*buf++ = c; isdigit(c = GetChar(p)); ++buf)
		*buf = c;
	}
	/* �����Ǥʤ����0 */
	while (tolower(c) == 'u' || tolower(c) == 'l') { /* ������ */
	    *buf++ = c;
	    c = GetChar(p);
	}
	UngetChar(c, p);
	*buf = 0;
	return (PARSE_NUMBER);
    }
    else if (GetOperator(p, buf, c) == 0)
	return (PARSE_OPERATOR);
    else {
	ParseErrorCode = PARSE_UNKNOWN_OPERATOR;
	ParseErrorLine = p->line;
	return (PARSE_UNKNOWN_OPERATOR);
    }
}

static int
IsReservedKeyword(char *key, char **reserved)
{
    char **ptr;

    for (ptr = reserved; (*ptr) != NULL; ++ptr) {
	if (strcmp(*ptr, key) == 0)
	    return (1);
    }
    return (0);
}

int
GetToken(Parse *p, char *buf, void (*drain)(int))
{
    int type;

    type = GetWord(p, buf, drain);
    if (type == PARSE_KEYWORD && IsReservedKeyword(buf, p->reserved_keywords))
	return (PARSE_RESERVED);
    else if (type != PARSE_OPERATOR)
	return (type);
    else if (strcmp(buf, "#") == 0) /* preprocessor command */
	return (PARSE_CPPCMD);
    else if (strcmp(buf, "\"") == 0) /* string const*/
	return (PARSE_STRCONST);
    else if (strcmp(buf, "\'") == 0) /* char const */
	return (PARSE_CHARCONST);
    else if (strcmp(buf, "/*") == 0) /* comment */
	return (PARSE_COMMENT);
    else
	return (type);
}
