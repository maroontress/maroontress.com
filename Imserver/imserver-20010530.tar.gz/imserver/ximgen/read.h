/*
	$Id: read.h,v 1.1 2000/10/03 18:46:03 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

void PrintRead(FILE *, PacketList *);
