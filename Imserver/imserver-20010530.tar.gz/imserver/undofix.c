/*
	$Id: undofix.c,v 1.5 2001/05/23 14:56:18 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdlib.h>

#include "Resource.h"
#include "Text.h"

#include "phrase.h"
#include "connection.h"
#include "xim.h"
#include "leakdetect.h" /* only for Feedback[] */
#include "message.h"
#include "status.h"
#include "commit.h"
#include "predict.h"
#include "undofix.h"

static void
UndofixPreedit(Connection *con, InputContext *ic,
	       XIM_FORWARD_EVENT *ev __unused)
{
    InsertSylTextIntoSylText(ic->preedit, 0, ic->fixed);
    ic->caret = LengthOfSylText(ic->preedit);
    ic->preedit_draw->cancel(con, ic, 0, 0);
    CommitPrediction(con, ic);
}

static void
PassImmediately(Connection *con, InputContext *ic __unused,
		XIM_FORWARD_EVENT *ev)
{
    EchoXIMForwardEvent(con, ev);
}

static void
DoublePreconversionMode(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_DOUBLE;
    CommitStatus(con, ic);
}

static void
SinglePreconversionMode(Connection *con, InputContext *ic,
			XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_SINGLE;
    CommitStatus(con, ic);
}

static void
DirectInputMode(Connection *con, InputContext *ic,
		XIM_FORWARD_EVENT *ev __unused)
{
    ic->preconversion = PRECONVERSION_NONE;
    CommitStatus(con, ic);
}

void (*UndofixBranch[])(Connection *, InputContext *, XIM_FORWARD_EVENT *) = {
#include "imserverUndofix.branch"
};
