/*
	$Id: predict.c,v 1.4 2001/05/30 13:54:41 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <limits.h>
#ifdef linux
#include <db_185.h>
#else
#include <db.h>
#endif
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <pwd.h>
#include <unistd.h>

#define HAS_BSD_OPEN (!defined(_POSIX_SOURCE) \
		      && defined(O_SHLOCK) && defined(O_EXLOCK))

#if HAS_BSD_OPEN
#define READ_DB_FLAGS (O_RDONLY | O_SHLOCK)
#define WRITE_DB_FLAGS (O_CREAT | O_RDWR | O_EXLOCK)
#else
#include <sys/file.h>
#define READ_DB_FLAGS O_RDONLY
#define WRITE_DB_FLAGS (O_CREAT | O_RDWR)
#endif /* HAS_BSD_OPEN */

#include "Resource.h"
#include "WCString.h"
#include "Text.h"

#include "phrase.h"
#include "heap.h"
#include "leakdetect.h"
#include "connection.h"
#include "predict.h"

static SylSetting
    CandidateBounds = {"maximumPredictions", "MaximumPredictions", "6", NULL},
    DictionaryPath = {"predictionDatabase", "PredictionDatabase", "", NULL};

static char *file;
static int bounds;

void
LoadPredictionPreference(Display *disp, char *name, char *class)
{
    struct passwd *user;
    char *dbfile = "/.imserver-prediction.db";
    int len;

    GetSylSetting(disp, name, class, &CandidateBounds);
    if ((bounds = atoi(CandidateBounds.spec)) <= 0)
	bounds = atoi(CandidateBounds.orig);

    GetSylSetting(disp, name, class, &DictionaryPath);
    if (strlen(DictionaryPath.spec) > 0) {
	file = DictionaryPath.spec;
	return;
    }
    if ((user = getpwuid(getuid())) == NULL) {
	file = NULL;
	return;
    }
    len = strlen(user->pw_dir) + strlen(dbfile);
    if ((file = (char *)malloc(len + 1)) == NULL) {
	return;
    }
    sprintf(file, "%s%s", user->pw_dir, dbfile);
}

struct HeapCell {
    char *str;
    char *ref; /* ptr == str + strlen(str) + 1 */
    time_t stamp;
};

static int
Compare(HeapCell p, HeapCell q)
{
    return ((int)(q->stamp - p->stamp));
}

static void
CreateKeyToRecord(wchar_t *head, wchar_t *tail, DBT *key)
{
    int bytes, headlen, taillen, headsize, tailsize;
    char *mbs;

    headlen = wstrlen(head);
    taillen = wstrlen(tail);
    bytes = sizeof(MB_LEN_MAX) * (headlen + taillen + 1);
    if ((mbs = (char *)alloca(bytes)) == NULL) {
	key->data = NULL;
	return;
    }
    headsize = wcstombs(mbs, head, bytes) + 1;
    tailsize = wcstombs(mbs + headsize, tail, bytes - headsize) + 1;
    key->size = headsize + tailsize;
    if ((key->data = malloc(key->size)) == NULL)
	return;
    memcpy(key->data, mbs, key->size);
}

void
RecordCommittedPhrase(wchar_t *pre, wchar_t *post)
{
    const int flags = WRITE_DB_FLAGS;
    const int mode = S_IRUSR | S_IWUSR;
    DB *db;
    DBT key, val;
    time_t stamp;
    
    CreateKeyToRecord(pre, post, &key);
    if (key.data == NULL)
	return;

    if ((db = dbopen(file, flags, mode, DB_BTREE, NULL)) != NULL) {
	stamp = time(NULL);
	val.data = (void *)&stamp;
	val.size = sizeof(stamp);
#if !HAS_BSD_OPEN
	flock(db->fd(db), LOCK_EX);
#endif
	db->put(db, &key, &val, 0);
	db->close(db);
    }
    free(key.data);
}

static HeapCell
CreateHeapCell(DBT *key, DBT *val)
{
    HeapCell v;
    char *str = (char *)key->data;
    time_t stamp = *((time_t *)val->data);
    int mid, len;
    
    if ((v = (HeapCell)malloc(sizeof(*v))) == NULL)
	return NULL;
    mid = strlen(str) + 1;
    len = mid + strlen(str + mid) + 1;
    if ((v->str = (char *)malloc(len)) == NULL) {
	free(v);
	return NULL;
    }
    memcpy(v->str, str, len);
    v->ref = v->str + mid;
    v->stamp = stamp;
    return v;
}

static void
FreeHeapCell(HeapCell v)
{
    free(v->str);
    free(v);
}

static Heap *
CreatePredictedHeap(char *pre)
{
    const int flags = READ_DB_FLAGS;
    const int mode = S_IRUSR | S_IWUSR;
    unsigned int len;
    int s;
    DB *db;
    DBT key, val;
    Heap *h;
    HeapCell v;
    
    if (pre == NULL)
	return NULL;
    if ((h = CreateHeap(Compare)) == NULL)
	return NULL;
    if ((db = dbopen(file, flags, mode, DB_BTREE, NULL)) == NULL) {
	FreeHeap(h);
	return NULL;
    }
    len = strlen(pre);
    key.data = (char *)pre;
    key.size = len;
#if !HAS_BSD_OPEN
    flock(db->fd(db), LOCK_SH);
#endif
    for (s = db->seq(db, &key, &val, R_CURSOR);
	 s == 0 && key.size > len && strncmp((char *)key.data, pre, len) == 0
	     && (v = CreateHeapCell(&key, &val)) != NULL;
	 s = db->seq(db, &key, &val, R_NEXT)) {
	InsertIntoHeap(h, v);
    }
    db->close(db);
    return (h);
}

static int
IsUniqueCandidate(Candidate *top, SylText *txt)
{ 
    Candidate *p;

    for (p = top; p && CompareSylText(p->applicant, txt); p = p->next)
	;
    return (p == NULL);
}

Phrase *
PredictedPhrase(SylText *text)
{
    unsigned char *mbs;
    Phrase *p;
    Heap *h;
    HeapCell v;
    Candidate *ptr;
    SylText *t;
    int n;

    mbs = CreateMBStringFromSylText0(text);
    if ((h = CreatePredictedHeap(mbs)) == NULL) {
	free(mbs);
	return NULL;
    }
    free(mbs);
    if ((p = (Phrase *)ldmalloc(sizeof(Phrase))) == NULL) {
	while ((v = TakeMinOfHeap(h)) != NULL)
	    FreeHeapCell(v);
	FreeHeap(h);
	return NULL;
    }
    p->next = NULL;
    p->prev = NULL;
    p->offset = 0;
    p->length = LengthOfSylText(text);
    p->original = p->length;
    p->chosen = NULL;
    p->predicted = True;
    p->top = NULL;
    ptr = NULL;
    for (n = 0; n < bounds && (v = TakeMinOfHeap(h)) != NULL; ++n) {
	t = CreateSylTextFromMBString(v->ref, False);
	if (IsUniqueCandidate(p->top, t)) {
	    if (ptr == NULL) {
		p->top = CreateCandidate(t);
		ptr = p->top;
	    }
	    else {
		ptr->next = CreateCandidate(t);
		ptr = ptr->next;
	    }
	    ptr->phonetic = CreateSylTextFromMBString(v->str, False);
	}
	FreeSylText(t);
	FreeHeapCell(v);
    }
    while ((v = TakeMinOfHeap(h)) != NULL) {
	FreeHeapCell(v);
    }
    FreeHeap(h);
    if (ptr == NULL) {
	p->top = CreateCandidate(text);
    }
    text = p->top->applicant;
    p->chosen = DuplicateSylText(text);
    p->applicant = DuplicateSylText(text);
    return (p);
}

static void
SetPredictSignature(Display *disp, unsigned short im, unsigned short ic)
{
    XTextProperty t;
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREDICT_SIGNATURE", False);
    char head[] = "syl", buf[sizeof(head) + 8], *ptr = buf;

    sprintf(ptr, "%s%04x%04x", head, im, ic);
    if (XStringListToTextProperty(&ptr, 1, &t) < 0) {
	return;
    }
    XSetTextProperty(disp, root, &t, atom);
    XFree(t.value);
}

static int
IsPredictSignature(Display *disp, unsigned short im, unsigned short ic)
{
    XTextProperty t;
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREDICT_SIGNATURE", False);
    char head[] = "syl", buf[sizeof(head) + 8], *ptr = buf, **list;
    int n_lists, result;

    sprintf(ptr, "%s%04x%04x", head, im, ic);
    if (XGetTextProperty(disp, root, &t, atom) == 0) {
        XDeleteProperty(disp, root, atom);
        return (False);
    } 
    if (XTextPropertyToStringList(&t, &list, &n_lists) < 0) {
        XFree(t.value);
        return (False);
    }
    XFree(t.value);
    if (n_lists <= 0) {
	XFreeStringList(list);
        return (False);
    }
    result = (strcmp(*list, ptr) == 0);
    XFreeStringList(list);
    return (result);
}

static void
SetPredictString(Display *disp, char **mbs, int num)
{
    XICCEncodingStyle style = XCompoundTextStyle;
    XTextProperty t;
    Window root = DefaultRootWindow(disp);
    Atom atom = XInternAtom(disp, "XIM_PREDICT_STRING", False);

    if (mbs == NULL || num == 0) {
	XDeleteProperty(disp, root, atom);
	return;
    }
    if (XmbTextListToTextProperty(disp, mbs, num, style, &t) < 0) {
	return;
    }
    XSetTextProperty(disp, root, &t, atom);
    XFree(t.value);
}

static int
CreatePredictedMBStringList(SylText *text, char ***ptr, int *num)
{
    unsigned char *mbs;
    Heap *h;
    HeapCell v;
    char **p;
    int n;

    mbs = CreateMBStringFromSylText0(text);
    if ((h = CreatePredictedHeap(mbs)) == NULL) {
	free(mbs);
	return False;
    }
    free(mbs);

    if ((*num = NodesOfHeap(h)) > bounds) {
	*num = bounds;
    }
    if ((*ptr = (char **)malloc(sizeof(char *) * (*num + 1))) == NULL) {
	while ((v = TakeMinOfHeap(h)) != NULL)
	    FreeHeapCell(v);
	FreeHeap(h);
	return False;
    }

    for (p = *ptr, n = 0; n < bounds && (v = TakeMinOfHeap(h)) != NULL; ++n) {
	*p++ = strdup(v->ref);
	FreeHeapCell(v);
    }
    while ((v = TakeMinOfHeap(h)) != NULL) {
	FreeHeapCell(v);
    }
    *p = NULL;
    FreeHeap(h);
    return True;
}

static void
FreePredictedMBStringList(char **ptr)
{
    char **p;

    for (p = ptr; *p; ++p) {
	free(*p);
    }
    free(ptr);
}

void
CommitPrediction(Connection *con, InputContext *ic)
{
    char **ptr;
    int num;

    if (CreatePredictedMBStringList(ic->preedit, &ptr, &num) == False) {
	SetPredictString(con->disp, NULL, 0);
	return;
    }
    SetPredictString(con->disp, ptr, num);
    FreePredictedMBStringList(ptr);
}

void
ClearPrediction(Connection *con, InputContext *ic __unused)
{
    SetPredictString(con->disp, NULL, 0);
}

void
FocusInPrediction(Connection *con, InputContext *ic)
{
    SetPredictSignature(con->disp, con->im_id, ic->ic_id);
    CommitPrediction(con, ic);
}

void
FocusOutPrediction(Connection *con, InputContext *ic)
{
    if (IsPredictSignature(con->disp, con->im_id, ic->ic_id)) {
	SetPredictString(con->disp, NULL, 0);
    }
}
