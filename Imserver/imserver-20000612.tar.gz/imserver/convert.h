extern void (*ConvertBranch[])(Connection *, InputContext *,
			       XIM_FORWARD_EVENT *);
