/*
        read.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "read.h"

static void
InsertPAD(FILE *fp)
{
    fprintf(fp, "\tq->c += (4 - ((q->c - q->s) %% 4)) %% 4;\n");
}

static int
IsCardinal(char *name)
{
    return (strcmp(name, "CARD8") == 0
	    || strcmp(name, "CARD16") == 0
	    || strcmp(name, "CARD32") == 0);
}

static void
ReadAny(FILE *fp, char *name, char *member)
{
    if (IsCardinal(name)) {
	fprintf(fp, "\t" "p->%s = *((%s *)q->c)++;\n", member, name);
    }
    else if (strcmp(name, "XEVENT") == 0) {
	fprintf(fp,
		"\t" "memcpy(&(p->%s), (XEVENT *)q->c, sizeof(XEVENT));\n"
		"\t" "q->c += sizeof(XEVENT);\n",
		member);
    }
    else {
	fprintf(fp, "\t" "Read_%s(&(p->%s), q);\n", name, member);
    }
}

static void
AllocateArray(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "p->%s.num = *((CARD16 *)q->c)++;\n", member);
    InsertPAD(fp);
    fprintf(fp, "\t"
	    "p->%s.val = (%s **)ldmalloc(sizeof(%s *) * (p->%s.num + 1));\n",
	    member, name, name, member);
    fprintf(fp,
	    "\t" "for (k = 0; k < p->%s.num; ++k) {\n"
	    "\t\t" "p->%s.val[k] = (%s *)ldmalloc(sizeof(%s));\n",
	    member, member, name, name);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "*(p->%s.val[k]) = *((%s *)q->c)++;\n",
		member, name);
    }
    else {
	fprintf(fp, "\t\t" "Read_%s(p->%s.val[k], q);\n",
		name, member);
    }
    fprintf(fp, "\t" "}\n");
}

static void
AllocateList(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "k = *((CARD16 *)q->c)++;\n");
    if (!IsCardinal(name))
	InsertPAD(fp);
    fprintf(fp,
	    "\t" "p->%s = NULL;\n"
	    "\t" "for (c = &(p->%s), b = q->c; q->c - b < k;"
	    " c = &((*c)->next)) {\n"
	    "\t\t" "(*c) = (LIST *)ldmalloc(sizeof(LIST));\n"
	    "\t\t" "(*c)->data = (%s *)ldmalloc(sizeof(%s));\n"
	    "\t\t" "(*c)->next = NULL;\n", member, member, name, name);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "*((%s *)(*c)->data) = *((%s *)q->c)++;\n",
		name, name);
    }
    else {
	fprintf(fp, "\t\t" "Read_%s((*c)->data, q);\n", name);
    }
    fprintf(fp, "\t" "}\n");
}

static void
AllocateMulti(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "p->%s.num = *((CARD16 *)q->c)++;\n", member);
    fprintf(fp, "\t" "p->%s.num /= sizeof(%s);\n", member, name);
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t"
	    "p->%s.val = (%s *)ldmalloc(sizeof(%s) * (p->%s.num + 1));\n",
	    member, name, name, member);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    fprintf(fp, "\t\t" "p->%s.val[k] = *((%s *)q->c)++;\n", member, name);
}

void
PrintRead(FILE *fp, PacketList *pl)
{
    int n;
    Type *t;
    Packet *ptr;

    fprintf(fp,
            "\n"
            "static void\n"
            "Read_STR(STR *p, Chunk *q)\n"
            "{\n"
            "\t" "p->len = *((CARD8 *)q->c)++;\n"
            "\t" "if ((p->val = (STRING8)ldmalloc(sizeof(CARD8)"
	    " * (p->len + 1))) != NULL) {\n"
	    "\t\t" "memcpy(p->val, q->c, p->len);\n"
	    "\t\t" "p->val[p->len] = 0;\n"
	    "\t" "}\n"
	    "\t" "q->c += p->len;\n"
	    "}\n"
	    "\n"
            "static void\n"
            "Read_STRING(STRING *p, Chunk *q)\n"
            "{\n"
            "\t" "p->len = *((CARD16 *)q->c)++;\n"
            "\t" "if ((p->val = (STRING8)ldmalloc(sizeof(CARD8)"
	    " * (p->len + 1)))"
	    " != NULL) "
	    "{\n"
	    "\t\t" "memcpy(p->val, q->c, p->len);\n"
	    "\t\t" "p->val[p->len] = 0;\n"
	    "\t" "}\n"
	    "\t" "q->c += p->len;\n"
	    "\t" "q->c += (4 - ((q->c - q->s) %% 4)) %% 4;\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Write)
	    continue;
	fprintf(fp,
		"\n"
		"void\n"
		"Read_%s(%s *p, Chunk *q)\n"
		"{\n",
		ptr->type, ptr->type);
	n = 0;
	for (t = ptr->head; t != NULL; t = t->next)
	    n |= (1 << t->is_list);
	if (n > 1) {
	    fprintf(fp, "\t" "int k;\n");
	    if (n & (1 << Listof)) {
		fprintf(fp, "\t" "LIST **c;\n");
		fprintf(fp, "\t" "CARD8 *b;\n");
	    }
	    fprintf(fp, "\n");
	}
	for (t = ptr->head; t != NULL; t = t->next) {
	    if (strcmp(t->name, "PAD") == 0)
		InsertPAD(fp);
	    else if (t->is_list == Array)
		AllocateArray(fp, t->name, t->member);
	    else if (t->is_list == Listof)
		AllocateList(fp, t->name, t->member);
	    else if (t->is_list == Multi)
		AllocateMulti(fp, t->name, t->member);
	    else
		ReadAny(fp, t->name, t->member);
	}
	fprintf(fp, "}\n");
    }
}
