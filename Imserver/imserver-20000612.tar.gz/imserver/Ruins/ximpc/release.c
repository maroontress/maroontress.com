/*
        release.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "release.h"

static int
IsCardinal(char *name)
{
    return (strcmp(name, "CARD8") == 0
	    || strcmp(name, "CARD16") == 0
	    || strcmp(name, "CARD32") == 0);
}

static void
FreeAny(FILE *fp, char *name, char *member, int need_release)
{
    if (!IsCardinal(name) && strcmp(name, "XEVENT") != 0 && need_release)
	fprintf(fp, "\t" "Release_%s(&(p->%s));\n", name, member);
}

static void
FreeArray(FILE *fp, char *name, char *member, int need_release)
{
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k) {\n", member);
    if (IsCardinal(name))
	fprintf(fp, "\t\t" "ldfree(p->%s.val[k]);\n", member);
    else if (need_release)
	fprintf(fp, "\t\t" "Release_%s(p->%s.val[k]);\n", name, member);
    fprintf(fp, "\t" "}\n");
    fprintf(fp, "\t" "ldfree(p->%s.val);\n", member);
}

static void
FreeList(FILE *fp, char *name, char *member, int need_release)
{
    fprintf(fp, "\t" "for (c = p->%s; c != NULL; c = next) {\n", member);
    if (IsCardinal(name))
	fprintf(fp, "\t\t" "ldfree(c->data);\n");
    else if (need_release)
	fprintf(fp, "\t\t" "Release_%s(c->data);\n", name);
    fprintf(fp, "\t\t" "ldfree(c->data);\n");
    fprintf(fp, "\t\t" "next = c->next;\n");
    fprintf(fp, "\t\t" "ldfree(c);\n");
    fprintf(fp, "\t" "}\n");
}

static void
FreeMulti(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "ldfree(p->%s.val);\n", member);
}

static int
NeedRelease(PacketList *pl, char *str)
{
    Packet *ptr;
    
    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (strcmp(str, ptr->type) == 0)
	    return (!ptr->cardinal_only);
    }
    return (1); /* NEVER REACHED */
}

void
PrintRelease(FILE *fp, PacketList *pl)
{
    int n, need_release;
    Type *t;
    Packet *ptr;

    fprintf(fp,
            "\n"
            "static void\n"
            "Release_STR(STR *p)\n"
            "{\n"
            "\t" "ldfree(p->val);\n"
	    "}\n"
	    "\n"
            "static void\n"
            "Release_STRING(STRING *p)\n"
            "{\n"
            "\t" "ldfree(p->val);\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL || ptr->cardinal_only)
	    continue;
	fprintf(fp,
		"\n"
		"static void\n"
		"Release_%s(%s *p)\n"
		"{\n",
		ptr->type, ptr->type);
	n = 0;
	for (t = ptr->head; t != NULL; t = t->next)
	    n |= (1 << t->is_list);
	if (n & (1 << Listof)) {
	    fprintf(fp, "\t" "LIST *c, *next;\n");
	    fprintf(fp, "\n");
	}
	else if (n & (1 << Array)) {
	    fprintf(fp, "\t" "int k;\n");
	    fprintf(fp, "\n");
	}
	
	for (t = ptr->head; t != NULL; t = t->next) {
	    need_release = NeedRelease(pl, t->name);
	    if (t->is_list == Array)
		FreeArray(fp, t->name, t->member, need_release);
	    else if (t->is_list == Listof)
		FreeList(fp, t->name, t->member, need_release);
	    else if (t->is_list == Multi)
		FreeMulti(fp, t->name, t->member);
	    else if (strcmp(t->name, "PAD") != 0)
		FreeAny(fp, t->name, t->member, need_release);
	}
	fprintf(fp, "}\n");
    }
}
