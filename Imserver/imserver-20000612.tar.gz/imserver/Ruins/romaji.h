int ConvertRomajiIntoKana(SylText *txt, int caret, int *back, int *forward);
