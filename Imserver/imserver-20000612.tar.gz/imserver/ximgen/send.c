/*
        send.c 1.0 for X11R6 & GNU C Compiler

        Copyright (C) 1999 Syllabub
        Maroontress Fast Software.
*/

#include <stdio.h>

#include "packet.h"
#include "send.h"

void
PrintSend(FILE *fp, PacketList *pl)
{
    Packet *ptr;

    fprintf(fp, "\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Read)
	    continue;
	fprintf(fp,
		"\n"
		"void\n"
		"Send_%s(%s *p, SerializedPacket **r, int *s)\n"
		"{\n"
		"\t" "int len;\n"
		"\n"
		"\t" "len = Sizeof_%s(p);\n"
		"\t" "*s = len;\n"
		"\t" "if ((*r = (SerializedPacket *)ldmalloc(*s)) != NULL) {\n"
		"\t\t" "Write_%s(p, *r);\n"
		"\t" "}\n"
		"}\n",
		ptr->type, ptr->type, ptr->type, ptr->type);
    }
}
