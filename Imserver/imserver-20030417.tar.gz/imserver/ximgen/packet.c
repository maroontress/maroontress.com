/*
	$Id: packet.c,v 1.1 2000/10/03 18:46:02 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdlib.h>
#include <string.h>

#include "packet.h"

Type *
CreateType(enum Modifier mod, char *name, char *member)
{
    Type *this;

    if ((this = (Type *)malloc(sizeof(Type))) == NULL)
	goto null_this;
    if ((this->name = strdup(name)) == NULL)
	goto null_this_name;
    if ((this->member = strdup(member)) == NULL)
	goto null_this_member;
    this->mod = mod;
    this->next = NULL;
    return (this);

null_this_member:
    free(this->name);
null_this_name:
    free(this);
null_this:
    return (NULL);
}

Packet *
CreatePacket(char *type, enum Category to_do)
{
    Packet *this;

    if ((this = (Packet *)malloc(sizeof(Packet))) == NULL)
	goto null_this;
    if ((this->type = strdup(type)) == NULL)
	goto null_this_type;
    this->to_do = to_do;
    this->cardinal_only = 0;
    this->next = NULL;
    this->head = NULL;
    this->tail = NULL;
    return (this);

null_this_type:
    free(this);
null_this:
    return (NULL);
}

void
AppendTypeToPacket(Packet *this, Type *type)
{
    if (this->head == NULL)
	this->head = type;
    else
	this->tail->next = type;
    this->tail = type;
}

PacketList *
CreatePacketList(void)
{
    PacketList *this;

    if ((this = (PacketList *)malloc(sizeof(PacketList))) == NULL)
	goto null_this;
    this->top = NULL;
    this->last = NULL;
    return (this);

null_this:
    return (NULL);
}

void
AddtoPacketList(PacketList *this, Packet *pac, int cardinal_only)
{
    pac->cardinal_only = cardinal_only;
    if (this->top == NULL)
	this->top = pac;
    else
	this->last->next = pac;
    this->last = pac;
}

int
IsAlreadyDefined(PacketList *this, char *type)
{
    Packet *p;

    for (p = this->top; p != NULL; p = p->next) {
	if (strcmp(p->type, type) == 0)
	    return (1);
    }
    return (0);
}

int
IsCardinalOnly(PacketList *this, char *type)
{
    Packet *p;

    for (p = this->top; p != NULL; p = p->next) {
	if (strcmp(p->type, type) == 0)
	    return (p->cardinal_only);
    }
    return (-1);
}
