/*
	$Id: sizeof.c,v 1.2 2003/03/16 14:16:21 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#include <stdio.h>
#include <string.h>

#include "packet.h"
#include "sizeof.h"

static void
InsertPAD(FILE *fp)
{
    fprintf(fp, "\t" "s += (4 - ((s) %% 4)) %% 4;\n");
}

static int
IsCardinal(char *name)
{
    return (strcmp(name, "CARD8") == 0
	    || strcmp(name, "CARD16") == 0
	    || strcmp(name, "CARD32") == 0);
}

static void
CountAny(FILE *fp, char *name, char *member)
{
    if (IsCardinal(name)) {
	/* fprintf(fp, "\t" "s += sizeof(%s);\n", name); */
	fprintf(fp, "\t" "s += sizeof(p->%s);\n", member);
    }
    else if (strcmp(name, "XEVENT") == 0) {
	fprintf(fp, "\t" "s += sizeof(XEVENT);\n");
    }
    else if (strcmp(name, "STRING") == 0) {
	fprintf(fp,
		"\t" "s += sizeof(CARD16);\n"
		"\t" "s += p->%s.len;\n",
		member);
	InsertPAD(fp);
    }
    else {
	fprintf(fp, "\t" "s += Sizeof_%s(&(p->%s));\n", name, member);
    }
}

static void
CountArray(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "s += sizeof(CARD16);\n");
    InsertPAD(fp);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "s += sizeof(%s);\n", name);
    }
    else {
	fprintf(fp, "\t\t" "s += Sizeof_%s(p->%s.val[0]);\n", name, member);
    }
}

static void
CountList(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "s += sizeof(CARD16);\n");
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t"
	    "for (c = p->%s; c != NULL; c = c->next) {\n", member);
    if (IsCardinal(name)) {
	fprintf(fp, "\t\t" "s += sizeof(%s);\n", name);
    }
    else {
	fprintf(fp, "\t\t" "s += Sizeof_%s(c->data);\n", name);
    }
    fprintf(fp, "\t" "}\n");
}

static void
CountMulti(FILE *fp, char *name, char *member)
{
    fprintf(fp, "\t" "s += sizeof(CARD16);\n");
    if (strcmp(name, "CARD16") != 0)
	InsertPAD(fp);
    fprintf(fp, "\t" "for (k = 0; k < p->%s.num; ++k)\n", member);
    fprintf(fp, "\t\t" "s += sizeof(%s);\n", name);
}

void
PrintSizeof(FILE *fp, PacketList *pl)
{
    int n;
    Type *t;
    Packet *ptr;

    fprintf(fp,
	    "\n"
            "int\n"
            "Sizeof_STRING(STRING *p)\n"
            "{\n"
	    "\t" "int s = 0;\n"
	    "\n"
	    "\t" "s += sizeof(CARD16);\n"
	    "\t" "s += p->len;\n"
	    "\t" "s += (4 - ((s) %% 4)) %% 4;\n"
	    "\t" "return (s);\n"
	    "}\n");

    for (ptr = pl->top; ptr != NULL; ptr = ptr->next) {
	if (ptr->head == NULL)
	    continue;
	if (ptr->to_do == Read)
	    continue;
	fprintf(fp,
		"\n"
		"%sint\n"
		"Sizeof_%s(%s *p)\n"
		"{\n"
		"\t" "int s = 0;\n",
		((ptr->to_do == Basic) ? "" : "static "),
		ptr->type, ptr->type);
	n = 0;
	for (t = ptr->head; t != NULL; t = t->next)
	    n |= (1 << t->mod);
	if (n > 1) {
	    if (n & (1 << Listof)) {
		fprintf(fp, "\t" "LIST *c;\n");
	    }
	    else {
		fprintf(fp, "\t" "int k;\n");
	    }
	}
	fprintf(fp, "\n");
	
	for (t = ptr->head; t != NULL; t = t->next) {
	    if (strcmp(t->name, "PAD") == 0)
		InsertPAD(fp);
	    else if (t->mod == Array)
		CountArray(fp, t->name, t->member);
	    else if (t->mod == Listof)
		CountList(fp, t->name, t->member);
	    else if (t->mod == Multi)
		CountMulti(fp, t->name, t->member);
	    else
		CountAny(fp, t->name, t->member);
	}
	fprintf(fp,
		"\t" "return (s);\n"
		"}\n");
    }
}
