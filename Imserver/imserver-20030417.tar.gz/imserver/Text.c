/*
	$Id: Text.c,v 1.6 2003/02/23 19:15:08 syl Exp $

	Copyright (C) 1998, 1999 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "WCString.h"
#include "Text.h"

SylText *
CreateSylTextFromMBString(const char *mbs, int eol)
{
    SylText *txt;
    wchar_t *wcs;
    int bytes, len;

    bytes = strlen(mbs) + 1;
    if ((wcs = (wchar_t *)alloca(sizeof(wchar_t) * bytes)) == NULL
        /*
	  ����: �ؿ�mbstowcs(wc_dst, mb_src, n_bytes)��3���ܤΰ����ˤϡ�
	  �̥�ʸ����ޤ᤿��������Ϳ���ʤ��ȡ��Ǹ�ˡ֥磻�ɥ���饯��ʸ��
	  ��Υ̥�ʸ���פ��ղä��ʤ����Ĥޤꡢ1���ܤΰ����ΥХåե���������
	  Ϳ���ʤ���Фʤ�ʤ���
        */
        || (len = mbstowcs(wcs, mbs, bytes)) < 0
        || (txt = (SylText *)malloc(sizeof(SylText))) == NULL) {
        return (NULL);
    }
    if ((txt->wcs = (wchar_t *)malloc(sizeof(wchar_t) * (len + 1))) == NULL) {
        free(txt);
        return (NULL);
    }
    wstrcpy(txt->wcs, wcs);
    txt->len = len;
    txt->eol = eol;
    return (txt);
}

SylText *
CreateSylTextFromWCString(const wchar_t *wcs, int eol)
{
    SylText *txt;
    
    if ((txt = (SylText *)malloc(sizeof(SylText))) == NULL)
	return (NULL);
    txt->len = wstrlen(wcs);
    txt->eol = eol;
    if ((txt->wcs = (wchar_t *)malloc((txt->len + 1) * sizeof(wchar_t)))
	== NULL) {
	free(txt);
	return (NULL);
    }
    wstrcpy(txt->wcs, wcs);
    return (txt);
}

void
FreeSylText(SylText *txt)
{
    free(txt->wcs);
    free(txt);
}

SylText *
DuplicateSylText(SylText *org)
{
    SylText *txt;

    if ((txt = (SylText *)malloc(sizeof(SylText))) == NULL)
	return (NULL);
    txt->len = org->len;
    txt->eol = org->eol;
    if ((txt->wcs = (wchar_t *)malloc((txt->len + 1) * sizeof(wchar_t)))
	== NULL) {
	free(txt);
	return (NULL);
    }
    wstrcpy(txt->wcs, org->wcs);
    return (txt);
}

wchar_t *
CreateWCStringFromSylText(SylText *txt, int bgn, int end)
{
    wchar_t *wcs;

    if ((wcs = (wchar_t *)malloc((end - bgn + 1) * sizeof(wchar_t))) == NULL)
	return (NULL);
    wstrncpy(wcs, txt->wcs + bgn, end - bgn);
    wcs[end - bgn] = 0;
    return (wcs);
}

wchar_t *
CreateWCStringFromSylText0(SylText *txt)
{
    wchar_t *wcs;

    if ((wcs = (wchar_t *)malloc((txt->len + 1) * sizeof(wchar_t))) == NULL)
	return (NULL);
    wstrcpy(wcs, txt->wcs);
    return (wcs);
}

char *
CreateMBStringFromSylText(SylText *txt, int bgn, int end)
{
    int bytes;
    char *mbs;
    wchar_t *wcs;

    if ((wcs = (wchar_t *)alloca((end - bgn + 1) * sizeof(wchar_t))) == NULL)
	return (NULL);
    wstrncpy(wcs, txt->wcs + bgn, end - bgn);
    wcs[end - bgn] = 0;

    bytes = MB_LEN_MAX * (end - bgn) + 1;
    if ((mbs = (char *)alloca(bytes)) == NULL
	/*
	  wcstombs()������ͤ�size_t������man�ڡ����ˤ���-1���֤�
	  ���Ȥ⤢�롣
	*/
	|| (int)wcstombs(mbs, wcs, bytes) < 0) {
        return (NULL);
    }
    return (strdup(mbs));
}

char *
CreateMBStringFromSylText0(SylText *txt)
{
    int bytes;
    char *mbs;

    bytes = MB_LEN_MAX * txt->len + 1;
    if ((mbs = (char *)alloca(bytes)) == NULL
	/*
	  wcstombs()������ͤ�size_t������man�ڡ����ˤ���-1���֤�
	  ���Ȥ⤢�롣
	*/
	|| (int)wcstombs(mbs, txt->wcs, bytes) < 0) {
        return (NULL);
    }
    return (strdup(mbs));
}

int
InsertWCharIntoSylText(SylText *txt, int n, wchar_t c)
{
    wchar_t *sum;
    int len;

    len = txt->len + 1;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return False;
    wstrncpy(sum, txt->wcs, n);
    sum[n] = c;
    wstrcpy(sum + n + 1, txt->wcs + n);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
    return True;
}

int
InsertWCStringIntoSylText(SylText *txt, int n, const wchar_t *p)
{
    wchar_t *sum;
    int len, add;

    add = wstrlen(p);
    len = txt->len + add;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return False;
    wstrncpy(sum, txt->wcs, n);
    wstrcpy(sum + n, p);
    wstrcpy(sum + n + add, txt->wcs + n);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
    return True;
}

int
InsertSylTextIntoSylText(SylText *txt, int n, SylText *sub, int bgn, int end)
{
    wchar_t *sum;
    int len, add;

    add = end - bgn;
    len = txt->len + add;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return False;
    wstrncpy(sum, txt->wcs, n);
    wstrncpy(sum + n, sub->wcs + bgn, add);
    wstrcpy(sum + n + add, txt->wcs + n);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
    return True;
}

int
InsertSylTextIntoSylText0(SylText *txt, int n, SylText *sub)
{
    wchar_t *sum;
    int len, add;

    add = sub->len;
    len = txt->len + add;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL)
	return False;
    wstrncpy(sum, txt->wcs, n);
    wstrcpy(sum + n, sub->wcs);
    wstrcpy(sum + n + add, txt->wcs + n);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
    return True;
}

void
DeleteCharOfSylText(SylText *txt, int n)
{
    wchar_t *sum;
    int len;

    if (txt->len <= 0 || txt->len <= n)
	return;
    len = txt->len - 1;
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL) {
	bcopy(txt + n + 1, txt + n, txt->len - n);
	txt->len = len;
	return;
    }
    wstrncpy(sum, txt->wcs, n);
    wstrcpy(sum + n, txt->wcs + n + 1);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
}

void
DeleteStringOfSylText(SylText *txt, int n, int m)
{
    wchar_t *sum;
    int len;

    if (txt->len <= 0 || n >= m || txt->len < m)
	return;
    len = txt->len - (m - n);
    if ((sum = (wchar_t *)malloc((len + 1) * sizeof(wchar_t))) == NULL) {
	bcopy(txt + m, txt + n, txt->len - (m - 1));
	txt->len = len;
	return;
    }
    wstrncpy(sum, txt->wcs, n); 
    wstrcpy(sum + n, txt->wcs + m);
    free(txt->wcs);
    txt->wcs = sum;
    txt->len = len;
}

void
ChangeEndOfLineSylText(SylText *txt, int eol)
{
    txt->eol = eol;
}

void
ReplaceCharOfSylText(SylText *txt, int n, wchar_t c)
{
    if (txt->len <= 0 || txt->len <= n)
	return;
    txt->wcs[n] = c;
}

wchar_t
GetCharOfSylText(SylText *txt, int n)
{
    return ((txt->len <= 0 || txt->len <= n) ? 0 : txt->wcs[n]);
}

/*
  head�θ��tail��Ϣ�뤷�����Ƥ�������SylText��������֤�.
*/
SylText *
ConcatAndCreateSylText(SylText *head, SylText *tail)
{
    wchar_t *s, *d;
    SylText *txt;
    
    if ((txt = (SylText *)malloc(sizeof(SylText))) == NULL)
	return (NULL);
    txt->len = LengthOfSylText(head) + LengthOfSylText(tail);
    txt->eol = EndOfLineSylText(tail);
    if ((txt->wcs = (wchar_t *)malloc((txt->len + 1) * sizeof(wchar_t)))
	== NULL) {
	free(txt);
	return (NULL);
    }
    d = txt->wcs;
    for (s = head->wcs; *s != 0; ++s)
	*d++ = *s;
    for (s = tail->wcs; *s != 0; ++s)
	*d++ = *s;
    *d = 0;
    return (txt);
}

/*
  txt��nʸ���ܤޤǤ����Ƥ�head�ˡ�nʸ���ܰʹߤ����Ƥ�tail�˺�������.
*/
void
SplitAndCreateSylTexts(SylText *txt, int n, int eol,
		       SylText **head, SylText **tail)
{
    if ((*head = (SylText *)malloc(sizeof(SylText))) != NULL) {
	(*head)->wcs = CreateWCStringFromSylText(txt, 0, n);
	(*head)->len = n;
	(*head)->eol = eol;
    }
    if ((*tail = (SylText *)malloc(sizeof(SylText))) != NULL) {
	(*tail)->wcs = CreateWCStringFromSylText(txt, n, LengthOfSylText(txt));
	(*tail)->len = LengthOfSylText(txt) - n;
	(*tail)->eol = EndOfLineSylText(txt);
    }
}

int
CompareSylText(SylText *t1, SylText *t2)
{
    return (wstrcmp(t1->wcs, t2->wcs));
}

int
GetCharPositionInSylText(SylText *t, int bgn, int end, wchar_t c)
{
    int n;

    for (n = bgn; n < end && t->wcs[n] != c; ++n)
	;
    return (n);
}

int
GetCharPositionInSylText0(SylText *t, wchar_t c)
{
    int n;

    for (n = 0; n < t->len && t->wcs[n] != c; ++n)
	;
    return (n);
}

int
SylTextEscapement(XFontSet fs, SylText *txt, int bgn, int end)
{
    return XwcTextEscapement(fs, txt->wcs + bgn, end - bgn);
}

int
SylTextEscapement0(XFontSet fs, SylText *txt)
{
    return XwcTextEscapement(fs, txt->wcs, txt->len);
}

void
DrawSylText(Display *disp, Drawable d, XFontSet fs, GC gc, int x, int y,
	    SylText *txt, int bgn, int end)
{
    XwcDrawString(disp, d, fs, gc, x, y, txt->wcs + bgn, end - bgn);
}

void
DrawSylText0(Display *disp, Drawable d, XFontSet fs, GC gc, int x, int y,
	     SylText *txt)
{
    XwcDrawString(disp, d, fs, gc, x, y, txt->wcs, txt->len);
}

void
DrawImageSylText(Display *disp, Drawable d, XFontSet fs, GC gc, int x, int y,
		 SylText *txt, int bgn, int end)
{
    XwcDrawImageString(disp, d, fs, gc, x, y, txt->wcs + bgn, end - bgn);
}

void
DrawImageSylText0(Display *disp, Drawable d, XFontSet fs, GC gc, int x, int y,
		  SylText *txt)
{
    XwcDrawImageString(disp, d, fs, gc, x, y, txt->wcs, txt->len);
}
