/*
	$Id: trigger.h,v 1.1 2000/10/03 18:45:29 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

void LoadTriggerKeys(Display *, char *, char *, SylSetting *, XIMTRIGGERKEY *);
