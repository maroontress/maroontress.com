/*
	$Id: preconv.c,v 1.5 2003/03/10 15:33:15 syl Exp $

	Copyright (C) 1999, 2000, 2001, 2003 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"

#include "preconv.h"

typedef struct ConversionRule {
    struct ConversionRule *next;
    wchar_t *src_wcs;
    int src_len;
    wchar_t *dst_wcs;
    int dst_len;
} ConversionRule;

static void
FreeConversionRule(ConversionRule *top)
{
    ConversionRule *next;

    for (; top != NULL; top = next) {
	next = top->next;
	free(top->src_wcs);
	free(top->dst_wcs);
	free(top);
    }
}

static ConversionRule *
AddToConversionRule(ConversionRule *top, char *src, char *dst)
{
    ConversionRule *map, *p;
    SylText *txt;

    if ((map = (ConversionRule *)malloc(sizeof(ConversionRule))) == NULL)
	return (NULL);
    map->next = NULL;
    map->src_wcs = NULL;
    map->dst_wcs = NULL;

    if ((txt = CreateSylTextFromMBString(src, False)) == NULL) {
	FreeConversionRule(map);
	return (NULL);
    }
    map->src_len = LengthOfSylText(txt);
    map->src_wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);

    if ((txt = CreateSylTextFromMBString(dst, False)) == NULL) {
	FreeConversionRule(map);
	return (NULL);
    }
    map->dst_len = LengthOfSylText(txt);
    map->dst_wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);

    if (top == NULL || top->src_len <= map->src_len) {
	map->next = top;
	return (map);
    }
    for (p = top; p->next != NULL && p->next->src_len > map->src_len;
	 p = p->next) {
	continue;
    }
    if (p->next != NULL) {
	map->next = p->next;
    }
    p->next = map;
    return (top);
}

typedef struct {
    char *ptr;
    int line;
} StringParse;

static int
GetChar(StringParse *p)
{
    int c;

    if ((c = *(p->ptr)) == 0)
	return (EOF);
    ++(p->ptr);
    if (c == '\n')
	++(p->line);
    return (c);
}

static int
IsDelimiter(int c)
{
    return (strchr(" \t\n", c) != NULL);
}

#define BEGINNING_OF_STRING 0
#define EQUAL_OPERATOR 1
#define UNKNOWN_OPERATOR 2

static int
GetNextWord(StringParse *p, int *buf)
{
    int c;

    while ((c = GetChar(p)) != EOF && IsDelimiter(c))
	;
    if (c == EOF) {
	*buf = 0;
	return (EOF);
    }
    else if (c == '"') {
	*buf = c;
	return (BEGINNING_OF_STRING);
    }
    else if (c == '=') {
	*buf = c;
	return (EQUAL_OPERATOR);
    }
    *buf = c;
    return (UNKNOWN_OPERATOR);
}

static int
CreateString(StringParse *p, char **str)
{
    int n, len;
    char *ptr;

    for (len = 0, ptr = p->ptr; *ptr != 0; ++ptr) {
	if (*ptr == '"')
	    break;
	if (*ptr == '\\' && *++ptr == 0)
	    return (-1);
	++len;
    }
    if (*ptr != '"')
	return (-1);
    if ((*str = malloc(len + 1)) == NULL)
	return (len);
    for (ptr = p->ptr, n = 0; n < len; ++ptr, ++n) {
	if (*ptr == '\\')
	    ++ptr;
	(*str)[n] = *ptr;
    }
    (*str)[n] = 0;
    p->ptr = ptr + 1;
    return (len);
}

static ConversionRule *
LoadConversionRule(char *name, SylSetting *map)
{
    ConversionRule *rule = NULL, *next;
    StringParse p;
    int type, c;
    char *src, *dst;

    p.ptr = map->spec;
    p.line = 1;
    while ((type = GetNextWord(&p, &c)) != EOF) {
	if (type != BEGINNING_OF_STRING) {
	    fprintf(stderr, "%s.%s: line %d, unexpected character `%c'.\n",
		    name, map->name, p.line, c);
	    break;
	}
	else if ((type = CreateString(&p, &src)) < 0) {
	    fprintf(stderr, "%s.%s: line %d, unterminated string.\n",
		    name, map->name, p.line);
	    break;
	}
	else if (src == NULL) {
	    fprintf(stderr, "%s.%s: line %d, too long string.\n",
		    name, map->name, p.line);
	    break;
	}
	else if (type == 0) {
	    fprintf(stderr, "%s.%s: line %d, zero-length string.\n",
		    name, map->name, p.line);
	    free(src);
	    break;
	}
	else if ((type = GetNextWord(&p, &c)) != EQUAL_OPERATOR) {
	    fprintf(stderr, "%s.%s: line %d, unexpected character `%c', "
		    "expected `='.\n", name, map->name, p.line, c);
	    free(src);
	    break;
	}
	else if ((type = GetNextWord(&p, &c)) != BEGINNING_OF_STRING) {
	    fprintf(stderr, "%s.%s: line %d, unexpected character `%c'.\n",
		    name, map->name, p.line, c);
	    free(src);
	    break;
	}
	else if ((type = CreateString(&p, &dst)) < 0) {
	    fprintf(stderr, "%s.%s: line %d, unterminated string.\n",
		    name, map->name, p.line);
	    free(src);
	    break;
	}
	else if (dst == NULL) {
	    fprintf(stderr, "%s.%s: line %d, too long string.\n",
		    name, map->name, p.line);
	    free(src);
	    break;
	}
	else if (type == 0) {
	    fprintf(stderr, "%s.%s: line %d, zero-length string.\n",
		    name, map->name, p.line);
	    free(src);
	    free(dst);
	    break;
	}
	else if ((next = AddToConversionRule(rule, src, dst)) == NULL) {
	    fprintf(stderr, "%s.%s: line %d, can't add rule.\n",
		    name, map->name, p.line);
	    free(src);
	    free(dst);
	    break;
	}
	rule = next;
	free(src);
	free(dst);
    }
    return (rule);
}

static wchar_t *
FindMappedString(ConversionRule *ptr, wchar_t *wcs, int len,
		 int *srclen, int *dstlen)
{
    int m;

    for (; ptr != NULL; ptr = ptr->next) {
	if ((m = len - ptr->src_len) < 0)
	    continue;
	if (wstrcmp(wcs + m, ptr->src_wcs) == 0) {
	    *srclen = ptr->src_len;
	    *dstlen = ptr->dst_len;
	    return (ptr->dst_wcs);
	}
    }
    return (NULL);
}

static int
Convert(ConversionRule *rule, SylText *txt, int caret, int *back, int *forward)
{
    wchar_t *wcs, *xch;

    wcs = CreateWCStringFromSylText(txt, 0, caret);
    if ((xch = FindMappedString(rule, wcs, caret, back, forward)) == NULL) {
	free(wcs);
	return (False);
    }
    DeleteStringOfSylText(txt, caret - *back, caret);
    InsertWCStringIntoSylText(txt, caret - *back, xch);
    free(wcs);
    return (True);
}

static ConversionRule *BasicRule = NULL;
static ConversionRule *FinalRule = NULL;

void
LoadPreconversionRule(Display *disp, char *name, char *class,
		      SylSetting *basic, SylSetting *final)
{
    GetSylSetting(disp, name, class, basic);
    BasicRule = LoadConversionRule(name, basic);

    GetSylSetting(disp, name, class, final);
    FinalRule = LoadConversionRule(name, final);
}

int
Preconvert(SylText *txt, int caret, int *back, int *forward, int is_final)
{
    ConversionRule *rule = (is_final ? FinalRule : BasicRule);

    return (Convert(rule, txt, caret, back, forward));
}

/* */

int
GetCharPosition(wchar_t *wcs, wchar_t c)
{
    int n;

    for (n = 0; wcs[n] != 0 && wcs[n] != c; ++n)
	;
    return (n);
}

static wchar_t
NormalReplacer(ConversionRule *r, wchar_t c)
{
    int pos;

    for (; r != NULL && (pos = GetCharPosition(r->src_wcs, c)) >= r->src_len;
	 r = r->next) {
	continue;
    }
    return ((r == NULL || pos >= r->dst_len) ? c : r->dst_wcs[pos]);
}

static wchar_t
ReverseReplacer(ConversionRule *r, wchar_t c)
{
    int pos;

    for (; r != NULL && (pos = GetCharPosition(r->dst_wcs, c)) >= r->dst_len;
	 r = r->next) {
	continue;
    }
    return ((r == NULL || pos >= r->src_len) ? c : r->src_wcs[pos]);
}

static void
ReplaceText(ConversionRule *rule, SylText *txt, int bgn, int end, int dir)
{
    int k, n;
    wchar_t (*replacer)(ConversionRule *, wchar_t);
    
    replacer = ((dir) ? NormalReplacer : ReverseReplacer);
    if ((n = LengthOfSylText(txt)) > end)
	n = end;
    for (k = bgn; k < n; ++k) {
	ReplaceCharOfSylText(txt, k, replacer(rule, GetCharOfSylText(txt, k)));
    }
}

static ConversionRule *SymbolSystem = NULL;

void
LoadSymbolSystemMapping(Display *disp, char *name, char *class,
			SylSetting *map)
{
    GetSylSetting(disp, name, class, map);
    SymbolSystem = LoadConversionRule(name, map);
}

void
ReplaceSymbolSystem(SylText *txt, int bgn, int end, int dir)
{
    ReplaceText(SymbolSystem, txt, bgn, end, dir);
}

static ConversionRule *SymbolWidth = NULL;

void
LoadSymbolWidthMapping(Display *disp, char *name, char *class,
		       SylSetting *map)
{
    GetSylSetting(disp, name, class, map);
    SymbolWidth = LoadConversionRule(name, map);
}

void
ReplaceSymbolWidth(SylText *txt, int bgn, int end, int dir)
{
    ReplaceText(SymbolWidth, txt, bgn, end, dir);
}
