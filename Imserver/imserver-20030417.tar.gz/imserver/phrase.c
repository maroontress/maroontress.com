/*
	$Id: phrase.c,v 1.9 2003/02/23 19:30:35 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "Resource.h"
#include "Text.h"
#include "WCString.h"
#include "leakdetect.h"
#include "preconv.h"
#include "phrase.h"
#include "engine.h"

static void
ReplacePhrase(Phrase *p, SylText *txt,
	      void (*replacer)(SylText *, int, int, int), int dir)
{
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    FreeSylText(p->chosen);
    p->chosen = CreateSylTextFromWCString(wcs, False);
    replacer(p->chosen, 0, LengthOfSylText(p->chosen), dir);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangeZenkakuPhrase(Phrase *p, SylText *txt)
{
    ReplacePhrase(p, txt, ReplaceSymbolWidth, True);
}

void
ChangeHankakuPhrase(Phrase *p, SylText *txt)
{
    ReplacePhrase(p, txt, ReplaceSymbolWidth, False);
}

void
ChangeHiraganaPhrase(Phrase *p, SylText *txt)
{
    ReplacePhrase(p, txt, ReplaceSymbolSystem, False);
}

void
ChangeKatakanaPhrase(Phrase *p, SylText *txt)
{
    ReplacePhrase(p, txt, ReplaceSymbolSystem, True);
}

void
ChangeNextRankOfPhrase(Phrase *p, SylText *txt)
{
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    ChangeNextRankOfPhraseWithEngine(p, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

void
ChangePrevRankOfPhrase(Phrase *p, SylText *txt)
{
    wchar_t *wcs;

    wcs = CreateWCStringFromSylText(txt, p->offset, p->offset + p->length);
    ChangePrevRankOfPhraseWithEngine(p, wcs);
    free(wcs); /* CreateWCStringFromSylText() */
}

Phrase *
CreateSinglePhrase(SylText *txt, int bgn, int end)
{
    wchar_t *wcs;
    Phrase *p;

    wcs = CreateWCStringFromSylText(txt, bgn, end);
    p = ConvertSinglePhraseWithEngine(wcs, bgn, end - bgn);
    free(wcs); /* CreateWCStringFromSylText() */
    return (p);
}

static Phrase *
CreateAnyPhrase(SylText *txt, int bgn, int end,
		void (*changer)(Phrase *, SylText *))
{
    wchar_t *wcs;
    Phrase *p;

    wcs = CreateWCStringFromSylText(txt, bgn, end);
    p = ConvertSinglePhraseWithEngine(wcs, bgn, end - bgn);
    changer(p, txt);
    free(wcs); /* CreateWCStringFromSylText() */
    return (p);
}

Phrase *
CreateHiraganaPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeHiraganaPhrase));
}    

Phrase *
CreateKatakanaPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeKatakanaPhrase));
}    

Phrase *
CreateZenkakuPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeZenkakuPhrase));
}    

Phrase *
CreateHankakuPhrase(SylText *txt, int bgn, int end)
{
    return (CreateAnyPhrase(txt, bgn, end, ChangeHankakuPhrase));
}    

Phrase *
CreatePhrase(SylText *txt, int bgn, int end)
{
    wchar_t *wcs;
    Phrase *p;

    wcs = CreateWCStringFromSylText(txt, bgn, end);
    p = ConvertWithEngine(wcs, bgn);
    free(wcs); /* CreateWCStringFromSylText() */
    return (p);
}

Candidate *
CreateCandidate(SylText *txt)
{
    Candidate *c;

    if ((c = (Candidate *)ldmalloc(sizeof(Candidate))) == NULL)
	return (NULL);
    c->applicant = DuplicateSylText(txt);
    c->phonetic = NULL;
    c->next = NULL;
    c->prev = NULL;
    return (c);
}

void
FreeCandidate(Candidate *top)
{
    Candidate *p, *next;

    for (p = top; p != NULL; p = next) {
	next = p->next;
	FreeSylText(p->applicant);
	if (p->phonetic != NULL) {
	    FreeSylText(p->phonetic);
	}
	ldfree(p);
    }
}

void
FreePhrase(Phrase *head)
{
    Phrase *p, *next;
    
    for (p = head; p != NULL; p = next) {
	next = p->next;
	FreeSylText(p->chosen);
	FreeSylText(p->applicant);
	FreeCandidate(p->head);
	ldfree(p);
    }
}

wchar_t *
CreateWCStringFromPhrase(Phrase *head)
{
    Phrase *p;
    SylText *txt;
    wchar_t *wcs;

    txt = CreateSylTextFromMBString("", False);
    for (p = head; p != NULL; p = p->next) {
	InsertSylTextIntoSylText0(txt, LengthOfSylText(txt), p->chosen);
    }
    wcs = CreateWCStringFromSylText0(txt);
    FreeSylText(txt);
    return (wcs);
}

SylText *
CreateSylTextFromPhrase(Phrase *head)
{
    Phrase *p;
    SylText *txt;

    txt = CreateSylTextFromMBString("", False);
    for (p = head; p != NULL; p = p->next) {
	InsertSylTextIntoSylText0(txt, LengthOfSylText(txt), p->chosen);
    }
    return (txt);
}

CARD32 *
CreateFeedbackFromPhrase(Phrase *head, Phrase *view)
{
    Phrase *p;
    CARD32 *feedback;
    int n, m, len;

    len = 0;
    for (p = head; p != NULL; p = p->next)
	len += LengthOfSylText(p->chosen);
    if ((feedback = (CARD32 *)malloc(sizeof(CARD32) * (len + 1))) == NULL)
	return (NULL);
    n = 0;
    for (p = head; p != NULL; p = p->next) {
	for (m = n + LengthOfSylText(p->chosen); n < m; ++n) {
	    feedback[n] = ((p == view) ? 1 : 0);
	}
    }    
    return (feedback);
}

int
CaretPositionOfPhrase(Phrase *head, Phrase *view)
{
    int len;
    Phrase *p;

    len = 0;
    for (p = head; p != view; p = p->next)
	len += LengthOfSylText(p->chosen);
#if 0
    len += LengthOfSylText(p->chosen);
#endif
    return (len);
}

int
LengthOfPhrase(Phrase *head)
{
    int len;
    Phrase *p;

    len = 0;
    for (p = head; p != NULL; p = p->next)
	len += LengthOfSylText(p->chosen);
    return (len);
}

int
BeginningOfPhrase(Phrase *head, Phrase *view)
{
    int len;
    Phrase *p;

    len = 0;
    for (p = head; p != view && p != NULL; p = p->next)
	len += LengthOfSylText(p->chosen);
    return (len);
}

static Phrase *
ChangeLengthOfPhrase(Phrase *view, SylText *txt)
{
    int length, offset, original;
    Phrase *prev, *next;

    length = view->length;
    offset = view->offset;
    original = view->original;
    prev = view->prev;
    FreePhrase(view);
    
    view = CreateSinglePhrase(txt, offset, offset + length);
    if (prev != NULL)
	prev->next = view;
    view->prev = prev;
    view->original = original;
    
    if ((offset += length) < LengthOfSylText(txt)) {
	next = CreatePhrase(txt, offset, LengthOfSylText(txt));
	view->next = next;
	next->prev = view;
    }
    else {
	view->next = NULL;
    }
    return (view);
}

Phrase *
ShortenPhrase(Phrase *view, SylText *txt)
{
    --(view->length);
    return (ChangeLengthOfPhrase(view, txt));
}

Phrase *
LengthenPhrase(Phrase *view, SylText *txt)
{
    ++(view->length);
    return (ChangeLengthOfPhrase(view, txt));
}

void
StudyPhrase(Phrase *head, SylText *txt)
{
    StudyPhraseWithEngine(head, txt);
}

Candidate *
HasCandidateOfPhrase(Phrase *p, SylText *t)
{
    Candidate *c;
    
    for (c = p->head; c != NULL && CompareSylText(c->applicant, t);
	 c = c->next)
	;
    return (c);
}

Candidate *
LookupCandidateOfPhrase(Phrase *p)
{
    return (HasCandidateOfPhrase(p, p->applicant));

}

void
AddCandidateToPhrase(Phrase *p, Candidate *c)
{
    if (p->head == NULL) {
	p->head = c;
	p->tail = c;
    }
    else {
	p->tail->next = c;
	c->prev = p->tail;
	p->tail = c;
    }
}
