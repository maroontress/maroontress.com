/*
	$Id: predict.h,v 1.2 2001/06/03 18:43:53 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

void LoadPredictionPreference(Display *, char *, char *);
void RecordCommittedPhrase(wchar_t *, wchar_t *);
Phrase * PredictedPhrase(SylText *);

void CommitPrediction(Connection *, InputContext *);
void CommitSecondaryPrediction(Connection *, InputContext *);
void ClearPrediction(Connection *, InputContext *);
void FocusInPrediction(Connection *, InputContext *);
void FocusOutPrediction(Connection *, InputContext *);
