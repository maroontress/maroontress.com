/*
	$Id: parse.h,v 1.1 2000/10/03 18:46:02 syl Exp $

	Copyright (C) 1999 Syllabub
	Maroontress Fast Software.
*/

#define PARSE_EMPTYLINES 0
#define PARSE_KEYWORD 1
#define PARSE_RESERVED 2
#define	PARSE_PUNCTUATOR 3
#define PARSE_NUMBER 4
#define PARSE_OPERATOR 5
#define PARSE_CPPCMD 6
#define PARSE_STRCONST 7
#define PARSE_CHARCONST 8
#define PARSE_COMMENT 9
#define PARSE_TOO_LONG_KEYWORD 10
#define PARSE_UNKNOWN_OPERATOR 11
#define PARSE_TOO_SHORT_MEMORY 12
#define PARSE_CANNOT_OPEN 13

extern int ParseErrorCode;
extern int ParseErrorLine;

typedef struct {
    int line;
    FILE *fp;
    char **reserved_keywords;
} Parse;

Parse * OpenParse(char *, char **);
void CloseParse(Parse *);
int GetChar(Parse *);
int UngetChar(int, Parse *);
int GetToken(Parse *, char *, void (*)(int));
#define ParseLine(p) ((p)->line)
