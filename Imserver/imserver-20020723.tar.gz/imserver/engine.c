/*
	$Id: engine.c,v 1.1 2001/05/23 14:00:44 syl Exp $

	Copyright (C) 2001 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "engine.h"

#if defined(USE_CANNA)
#include "canna.h"
#elif defined(USE_SJ3)
#include "sj3.h"
#endif

static Engine *concrete = NULL;

int
OpenEngine(char *server)
{
#if defined(USE_CANNA)
    concrete = CannaEngine;
#elif defined(USE_SJ3)
    concrete = Sj3Engine;
#endif
    return concrete->open(server);
}

void
CloseEngine(void)
{
    concrete->close();
    concrete = NULL;
}

static void
ChangePhrase(Phrase *p, SylText *txt)
{
    FreeSylText(p->chosen);
    p->chosen = DuplicateSylText(txt);
    FreeSylText(p->applicant);
    p->applicant = DuplicateSylText(txt);
}

void
ChangeNextRankOfPhraseWithEngine(Phrase *p, wchar_t *wcs)
{
    Candidate *ptr;
    SylText *txt;

    if (p->top == NULL) {
	concrete->get_candidate_list(p, wcs);
    }

    txt = p->applicant;
    for (ptr = p->top; ptr != NULL; ptr = ptr->next) {
	if (CompareSylText(ptr->applicant, p->applicant) == 0) {
	    if (ptr->next == NULL)
		txt = p->top->applicant;
	    else
		txt = ptr->next->applicant;
	    break;
	}
    }
    ChangePhrase(p, txt);
}

static Candidate *
LastCandidate(Candidate *p)
{
    Candidate *ptr;

    for (ptr = p; ptr->next != NULL; ptr = ptr->next)
	;
    return (ptr);
}

void
ChangePrevRankOfPhraseWithEngine(Phrase *p, wchar_t *wcs)
{
    Candidate *ptr;
    SylText *txt;

    if (p->top == NULL) {
	concrete->get_candidate_list(p, wcs);
    }

    if (CompareSylText(p->top->applicant, p->applicant) == 0) {
	ptr = LastCandidate(p->top);
	txt = ptr->applicant;
    }
    else {
	txt = p->applicant;
	for (ptr = p->top; ptr->next != NULL; ptr = ptr->next) {
	    if (CompareSylText(ptr->next->applicant, p->applicant) == 0) {
		txt = ptr->applicant;
		break;
	    }
	}
    }
    ChangePhrase(p, txt);
}

Phrase *
ConvertSinglePhraseWithEngine(wchar_t *wcs, int offset, int length)
{
    return (concrete->convert_single_phrase(wcs, offset, length));
}

Phrase *
ConvertWithEngine(wchar_t *wcs, int offset)
{
    return (concrete->convert(wcs, offset));
}

void
StudyPhraseWithEngine(Phrase *p, SylText *txt)
{
    concrete->study(p, txt);
}
