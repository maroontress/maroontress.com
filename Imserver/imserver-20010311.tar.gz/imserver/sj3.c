/*
	$Id: sj3.c,v 1.2 2001/02/04 17:33:58 syl Exp $

	Copyright (C) 1999, 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <sys/types.h>
#include <unistd.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sj3lib.h>

#include "Resource.h"
#include "Text.h"
#include "leakdetect.h"
#include "phrase.h"
#include "sj3.h"

int sj3_open(char *, char *);
int sj3_close(void);
int sj3_getkan_euc(unsigned char *, struct bunsetu[], unsigned char *, int);
int sj3_douoncnt_euc(unsigned char *);
int sj3_getdouon_euc(unsigned char *, struct douon[]);
int sj3_lockserv(void);
int sj3_unlockserv(void);
int sj3_gakusyuu(struct studyrec *);
int sj3_gakusyuu2_euc(unsigned char *, unsigned char *, struct studyrec *);

int
OpenConversionServerWithSj3(char *server)
{
    int status;
    struct passwd *pwd;

    if ((pwd = getpwuid(getuid())) == NULL) {
	fprintf(stderr, "Fatal: �桼��̾�������Ǥ��ޤ���\n");
	return (1);
    }
    if (server == NULL || (server = getenv("SJ3SERV")) == NULL)
	server = "localhost";
    if ((status = sj3_open(server, pwd->pw_name)) != 0) {
	if (status & SJ3_SERVER_DEAD)
	    fprintf(stderr, "Fatal: ��³������˥����Ф������󤷤ޤ�����\n");
	if (status & SJ3_CONNECT_ERROR)
	    fprintf(stderr, "Fatal: �����Ф��ʤ��������뤤����³�Ǥ��ޤ���\n");
	if (status & SJ3_ALREADY_CONNECTED)
	    fprintf(stderr, "Warning: ���Ǥ˥����Ф���³�ѤߤǤ���\n");
	if (status & SJ3_CANNOT_OPEN_MDICT)
	    fprintf(stderr, "Warning: �ᥤ�󼭽�򥪡��ץ�Ǥ��ޤ���\n");
	if (status & SJ3_CANNOT_OPEN_UDICT)
	    fprintf(stderr, "Warning: �桼������򥪡��ץ�Ǥ��ޤ���\n");
	if (status & SJ3_CANNOT_OPEN_UDICT)
	    fprintf(stderr, "Warning: �ؽ��ե�����򥪡��ץ�Ǥ��ޤ���\n");
	if (status & SJ3_CANNOT_MAKE_UDIR)
	    fprintf(stderr, "Warning: �Ŀͥե�����Τ���Υǥ��쥯�ȥ��"
		    "�����Ǥ��ޤ���");
	if (status & SJ3_CANNOT_MAKE_UDICT)
	    fprintf(stderr, "Warning: �桼�����������Ǥ��ޤ���\n");
	if (status & SJ3_CANNOT_MAKE_STUDY)
	    fprintf(stderr, "Warning: �ؽ��ե����������Ǥ��ޤ���\n");
	if (status & (SJ3_SERVER_DEAD | SJ3_CONNECT_ERROR))
	    return (1);
    }
    return (0);
}

void
CloseConversionServerWithSj3(void)
{
    int status;

    if ((status = sj3_close()) != 0) {
	fprintf(stderr, "Warning: sj3�����ФȤ���³���ڤ�Υ���Ȥ��ˡ�"
		"�ʤˤ����顼������ޤ�����\n");
    }
}

static int
IsUniqueCandidate(Candidate *top, SylText *txt)
{ 
    Candidate *p;

    for (p = top; p && CompareSylText(p->applicant, txt); p = p->next)
	;
    return (p == NULL);
}

static void
GetCandidateList(Phrase *p, wchar_t *wcs)
{
    struct douon phr[256];
    unsigned char mbs[1024];
    Candidate *ptr;
    const int len = 1024;
    int n, n_items;
    SylText *txt;

    p->top = CreateCandidate(p->applicant);
    ptr = p->top;
    wcstombs(mbs, wcs, len);
    for (n = 0, n_items = sj3_getdouon_euc(mbs, phr); n < n_items; ++n) {
	txt = CreateSylTextFromMBString(phr[n].ddata, False);
	if (IsUniqueCandidate(p->top, txt)) {
	    ptr->next = CreateCandidate(txt);
	    ptr = ptr->next;
	}
	FreeSylText(txt);
    }
}

void
ChangeNextRankOfPhraseWithSJ3(Phrase *p, wchar_t *wcs)
{
    Candidate *ptr;
    SylText *txt;

    if (p->top == NULL) {
	GetCandidateList(p, wcs);
    }

    txt = p->applicant;
    for (ptr = p->top; ptr != NULL; ptr = ptr->next) {
	if (CompareSylText(ptr->applicant, p->applicant) == 0) {
	    if (ptr->next == NULL)
		txt = p->top->applicant;
	    else
		txt = ptr->next->applicant;
	    break;
	}
    }

    wcs = CreateWCStringFromSylText(txt, 0, LengthOfSylText(txt));
    FreeSylText(p->chosen);
    p->chosen = CreateSylTextFromWCString(wcs, False);
    FreeSylText(p->applicant);
    p->applicant = CreateSylTextFromWCString(wcs, False);
    free(wcs);
}

static Candidate *
LastCandidate(Candidate *p)
{
    Candidate *ptr;

    for (ptr = p; ptr->next != NULL; ptr = ptr->next)
	;
    return (ptr);
}

void
ChangePrevRankOfPhraseWithSJ3(Phrase *p, wchar_t *wcs)
{
    Candidate *ptr;
    SylText *txt;

    if (p->top == NULL) {
	GetCandidateList(p, wcs);
    }

    if (CompareSylText(p->top->applicant, p->applicant) == 0) {
	ptr = LastCandidate(p->top);
	txt = ptr->applicant;
    }
    else {
	txt = p->applicant;
	for (ptr = p->top; ptr->next != NULL; ptr = ptr->next) {
	    if (CompareSylText(ptr->next->applicant, p->applicant) == 0) {
		txt = ptr->applicant;
		break;
	    }
	}
    }

    wcs = CreateWCStringFromSylText(txt, 0, LengthOfSylText(txt));
    FreeSylText(p->chosen);
    p->chosen = CreateSylTextFromWCString(wcs, False);
    FreeSylText(p->applicant);
    p->applicant = CreateSylTextFromWCString(wcs, False);
    free(wcs);
}

Phrase *
ConvertSinglePhraseWithSJ3(wchar_t *wcs, int offset, int length)
{
    unsigned char mbs[1024], *raw;
    struct douon phr[256];
    const int len = 1024;
    int status;
    Phrase *p;

    wcstombs(mbs, wcs, len);
    raw = (((status = sj3_getdouon_euc(mbs, phr)) > 0) ? phr[0].ddata : mbs);

    p = (Phrase *)ldmalloc(sizeof(Phrase));
    p->next = NULL;
    p->prev = NULL;
    p->offset = offset;
    p->length = length;
    p->original = length;
    p->chosen = CreateSylTextFromMBString(raw, False);
    p->applicant = CreateSylTextFromMBString(raw, False);
    p->top = NULL;
    /* printf("%s %d %d\n", raw, p->offset, p->length); */
    return (p);
}

Phrase *
ConvertWithSJ3(wchar_t *wcs, int offset)
{
    unsigned char mbs[1024], buf[1024], ext[1024];
    struct bunsetu bun[1024];
    const int len = 1024;
    int n, status, length;
    Phrase *p, *head = NULL, *tail = NULL;
    SylText *txt;

    wcstombs(mbs, wcs, len);
    /* printf("before: %s\n", mbs); */
    if ((status = sj3_getkan_euc(mbs, bun, buf, len)) <= 0)
	return (NULL);

    for (n = 0; n < status && (p = (Phrase *)ldmalloc(sizeof(Phrase))) != NULL;
	 (offset += p->length), ++n) {
	strncpy(ext, bun[n].srcstr, bun[n].srclen);
	ext[bun[n].srclen] = 0;
	txt = CreateSylTextFromMBString(ext, False);
	length = LengthOfSylText(txt);
	FreeSylText(txt);

	strncpy(ext, bun[n].deststr, bun[n].destlen);
	ext[bun[n].destlen] = 0;

	p->next = NULL;
	p->prev = tail;
	p->offset = offset;
	p->length = length;
	p->original = length;
	p->chosen = CreateSylTextFromMBString(ext, False);
	p->applicant = CreateSylTextFromMBString(ext, False);
	p->top = NULL;
        /* printf("after: %s %d %d\n", ext, p->offset, p->length); */

	if (head == NULL)
	    head = p;
	else
	    tail->next = p;
	tail = p;
    }
    return (head);
}

void
StudyPhraseWithSJ3(Phrase *p, wchar_t *wcs)
{
    unsigned char mbs[1024], *app;
    struct douon phr[256];
    const int len = 1024;
    int n, n_items;

    if (sj3_lockserv() != 0)
	return;
    wcstombs(mbs, wcs, len);
    app = CreateMBStringFromSylText(p->applicant,
				    0, LengthOfSylText(p->applicant));
    for (n = 0, n_items = sj3_getdouon_euc(mbs, phr); n < n_items; ++n) {
	if (strcmp(phr[n].ddata, app) == 0) {
	    sj3_gakusyuu(&(phr[n].dcid));
	    break;
	}
    }
    free(app);
    sj3_unlockserv();
}

void
StudyPairOfPhraseWithSJ3(Phrase *p, wchar_t *wcs1, wchar_t *wcs2)
{
    unsigned char mbs1[1024], mbs2[1024], *app;
    struct douon phr[256];
    const int len = 1024;
    int n, n_items;

    if (sj3_lockserv() != 0)
	return;
    if (wcs2 == NULL || p->next == NULL) {
	wcstombs(mbs1, wcs1, len);
	sj3_gakusyuu2_euc(mbs1, "", NULL);
    }
    else {
	wcstombs(mbs1, wcs1, len);
	wcstombs(mbs2, wcs2, len);
	app = CreateMBStringFromSylText(p->next->applicant, 0,
					LengthOfSylText(p->next->applicant));
	for (n = 0, n_items = sj3_getdouon_euc(mbs2, phr); n < n_items; ++n) {
	    if (strcmp(phr[n].ddata, app) == 0) {
		sj3_gakusyuu2_euc(mbs1, mbs2, &(phr[n].dcid));
		break;
	    }
	}
	if (n == n_items) {
	    sj3_gakusyuu2_euc(mbs1, "", NULL);
	}
	free(app);
    }
    sj3_unlockserv();
}
