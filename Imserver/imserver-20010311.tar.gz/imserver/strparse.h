/*
	$Id: strparse.h,v 1.1 2000/10/03 18:45:29 syl Exp $

	Copyright (C) 1997, 1998, 1999 Syllabub
	Maroontress Fast Software.
*/

#define STR_PARSE_EMPTYLINES 0
#define STR_PARSE_KEYWORD 1
#define STR_PARSE_RESERVED 2
#define	STR_PARSE_PUNCTUATOR 3
#define STR_PARSE_NUMBER 4
#define STR_PARSE_OPERATOR 5
#define STR_PARSE_CPPCMD 6
#define STR_PARSE_STRCONST 7
#define STR_PARSE_CHARCONST 8
#define STR_PARSE_COMMENT 9
#define STR_PARSE_TOO_LONG_KEYWORD 10
#define STR_PARSE_UNKNOWN_OPERATOR 11
#define STR_PARSE_TOO_SHORT_MEMORY 12
#define STR_PARSE_CANNOT_OPEN 13

extern int StrParseErrorCode;
extern int StrParseErrorLine;

typedef struct {
    int line;
    char *sp;
    int max_keyword_len;
    char **reserved;
} StrParse;

StrParse * OpenStrParse(char *, int, char **);
void CloseStrParse(StrParse *);
int GetChar(StrParse *);
void UngetChar(int, StrParse *);
int GetToken(StrParse *, char *, void (*)(int));
#define StrParseLine(p) ((p)->line)
