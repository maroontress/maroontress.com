/*
	$Id: overthespot.c,v 1.5 2001/03/10 19:35:42 syl Exp $

	Copyright (C) 2000 Syllabub
	Maroontress Fast Software.
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xproto.h>
#include <X11/Xresource.h>
#include <X11/Xatom.h>
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>

#include "Resource.h"
#include "Text.h"
#include "phrase.h"
#include "connection.h"
#include "leakdetect.h"
#include "ontheroot.h"

static void
SetPreeditString(Display *disp, Window w, wchar_t *wcs)
{
    XICCEncodingStyle style = XCompoundTextStyle;
    XTextProperty t;
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_STRING", False);

    if (w == None)
	return;
    if (wcs == NULL) {
	XDeleteProperty(disp, w, atom);
	return;
    }
    if (XwcTextListToTextProperty(disp, &wcs, 1, style, &t) < 0) {
	return;
    }
    XSetTextProperty(disp, w, &t, atom);
    XFree(t.value);
}

static void
SetPreeditCaret(Display *disp, Window w, int caret)
{
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_CARET", False);

    if (w == None)
	return;
    XChangeProperty(disp, w, atom, XA_INTEGER, 32, PropModeReplace,
		    (unsigned char *)&caret, 1);
}

static void
SetPreeditFeedback(Display *disp, Window w, CARD32 *feedback, int len)
{
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_FEEDBACK", False);

    if (w == None)
	return;
    if (feedback == NULL) {
	XDeleteProperty(disp, w, atom);
	return;
    }
    XChangeProperty(disp, w, atom, XA_INTEGER, 32, PropModeReplace,
		    (unsigned char *)feedback, len);
}

static void
SetSpotLocation(Display *disp, Window w, Window norm, XPoint *spot)
{
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_SPOT_LOCATION", False);
    int x, y;
    XPoint p;

    if (w == None || norm == None)
	return;
    if (spot == NULL) {
	XDeleteProperty(disp, w, atom);
	return;
    }
    XTranslateCoordinates(disp, norm, DefaultRootWindow(disp),
			  spot->x, spot->y, &x, &y, &norm);
    p.x = (short)x;
    p.y = (short)y;
    XChangeProperty(disp, w, atom, XA_POINT, 16, PropModeReplace,
		    (unsigned char *)&p, 2);
}

static void
SetFontset(Display *disp, Window w, char *name)
{
    XTextProperty t;
    Atom atom = XInternAtom(disp, "XIM_PREEDIT_FONTSET", False);

    if (w == None)
	return;
    if (name == NULL) {
	XDeleteProperty(disp, w, atom);
	return;
    }
    if (XStringListToTextProperty(&name, 1, &t) < 0) {
	return;
    }
    XSetTextProperty(disp, w, &t, atom);
    XFree(t.value);
}

static void
Clear(Connection *con, InputContext *ic)
{ 
    SetPreeditString(con->disp, ic->preedit_window, NULL);
#ifdef DEBUG
    printf("|\n");
#endif
}

static void
ChangePhrase(Connection *con, InputContext *ic, int chg_first __unused,
	     int chg_length __unused)
{
    int n, len, size;
    wchar_t *wcs;
    CARD32 *feedback;
#ifdef DEBUG
    char mb[MB_LEN_MAX + 1];
#endif

    wcs = CreateWCStringFromPhrase(ic->head);
    len = LengthOfPhrase(ic->head);
    feedback = CreateFeedbackFromPhrase(ic->head, ic->view); /* XXX */

    SetPreeditString(con->disp, ic->preedit_window, wcs);
    SetPreeditCaret(con->disp, ic->preedit_window, ic->caret);
    SetPreeditFeedback(con->disp, ic->preedit_window, feedback, len);
#ifdef DEBUG
    for (n = 0; n < len; ++n) {
	if ((size = wctomb(mb, wcs[n])) < 0)
	    strcpy(mb, "?");
	else
	    mb[size] = 0;
	printf("%s%s", feedback[n] ? "\033[7m" : "\033[m", mb);
    }
    printf("\033[m\n");
#endif
    
    free(feedback); /* CreateFeedbackFromPhrase() */
    free(wcs); /* CreateWCStringFromPhrase() */
}

static void
ResizePhrase(Connection *con, InputContext *ic, int chg_first, int chg_length)
{
    ChangePhrase(con, ic, chg_first, chg_length);
}

static void
Cancel(Connection *con, InputContext *ic, int chg_first __unused,
       int chg_length __unused)
{
    int n, len;
    wchar_t *wcs;
    CARD32 *feedback;
#ifdef DEBUG
    char *mbs;
#endif

    len = LengthOfSylText(ic->preedit);
    wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);
    for (n = 0; n < len; ++n)
	feedback[n] = 2;

    SetPreeditString(con->disp, ic->preedit_window, wcs);
    SetPreeditCaret(con->disp, ic->preedit_window, ic->caret);
    SetPreeditFeedback(con->disp, ic->preedit_window, feedback, len);
    free(wcs); /* CreateWCStringFromSylText() */
    ldfree(feedback); /* ldmalloc() */

#ifdef DEBUG
    mbs = CreateMBStringFromSylText(ic->preedit, 0, len);
    printf("\033[4m%s\033[m|\n", mbs);
    free(mbs); /* CreateMBStringFromSylText() */
#endif
}

static void
SelectPhrase(Connection *con, InputContext *ic)
{
    ChangePhrase(con, ic, 0, 0);
}

static void
Replace(Connection *con, InputContext *ic, int chg_first __unused,
	int chg_length __unused)
{
    int n, len, size;
    wchar_t *wcs;
    CARD32 *feedback;
#ifdef DEBUG
    char mb[MB_LEN_MAX + 1];
#endif

    len = LengthOfSylText(ic->preedit);
    wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
    feedback = (CARD32 *)ldmalloc(sizeof(CARD32) * len);
    for (n = 0; n < len; ++n)
	feedback[n] = 2;

    SetPreeditString(con->disp, ic->preedit_window, wcs);
    SetPreeditCaret(con->disp, ic->preedit_window, ic->caret);
    SetPreeditFeedback(con->disp, ic->preedit_window, feedback, len);

#ifdef DEBUG
    printf("\033[4m");
    for (n = 0; n < ic->caret; ++n) {
	if ((size = wctomb(mb, wcs[n])) < 0)
	    strcpy(mb, "?");
	else
	    mb[size] = 0;
	printf("%s", mb);
    }
    printf("\033[m" "|" "\033[4m");
    for (; n < len; ++n) {
	if ((size = wctomb(mb, wcs[n])) < 0)
	    strcpy(mb, "?");
	else
	    mb[size] = 0;
	printf("%s", mb);
    }
    printf("\033[m\n");
#endif
    
    free(wcs); /* CreateWCStringFromPhrase() */
    ldfree(feedback); /* ldmalloc() */
}

static void
Convert(Connection *con, InputContext *ic)
{
    ChangePhrase(con, ic, 0, 0);
}

static void
DeleteChar(Connection *con, InputContext *ic)
{
    Replace(con, ic, 0, 0);
}

static void
MoveCaret(Connection *con, InputContext *ic)
{
    Replace(con, ic, 0, 0);
}

static void
HoldFocus(Connection *con, InputContext *ic)
{
    int n, len;
    wchar_t *wcs;
    CARD32 *feedback;
    Window norm = (ic->focus_window) ? ic->focus_window : ic->client_window;

    if (ic->head != NULL) {
	wcs = CreateWCStringFromPhrase(ic->head);
	len = LengthOfPhrase(ic->head);
	feedback = CreateFeedbackFromPhrase(ic->head, ic->view); /* XXX */
    }
    else {
	len = LengthOfSylText(ic->preedit);
	wcs = CreateWCStringFromSylText(ic->preedit, 0, len);
	feedback = (CARD32 *)malloc(sizeof(CARD32) * len);
	for (n = 0; n < len; ++n)
	    feedback[n] = 2;
    }

    XConvertSelection(con->disp,  
		      XInternAtom(con->disp, "XIM_RECEIVER", False),
		      XInternAtom(con->disp, "XIM_PREEDIT_WINDOW", False),
		      None, ic->preedit_window, CurrentTime);
    SetPreeditString(con->disp, ic->preedit_window, wcs);
    SetSpotLocation(con->disp, ic->preedit_window,
		    norm, &ic->preedit_spot_location);
    SetPreeditCaret(con->disp, ic->preedit_window, ic->caret);
    SetPreeditFeedback(con->disp, ic->preedit_window, feedback, len);
    free(wcs); /* CreateWCStringFromPhrase() or CreateWCStringFromSylText() */
    free(feedback); /* CreateFeedbackFromPhrase() or malloc() */

    if (ic->candidate_window != None
	&& ic->head != NULL
	&& ic->view->top != NULL
	&& CompareSylText(ic->view->chosen, ic->view->applicant) == 0) {
	XMapRaised(con->disp, ic->candidate_window);
    }
}

static void
LostFocus(Connection *con, InputContext *ic)
{
    SetPreeditString(con->disp, ic->preedit_window, NULL);
    if (ic->candidate_window != None)
	XUnmapWindow(con->disp, ic->candidate_window);
}

static void
Destroy(Connection *con, InputContext *ic)
{
    if (ic->candidate_window != None) {
	XDeleteContext(con->disp, ic->candidate_window, con->candidate);
	XDestroyWindow(con->disp, ic->candidate_window);
	ic->candidate_window = None;
    }
}

static ICPreeditDrawMethods methods = {
    Clear,
    ChangePhrase,
    ResizePhrase,
    Cancel,
    SelectPhrase,
    Replace,
    Convert,
    DeleteChar,
    MoveCaret,
    HoldFocus,
    LostFocus,
    Destroy};

ICPreeditDrawMethods *ICPreeditDrawOverTheSpot = &methods;

void
UpdateSpotLocation(Connection *con, InputContext *ic)
{
    Window norm = (ic->focus_window) ? ic->focus_window : ic->client_window;

    SetSpotLocation(con->disp, ic->preedit_window,
		    norm, &ic->preedit_spot_location);
}

void
UpdateFontset(Connection *con, InputContext *ic)
{
    SetFontset(con->disp, ic->preedit_window, ic->preedit_fontset_name);
}
