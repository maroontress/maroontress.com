#include        <X11/Xlib.h>
#include        <X11/Xutil.h>
#include        <X11/Xatom.h>
#include        <stdio.h>
#include        <stdlib.h>

#ifndef max
#define max(a, b) (((a) < (b)) ? (b) : (a))
#endif

typedef unsigned long Pixel;

static Display *disp;
static int screen = 1;
static Window window;
static GC gc;
static Pixel fgcolor, bgcolor;
static int MainPower = 1;
static Atom WM_Sn, VERSION;
static Atom WM_PROTOCOLS, WM_REQUEST[2], WM_DELETE_WINDOW, WM_TAKE_FOCUS;

void
SetProperties(Display *disp, Window w, char *title, char *name, char *class,
              int ac, char **av, int maxw, int maxh, int minw, int minh,
              int incw, int inch)
{
    XWindowAttributes attrs;
    XSizeHints xsize;
    XClassHint xclass;
    XWMHints xwm;

    XGetWindowAttributes(disp, w, &attrs);
    xsize.width = attrs.width;
    xsize.height = attrs.height;
    xsize.width_inc = incw;
    xsize.height_inc = inch;
    xsize.flags = PSize | PResizeInc;
    if (minw > 0 && minh > 0) {
        xsize.min_width = minw;
        xsize.min_height = minh; 
        xsize.flags |=  PMinSize;
    }
    if (maxw > 0 && maxh > 0) {
        xsize.max_width = max(maxw, minw);
        xsize.max_height = max(maxh, minh);
        xsize.flags |=  PMaxSize;
    }
    xwm.flags = InputHint /* | XUrgencyHint */;
    xwm.input = True;
    xclass.res_name = name;
    xclass.res_class = class;
    XmbSetWMProperties(disp, w, title, title, av, ac, &xsize, &xwm, &xclass);

    WM_PROTOCOLS = XInternAtom(disp, "WM_PROTOCOLS", False);
    WM_TAKE_FOCUS = XInternAtom(disp, "WM_TAKE_FOCUS", False);
    WM_DELETE_WINDOW = XInternAtom(disp, "WM_DELETE_WINDOW", False);
    WM_REQUEST[0] = WM_TAKE_FOCUS;
    WM_REQUEST[1] = WM_DELETE_WINDOW;
    XSetWMProtocols(disp, w, WM_REQUEST, 2);
}

static int
WindowMain(char **av, XEvent *ev)
{
    switch (ev->type) {
    case MappingNotify:
	XRefreshKeyboardMapping(&(ev->xmapping));
	break;
    case ClientMessage:
	if (ev->xclient.message_type != WM_PROTOCOLS)
	    break;
	if (ev->xclient.data.l[0] == (signed)WM_DELETE_WINDOW) {
	    if (ev->xclient.data.l[1] == CurrentTime) {
		printf("%s: This window manager uses CurrentTime"
		       " for the data[1] field "
		       "in the WM_DELETE_WINDOW messages.\n", av[0]);
	    }
	    else {
		printf("%s: WM_DELETE_WINDOW messages"
		       " sent by this winndow manager complies"
		       " ICCCM version 2.0 or later.\n", av[0]);
	    }
	    MainPower = 0;
	}
	else if (ev->xclient.data.l[0] == (signed)WM_TAKE_FOCUS) {
	    if (ev->xclient.data.l[1] == CurrentTime) {
		printf("%s: This window manager uses CurrentTime"
		       " for the data[1] field "
		       "in the WM_TAKE_FOCUS messages.\n", av[0]);
	    }
	    else {
		printf("%s: WM_TAKE_FOCUS messages"
		       " sent by this winndow manager complies"
		       " ICCCM version 2.0 or later.\n", av[0]);
	    }
	}
	break;
    }
    return (0);
}

int
main(int ac, char **av)
{
    char buf[256];
    XEvent ev;

    if ((disp = XOpenDisplay("")) == NULL) {
        fprintf(stderr, "%s: Cannot open display.\n", av[0]);
        exit(1);
    }
    screen = DefaultScreen(disp);
    bgcolor = WhitePixel(disp, DefaultScreen(disp));
    fgcolor = BlackPixel(disp, DefaultScreen(disp));
    window = XCreateSimpleWindow(disp, DefaultRootWindow(disp),
	0, 0, 320, 160, 1, fgcolor, bgcolor);
    SetProperties(disp, window, "xcompliance", "xcompliance",
		  "XCompliance", ac, av, 0, 0, 0, 0, 0, 0);
    gc = XCreateGC(disp, window, 0, 0);
    XSetFunction(disp, gc, GXcopy);
    XSelectInput(disp, window, ButtonPressMask);
    XMapRaised(disp, window);

    sprintf(buf, "WM_S%d", screen);
    if ((WM_Sn = XInternAtom(disp, buf, True)) == None)
	printf("%s: Atom `%s' not found.\n", av[0], buf);
    if ((VERSION = XInternAtom(disp, "VERSION", True)) == None)
	printf("%s: Atom `VERSION' not found.\n", av[0]);

    if (WM_Sn == None || XGetSelectionOwner(disp, WM_Sn) == None) {
	printf("%s: This window manager does not comply with"
	       " ICCCM version 2.0 or later.\n", av[0]);
    }
    else {
	printf("%s: This window manager complies with"
	       " ICCCM version 2.0 or later.\n", av[0]);
    }

    while (MainPower) {
        XNextEvent(disp, &ev);
	WindowMain(av, &ev);
    }
    XDestroyWindow(disp, window);
    XCloseDisplay(disp);
    exit(0);
}
